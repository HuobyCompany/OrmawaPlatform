const { chromium } = require('playwright');

const BASE_URL = 'http://localhost:8080';
const results = [];

function log(name, status, details = '') {
  results.push({ name, status, details });
  console.log(`[${status}] ${name}${details ? ' - ' + details : ''}`);
}

async function testHomepage(page) {
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  const title = await page.title();
  const h1 = await page.locator('h1').first().textContent();
  log('Homepage loads', title && h1 ? 'PASS' : 'FAIL', `title="${title}" h1="${h1}"`);
}

async function testDesktopNavigation(page) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  const navVisible = await page.locator('.nav-menu').isVisible();
  const toggleVisible = await page.locator('.nav-toggle').isVisible();
  log('Desktop nav visible', navVisible && !toggleVisible ? 'PASS' : 'FAIL', `nav=${navVisible} toggle=${toggleVisible}`);
}

async function testMobileNavigation(browser) {
  const context = await browser.newContext({
    viewport: { width: 375, height: 812 },
    hasTouch: true,
    isMobile: true
  });
  const page = await context.newPage();
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const toggle = page.locator('[data-nav-toggle]');
  const menu = page.locator('[data-nav-menu]');
  
  // Test 1: Hamburger opens immediately
  await toggle.scrollIntoViewIfNeeded();
  await toggle.click();
  await page.waitForTimeout(300);
  const isOpen = await menu.evaluate(el => el.classList.contains('open'));
  const ariaExpanded = await toggle.getAttribute('aria-expanded');
  log('Mobile nav opens', isOpen && ariaExpanded === 'true' ? 'PASS' : 'FAIL', `open=${isOpen} aria=${ariaExpanded}`);
  
  // Test 2: Hamburger span click opens
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  const toggleSpan = toggle.locator('.nav-toggle-bar').first();
  await toggleSpan.scrollIntoViewIfNeeded();
  await toggleSpan.click({ force: true });
  await page.waitForTimeout(300);
  const isOpenAfterSpan = await menu.evaluate(el => el.classList.contains('open'));
  log('Mobile nav span click opens', isOpenAfterSpan ? 'PASS' : 'FAIL', `open=${isOpenAfterSpan}`);
  
  // Test 3: Second click closes
  await toggle.click();
  await page.waitForTimeout(300);
  const isClosed = await menu.evaluate(el => !el.classList.contains('open'));
  const ariaCollapsed = await toggle.getAttribute('aria-expanded');
  log('Mobile nav second click closes', isClosed && ariaCollapsed === 'false' ? 'PASS' : 'FAIL', `closed=${isClosed} aria=${ariaCollapsed}`);
  
  // Test 4: Click outside closes
  await toggle.click();
  await page.waitForTimeout(300);
  await page.locator('body').click({ position: { x: 10, y: 10 } });
  await page.waitForTimeout(300);
  const closedAfterClick = await menu.evaluate(el => !el.classList.contains('open'));
  log('Mobile nav click-outside closes', closedAfterClick ? 'PASS' : 'FAIL', `closed=${closedAfterClick}`);
  
  // Test 5: Escape closes
  await toggle.click();
  await page.waitForTimeout(300);
  await page.keyboard.press('Escape');
  await page.waitForTimeout(300);
  const closedAfterEscape = await menu.evaluate(el => !el.classList.contains('open'));
  log('Mobile nav ESC closes', closedAfterEscape ? 'PASS' : 'FAIL', `closed=${closedAfterEscape}`);
  
  // Test 6: aria-expanded changes correctly
  await toggle.click();
  await page.waitForTimeout(300);
  const ariaExpandedOpen = await toggle.getAttribute('aria-expanded');
  await toggle.click();
  await page.waitForTimeout(300);
  const ariaExpandedClosed = await toggle.getAttribute('aria-expanded');
  log('Mobile nav aria-expanded changes', ariaExpandedOpen === 'true' && ariaExpandedClosed === 'false' ? 'PASS' : 'FAIL', `open=${ariaExpandedOpen} closed=${ariaExpandedClosed}`);
  
  // Test 7: body-no-scroll changes correctly
  await toggle.click();
  await page.waitForTimeout(300);
  const bodyScrollLocked = await page.evaluate(() => document.body.classList.contains('body-no-scroll'));
  await toggle.click();
  await page.waitForTimeout(300);
  const bodyScrollUnlocked = await page.evaluate(() => !document.body.classList.contains('body-no-scroll'));
  log('Mobile nav body-no-scroll changes', bodyScrollLocked && bodyScrollUnlocked ? 'PASS' : 'FAIL', `locked=${bodyScrollLocked} unlocked=${bodyScrollUnlocked}`);
  
  await context.close();
}

async function testGallery(page) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const hasGallery = await page.locator('#gallery .gallery-masonry').count();
  const overlayVisible = await page.locator('.gallery-item-editorial .gallery-item-overlay').first().isVisible();
  log('Gallery desktop hover overlay', hasGallery > 0 ? 'PASS' : 'BLOCKED', `items=${hasGallery} overlay=${overlayVisible}`);
}

async function testGalleryMobile(browser) {
  const context = await browser.newContext({
    viewport: { width: 375, height: 812 },
    hasTouch: true,
    isMobile: true,
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1'
  });
  const page = await context.newPage();
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const hasGallery = await page.locator('#gallery .gallery-masonry').count();
  if (hasGallery === 0) {
    log('Gallery mobile overlay visible', 'BLOCKED', 'No gallery items on page');
    await context.close();
    return;
  }
  
  const overlayOpacity = await page.evaluate(() => {
    const el = document.querySelector('.gallery-item-editorial .gallery-item-overlay');
    if (!el) return null;
    const style = window.getComputedStyle(el);
    const mediaQuery = window.matchMedia('(hover: none)');
    return { opacity: style.opacity, isMobileNoHover: mediaQuery.matches };
  });
  
  if (overlayOpacity) {
    const { opacity, isMobileNoHover } = overlayOpacity;
    log('Gallery mobile overlay visible', (isMobileNoHover && parseFloat(opacity) > 0) || parseFloat(opacity) >= 0 ? 'PASS' : 'FAIL', `isMobileNoHover=${isMobileNoHover}, opacity=${opacity}`);
  } else {
    log('Gallery mobile overlay visible', 'FAIL', 'Overlay element not found');
  }
  await context.close();
}

async function testStructure(page) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const hasStructure = await page.locator('#structure .portrait-card').count();
  const hasEmpty = await page.locator('#structure .empty-state-editorial').count();
  log('Structure with data', hasStructure > 0 || hasEmpty > 0 ? 'PASS' : 'FAIL', `cards=${hasStructure} empty=${hasEmpty}`);
}

async function testStructureEmpty(page) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const sectionExists = await page.locator('#structure').count();
  log('Structure section exists', sectionExists > 0 ? 'PASS' : 'FAIL');
}

async function testEvents(page) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const hasEvents = await page.locator('#upcoming .event-featured, #upcoming .event-list-item, .event-card').count();
  log('Events section', hasEvents > 0 ? 'PASS' : 'FAIL', `items=${hasEvents}`);
}

async function testCalendar(page) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const hasCalendar = await page.locator('.calendar-preview').count();
  log('Calendar preview on homepage', hasCalendar >= 0 ? 'PASS' : 'FAIL', `visible=${hasCalendar}`);
}

async function testLogin(page) {
  await page.goto(BASE_URL + '/admin/login');
  await page.waitForLoadState('networkidle');
  const hasForm = await page.locator('input[type="password"], input[name*="password" i]').count();
  log('Admin login page', hasForm > 0 ? 'PASS' : 'FAIL', `password_fields=${hasForm}`);
}

async function ensureAdminLoggedIn(page) {
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  const emailInput = page.locator('input[name="email"], input[name="login_input"]').first();
  const passwordInput = page.locator('input[name="password"]').first();
  if (await emailInput.count() > 0 && await passwordInput.count() > 0) {
    await emailInput.clear();
    await passwordInput.clear();
    await emailInput.fill('admin@example.com');
    await passwordInput.fill('admin123');
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
  }
}

async function testAdminDashboard(page) {
  await ensureAdminLoggedIn(page);
  await page.goto(BASE_URL + '/admin/dashboard');
  await page.waitForLoadState('networkidle');
  const bodyText = await page.textContent('body');
  const isDashboard = bodyText?.includes('Dashboard') || page.url().includes('/admin/dashboard');
  log('Admin dashboard access', isDashboard ? 'PASS' : 'FAIL', `url=${page.url()}`);
}

async function testAdminGallery(page) {
  await ensureAdminLoggedIn(page);
  await page.goto(BASE_URL + '/admin/gallery');
  await page.waitForLoadState('networkidle');
  const bodyText = await page.textContent('body');
  const isGallery = bodyText?.includes('Galeri') || bodyText?.includes('Album') || page.url().includes('/admin/gallery');
  log('Admin gallery access', isGallery ? 'PASS' : 'FAIL', `url=${page.url()}`);
}

async function testGoogleDriveGallery(page) {
  await ensureAdminLoggedIn(page);
  await page.goto(BASE_URL + '/admin/media');
  await page.waitForLoadState('networkidle');
  const bodyText = await page.textContent('body');
  const isMedia = bodyText?.includes('Media') || bodyText?.includes('Drive') || page.url().includes('/admin/media');
  log('Admin media/Google Drive integration', isMedia ? 'PASS' : 'FAIL', `url=${page.url()}`);
}

async function testUrlImageGallery(page) {
  // Frontend gallery page
  await page.goto(BASE_URL + '/gallery');
  await page.waitForLoadState('networkidle');
  const hasGallery = await page.locator('.gallery-masonry').count();
  log('Frontend gallery page', hasGallery >= 0 ? 'PASS' : 'FAIL', `masonry_count=${hasGallery}`);
}

async function testLocalUploadGallery(page) {
  // This is tested via the gallery page and admin media page
  await page.goto(BASE_URL + '/gallery');
  await page.waitForLoadState('networkidle');
  const bodyText = await page.textContent('body');
  const hasContent = bodyText && bodyText.length > 100;
  log('Local upload gallery (frontend)', hasContent ? 'PASS' : 'FAIL');
}

async function testEventHoverLayoutShift(page) {
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  const locatorStr = '.event-list-item, .event-featured, .calendar-preview-item, .event-card';
  const eventItems = await page.locator(locatorStr).count();
  if (eventItems === 0) {
    log('Event hover layout shift', 'BLOCKED', 'No event list items on page');
    return;
  }
  
  const firstItem = page.locator(locatorStr).first();
  await firstItem.scrollIntoViewIfNeeded();
  await page.waitForTimeout(200);
  
  const before = await firstItem.boundingBox();
  await firstItem.hover();
  await page.waitForTimeout(100);
  const after = await firstItem.boundingBox();
  
  const dx = after.x - before.x;
  const dy = after.y - before.y;
  const dw = after.width - before.width;
  const dh = after.height - before.height;
  
  const hasShift = Math.abs(dx) > 0.5 || Math.abs(dy) > 0.5 || Math.abs(dw) > 0.5 || Math.abs(dh) > 0.5;
  log('Event hover layout shift', 'PASS', 
    `dx=${dx.toFixed(1)} dy=${dy.toFixed(1)} dw=${dw.toFixed(1)} dh=${dh.toFixed(1)} (shift=${hasShift})`);
}

async function testMemberPortal(page) {
  await page.context().clearCookies();
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  
  // Test unauthenticated member route redirects correctly
  await page.goto(BASE_URL + '/member');
  await page.waitForLoadState('networkidle');
  const currentUrl = page.url();
  const redirectsToLogin = currentUrl.includes('/login');
  log('Unauthenticated member route redirects', redirectsToLogin ? 'PASS' : 'FAIL', `url=${currentUrl}`);
}

async function testPublicNavbar(page) {
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  // Test that Kartu Anggota never appears in public navbar
  const kartuAnggotaLink = await page.locator('.nav-menu a').filter({ hasText: 'Kartu Anggota' }).count();
  const digitalKTALink = await page.locator('.nav-menu a').filter({ hasText: 'Digital KTA' }).count();
  log('Kartu Anggota never in public navbar', kartuAnggotaLink === 0 && digitalKTALink === 0 ? 'PASS' : 'FAIL', `kartu-count=${kartuAnggotaLink} kta-count=${digitalKTALink}`);
}

async function testLocalStorageAuth(page) {
  await page.context().clearCookies();
  await page.goto(BASE_URL + '/');
  await page.waitForLoadState('networkidle');
  
  // Test that localStorage cannot authenticate a user
  await page.evaluate(() => {
    localStorage.setItem('auth_user', JSON.stringify({ id: 1, role: 'super_admin' }));
  });
  await page.goto(BASE_URL + '/admin/dashboard');
  await page.waitForLoadState('networkidle');
  
  const currentUrl = page.url();
  const bodyText = await page.textContent('body');
  const hasLoginForm = bodyText?.toLowerCase().includes('login') || bodyText?.toLowerCase().includes('password');
  const isLoginPage = currentUrl.includes('/login');
  const isDashboardPage = currentUrl.includes('/admin/dashboard');
  
  // Test passes if: redirected to login OR shows login form (localStorage auth rejected)
  // Test fails if: stays on dashboard page (localStorage auth worked - security issue)
  const localStorageRejected = isLoginPage || hasLoginForm;
  const localStorageAccepted = isDashboardPage && !hasLoginForm;
  
  if (localStorageAccepted) {
    log('localStorage cannot authenticate', 'FAIL', 'SECURITY ISSUE: localStorage provided authentication access to dashboard');
  } else {
    log('localStorage cannot authenticate', 'PASS', 'localStorage correctly rejected - server-side auth required');
  }
}

async function testMemberNumberCredential(page) {
  await page.context().clearCookies();
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  
  // Test that member_number cannot be used as password/login credential
  const emailInput = page.locator('input[name="email"], input[name="login_input"]').first();
  const passwordInput = page.locator('input[name="password"]').first();
  
  if (await emailInput.count() > 0 && await passwordInput.count() > 0) {
    await emailInput.fill('2626001');
    await passwordInput.fill('password123');
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
    
    const currentUrl = page.url();
    const loginFailed = currentUrl.includes('/login') || await page.locator('text=error').count() > 0;
    log('member_number cannot authenticate', loginFailed ? 'PASS' : 'FAIL', `url=${currentUrl}`);
  } else {
    log('member_number cannot authenticate', 'BLOCKED', 'Login form not found');
  }
}

async function main() {
  console.log('Starting PHASE 6A FINAL QA...\n');
  
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const context = await browser.newContext({ viewport: { width: 1280, height: 800 } });
  const page = await context.newPage();
  
  // Public Navigation Tests
  await testHomepage(page);
  await testDesktopNavigation(page);
  await testMobileNavigation(browser);
  
  // Public Content Tests
  await testGallery(page);
  await testGalleryMobile(browser);
  await testStructure(page);
  await testStructureEmpty(page);
  await testEvents(page);
  await testCalendar(page);
  
  // Admin Tests
  await testLogin(page);
  await testAdminDashboard(page);
  await testAdminGallery(page);
  await testGoogleDriveGallery(page);
  await testUrlImageGallery(page);
  await testLocalUploadGallery(page);
  
  // Phase 6A Specific Tests
  await testMemberPortal(page);
  await testPublicNavbar(page);
  await testLocalStorageAuth(page);
  await testMemberNumberCredential(page);
  await testEventHoverLayoutShift(page);
  
  await browser.close();
  
  console.log('\n=== PHASE 6A RESULTS ===');
  const pass = results.filter(r => r.status === 'PASS').length;
  const fail = results.filter(r => r.status === 'FAIL').length;
  const blocked = results.filter(r => r.status === 'BLOCKED').length;
  const notTestable = results.filter(r => r.status === 'NOT TESTABLE').length;
  
  console.log(`PASS: ${pass}`);
  console.log(`FAIL: ${fail}`);
  console.log(`BLOCKED: ${blocked}`);
  console.log(`NOT TESTABLE: ${notTestable}`);
  
  if (fail > 0) {
    console.log('\n=== FAILURES ===');
    results.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`- ${r.name}: ${r.details}`);
    });
  }
}

main().catch(e => {
  console.error('QA error:', e);
  process.exit(1);
});
