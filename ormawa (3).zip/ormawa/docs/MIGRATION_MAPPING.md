# Legacy Structure Migration Mapping

This document details how data from legacy `organization_positions` maps to the new core structure schema.

## Legacy Schema Context (`organization_positions`)
- `id`
- `organization_id`
- `parent_id`
- `position_name`
- `description`
- `sort_order`
- `photo`
- `person_name`
- `period`
- `status`

## Entity Migration Strategy

### 1. Groups (`structure_groups`)
- Legacy top-level positions or parent groupings (`parent_id IS NULL`) are mapped to default or custom `structure_groups`.
- Field mapping:
  - `organization_positions.position_name` (for group header rows) -> `structure_groups.name`
  - `organization_positions.sort_order` -> `structure_groups.sort_order`

### 2. Positions (`positions`)
- Detailed titles under a group map to `positions`.
- Field mapping:
  - `organization_positions.position_name` -> `positions.title`
  - `organization_positions.description` -> `positions.description`
  - `organization_positions.sort_order` -> `positions.sort_order`

### 3. Persons (`persons`)
- Explicit identity rule: `person_name` string from legacy rows is **not** permanently treated as unique identity without verification.
- Distinct non-empty `person_name` values within an organization create a `persons` record.
- Photo handling: Raw `photo` string paths can be referenced or registered into `media` and linked via `persons.photo_media_id`.

### 4. Terms (`organization_terms`)
- Legacy `period` strings (e.g. `"2025/2026"`, `"2026"`) are parsed into explicit term entities.
- Ambiguous or missing period strings are **not** silently converted into the current active term. They remain in an unassigned/unknown term state until explicitly reviewed.

### 5. Position Assignments (`position_assignments`)
- Links `person_id` + `position_id` + `term_id`.
- Vacant positions (`person_name IS NULL` or empty string) create an assignment with `person_id = NULL` and `status = 'vacant'`.
