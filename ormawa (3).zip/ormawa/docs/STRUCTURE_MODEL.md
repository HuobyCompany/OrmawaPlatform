# Dynamic Core Structure Data Model

This document outlines the core dynamic organizational structure entities introduced in Phase 1.

## Overview

The structure data model separates person identities, organizational terms, groups, positions, and assignments into distinct relational entities.

```
+--------------------+           +-------------------+
| organizations      |<----------| organization_terms|
+--------------------+           +-------------------+
       ^   ^                               ^
       |   |                               |
       |   +------------+                  |
       |                |                  |
+--------------+   +----+----------+  +----+------------------+
| persons      |   |structure_groups| | position_assignments  |
+--------------+   +---------------+  +-----------------------+
       ^                  ^                      ^   ^
       |                  |                      |   |
       +------------------+-- position_id -------+   |
                          |                          |
                   +------+------+                   |
                   | positions   |-------------------+
                   +-------------+
```

## Core Tables

### 1. `organization_terms`
Stores distinct leadership terms / academic periods per organization.
- **Columns**: `id`, `organization_id`, `name`, `slug`, `start_date`, `end_date`, `created_at`, `updated_at`.
- **Constraints**: FK to `organizations(id)` ON DELETE CASCADE. UNIQUE (`organization_id`, `slug`).

### 2. `persons`
Stores individual person profiles (students, advisors, alumni).
- **Columns**: `id`, `organization_id`, `full_name`, `email`, `phone`, `photo_media_id`, `created_at`, `updated_at`.
- **Constraints**: FK to `organizations(id)` ON DELETE CASCADE, FK to `media(id)` ON DELETE SET NULL.

### 3. `structure_groups`
Stores customizable structural groupings (e.g., BPH, Pembina, Divisi Humas, ad-hoc committee). Supports hierarchy via self-referencing `parent_id`.
- **Columns**: `id`, `organization_id`, `name`, `description`, `parent_id`, `sort_order`, `created_at`, `updated_at`.
- **Constraints**: FK to `organizations(id)` ON DELETE CASCADE, FK to `structure_groups(id)` ON DELETE SET NULL.

### 4. `positions`
Stores position definitions within a group (e.g., Ketua, Wakil Ketua, Anggota).
- **Columns**: `id`, `organization_id`, `group_id`, `title`, `description`, `sort_order`, `created_at`, `updated_at`.
- **Constraints**: FK to `organizations(id)` ON DELETE CASCADE, FK to `structure_groups(id)` ON DELETE CASCADE.

### 5. `position_assignments`
Maps a person to a position during a specific organization term.
- **Columns**: `id`, `organization_id`, `term_id`, `position_id`, `person_id`, `start_date`, `end_date`, `status` (`active`, `inactive`, `vacant`), `created_at`, `updated_at`.
- **Constraints**: FK to `organizations(id)`, `organization_terms(id)`, `positions(id)`, `persons(id)`.

## Dynamic Flexibility Requirements Supported
1. **Multiple Occupants**: Multiple `position_assignments` rows with different `person_id` for the same `position_id` and `term_id`.
2. **Multiple Assignments**: A single `person_id` holding multiple `position_id` assignments within one or multiple terms.
3. **Vacant Positions**: A `position_assignments` row with `person_id` = NULL and `status` = `'vacant'`.
4. **Historical Terms**: Query assignments filtered by `term_id`.
5. **Ad-hoc / Custom Groups**: Dynamic `structure_groups` without restricted ENUM limits.
