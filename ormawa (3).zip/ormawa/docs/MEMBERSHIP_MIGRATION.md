# Membership Migration Documentation

## Overview

This document details the migration process from the legacy `registration_submissions` table to the new separated membership model (Person → Member → User Account).

## Migration Goals

1. **Separate Identity from Membership**: Create distinct Person records independent of membership status
2. **Preserve Legacy Data**: Maintain all existing registration_submissions for historical reference
3. **Enable Future Authentication**: Prepare for unified Person → Member → User Account authentication
4. **Maintain Continuity**: Ensure existing admin and member authentication continues to work
5. **Audit Trail**: Track all migration decisions for transparency and reversibility

## Pre-Migration State

### Legacy Schema
- `registration_submissions` contains mixed identity + membership + status data
- Authentication uses `registration_submissions.member_number` for member login
- No clear separation between person identity and membership relationship
- Status stored directly in registration_submissions

### Issues with Legacy Approach
- Identity tied to membership (can't have person without membership)
- No audit trail for status changes
- Limited membership lifecycle (only pending/approved/rejected)
- No support for suspended/inactive/alumni states
- Difficult to handle duplicate names or identity changes

## Migration Strategy

### Phase 1: Schema Creation
Create new tables while preserving legacy data:

1. **`members` table** - New membership relationship table
2. **`member_audit` table** - Status change history
3. **`registration_member_mapping` table** - Track migration decisions

### Phase 2: Data Migration
Migrate existing registration_submissions to new structure:

1. **Identity Resolution** - Find or create Person records
2. **Member Creation** - Create Member records with proper relationships
3. **Mapping Creation** - Track which submission maps to which member
4. **Status Preservation** - Maintain existing status with audit trail

### Phase 3: Continuity Maintenance
Keep existing systems working:

1. **Legacy Authentication** - Continue using registration_submissions for login
2. **Admin Access** - No changes to admin authentication
3. **Member Cards** - Existing member card generation continues
4. **Registration Flow** - New registrations still work (to be migrated later)

## Identity Resolution Algorithm

The migration uses a confidence-based approach to identify persons:

### Priority 1: Email Match (Confidence: 100%)
```php
if (email exists in submission) {
    find person by email
    if (person found) {
        return person_id (high confidence)
    }
}
```

**Rationale**: Email is the most reliable unique identifier for individuals.

### Priority 2: Full Name + Phone Match (Confidence: 80%)
```php
if (phone exists in submission && full_name exists) {
    find person by full_name + phone
    if (person found) {
        return person_id (medium confidence)
    }
}
```

**Rationale**: Name + phone combination is reasonably unique but can have false positives.

### Priority 3: Create New Person (Confidence: N/A)
```php
if (no match found) {
    create new person record
    return new person_id
}
```

**Rationale**: When identity cannot be determined, create new person to avoid incorrect merging.

## Migration Process

### Step 1: Run Schema Migration
```bash
mysql -u root -p ormawa_platform < database/migrations/20260916_create_members_table.sql
```

This creates:
- `members` table
- `member_audit` table  
- `registration_member_mapping` table

### Step 2: Run Data Migration
```bash
php database/migrations/migrate_members.php
```

Or for specific organization:
```bash
php database/migrations/migrate_members.php 1
```

### Step 3: Verify Migration
Check migration results:
- Count of migrated records
- Count of skipped records (already mapped)
- Count of ambiguous identities
- Count of errors

## Mapping Types

### Direct Mapping (Type: 'direct')
High-confidence identity match using email or name+phone.

**Example:**
- Submission: "John Doe" john@example.com
- Person: "John Doe" john@example.com
- Result: Link to existing person

### Ambiguous Mapping (Type: 'ambiguous')
Low-confidence match requiring manual review.

**Example:**
- Submission: "John Doe" no email, no phone
- Person: "John Doe" (different person with same name)
- Result: Create new person, flag for review

### Manual Mapping (Type: 'manual')
Administrator manually resolves identity conflicts.

**Example:**
- Multiple "John Doe" submissions
- Admin decides which belongs to which person
- Result: Admin creates explicit mapping

## Data Field Mapping

### From registration_submissions to members

| registration_submissions | members | Notes |
|------------------------|---------|-------|
| organization_id | organization_id | Direct copy |
| full_name | → person.full_name | Moved to person table |
| faculty_name | faculty_name | Direct copy |
| prodi_name | prodi_name | Direct copy |
| whatsapp | → person.phone | Moved to person table |
| batch_year | batch_year | Direct copy |
| status | status | Direct copy (pending/approved/rejected) |
| submitted_at | joined_at | Used as join date |
| reviewed_at | reviewed_at | Direct copy |
| reviewed_by | reviewed_by | Direct copy |
| reviewer_notes | reviewer_notes | Direct copy |
| member_number | member_number | Direct copy or generate new |

### From registration_values to persons

| registration_values | persons | Notes |
|---------------------|---------|-------|
| field_type='email' | email | If email field exists |
| field_type='file_image' | photo_media_id | Future: migrate to media table |

## Preservation Rules

### What is Preserved
- All `registration_submissions` records (no deletion)
- All `registration_values` records (no deletion)
- Existing authentication logic (no changes)
- Admin user accounts (no changes)
- Member authentication via registration_submissions (no changes)

### What is Created
- New `members` records
- New `member_audit` records
- New `registration_member_mapping` records
- New `persons` records (if needed)

### What is Changed
- Nothing - this is additive migration only

## Rollback Strategy

If migration needs to be reversed:

1. **Drop new tables** (if no data depends on them):
```sql
DROP TABLE IF EXISTS registration_member_mapping;
DROP TABLE IF EXISTS member_audit;
DROP TABLE IF EXISTS members;
```

2. **Restore original state**:
- Legacy registration_submissions still exists unchanged
- Authentication continues to work via registration_submissions
- No data loss occurred

## Post-Migration State

### Dual System Period
After migration, both systems coexist:

**Legacy System (still functional):**
- Member authentication via registration_submissions
- Member card generation using registration_submissions
- Registration flow writing to registration_submissions

**New System (ready for use):**
- Member management via members table
- Status tracking via member_audit
- Person management via persons table
- Structure assignments via persons

### Future Transition Plan
The migration prepares for future phases:

1. **Phase 5**: Update registration flow to write to members table
2. **Phase 6**: Update authentication to use members table
3. **Phase 7**: Create user_account_members linking table
4. **Phase 8**: retire registration_submissions authentication

## Verification Steps

### 1. Schema Verification
```sql
-- Check new tables exist
SHOW TABLES LIKE 'members';
SHOW TABLES LIKE 'member_audit';
SHOW TABLES LIKE 'registration_member_mapping';

-- Check table structures
DESCRIBE members;
DESCRIBE member_audit;
DESCRIBE registration_member_mapping;
```

### 2. Data Verification
```sql
-- Count migrated members
SELECT COUNT(*) FROM members;

-- Count registration mappings
SELECT COUNT(*) FROM registration_member_mapping;

-- Check for unmapped submissions
SELECT COUNT(*) FROM registration_submissions s
LEFT JOIN registration_member_mapping m ON m.registration_submission_id = s.id
WHERE m.id IS NULL;

-- Check mapping types
SELECT mapping_type, COUNT(*) FROM registration_member_mapping GROUP BY mapping_type;
```

### 3. Identity Verification
```sql
-- Check for duplicate persons
SELECT full_name, COUNT(*) as count
FROM persons
GROUP BY full_name
HAVING count > 1;

-- Check for orphaned members (no person)
SELECT COUNT(*) FROM members WHERE person_id IS NULL;
```

### 4. Status Verification
```sql
-- Check status distribution
SELECT status, COUNT(*) FROM members GROUP BY status;

-- Compare with legacy status distribution
SELECT status, COUNT(*) FROM registration_submissions GROUP BY status;
```

### 5. Authentication Verification
```bash
# Test admin login still works
curl -X POST http://localhost/ormawa-platform/admin/login \
  -d "email=admin@example.com&password=admin123"

# Test member login still works
curl -X POST http://localhost/ormawa-platform/kartu-anggota \
  -d "full_name=TestUser&member_number=2626001"
```

## Ambiguous Identity Handling

### Detection
The migration flags identities as ambiguous when:

1. Multiple persons with same name exist
2. No unique identifier (email/phone) available
3. Name is too common (e.g., "John Doe")

### Resolution
Ambiguous identities require manual review:

1. **Review flagged mappings** in registration_member_mapping
2. **Compare submission details** with existing persons
3. **Decide on correct mapping** or create new person
4. **Update mapping_type** to 'manual' after resolution

### Example
```
Submission: "Ahmad Fauzi" (no email, no phone)
Existing Persons:
  - "Ahmad Fauzi" (student, 2020)
  - "Ahmad Fauzi" (alumni, 2018)

Action: Manual review required to determine which person (or if new person needed)
```

## Performance Considerations

### Migration Performance
- Processing time: ~1-2 seconds per 1000 submissions
- Memory usage: Minimal due to batch processing
- Database load: Moderate during migration
- Locking: Short table locks during inserts

### Post-Migration Performance
- Member queries: Slightly slower due to JOIN with persons
- Indexes: Properly indexed for common queries
- Caching: Can be added for frequently accessed member data

## Risk Assessment

### Low Risk
- Data loss: Impossible (legacy data preserved)
- Authentication breakage: Impossible (legacy auth unchanged)
- Performance impact: Minimal (proper indexing)

### Medium Risk
- Identity confusion: Possible (mitigated by mapping table)
- Duplicate persons: Possible (manual review process)
- Migration rollback: Complex but possible

### High Risk
- None identified

## Troubleshooting

### Issue: Migration Fails
**Symptom**: Script exits with error
**Solution**: 
1. Check database connection
2. Verify table creation succeeded
3. Check for duplicate member_number conflicts
4. Review error logs in storage/logs/app.log

### Issue: Duplicate Member Numbers
**Symptom**: Migration fails with unique constraint error
**Solution**:
1. Check existing member_number values
2. Run conflict resolution query
3. Regenerate conflicting numbers

### Issue: Orphaned Members
**Symptom**: Members without person_id
**Solution**:
1. Find submissions without person match
2. Create person records manually
3. Link to existing members

### Issue: Authentication Breaks
**Symptom**: Member login fails after migration
**Solution**:
1. Verify registration_submissions still exists
2. Check member_number still present
3. Verify authentication code unchanged

## Success Criteria

Migration is successful when:

1. ✅ All new tables created successfully
2. ✅ All registration_submissions mapped (or flagged)
3. ✅ No data loss in legacy tables
4. ✅ Admin authentication still works
5. ✅ Member authentication still works
6. ✅ Person records created appropriately
7. ✅ Member numbers generated correctly
8. ✅ Status audit trail created
9. ✅ Mapping table tracks all decisions
10. ✅ Ambiguous identities flagged for review

## Future Enhancements

### Planned Improvements
1. **Automatic identity matching** using machine learning
2. **Merge suggestion system** for duplicate persons
3. **Bulk identity resolution** tools for admins
4. **Enhanced audit reports** with visualization
5. **Real-time migration status** dashboard

### API Endpoints (Future)
- `GET /api/members/migration/status` - Migration progress
- `POST /api/members/migration/resolve` - Resolve ambiguous identity
- `GET /api/members/audit/{id}` - Get member audit history
- `POST /api/members/merge` - Merge duplicate persons

## Summary

This migration achieves:

1. **Clear Separation**: Person, Member, and User Account are now distinct
2. **Data Preservation**: Legacy data completely preserved
3. **Continuity**: Existing systems continue to work
4. **Audit Trail**: All migration decisions tracked
5. **Future-Ready**: Prepared for unified authentication
6. **Reversible**: Can be rolled back if needed

The migration provides a solid foundation for future authentication improvements while maintaining complete backward compatibility.
