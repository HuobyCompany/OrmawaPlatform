# CLEANUP INVENTORY & AUDIT

**Date**: September 19, 2026  
**Project**: ORMAWA Platform  

---

## 1. Classification Overview

| Category | Description | Action |
| :--- | :--- | :--- |
| **A. REQUIRED RUNTIME** | Application source code (controllers, models, views, helpers, core, config, assets) | **KEEP** |
| **B. REQUIRED DEPLOYMENT** | Entry point `index.php`, `.htaccess`, `database/database.sql`, `config/config.php` | **KEEP** |
| **C. REQUIRED DOCUMENTATION** | Core architecture docs (`docs/AUTHENTICATION_MODEL.md`, `docs/MEMBERSHIP_MODEL.md`, `README.md`, etc.) | **KEEP** |
| **D. REQUIRED AUTOMATED TESTS** | Core Playwright E2E regression test suites | **KEEP** |
| **E. DEVELOPMENT-ONLY** | Local override `config/config.local.php`, Node dependencies (`node_modules`), package manifests | **KEEP (Dev) / EXCLUDE (Prod)** |
| **F. DEBUG / TEMPORARY** | Temporary HTML captures, debug response files, scratch scripts, screenshot artifacts | **DELETE** |
| **G. LEGACY / HISTORICAL** | Historical one-time test scripts and debug verification files | **MOVE to `tests/legacy/` / `database/migrations/archive/`** |

---

## 2. File-by-File Inventory & Decision Matrix

### Root Directory Files

| File Name | Category | Action | Reason |
| :--- | :---: | :---: | :--- |
| `index.php` | A/B | **KEEP** | Application entry point |
| `.htaccess` | B | **KEEP** | Apache rewrite rules |
| `README.md` | C | **KEEP** | Project description and setup instructions |
| `final-qa.js` | D | **KEEP** | Phase 6A core Playwright E2E test suite |
| `admin_structure.png` | F | **DELETE** | Temporary UI screenshot capture |
| `check_org.php` | F | **DELETE** | Temporary debug script |
| `check_org_slugs.php` | F | **DELETE** | Temporary debug script |
| `home.html` | F | **DELETE** | Debug HTML capture |
| `letters-cookies.txt` | F | **DELETE** | Debug capture |
| `letters.html` | F | **DELETE** | Debug HTML capture |
| `login-response.txt` | F | **DELETE** | Debug text capture |
| `login.html` | F | **DELETE** | Debug HTML capture |
| `response.html` | F | **DELETE** | Debug HTML capture |
| `settings.html` | F | **DELETE** | Debug HTML capture |
| `settings-order.html` | F | **DELETE** | Debug HTML capture |
| `settings-order-badges.html` | F | **DELETE** | Debug HTML capture |
| `test_db.php` | F | **DELETE** | Debug connection script |
| `verify_drive.php` | F | **DELETE** | Debug Google Drive script |
| `GBHO new.docx` | F | **DELETE** | Temporary binary document artifact |
| `New AD-ART.docx` | F | **DELETE** | Temporary binary document artifact |
| `import_official_data.php` | G | **MOVE** | One-time official seed script moved to `database/migrations/archive/` |

---

### Test Directory Files (`tests/`)

| File Name | Action | Reason |
| :--- | :---: | :--- |
| `tests/phase7_registration_member_test.js` | **KEEP** | Core Phase 7 Playwright E2E test suite |
| `tests/phase6c_test.js` | **KEEP** | Core Phase 6C Playwright E2E test suite |
| `tests/member_auth_test.js` | **KEEP** | Core Member Auth Playwright E2E test suite |
| `tests/organization_isolation_test.js` | **KEEP** | Core Multi-Tenant Isolation Playwright test suite |
| `tests/MANUAL_TEST_GUIDE.md` | **KEEP** | Manual test documentation |
| `tests/PHASE5B_MANUAL_TEST_RESULTS.md` | **KEEP** | Test evidence documentation |
| `tests/PHASE5C_BROWSER_RESULTS.md` | **KEEP** | Test evidence documentation |
| `tests/check_table_structure.php` | **MOVE** | One-off debug script ➔ `tests/legacy/` |
| `tests/check_test_users.php` | **MOVE** | One-off debug script ➔ `tests/legacy/` |
| `tests/check_user_passwords.php` | **MOVE** | One-off debug script ➔ `tests/legacy/` |
| `tests/cleanup_test_fixtures.php` | **MOVE** | One-off debug script ➔ `tests/legacy/` |
| `tests/get_test_passwords.php` | **MOVE** | One-off debug script ➔ `tests/legacy/` |
| `tests/inspect_legacy.php` | **MOVE** | One-off debug script ➔ `tests/legacy/` |
| `tests/run_mapping_migration.php` | **MOVE** | One-off migration runner ➔ `tests/legacy/` |
| `tests/security_verification.php` | **MOVE** | Historical security audit ➔ `tests/legacy/` |
| `tests/test_admin_structure_ui.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/test_admin_structure_verification.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/test_auth_flows.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/test_authentication.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/test_db_connection.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/test_membership_functional.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/test_membership_verification.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/test_structure_model.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/verify_member_role.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/verify_migrated_data.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |
| `tests/verify_role_status_separation.php` | **MOVE** | Historical test script ➔ `tests/legacy/` |

---

### Migration Directory Files (`database/migrations/`)

| File Name | Action | Reason |
| :--- | :---: | :--- |
| `20250909_google_drive_gallery.php` | **KEEP** | Schema upgrade migration |
| `20250909_remote_url_gallery.php` | **KEEP** | Schema upgrade migration |
| `20260910_member_registration.sql` | **KEEP** | Schema upgrade migration |
| `20260912_registration_public_token.sql` | **KEEP** | Schema upgrade migration |
| `20260915_add_structure_visibility.sql` | **KEEP** | Schema upgrade migration |
| `20260915_create_legacy_structure_mappings.sql` | **KEEP** | Schema upgrade migration |
| `20260915_create_structure_entities.sql` | **KEEP** | Schema upgrade migration |
| `20260916_create_members_table.sql` | **KEEP** | Schema upgrade migration |
| `20260917_add_member_role_to_users.sql` | **KEEP** | Schema upgrade migration |
| `20260917_add_users_remember_token.sql` | **KEEP** | Schema upgrade migration |
| `20260917_create_user_account_members_table.sql` | **KEEP** | Schema upgrade migration |
| `fix_user_account_members_table.php` | **MOVE** | Historical runner ➔ `database/migrations/archive/` |
| `migrate_auth.php` | **MOVE** | Historical runner ➔ `database/migrations/archive/` |
| `migrate_members.php` | **MOVE** | Historical runner ➔ `database/migrations/archive/` |
| `run_legacy_migration.php` | **MOVE** | Historical runner ➔ `database/migrations/archive/` |
| `run_migration.php` | **MOVE** | Historical runner ➔ `database/migrations/archive/` |
