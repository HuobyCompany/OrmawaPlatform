# Phase 2A — Legacy Structure Data Migration Report

This document records the migration of legacy `organization_positions` data into the new dynamic structure data model (`organization_terms`, `structure_groups`, `positions`, `persons`, `position_assignments`).

## 1. Overview & Strategy

The migration safely transforms flat legacy position records into the core dynamic entities without deleting, modifying, or dropping any existing legacy tables or columns.

### Core Rules Enforced
1. **Zero Data Destruction:** Legacy table `organization_positions` remains completely untouched.
2. **Explicit ID Traceability:** All migrated relationships are recorded in `legacy_structure_mappings` to link each legacy `organization_positions.id` to its corresponding `term_id`, `group_id`, `position_id`, `person_id`, and `assignment_id`.
3. **Idempotency & Re-runs:** Running the migration multiple times safely skips previously migrated records without creating duplicates.
4. **Identity Disambiguation:** `person_name` strings are not permanently assumed to be unique. Candidate persons are queried per organization, and duplicate names generate explicit warnings.
5. **Period Handling:** Reliable legacy periods (e.g. `"2026/2027"`) map to structured `organization_terms`. Null or unparsable periods map to `Unmapped Legacy Term` and are logged.
6. **Vacant Position Support:** Legacy positions without a person (`person_name IS NULL`) create an assignment with `person_id = NULL` and `status = 'vacant'`.
7. **Media Relational Integrity:** Legacy photo paths are checked on disk and registered as `media` records before linking to `persons`. Missing files produce clear diagnostic reports.

---

## 2. Mapping Table Schema (`legacy_structure_mappings`)

```sql
CREATE TABLE legacy_structure_mappings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    legacy_position_id BIGINT UNSIGNED NOT NULL UNIQUE,
    term_id BIGINT UNSIGNED NULL,
    group_id BIGINT UNSIGNED NULL,
    position_id BIGINT UNSIGNED NULL,
    person_id BIGINT UNSIGNED NULL,
    assignment_id BIGINT UNSIGNED NULL,
    status ENUM('migrated', 'skipped', 'ambiguous') NOT NULL DEFAULT 'migrated',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_map_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    CONSTRAINT fk_map_legacy FOREIGN KEY (legacy_position_id) REFERENCES organization_positions(id) ON DELETE CASCADE
);
```

---

## 3. Migration Utility & Tooling

- **Service Class:** `app/services/LegacyStructureMigrationService.php`
- **CLI Command Script:** `database/migrations/run_legacy_migration.php`
- **Usage:**
  - Dry Run (Simulation mode): `php database/migrations/run_legacy_migration.php --dry-run`
  - Real Execution: `php database/migrations/run_legacy_migration.php --execute`

---

## 4. Execution & Audit Results

### Dry Run Result
```
=================================================
 LEGACY STRUCTURE DATA MIGRATION REPORT
 Mode: DRY RUN (No changes committed)
=================================================
Total Legacy Records Evaluated : 8
Already Migrated Records       : 0

--- Summary of Entities to Create ---
 Terms       : 1
 Groups      : 3
 Positions   : 8
 Persons     : 5
 Assignments : 8

--- Terms Created ---
 + Periode 2026/2027

--- Groups Created ---
 + Pembina / Pembimbing
 + Badan Pengurus Harian (BPH)
 + Divisi / Departemen

--- Positions Created ---
 + Pembina
 + Ketua Umum
 + Wakil Ketua
 + Sekretaris
 + Bendahara
 + Kaderisasi
 + Kemuslimahan
 + Syiar

--- Persons Created ---
 + Dr. Ir. Budi Santoso, S.T., M.T.
 + Wafdanu Zahrawaan
 + Nauvarel Shidqi Zein
 + Andika Rafa Syahputra
 + Fina Dwi Damayanti
```

### Real Execution Result & Idempotency Audit
- **First Execution (`--execute`):** 8 legacy records evaluated, 8 records successfully migrated into 1 term, 3 groups, 8 positions, 5 persons, and 8 assignments (5 active, 3 vacant).
- **Second Execution (`--execute`):** 8 legacy records evaluated, 8 records reported as **Already Migrated**, 0 new entities created. (100% Idempotency verified).

---

## 5. Summary of Migrated Data

| Legacy ID | Position Title | Legacy Person | Target Group | Person Status | Assignment Status |
|-----------|----------------|---------------|--------------|---------------|-------------------|
| #18 | Pembina | Dr. Ir. Budi Santoso, S.T., M.T. | Pembina / Pembimbing | Active | Active |
| #19 | Ketua Umum | Wafdanu Zahrawaan | Badan Pengurus Harian (BPH) | Active | Active |
| #20 | Wakil Ketua | Nauvarel Shidqi Zein | Badan Pengurus Harian (BPH) | Active | Active |
| #21 | Sekretaris | Andika Rafa Syahputra | Badan Pengurus Harian (BPH) | Active | Active |
| #22 | Bendahara | Fina Dwi Damayanti | Badan Pengurus Harian (BPH) | Active | Active |
| #23 | Kaderisasi | *NULL* | Divisi / Departemen | *None* | Vacant |
| #24 | Kemuslimahan | *NULL* | Divisi / Departemen | *None* | Vacant |
| #25 | Syiar | *NULL* | Divisi / Departemen | *None* | Vacant |

---

## 6. Verification Status & Next Phase

- **Legacy Integrity:** `organization_positions` remains unmodified. Public UI and current admin UI continue reading from legacy tables without disruption.
- **New Engine Readiness:** All legacy data is now mapped and accessible via `StructureService` and the new relational structure models.
- **Next Step (Phase 2B / Phase 3):** Admin Structure Builder UI refactor and public frontend structure tree rendering using the new service engine.
