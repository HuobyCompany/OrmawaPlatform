# Public Structure Data Rules

## Overview

This document defines the rules and mechanisms for ensuring that only legitimate organization data appears on the public `/struktur` page, preventing test fixtures and development data from leaking into production views.

## Problem Statement

The public structure page was displaying development/test records such as:
- Empty Group
- Many Group  
- Test Group
- Test MultiPos
- Order A
- Order B
- Pos 1..20
- Pos A/B
- Many vacancy test records

These were test fixtures created by automated tests and should never appear on the public website.

## Solution Implementation

### 1. Test Fixture Isolation

**Problem:** Test files were writing directly to the real development database without transaction rollback.

**Solution:** 
- Fixed `tests/test_admin_structure_verification.php` to use transaction rollback
- All test data is now automatically rolled back after test completion
- No test fixtures persist in the database after test execution

**Cleanup Script:** Created `tests/cleanup_test_fixtures.php` to safely remove existing test fixtures:
- Removes groups with names containing: "Test Group", "Empty Group", "Many Group", "Order A", "Order B", "Parent Group", "Child Group"
- Removes positions under test groups
- Removes persons with names containing: "Test MultiPos", "Second Person", "Term2 Person", "NoLogin Person"
- Preserves real organization data (groups 6, 7, 8; persons 8-12)

### 2. Visibility/Publishing Controls

**Database Schema Changes:**
Added `is_public` columns to:
- `structure_groups` (TINYINT(1), default 1)
- `positions` (TINYINT(1), default 1)  
- `position_assignments` (TINYINT(1), default 1)

**Migration:** `database/migrations/20260915_add_structure_visibility.sql`

**Purpose:** Allows administrators to mark structure entities as private (admin-only) without deleting them.

### 3. Data Filtering for Public Display

**Model Updates:**
- `StructureGroupModel::all($orgId, $publicOnly = false)` - filters by `is_public` when `$publicOnly = true`
- `StructurePositionModel::all($orgId, $groupId, $publicOnly = false)` - filters by `is_public` when `$publicOnly = true`
- `PositionAssignmentModel::all($orgId, $termId, $publicOnly = false)` - filters by `is_public` when `$publicOnly = true`

**Service Updates:**
- `StructureService::getStructureTree($orgId, $termId, $publicOnly = false)` - cascades the public filter through all models

**Controller Updates:**
- `FrontendController::structure()` - calls `StructureService::getStructureTree($orgId, $selectedTermId, true)` to filter for public display

### 4. Empty Group Handling

**Problem:** Empty groups were rendering with "Empty Group" text or appearing as empty sections.

**Solution:** 
- Skip groups with zero positions entirely in the public view
- No empty groups appear on the public structure page
- Groups are filtered before rendering

**Implementation:** In `views/frontend/structure.php`:
```php
<?php if (empty($group['positions'])): ?>
  <?php continue; // Skip empty groups entirely ?>
<?php endif; ?>
```

### 5. Vacant Position Management

**Problem:** Large numbers of vacant positions could flood the public page.

**Solution:**
- Limit vacant position display to 10 per group
- Show a summary message for additional vacant positions
- Vacant positions are still visible but controlled

**Implementation:** In `views/frontend/structure.php`:
```php
$vacantCount = 0;
$maxVacant = 10; // Limit vacant positions to prevent flooding
foreach ($group['positions'] as $position): 
  $assignments = $position['assignments'] ?? [];
  if (empty($assignments)): 
    $vacantCount++;
    if ($vacantCount > $maxVacant) continue; // Skip after limit
    // ... render vacant position card
  endif;
endforeach;
if ($vacantCount > $maxVacant): ?>
  <p class="text-muted small">Dan <?= $vacantCount - $maxVacant ?> posisi lainnya yang tersedia...</p>
<?php endif;
```

### 6. Term Isolation

**Problem:** Historical terms could mix with current term data.

**Solution:**
- Public structure page always filters by a specific term
- Term selector allows users to switch between terms
- Each term's structure is completely isolated
- Assignments from different terms never mix

**Implementation:** `FrontendController::structure()`:
- Defaults to the most recent term (by start_date)
- Respects `?term=` query parameter for manual selection
- Passes `$selectedTermId` to `StructureService::getStructureTree()`

## Public Structure Page Data Rules

### What Appears on `/struktur`

**✅ YES - Visible on public page:**
- Groups where `is_public = 1`
- Positions where `is_public = 1`
- Assignments where `is_public = 1`
- Groups with at least one position
- Positions with active assignments
- Vacant positions (limited to 10 per group)
- Data from the selected/current term only
- Real organization data only

**❌ NO - Hidden from public page:**
- Groups where `is_public = 0`
- Positions where `is_public = 0`
- Assignments where `is_public = 0`
- Empty groups (groups with zero positions)
- Excess vacant positions (beyond 10 per group)
- Data from other terms (not selected)
- Test fixtures (Test Group, Empty Group, etc.)
- Development data
- Unpublished/draft structure entities

## Admin Access

Administrators can still access all structure data (including private entities) through:
- Admin structure builder (unfiltered)
- Direct database access
- Admin API endpoints

The `publicOnly` parameter controls the filtering level:
- `false` (default): Show all data for admin views
- `true`: Show only public data for frontend views

## Data Integrity Guarantees

1. **Test Data Isolation:** Test fixtures are automatically rolled back and never persist
2. **Visibility Control:** Private structure entities are completely hidden from public views
3. **Term Separation:** Historical and current term data never mix
4. **Empty Group Safety:** Groups without positions are silently skipped
5. **Vacant Position Limits:** Large numbers of vacant positions are controlled
6. **Organization Scoping:** All queries are scoped to the current organization

## Verification Checklist

- [x] `/struktur` shows only real organization data
- [x] No "Test Group", "Many Group", "Empty Group", "Order A/B" appear publicly
- [x] Historical terms do not mix with current term
- [x] Empty groups are handled safely (not rendered)
- [x] Vacant positions are handled safely (limited display)
- [x] Admin can still see all data when appropriate
- [x] Test fixtures never persist after test execution
- [x] Real organization data is preserved during cleanup

## Migration and Cleanup

To apply these rules to an existing installation:

1. Run the visibility migration:
   ```bash
   php -r "require_once 'config/config.php'; require_once 'app/core/Database.php'; \$pdo = Database::connection(); \$pdo->exec(file_get_contents('database/migrations/20260915_add_structure_visibility.sql'));"
   ```

2. Clean up existing test fixtures:
   ```bash
   php tests/cleanup_test_fixtures.php
   ```

3. Verify the public structure page shows only real data:
   ```bash
   curl http://localhost:8000/struktur
   ```

## Future Considerations

- Consider adding UI controls for admins to toggle `is_public` status
- Consider adding bulk operations for marking structure entities as public/private
- Consider adding validation to prevent making required positions private
- Consider adding audit logging for visibility changes
