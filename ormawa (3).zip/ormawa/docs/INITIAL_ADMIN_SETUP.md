# INITIAL BOOTSTRAP ADMIN SETUP GUIDE

**Date**: September 19, 2026  
**Project**: ORMAWA Platform  

---

## 1. Overview

After deploying the canonical `database/database.sql` and `database/seed.sql` to a fresh database, the platform comes pre-configured with bootstrap admin access while maintaining production security standards.

---

## 2. Default Bootstrap Admin Credentials

Upon fresh import of `database/seed.sql`:

- **Super Admin Account**:
  - **Email**: `super@example.com`
  - **Initial Password**: `admin123`
  - **Role**: `super_admin`
  - **Access**: Global system administration & multi-organization management (`/admin/dashboard`).

- **Organization Admin Account**:
  - **Email**: `admin@example.com`
  - **Initial Password**: `admin123`
  - **Role**: `organization_admin`
  - **Access**: Organization administrator for default HMTI organization (`/admin/dashboard`).

---

## 3. Post-Deployment Credential Security Hardening

> [!IMPORTANT]
> Immediately after first login to a production instance:
> 1. Log in to the Admin Dashboard (`/admin/login`).
> 2. Navigate to **Kelola User / Pengurus** (`/admin/users`).
> 3. Edit the Super Admin and Organization Admin password credentials.
> 4. Use strong, unique passwords (`password_hash` will hash them securely using BCRYPT).

Alternatively, admins can update their passwords programmatically using the CLI bootstrap helper script:

```bash
php database/bootstrap_admin.php --email="admin@yourdomain.com" --password="YourSecurePasswordHere!"
```

---

## 4. Production Deployment Checklist

1. **Import Database Schema**:
   ```bash
   mysql -u [db_user] -p [db_name] < database/database.sql
   mysql -u [db_user] -p [db_name] < database/seed.sql
   ```
2. **Set Local Secrets**:
   Copy `config/config.example.php` to `config/config.local.php` and set your live `APP_URL`, `DB_USER`, and `DB_PASS`.
3. **Change Bootstrap Passwords**:
   Log in and update admin credentials immediately.
