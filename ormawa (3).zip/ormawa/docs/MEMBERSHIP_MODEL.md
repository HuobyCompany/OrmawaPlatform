# Membership Model Documentation

## Overview

Phase 4 introduces a clear separation between three core identity concepts:

1. **Person** - Real-world individual identity
2. **Member** - Membership relationship with an organization  
3. **User Account** - Authentication credentials and system access

This separation enables flexible organizational management while maintaining clear data relationships.

## Core Concepts

### Person
A **Person** represents a real-world individual, independent of any organizational membership or system access.

**Key Characteristics:**
- Exists as a unique identity in the system
- May have zero, one, or multiple organizational memberships
- May appear in organizational structure without user account
- Contains core identity data (name, contact info, photo)

**Use Cases:**
- A person listed in organizational structure who doesn't need system access
- An alumni who is no longer a member but their data is preserved
- External advisors or partners who have roles but no login
- People who exist for historical/archival purposes

### Member
A **Member** represents the relationship between a Person and an Organization.

**Key Characteristics:**
- Links a Person to an Organization
- Has a lifecycle status (pending, active, rejected, suspended, inactive, alumni)
- Contains organization-specific membership data
- Independent from authentication credentials
- member_number is an identifier, NOT a password

**Membership Lifecycle:**
- `pending` - Application submitted, awaiting review
- `active` - Approved member in good standing
- `rejected` - Application denied
- `suspended` - Temporarily suspended
- `inactive` - No longer active (graduated, resigned, etc.)
- `alumni` - Former member with alumni status

**Use Cases:**
- Tracking current and historical membership
- Managing member status transitions
- Generating member numbers and cards
- Membership statistics and reporting

### User Account
A **User Account** represents authentication credentials and system access permissions.

**Key Characteristics:**
- Login credentials (email/username + password)
- Role-based permissions (super_admin, organization_admin, editor)
- May represent a member or admin
- Independent from membership status
- Can exist without membership (e.g., external auditors)

**Use Cases:**
- Admin access to organization management
- Member access to member portal
- System administration
- Limited access for external parties

## Database Schema

### Core Tables

#### `persons`
Stores individual person profiles.

```sql
CREATE TABLE persons (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    full_name VARCHAR(180) NOT NULL,
    email VARCHAR(190) NULL,
    phone VARCHAR(60) NULL,
    photo_media_id BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_persons_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    CONSTRAINT fk_persons_photo FOREIGN KEY (photo_media_id) REFERENCES media(id) ON DELETE SET NULL
);
```

#### `members`
Stores membership relationships between persons and organizations.

```sql
CREATE TABLE members (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    person_id BIGINT UNSIGNED NULL,
    member_number VARCHAR(20) NOT NULL UNIQUE,
    status ENUM('pending','active','rejected','suspended','inactive','alumni') NOT NULL DEFAULT 'pending',
    joined_at DATETIME NULL,
    reviewed_at DATETIME NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    reviewer_notes TEXT NULL,
    current_term_id BIGINT UNSIGNED NULL,
    batch_year VARCHAR(10) NULL,
    faculty_name VARCHAR(180) NULL,
    prodi_name VARCHAR(180) NULL,
    whatsapp VARCHAR(60) NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    CONSTRAINT fk_members_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    CONSTRAINT fk_members_person FOREIGN KEY (person_id) REFERENCES persons(id) ON DELETE SET NULL,
    CONSTRAINT fk_members_term FOREIGN KEY (current_term_id) REFERENCES organization_terms(id) ON DELETE SET NULL,
    CONSTRAINT fk_members_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
);
```

#### `member_audit`
Stores membership status change history.

```sql
CREATE TABLE member_audit (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    member_id BIGINT UNSIGNED NOT NULL,
    old_status VARCHAR(20) NULL,
    new_status VARCHAR(20) NOT NULL,
    changed_by BIGINT UNSIGNED NULL,
    changed_at DATETIME NOT NULL,
    notes TEXT NULL,
    CONSTRAINT fk_audit_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    CONSTRAINT fk_audit_user FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL
);
```

#### `registration_member_mapping`
Maps legacy registration_submissions to new members.

```sql
CREATE TABLE registration_member_mapping (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    registration_submission_id BIGINT UNSIGNED NOT NULL,
    member_id BIGINT UNSIGNED NOT NULL,
    mapping_type ENUM('direct','ambiguous','manual') NOT NULL DEFAULT 'direct',
    confidence_score TINYINT UNSIGNED NULL,
    mapped_at DATETIME NOT NULL,
    mapped_by BIGINT UNSIGNED NULL,
    notes TEXT NULL,
    CONSTRAINT fk_map_submission FOREIGN KEY (registration_submission_id) REFERENCES registration_submissions(id) ON DELETE CASCADE,
    CONSTRAINT fk_map_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    CONSTRAINT fk_map_user FOREIGN KEY (mapped_by) REFERENCES users(id) ON DELETE SET NULL
);
```

## Entity Relationships

```
organizations
    ↓
persons ← (organization_id)
    ↓
members ← (person_id)
    ↓
member_audit ← (member_id)

organizations
    ↓
members ← (organization_id)

users
    ↓
members ← (reviewed_by)

organization_terms
    ↓
members ← (current_term_id)

registration_submissions
    ↓
registration_member_mapping ← (registration_submission_id)
    ↓
members ← (member_id)
```

## Key Rules

1. **Person Independence**: A Person may exist without being a Member
2. **Structure Independence**: A Person may appear in Structure without a User Account
3. **Membership Independence**: A Member may exist without a User Account
4. **Account Representation**: A User Account may represent a Member
5. **No Duplicate Persons**: Do not create duplicate Person records because of multiple positions
6. **Structure Continuity**: Structure assignments continue to reference Person
7. **Status Independence**: Member status must be independent from authentication credentials
8. **Identifier vs Password**: member_number is an identifier, NOT a password

## Model API

### MemberModel

#### Core Methods
- `all(int $orgId, ?string $status = null): array` - Get all members for organization
- `find(int $id, int $orgId): ?array` - Find specific member
- `findByMemberNumber(string $memberNumber, int $orgId): ?array` - Find by member number
- `findByPersonId(int $personId, int $orgId): ?array` - Find by person
- `create(array $data): int` - Create new member
- `update(int $id, int $orgId, array $data): void` - Update member
- `delete(int $id, int $orgId): void` - Delete member

#### Status Management
- `approve(int $id, int $orgId, int $userId, ?string $notes = null): void` - Approve member
- `reject(int $id, int $orgId, int $userId, ?string $notes = null): void` - Reject member
- `suspend(int $id, int $orgId, int $userId, ?string $notes = null): void` - Suspend member

#### Utility Methods
- `generateMemberNumber(int $orgId, ?string $batchYear = null): string` - Generate unique member number
- `countByStatus(int $orgId, string $status): int` - Count members by status
- `getDistinctBatches(int $orgId): array` - Get distinct batch years
- `addAudit(int $memberId, ?string $oldStatus, string $newStatus, ?int $changedBy, ?string $notes = null): void` - Add audit entry
- `getAuditHistory(int $memberId): array` - Get status change history

### MemberService

#### Migration
- `migrateRegistrationSubmissions(int $orgId, ?int $mappedBy = null): array` - Migrate submissions to members

#### Business Logic
- `getStatistics(int $orgId): array` - Get member statistics
- `getMemberWithDetails(int $memberId, int $orgId): ?array` - Get member with related data
- `updateStatus(int $memberId, int $orgId, string $newStatus, int $userId, ?string $notes = null): void` - Update status with audit
- `search(int $orgId, string $query, ?string $status = null, ?string $batch = null): array` - Search members

## Authentication Preparation

The current authentication system continues to work during this phase. The new model prepares for future unified authentication:

**Future Authentication Flow:**
```
Person
    ↓ (has Member relationship)
Member
    ↓ (has User Account)
User Account
    ↓ (authenticates)
System Access
```

**Current Authentication (preserved):**
- Admin authentication via `users` table (unchanged)
- Member authentication via `registration_submissions` (unchanged)
- `member_auth` session (unchanged)

## Data Integrity

### Identity Resolution
When migrating from registration_submissions to members, the system uses this priority for person identification:

1. **Email** (most reliable) - If email exists, find person by email
2. **Full Name + Phone** (moderately reliable) - If phone exists, find by name + phone
3. **Create New Person** (fallback) - If no match found, create new person

### Audit Trail
All membership status changes are automatically logged in `member_audit`:
- Records old status, new status
- Records who made the change
- Records timestamp and notes
- Enables full history reconstruction

### Migration Safety
- Legacy `registration_submissions` are preserved
- `registration_member_mapping` tracks all migrations
- No data is deleted during migration
- Mapping can be reversed if needed
- Ambiguous identities are flagged for manual review

## Examples

### Example 1: Person without Member
```php
// A person exists in structure but has no membership
$person = PersonModel::save([
    'full_name' => 'Dr. Budi Santoso',
    'email' => 'budi@example.com',
    'phone' => '081234567890'
], null, $orgId);

// Person can be assigned to structure without membership
PositionAssignmentModel::create([
    'person_id' => $person['id'],
    'position_id' => $positionId,
    'term_id' => $termId,
    // ...
]);
```

### Example 2: Member without User Account
```php
// A member exists but has no login credentials
$member = MemberModel::create([
    'organization_id' => $orgId,
    'person_id' => $personId,
    'member_number' => '2626001',
    'status' => 'active',
    'batch_year' => '2026'
]);

// Member can be active without user account
// They can still appear in structure, receive member cards, etc.
```

### Example 3: Member with User Account
```php
// Member has both membership and login access
$member = MemberModel::create([
    'organization_id' => $orgId,
    'person_id' => $personId,
    'member_number' => '2626002',
    'status' => 'active'
]);

$user = UserModel::save([
    'organization_id' => $orgId,
    'name' => $person['full_name'],
    'email' => $person['email'],
    'password' => password_hash('secure_password', PASSWORD_DEFAULT),
    'role' => 'organization_admin'
]);

// Future: Link user to member via user_account_members table
```

## Migration Notes

### From Legacy Structure
The migration from `organization_positions` to the new structure system already created `persons` records. This phase enhances those records with proper membership relationships.

### From Registration System
The migration from `registration_submissions` to `members`:
- Preserves all registration data
- Creates proper person records
- Generates member numbers
- Maintains status transitions
- Tracks all mappings for audit

### Future Enhancements
This model supports future additions:
- `user_account_members` table to link users to members
- Additional membership attributes (dues paid, attendance, etc.)
- Enhanced role-based access control
- Multi-organization memberships

## Verification Checklist

- [x] Person can exist without Member
- [x] Person can have Structure Assignment without User
- [x] Member can exist without User Account
- [x] Member status is independent from authentication
- [x] member_number is identifier, not password
- [x] No duplicate Person records for multiple positions
- [x] Structure assignments reference Person
- [x] Legacy registration_submissions preserved
- [x] Audit trail for all status changes
- [x] Admin authentication still works
- [x] Member authentication still works
