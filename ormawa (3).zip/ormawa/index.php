<?php
declare(strict_types=1);

if (php_sapi_name() === 'cli-server') {
    $reqPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
    if ($reqPath !== '/' && is_file(__DIR__ . $reqPath)) {
        return false;
    }
}

require __DIR__.'/config/config.php';
require __DIR__.'/config/constants.php';
date_default_timezone_set(APP_TIMEZONE);

// Output compression for production
if (!headers_sent() && APP_ENV === 'production') {
    if (str_contains($_SERVER['HTTP_ACCEPT_ENCODING'] ?? '', 'gzip')) {
        ob_start('ob_gzhandler');
    } else {
        ob_start();
    }
}

if(session_status()!==PHP_SESSION_ACTIVE){
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// Security headers
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: interest-cohort=()');
}

foreach(glob(BASE_PATH.'/app/helpers/*.php') as $f)require_once $f;
foreach([BASE_PATH.'/app/core/Database.php',BASE_PATH.'/app/core/View.php',BASE_PATH.'/app/core/Router.php',BASE_PATH.'/app/middleware/AuthMiddleware.php'] as $f)require_once $f;
foreach(glob(BASE_PATH.'/app/services/*.php') as $f)require_once $f;
foreach(glob(BASE_PATH.'/app/models/*.php') as $f)require_once $f;
foreach(glob(BASE_PATH.'/app/controllers/*.php') as $f)require_once $f;
set_exception_handler(function(Throwable $e){
  $message = (string) $e;
  error_log($message);
  $logDir = BASE_PATH . '/storage/logs';
  if (!is_dir($logDir) && !mkdir($logDir, 0755, true)) {
      $logDir = BASE_PATH;
  }
  @file_put_contents($logDir . '/app.log', '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL, FILE_APPEND | LOCK_EX);
  http_response_code(500);
  try{View::render('errors/500',[],'error');}catch(Throwable $ignore){echo 'Server Error';}
  exit;
});

$router=new Router();

// 1. Admin Routes (Must be registered FIRST to avoid wildcard clashes)
$auth=new AuthController();
$router->get('/login',[$auth,'login']);
$router->post('/login',[$auth,'authenticate']);
$router->get('/admin/login',[$auth,'login']);
$router->post('/admin/login',[$auth,'authenticate']);
$router->post('/admin/logout',[$auth,'logout']);
$router->get('/admin/logout',[$auth,'logout']);

$admin=new AdminController();
$router->get('/admin',[$admin,'dashboard']);
$router->get('/admin/dashboard',[$admin,'dashboard']);
$router->get('/admin/calendar',[$admin,'calendar']);

$org=new OrganizationController();
$router->get('/admin/organization',[$org,'edit']);
$router->get('/admin/organization/create',[$org,'edit']);
$router->get('/admin/organization/edit/{id}',[$org,'edit']);
$router->post('/admin/organization/save',[$org,'save']);
$router->post('/admin/organization/delete/{id}',[$org,'delete']);
$router->get('/admin/organizations',[$org,'list']);
$router->post('/admin/organizations/switch',[$org,'switch']);

$settings=new SettingsController();
$router->get('/admin/settings',[$settings,'index']);
$router->post('/admin/settings/save',[$settings,'save']);

$ev=new EventController();
$router->get('/admin/events',[$ev,'index']);
$router->get('/admin/events/create',[$ev,'form']);
$router->get('/admin/events/edit/{id}',[$ev,'form']);
$router->post('/admin/events/save',[$ev,'save']);
$router->post('/admin/events/delete/{id}',[$ev,'delete']);

$g=new GalleryController();
$router->get('/admin/gallery',[$g,'index']);
$router->get('/admin/gallery/create',[$g,'form']);
$router->get('/admin/gallery/edit/{id}',[$g,'form']);
$router->post('/admin/gallery/save',[$g,'save']);
$router->post('/admin/gallery/{albumId}/item/{id}/update',[$g,'updateItem']);
$router->post('/admin/gallery/delete/{id}',[$g,'deleteAlbum']);
$router->post('/admin/gallery/{albumId}/delete-item/{id}',[$g,'deleteItem']);
$router->post('/admin/gallery/add-drive-file/{id}',[$g,'addDriveFile']);
$router->post('/admin/gallery/verify-drive-file',[$g,'verifyDriveFile']);
$router->post('/admin/gallery/add-remote-url/{id}',[$g,'addRemoteUrl']);

$st=new StructureController();
$router->get('/admin/structure',[$st,'index']);
$router->get('/admin/structure/group/{id}',[$st,'manageGroup']);
$router->post('/admin/structure/term/save',[$st,'saveTerm']);
$router->post('/admin/structure/group/save',[$st,'saveGroup']);
$router->post('/admin/structure/group/move/{id}/{direction}',[$st,'moveGroup']);
$router->post('/admin/structure/group/delete/{id}',[$st,'deleteGroup']);
$router->post('/admin/structure/position/save',[$st,'savePosition']);
$router->post('/admin/structure/position/move/{id}/{direction}',[$st,'movePosition']);
$router->post('/admin/structure/position/delete/{id}',[$st,'deletePosition']);
$router->post('/admin/structure/assignment/save',[$st,'saveAssignment']);
$router->post('/admin/structure/assignment/delete/{id}',[$st,'deleteAssignment']);

// Legacy structure fallbacks
$router->get('/admin/structure/create',[$st,'legacyForm']);
$router->get('/admin/structure/edit/{id}',[$st,'legacyForm']);
$router->post('/admin/structure/save',[$st,'legacySave']);
$router->post('/admin/structure/move/{id}/{direction}',[$st,'legacyMove']);
$router->post('/admin/structure/set-parent',[$st,'legacySetParent']);
$router->post('/admin/structure/delete/{id}',[$st,'legacyDelete']);

$media=new MediaController();
$router->get('/admin/media',[$media,'index']);
$router->post('/admin/media/upload',[$media,'upload']);
$router->post('/admin/media/delete/{id}',[$media,'delete']);

$users=new UserController();
$router->get('/admin/users',[$users,'index']);
$router->get('/admin/users/create',[$users,'form']);
$router->get('/admin/users/edit/{id}',[$users,'form']);
$router->post('/admin/users/save',[$users,'save']);
$router->post('/admin/users/delete/{id}',[$users,'delete']);

$letters=new LetterController();
$router->get('/admin/letters',[$letters,'index']);
$router->get('/admin/letters/create',[$letters,'form']);
$router->get('/admin/letters/edit/{id}',[$letters,'form']);
$router->post('/admin/letters/save',[$letters,'save']);
$router->post('/admin/letters/delete/{id}',[$letters,'delete']);
$router->get('/admin/letters/download/{id}',[$letters,'download']);

// Registration Form Builder + Submissions
$reg=new RegistrationController();
$router->get('/admin/registration',[$reg,'builder']);
$router->post('/admin/registration/form/create',[$reg,'createForm']);
$router->post('/admin/registration/form/save',[$reg,'saveForm']);
$router->post('/admin/registration/form/field/add',[$reg,'addField']);
$router->post('/admin/registration/form/field/edit',[$reg,'editField']);
$router->post('/admin/registration/form/field/delete',[$reg,'deleteField']);
$router->post('/admin/registration/form/field/toggle',[$reg,'toggleField']);
$router->post('/admin/registration/form/field/reorder',[$reg,'reorderFields']);
$router->get('/admin/registration/submissions',[$reg,'submissions']);
$router->get('/admin/registration/submission/{id}',[$reg,'submissionView']);
$router->post('/admin/registration/submission/approve',[$reg,'approve']);
$router->post('/admin/registration/submission/reject',[$reg,'reject']);
$router->post('/admin/registration/submission/delete',[$reg,'deleteSubmission']);
$router->get('/admin/members',[$reg,'members']);
$router->get('/admin/members/create',[$reg,'memberCreate']);
$router->post('/admin/members/store',[$reg,'memberStore']);
$router->get('/admin/members/edit',[$reg,'memberEdit']);
$router->post('/admin/members/update',[$reg,'memberUpdate']);
$router->post('/admin/members/delete',[$reg,'memberDelete']);
$router->get('/admin/members/detail',[$reg,'memberDetailAjax']);

$fac = new FacultyController();
$router->get('/admin/faculties', [$fac, 'index']);
$router->post('/admin/faculties/save', [$fac, 'saveFaculty']);
$router->post('/admin/faculties/delete', [$fac, 'deleteFaculty']);
$router->post('/admin/programs/save', [$fac, 'saveProgram']);
$router->post('/admin/programs/delete', [$fac, 'deleteProgram']);

// 2. Default Organization Frontend Routes (Root level without slug)
$router->get('/',[new FrontendController(),'home']);
$router->get('/tentang',[new FrontendController(),'about']);
$router->get('/kegiatan',[new FrontendController(),'events']);
$router->get('/kegiatan/{slug}',[new FrontendController(),'event']);
$router->get('/kalender',[new FrontendController(),'calendar']);
$router->get('/gallery',[new FrontendController(),'gallery']);
$router->get('/gallery/{slug}',[new FrontendController(),'galleryAlbum']);
$router->get('/struktur',[new FrontendController(),'structure']);
$router->get('/kontak',[new FrontendController(),'contact']);

// Public Member Registration & Card Routes (default, no org slug)
$memberCard = new MemberCardController();
$router->get('/kartu-anggota', [$memberCard, 'show']);
$router->post('/kartu-anggota/login', [$memberCard, 'loginByNumber']);
$router->get('/kartu-anggota/logout', [$memberCard, 'logout']);

// Member area routes (for unified authentication member portal)
$memberPortal = new MemberPortalController();
$router->get('/member', [$memberPortal, 'index']);
$router->get('/member/card', [$memberPortal, 'card']);
$router->get('/member/profile', [$memberPortal, 'profile']);
$router->post('/member/profile/update', [$memberPortal, 'updateProfile']);

$router->get('/join',[$reg,'publicForm']);
$router->post('/join',[$reg,'publicSubmit']);
$router->get('/join/thanks',[$reg,'publicThanks']);
$router->post('/join/status',[$reg,'publicStatus']);
$router->get('/api/study-programs',[$reg,'studyProgramsAjax']);

// 3. Multi-Organization Frontend Routes (With slug prefix)
// Organization-specific admin routes (must be before general routes for proper matching)
$router->get('/{organization}/admin',[$admin,'dashboard']);
$router->get('/{organization}/admin/dashboard',[$admin,'dashboard']);
$router->get('/{organization}/admin/calendar',[$admin,'calendar']);

$router->get('/{organization}',[new FrontendController(),'home']);
$router->get('/{organization}/tentang',[new FrontendController(),'about']);
$router->get('/{organization}/kegiatan',[new FrontendController(),'events']);
$router->get('/{organization}/kegiatan/{slug}',[new FrontendController(),'event']);
$router->get('/{organization}/kalender',[new FrontendController(),'calendar']);
$router->get('/{organization}/gallery',[new FrontendController(),'gallery']);
$router->get('/{organization}/gallery/{slug}',[new FrontendController(),'galleryAlbum']);
$router->get('/{organization}/struktur',[new FrontendController(),'structure']);
$router->get('/{organization}/kontak',[new FrontendController(),'contact']);
$router->get('/{organization}/kartu-anggota', [$memberCard, 'show']);
$router->post('/{organization}/kartu-anggota/login', [$memberCard, 'loginByNumber']);
$router->get('/{organization}/kartu-anggota/logout', [$memberCard, 'logout']);

// Member area routes (for unified authentication member portal - org-specific)
$router->get('/{organization}/member', function($organization) use ($memberPortal) {
    $memberPortal->index($organization);
});
$router->get('/{organization}/member/card', function($organization) use ($memberPortal) {
    $memberPortal->card($organization);
});
$router->get('/{organization}/member/profile', function($organization) use ($memberPortal) {
    $memberPortal->profile($organization);
});
$router->post('/{organization}/member/profile/update', function($organization) use ($memberPortal) {
    $memberPortal->updateProfile($organization);
});

// Public Member Registration Routes (org-slug prefixed)
$router->get('/{organization}/join',[$reg,'publicForm']);
$router->post('/{organization}/join',[$reg,'publicSubmit']);
$router->get('/{organization}/join/thanks',[$reg,'publicThanks']);
$router->post('/{organization}/join/status',[$reg,'publicStatus']);

$router->dispatch($_SERVER['REQUEST_METHOD']??'GET',$_SERVER['REQUEST_URI']??'/');
