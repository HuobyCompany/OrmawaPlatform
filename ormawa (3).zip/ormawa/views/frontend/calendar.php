<section class="section-editorial pt-4">
  <div class="container-editorial">
    <div class="mb-4">
      <span class="editorial-label mb-2"><i class="bi bi-calendar3 me-1"></i> Jadwal Organisasi</span>
      <h1 class="display-title mb-2">Kalender Kegiatan</h1>
    </div>

    <div class="calendar-shell" data-calendar data-events='<?= e(json_encode($events, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>'>
      <div class="calendar-head">
        <button class="calendar-nav-btn" data-cal-prev aria-label="Bulan sebelumnya">
          <i class="bi bi-chevron-left"></i>
        </button>
        <div class="text-center">
          <div class="calendar-title-text" data-cal-title>Memuat Kalender...</div>
        </div>
        <button class="calendar-nav-btn" data-cal-next aria-label="Bulan berikutnya">
          <i class="bi bi-chevron-right"></i>
        </button>
      </div>

      <div class="calendar-weekdays">
        <?php foreach (['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'] as $d): ?>
          <div><?= e($d) ?></div>
        <?php endforeach; ?>
      </div>

      <div class="calendar-grid" data-cal-grid></div>
    </div>

    <div class="modal fade" id="calendarEventModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-5 overflow-hidden shadow-lg">
          <div class="modal-body p-0" data-cal-modal-body></div>
        </div>
      </div>
    </div>
  </div>
</section>
