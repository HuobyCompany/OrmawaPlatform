<?php
/** @var array $form @var array $fields @var array $faculties @var array $studyPrograms @var array $organization @var array $settings @var array $sections @var array $pages */
$errors = $_SESSION['_errors'] ?? [];
$old = $_SESSION['_old'] ?? [];
unset($_SESSION['_errors'], $_SESSION['_old']);
?>

<style>
.public-reg-bg {
    background: linear-gradient(180deg, #f4f7fc 0%, #edf2f8 100%);
    min-height: 85vh;
}
.gform-pub-card {
    background: #ffffff;
    border: 1px solid rgba(226, 232, 240, 0.8);
    box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.05);
    border-radius: 1.25rem !important;
    transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}
.gform-pub-card:hover {
    box-shadow: 0 10px 30px -4px rgba(15, 23, 42, 0.08);
}
.gform-pub-card:focus-within {
    border-color: #0066ff;
    box-shadow: 0 0 0 4px rgba(0, 102, 255, 0.08), 0 12px 32px -4px rgba(15, 23, 42, 0.1);
}
.gform-pub-header {
    border-top: 6px solid #0066ff !important;
    background: linear-gradient(180deg, #ffffff 0%, #fafbfc 100%);
}
.gform-input {
    background-color: #f8fafc;
    border: 1.5px solid #e2e8f0;
    font-size: 0.95rem;
    font-weight: 500;
    color: #1e293b;
    transition: all 0.2s ease;
}
.gform-input:focus {
    background-color: #ffffff;
    border-color: #0066ff;
    box-shadow: 0 0 0 4px rgba(0, 102, 255, 0.12);
}
.gform-input::placeholder {
    color: #94a3b8;
    font-weight: 400;
}
.gform-option-item {
    border: 1.5px solid #e2e8f0;
    background: #f8fafc;
    border-radius: 0.85rem;
    transition: all 0.2s ease;
    cursor: pointer;
}
.gform-option-item:hover {
    background: #ffffff;
    border-color: #0066ff;
}
.gform-option-item:has(input:checked) {
    background: #f0f7ff;
    border-color: #0066ff;
}
.gform-section-title {
    font-size: 0.9rem;
    font-weight: 700;
    letter-spacing: 0.03em;
    text-transform: uppercase;
    color: #0066ff;
}
</style>

<div class="public-reg-bg py-5">
  <div class="container" style="max-width: 720px;">

    <!-- Flash Error Notification -->
    <?php if (isset($_SESSION['_flash']['error'])): ?>
      <?php $msg = flash('error'); ?>
      <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 shadow-sm mb-4" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($msg) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      </div>
    <?php endif; ?>

    <!-- Form Element -->
    <form method="post" action="<?= e(org_url($organization, 'join')) ?>" enctype="multipart/form-data" id="registrationForm" novalidate>
      <?= Csrf::field() ?>

      <!-- 1. Header Card -->
      <div class="card gform-pub-card gform-pub-header border-0 rounded-4 p-4 p-md-5 mb-4">
        <div class="d-flex align-items-center gap-3 mb-3">
          <?php if (!empty($organization['logo'])): ?>
            <img src="<?= e(media_url($organization['logo'])) ?>" alt="Logo" class="rounded-circle shadow-sm" style="width: 48px; height: 48px; object-fit: cover;">
          <?php else: ?>
            <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle" style="width: 48px; height: 48px;">
              <i class="bi bi-buildings fs-4"></i>
            </div>
          <?php endif; ?>
          <div>
            <h6 class="text-uppercase fw-bold text-primary mb-0 small" style="letter-spacing: 0.5px;"><?= e($organization['short_name'] ?: $organization['name']) ?></h6>
            <div class="small text-muted">Formulir Pendaftaran Resmi</div>
          </div>
        </div>

        <h1 class="fw-bold text-dark mb-2" style="font-size: 1.85rem;"><?= e($form['title'] ?: 'Pendaftaran Anggota') ?></h1>

        <?php if (!empty($form['description'])): ?>
          <p class="text-secondary mb-3 fs-6"><?= e($form['description']) ?></p>
        <?php else: ?>
          <p class="text-secondary mb-3 fs-6">Silakan lengkapi formulir pendaftaran berikut dengan data yang valid.</p>
        <?php endif; ?>

        <div class="pt-3 border-top d-flex justify-content-between align-items-center small text-muted">
          <span><span class="text-danger fw-bold">*</span> Menunjukkan pertanyaan wajib diisi</span>
          <span class="badge bg-light text-secondary border rounded-pill px-2.5 py-1"><i class="bi bi-lock me-1"></i>Aman & Rahasia</span>
        </div>
      </div>

      <!-- 2. Section 1: Data Diri Utama (Wajib Isi Sistem) -->
      <div class="card gform-pub-card border-0 rounded-4 p-4 mb-4" style="border-top: 4px solid #007aff !important;">
        <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom">
            <i class="bi bi-person-vcard text-primary fs-5"></i>
            <h5 class="fw-bold text-dark mb-0 fs-6">Data Diri Utama (Wajib Isi)</h5>
        </div>

        <div class="row g-3">
            <div class="col-12">
                <label class="form-label fw-bold text-dark mb-1">Nama Lengkap <span class="text-danger">*</span></label>
                <input type="text" name="core_full_name" class="form-control gform-input rounded-3 py-2.5 px-3" placeholder="Masukkan nama lengkap Anda..." value="<?= e($old['core_full_name'] ?? '') ?>" required>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-bold text-dark mb-1">Fakultas <span class="text-danger">*</span></label>
                <select name="core_faculty_id" id="pubCoreFacultySelect" class="form-select gform-input rounded-3 py-2.5 px-3" required>
                    <option value="">-- Pilih Fakultas --</option>
                    <?php foreach ($faculties as $f): ?>
                        <option value="<?= $f['id'] ?>" <?= (int)($old['core_faculty_id'] ?? 0) === (int)$f['id'] ? 'selected' : '' ?>><?= e($f['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-bold text-dark mb-1">Program Studi <span class="text-danger">*</span></label>
                <select name="core_program_id" id="pubCoreProdiSelect" class="form-select gform-input rounded-3 py-2.5 px-3" required>
                    <option value="">-- Pilih Program Studi --</option>
                    <?php if (!empty($old['core_faculty_id']) && !empty($studyPrograms[$old['core_faculty_id']])): ?>
                        <?php foreach ($studyPrograms[$old['core_faculty_id']] as $sp): ?>
                            <option value="<?= $sp['id'] ?>" <?= (int)($old['core_program_id'] ?? 0) === (int)$sp['id'] ? 'selected' : '' ?>><?= e($sp['name']) ?></option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-bold text-dark mb-1">Kontak WhatsApp <span class="text-danger">*</span></label>
                <input type="tel" name="core_whatsapp" class="form-control gform-input rounded-3 py-2.5 px-3" placeholder="Contoh: 08123456789" value="<?= e($old['core_whatsapp'] ?? '') ?>" required>
                <div class="form-text small" style="font-size:0.75rem;">Nomor aktif untuk verifikasi &amp; grup keanggotaan.</div>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-bold text-dark mb-1">Angkatan Kuliah <span class="text-danger">*</span></label>
                <select name="core_batch_year" class="form-select gform-input rounded-3 py-2.5 px-3" required>
                    <option value="">-- Pilih Tahun Angkatan --</option>
                    <?php 
                    $thisYear = (int)date('Y');
                    for ($y = $thisYear; $y >= $thisYear - 6; $y--): 
                    ?>
                        <option value="<?= $y ?>" <?= (int)($old['core_batch_year'] ?? $thisYear) === $y ? 'selected' : '' ?>>Angkatan <?= $y ?></option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
      </div>

      <!-- 3. Question Cards Stack (Dynamic Fields) -->
      <?php if (!empty($fields)): ?>
        <?php foreach ($fields as $fi => $field): ?>
          <?php
          $ft = $field['field_type'];
          $fn = $field['name'];
          $label = $field['label'];
          $ph = $field['placeholder'] ?? '';
          $help = $field['help_text'] ?? '';
          $required = (int)$field['is_required'];
          $opts = RegistrationFieldModel::parseOptions($field['options_json']);
          $hasError = isset($errors[$fn]);
          $oldVal = $old[$fn] ?? '';
          ?>

          <div class="card gform-pub-card border-0 rounded-4 p-4 mb-3 <?= $hasError ? 'border border-danger' : '' ?>">
            <label class="form-label fw-bold text-dark fs-6 mb-1" for="field_<?= e($fn) ?>">
              <?= e($label) ?><?= $required ? ' <span class="text-danger">*</span>' : '' ?>
            </label>

            <?php if ($help): ?>
              <div class="small text-secondary mb-3"><i class="bi bi-info-circle me-1"></i><?= e($help) ?></div>
            <?php endif; ?>

            <div class="mt-2">
              <?php if ($ft === 'text'): ?>
                <input type="text" id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-control gform-input rounded-3 py-2.5 px-3 <?= $hasError ? 'is-invalid' : '' ?>" placeholder="<?= e($ph ?: 'Jawaban Anda') ?>" value="<?= e($oldVal) ?>" <?= $required ? 'required' : '' ?>>

              <?php elseif ($ft === 'textarea'): ?>
                <textarea id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" rows="3" class="form-control gform-input rounded-3 py-2.5 px-3 <?= $hasError ? 'is-invalid' : '' ?>" placeholder="<?= e($ph ?: 'Jawaban Anda') ?>" <?= $required ? 'required' : '' ?>><?= e($oldVal) ?></textarea>

              <?php elseif ($ft === 'number'): ?>
                <input type="number" id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-control gform-input rounded-3 py-2.5 px-3 <?= $hasError ? 'is-invalid' : '' ?>" placeholder="<?= e($ph ?: '0') ?>" value="<?= e($oldVal) ?>" <?= $required ? 'required' : '' ?>>

              <?php elseif ($ft === 'phone'): ?>
                <input type="tel" id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-control gform-input rounded-3 py-2.5 px-3 <?= $hasError ? 'is-invalid' : '' ?>" placeholder="<?= e($ph ?: '08xxxxxxxxxx') ?>" value="<?= e($oldVal) ?>" <?= $required ? 'required' : '' ?>>

              <?php elseif ($ft === 'date'): ?>
                <input type="date" id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-control gform-input rounded-3 py-2.5 px-3 <?= $hasError ? 'is-invalid' : '' ?>" value="<?= e($oldVal) ?>" <?= $required ? 'required' : '' ?>>

              <?php elseif ($ft === 'email'): ?>
                <input type="email" id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-control gform-input rounded-3 py-2.5 px-3 <?= $hasError ? 'is-invalid' : '' ?>" placeholder="<?= e($ph ?: 'nama@email.com') ?>" value="<?= e($oldVal) ?>" <?= $required ? 'required' : '' ?>>

              <?php elseif (in_array($ft, ['select', 'radio', 'checkbox'])): ?>
                <?php if ($ft === 'checkbox'): ?>
                  <div class="d-flex flex-column gap-2">
                    <?php foreach ($opts as $opt): ?>
                      <div class="form-check gform-option-item rounded-3 p-2.5 ps-4 m-0">
                        <input type="checkbox" id="field_<?= e($fn) ?>_<?= e($opt) ?>" name="<?= e($fn) ?>[]" value="<?= e($opt) ?>" class="form-check-input <?= $hasError ? 'is-invalid' : '' ?>">
                        <label class="form-check-label text-dark fw-medium ms-1" for="field_<?= e($fn) ?>_<?= e($opt) ?>"><?= e($opt) ?></label>
                      </div>
                    <?php endforeach; ?>
                  </div>
                <?php elseif ($ft === 'radio'): ?>
                  <div class="d-flex flex-column gap-2">
                    <?php foreach ($opts as $opt): ?>
                      <div class="form-check gform-option-item rounded-3 p-2.5 ps-4 m-0">
                        <input type="radio" id="field_<?= e($fn) ?>_<?= e($opt) ?>" name="<?= e($fn) ?>" value="<?= e($opt) ?>" class="form-check-input <?= $hasError ? 'is-invalid' : '' ?>">
                        <label class="form-check-label text-dark fw-medium ms-1" for="field_<?= e($fn) ?>_<?= e($opt) ?>"><?= e($opt) ?></label>
                      </div>
                    <?php endforeach; ?>
                  </div>
                <?php else: /* select */ ?>
                  <select id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-select gform-input rounded-3 py-2.5 px-3 <?= $hasError ? 'is-invalid' : '' ?>" <?= $required ? 'required' : '' ?>>
                    <option value="">-- <?= e($ph ?: 'Pilih Opsi') ?> --</option>
                    <?php foreach ($opts as $opt): ?>
                      <option value="<?= e($opt) ?>" <?= e($oldVal) === e($opt) ? 'selected' : '' ?>><?= e($opt) ?></option>
                    <?php endforeach; ?>
                  </select>
                <?php endif; ?>

              <?php elseif (in_array($ft, ['faculty_selector', 'program_study_selector'])): ?>
                <?php if ($ft === 'faculty_selector'): ?>
                  <select id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-select gform-input rounded-3 py-2.5 px-3 faculty-select <?= $hasError ? 'is-invalid' : '' ?>" data-depends-target="field_<?= e($fn) ?>" <?= $required ? 'required' : '' ?>>
                    <option value="">-- Pilih Fakultas --</option>
                    <?php foreach ($faculties as $fac): ?>
                      <option value="<?= $fac['id'] ?>" <?= (int)$oldVal === (int)$fac['id'] ? 'selected' : '' ?>><?= e($fac['name']) ?> (<?= e($fac['code']) ?>)</option>
                    <?php endforeach; ?>
                  </select>
                <?php else: /* program_study_selector */ ?>
                  <?php
                  $dependsOn = $field['config_json'] ? (json_decode($field['config_json'], true)['depends_on'] ?? null) : null;
                  $depField = null;
                  if ($dependsOn) {
                      foreach ($fields as $df) {
                          if ($df['name'] === $dependsOn) { $depField = $df; break; }
                      }
                  }
                  ?>
                  <select id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-select gform-input rounded-3 py-2.5 px-3 program-select <?= $hasError ? 'is-invalid' : '' ?>" data-depends-on="<?= e($depField ? $depField['name'] : '') ?>" data-all-programs="<?= e(json_encode($studyPrograms)) ?>" <?= $required ? 'required' : '' ?>>
                    <option value="">-- Pilih Program Studi --</option>
                    <?php
                    $savedFaculty = $old[$depField['name'] ?? ''] ?? '';
                    if ($savedFaculty && $depField): ?>
                      <?php foreach ($studyPrograms[(int)$savedFaculty] ?? [] as $sp): ?>
                        <option value="<?= $sp['id'] ?>" <?= (int)$oldVal === (int)$sp['id'] ? 'selected' : '' ?>><?= e($sp['name']) ?> (<?= e($sp['code']) ?>)</option>
                      <?php endforeach; ?>
                    <?php endif; ?>
                  </select>
                <?php endif; ?>

              <?php elseif ($ft === 'social_media'): ?>
                <?php
                $savedSocial = $old[$fn] ?? '';
                $socialData = [];
                if ($savedSocial) {
                    $decoded = json_decode($savedSocial, true);
                    if (is_array($decoded)) $socialData = $decoded;
                }
                $platforms = ['instagram' => 'Instagram', 'tiktok' => 'TikTok', 'twitter' => 'Twitter', 'linkedin' => 'LinkedIn', 'website' => 'Website'];
                ?>
                <div class="row g-2">
                  <?php foreach ($platforms as $platform => $pname): ?>
                    <div class="col-md-6">
                      <div class="input-group input-group-sm">
                        <span class="input-group-text border-0 bg-light text-muted small"><?= e($pname) ?></span>
                        <input type="url" name="<?= e($fn) ?>[<?= e($platform) ?>]" class="form-control gform-input" placeholder="<?= e($pname === 'Website' ? 'https://...' : '@username') ?>" value="<?= e($socialData[$platform] ?? '') ?>">
                      </div>
                    </div>
                  <?php endforeach; ?>
                </div>

              <?php elseif (in_array($ft, ['file_image', 'file'])): ?>
                <div class="p-3 text-center rounded-3 bg-light border border-dashed">
                  <i class="bi bi-cloud-arrow-up fs-2 text-primary mb-2 d-block"></i>
                  <input type="file" id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-control gform-input rounded-3 <?= $hasError ? 'is-invalid' : '' ?>" accept="<?= e($field['file_accept'] ?? 'image/*') ?>" <?= $required ? 'required' : '' ?>>
                  <span class="small text-muted mt-1 d-block">Format: <?= e($field['file_accept'] ?? 'Foto / PDF') ?> (Maks <?= round(((int)($field['file_max_bytes'] ?? 5242880)) / 1048576, 1) ?> MB)</span>
                </div>

              <?php else: ?>
                <input type="text" id="field_<?= e($fn) ?>" name="<?= e($fn) ?>" class="form-control gform-input rounded-3 py-2.5 px-3" placeholder="<?= e($ph) ?>" value="<?= e($oldVal) ?>" <?= $required ? 'required' : '' ?>>
              <?php endif; ?>
            </div>

            <?php if ($hasError): ?>
              <div class="text-danger small mt-2 d-flex align-items-center gap-1">
                <i class="bi bi-exclamation-circle-fill"></i>
                <span><?= e($errors[$fn]) ?></span>
              </div>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="card gform-pub-card border-0 rounded-4 p-5 text-center my-3">
          <i class="bi bi-clipboard-data fs-1 text-muted opacity-20 mb-3 d-block"></i>
          <p class="mb-0 text-secondary">Formulir belum dikonfigurasi oleh pengurus.</p>
        </div>
      <?php endif; ?>

      <!-- 3. Form Submit Bar -->
      <div class="d-flex justify-content-between align-items-center pt-3 pb-5">
        <button type="submit" class="btn btn-primary rounded-pill px-5 py-2.5 fw-bold shadow-sm d-inline-flex align-items-center gap-2">
          <i class="bi bi-send-fill"></i><span>Kirim Pendaftaran</span>
        </button>
        <button type="reset" class="btn btn-link text-decoration-none text-secondary small">
          Kosongkan Formulir
        </button>
      </div>

    </form>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Core Faculty -> Prodi Selector
    var pubFacSelect = document.getElementById('pubCoreFacultySelect');
    var pubProdiSelect = document.getElementById('pubCoreProdiSelect');
    var studyPrograms = <?php echo json_encode($studyPrograms); ?>;

    if (pubFacSelect && pubProdiSelect) {
        pubFacSelect.addEventListener('change', function() {
            var fid = this.value;
            var html = '<option value="">-- Pilih Program Studi --</option>';
            if (fid && studyPrograms[fid]) {
                studyPrograms[fid].forEach(function(p) {
                    html += '<option value="' + p.id + '">' + p.name + ' (' + p.code + ')</option>';
                });
            }
            pubProdiSelect.innerHTML = html;
        });
    }

    // Dependent select: faculty -> program study
    var facultySelects = document.querySelectorAll('.faculty-select');
    facultySelects.forEach(function(sel) {
        sel.addEventListener('change', function() {
            var fid = this.value;
            var depName = this.name;
            document.querySelectorAll('.program-select[data-depends-on="' + depName + '"]').forEach(function(psel) {
                var allPrograms = JSON.parse(psel.dataset.allPrograms || '{}');
                var html = '<option value="">-- Pilih Program Studi --</option>';
                if (fid && allPrograms[fid]) {
                    allPrograms[fid].forEach(function(p) {
                        html += '<option value="' + p.id + '">' + p.name + ' (' + p.code + ')</option>';
                    });
                }
                psel.innerHTML = html;
            });
        });
        if (sel.value) sel.dispatchEvent(new Event('change'));
    });
});

// Registration status tracking via localStorage
document.addEventListener('DOMContentLoaded', function() {
    var storageKey = 'registration_status_' + '<?php echo e($organization['slug'] ?? ""); ?>';
    var form = document.getElementById('registrationForm');
    var statusContainer = document.createElement('div');
    statusContainer.id = 'registrationStatus';
    statusContainer.style.display = 'none';

    function showStatus(message, isError, showRefresh, showClear, isApproved) {
        statusContainer.innerHTML = '';
        var alertClass = isError ? 'alert-danger' : 'alert-success';
        var alert = document.createElement('div');
        alert.className = 'alert ' + alertClass + ' alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm';
        alert.setAttribute('role', 'alert');
        alert.innerHTML = '<i class="bi bi-' + (isError ? 'exclamation-circle-fill' : 'patch-check-fill') + ' fs-5 me-2"></i><strong>' + message + '</strong>';
        statusContainer.appendChild(alert);

        var btnGroup = document.createElement('div');
        btnGroup.className = 'd-flex justify-content-center gap-2 flex-wrap mt-3';

        if (isApproved) {
            var ktaBtn = document.createElement('a');
            ktaBtn.href = '<?php echo e(org_url($organization, "kartu-anggota")); ?>';
            ktaBtn.className = 'btn btn-success btn-lg rounded-pill px-4 py-2.5 fw-bold shadow-sm d-inline-flex align-items-center gap-2';
            ktaBtn.innerHTML = '<i class="bi bi-person-vcard fs-5"></i><span>Lihat & Cetak Kartu Anggota Digital (KTA)</span>';
            btnGroup.appendChild(ktaBtn);
        } else {
            if (showRefresh) {
                var refreshBtn = document.createElement('button');
                refreshBtn.type = 'button';
                refreshBtn.className = 'btn btn-outline-primary rounded-pill px-4';
                refreshBtn.innerHTML = '<i class="bi bi-arrow-clockwise me-1"></i> Refresh Status';
                refreshBtn.addEventListener('click', checkStatus);
                btnGroup.appendChild(refreshBtn);
            }
        }

        if (showClear) {
            var clearBtn = document.createElement('button');
            clearBtn.type = 'button';
            clearBtn.className = 'btn btn-outline-secondary rounded-pill px-4';
            clearBtn.innerHTML = '<i class="bi bi-person-plus me-1"></i> Daftar Dengan Data Lain';
            clearBtn.addEventListener('click', function() {
                localStorage.removeItem(storageKey);
                statusContainer.style.display = 'none';
                if (form) form.style.display = '';
            });
            btnGroup.appendChild(clearBtn);
        }

        statusContainer.appendChild(btnGroup);
        statusContainer.style.display = 'block';
        if (form) form.style.display = 'none';
    }

    function checkStatus() {
        var stored = localStorage.getItem(storageKey);
        if (!stored) return;
        try {
            var data = JSON.parse(stored);
        } catch (e) {
            localStorage.removeItem(storageKey);
            if (form) form.style.display = '';
            return;
        }
        var reference = data.reference;
        var token = data.token;
        if (!reference || !token) {
            localStorage.removeItem(storageKey);
            if (form) form.style.display = '';
            return;
        }

        var formData = new FormData();
        formData.append('reference', reference);
        formData.append('token', token);

        var statusUrl = '<?php echo e(org_url($organization, "join/status")); ?>';

        fetch(statusUrl, { method: 'POST', body: formData, credentials: 'same-origin' })
            .then(function(r) { return r.json(); })
            .then(function(res) {
                if (!res.ok) {
                    localStorage.removeItem(storageKey);
                    if (form) form.style.display = '';
                    return;
                }
                var status = res.status;
                data.status = status;
                localStorage.setItem(storageKey, JSON.stringify(data));
                if (status === 'approved') {

                    showStatus('Selamat! Pendaftaran Anda telah disetujui. Kartu Anggota Digital (KTA) Anda telah diterbitkan.', false, false, false, true);
                } else if (status === 'pending') {
                    showStatus('Pendaftaran Anda sudah diterima dan sedang menunggu persetujuan pengurus.', false, true, true, false);
                } else if (status === 'rejected') {
                    showStatus('Pendaftaran Anda tidak disetujui oleh pengurus.', true, true, true, false);
                } else {
                    showStatus('Status: ' + status, false, true, true, false);
                }
            })
            .catch(function() {
                // Network error - keep form visible
            });
    }

    var stored = localStorage.getItem(storageKey);
    if (stored) {
        if (form) {
            form.parentNode.insertBefore(statusContainer, form.nextSibling);
            checkStatus();
        }
    }
});
</script>
