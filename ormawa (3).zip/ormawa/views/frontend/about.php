<section class="section-editorial pt-4 pb-5">
  <div class="container-editorial">
    <div class="section-header mb-4">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-info-circle me-1"></i> Profil Lengkap</div>
        <h1 class="display-title mb-2">Tentang Organisasi</h1>
        <p class="editorial-lead mb-0"><?= e($organization['name']) ?></p>
      </div>
    </div>

    <!-- Row 1: About Profil + Nilai Utama -->
    <div class="row g-4 mb-4 align-items-stretch">
      <div class="col-lg-7">
        <div class="editorial-card p-4 p-md-5 h-100 bg-white rounded-4 shadow-sm border border-light-subtle">
          <div class="d-flex align-items-center gap-2 mb-3 text-primary fw-bold" style="font-size:0.85rem; letter-spacing:0.05em; text-transform:uppercase;">
            <span class="d-inline-flex align-items-center justify-content-center bg-primary-subtle text-primary rounded-3 p-2" style="width:36px;height:36px;">
              <i class="bi bi-building fs-5"></i>
            </span>
            <span>Profil &amp; Latar Belakang</span>
          </div>
          <div class="editorial-body" style="font-size: 1rem; line-height: 1.85; color: #2d3748;">
            <?= clean_rich($organization['about'] ?: '<p class="text-muted">Belum ada informasi tentang organisasi.</p>') ?>
          </div>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="editorial-card p-4 p-md-5 h-100 bg-white rounded-4 shadow-sm border border-light-subtle">
          <div class="d-flex align-items-center gap-2 mb-3 text-warning-emphasis fw-bold" style="font-size:0.85rem; letter-spacing:0.05em; text-transform:uppercase;">
            <span class="d-inline-flex align-items-center justify-content-center bg-warning-subtle text-warning-emphasis rounded-3 p-2" style="width:36px;height:36px;">
              <i class="bi bi-gem fs-5"></i>
            </span>
            <span>Prinsip &amp; Nilai Utama</span>
          </div>
          <div class="editorial-body" style="font-size: 0.95rem; line-height: 1.75; color: #2d3748;">
            <?= clean_rich($organization['values_text'] ?: '<p class="text-muted">Belum diatur.</p>') ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Row 2: Visi & Misi Cards -->
    <div class="row g-4">
      <div class="col-md-6">
        <div class="editorial-card p-4 p-md-5 h-100 bg-white rounded-4 shadow-sm border border-light-subtle">
          <div class="d-flex align-items-center gap-3 mb-3">
            <span class="d-inline-flex align-items-center justify-content-center bg-info-subtle text-info-emphasis rounded-3 p-2" style="width:44px;height:44px;">
              <i class="bi bi-compass fs-4"></i>
            </span>
            <h3 class="h4 fw-bold mb-0" style="color: #1a202c;">Visi Organisasi</h3>
          </div>
          <div class="editorial-body" style="font-size: 0.95rem; line-height: 1.75; color: #2d3748;">
            <?= clean_rich($organization['vision'] ?: '<p class="text-muted">Belum diatur.</p>') ?>
          </div>
        </div>
      </div>

      <div class="col-md-6">
        <div class="editorial-card p-4 p-md-5 h-100 bg-white rounded-4 shadow-sm border border-light-subtle">
          <div class="d-flex align-items-center gap-3 mb-3">
            <span class="d-inline-flex align-items-center justify-content-center bg-success-subtle text-success rounded-3 p-2" style="width:44px;height:44px;">
              <i class="bi bi-bullseye fs-4"></i>
            </span>
            <h3 class="h4 fw-bold mb-0" style="color: #1a202c;">Misi Organisasi</h3>
          </div>
          <div class="editorial-body" style="font-size: 0.95rem; line-height: 1.75; color: #2d3748;">
            <?= clean_rich($organization['mission'] ?: '<p class="text-muted">Belum diatur.</p>') ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

