<section class="section-editorial pt-4">
  <div class="container-editorial">
    <div class="section-header mb-5">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-images me-1"></i> Arsip Dokumentasi</div>
        <h1 class="display-title mb-2">Galeri Foto</h1>
        <p class="editorial-lead">Momen berharga kegiatan dan aktivitas organisasi.</p>
      </div>
    </div>

    <!-- Filter Bar -->
    <div class="filter-bar mb-5">
      <form class="row g-2 align-items-end" method="get">
        <div class="col-md-5">
          <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" name="q" value="<?= e($filters['q'] ?? '') ?>" placeholder="Cari judul album...">
          </div>
        </div>
        <div class="col-6 col-md-3">
          <select class="form-select-editorial" name="category" aria-label="Kategori">
            <option value="">Semua Kategori</option>
            <?php foreach (($categories ?? []) as $cat): ?>
              <option value="<?= e($cat['category']) ?>" <?= ($filters['category'] ?? '') === $cat['category'] ? 'selected' : '' ?>>
                <?= e($cat['category']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-6 col-md-2">
          <select class="form-select-editorial" name="year" aria-label="Tahun">
            <option value="">Semua Tahun</option>
            <?php foreach (($years ?? []) as $year): ?>
              <option value="<?= e($year['year']) ?>" <?= ($filters['year'] ?? '') == $year['year'] ? 'selected' : '' ?>>
                <?= e($year['year']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-12 col-md-2">
          <button type="submit" class="btn-editorial-primary w-100">
            <span>Filter</span>
          </button>
        </div>
      </form>
    </div>

    <?php if (!$albums): ?>
      <div class="empty-state-editorial">
        <i class="bi bi-images"></i>
        <p class="editorial-body">Belum ada album dokumentasi.</p>
      </div>
    <?php else: ?>
      <div class="gallery-masonry">
        <?php foreach ($albums as $album): 
          $coverSrc = '';
          if (!empty($album['cover_image'])) {
              $coverSrc = media_url($album['cover_image']);
          }
        ?>
          <a href="<?= e(org_url($organization, '/gallery/' . $album['slug'])) ?>" class="gallery-item-editorial">
            <div class="gallery-item-media">
              <?php if ($coverSrc): ?>
                <img src="<?= $coverSrc ?>" loading="lazy" alt="<?= e($album['title']) ?>">
              <?php elseif (DEBUG_DUMMY_IMAGES): ?>
                <img src="<?= dummy_image_url('album-fallback', 800, 600) ?>" loading="lazy" alt="<?= e($album['title']) ?>">
              <?php else: ?>
                <div class="gallery-item-fallback"><i class="bi bi-images"></i></div>
              <?php endif; ?>
              <div class="gallery-item-overlay">
                <span class="gallery-item-count"><i class="bi bi-camera me-1"></i> <?= (int)($album['photo_count'] ?? 0) ?> Foto</span>
              </div>
            </div>
            <div class="gallery-item-meta">
              <div class="small text-secondary mb-1">
                <i class="bi bi-calendar3 me-1"></i> <?= e(format_date_id($album['event_date'])) ?>
                <?php if (!empty($album['category'])): ?>
                  • <span class="text-primary fw-semibold"><?= e($album['category']) ?></span>
                <?php endif; ?>
              </div>
              <h2 class="h6 fw-bold mb-0 text-truncate"><?= e($album['title']) ?></h2>
            </div>
          </a>
        <?php endforeach; ?>
      </div>

      <?php if (($pagination['total_pages'] ?? 1) > 1): ?>
        <nav class="mt-5" aria-label="Pagination">
          <ul class="pagination justify-content-center gap-1">
            <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
              <li class="page-item <?= $i == ($pagination['page'] ?? 1) ? 'active' : '' ?>">
                <a class="page-link-editorial" href="<?= e(org_url($organization, '/gallery') . '?page=' . $i . '&q=' . urlencode($filters['q'] ?? '') . '&category=' . urlencode($filters['category'] ?? '') . '&year=' . urlencode($filters['year'] ?? '')) ?>">
                  <?= $i ?>
                </a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
