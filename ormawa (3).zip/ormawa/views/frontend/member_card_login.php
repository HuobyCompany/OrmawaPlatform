<?php
/** @var array $organization */
$orgName = $organization['name'] ?? 'ORMAWA';
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-5">

            <div class="text-center mb-4">
                <div class="d-inline-flex p-3 rounded-circle bg-primary bg-opacity-10 text-primary mb-3 shadow-sm">
                    <i class="bi bi-person-vcard fs-1"></i>
                </div>
                <h1 class="h3 fw-bold text-dark mb-1">Akses Kartu Anggota Digital</h1>
                <p class="text-secondary small mb-0">Masukkan Nama Lengkap &amp; Nomor Anggota Anda sebagai verifikasi untuk melihat Kartu Tanda Anggota <?= e($orgName) ?></p>
            </div>

            <?php if (!empty($flash_error)): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($flash_error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (!empty($flash_success)): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i><?= e($flash_success) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm rounded-5 p-4 p-md-5 bg-white">
                <form method="post" action="<?= e(org_url($organization ?? null, 'login')) ?>">
                    <?= Csrf::field() ?>

                    <div class="mb-3">
                        <label class="form-label small fw-bold text-dark mb-1">Nama Lengkap / Email / ID</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light border-0 rounded-start-pill ps-3 text-primary"><i class="bi bi-person"></i></span>
                            <input class="form-control border-0 bg-light rounded-end-pill fw-medium text-dark" type="text" name="login_input" placeholder="Masukkan nama lengkap, email, atau ID..." required autocomplete="username">
                        </div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label small fw-bold text-dark mb-1">Nomor Anggota (Kata Sandi)</label>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text bg-light border-0 rounded-start-pill ps-3 text-primary"><i class="bi bi-shield-lock"></i></span>
                            <input class="form-control border-0 bg-light rounded-end-pill font-monospace fw-bold text-dark" type="password" name="password" placeholder="Nomor Anggota 8-Digit" required autocomplete="current-password">
                        </div>
                        <div class="form-text small mt-2 text-secondary" style="font-size: 0.78rem;">
                            <i class="bi bi-info-circle me-1 text-primary"></i>Masukkan 8-digit Nomor Anggota Anda (contoh: <strong>24260001</strong>).
                        </div>
                    </div>

                    <button type="submit" class="btn btn-dark w-100 py-3 rounded-pill fw-bold d-flex align-items-center justify-content-center gap-2 shadow-sm">
                        <span>Masuk &amp; Buka Kartu Anggota</span>
                        <i class="bi bi-arrow-right"></i>
                    </button>
                </form>

                <div class="mt-4 pt-3 border-top text-center">
                    <p class="small text-secondary mb-1">Belum mendaftar sebagai anggota?</p>
                    <a href="<?= e(org_url($organization ?? null, 'join')) ?>" class="fw-bold text-primary text-decoration-none">
                        Daftar Anggota Baru <i class="bi bi-arrow-right me-1"></i>
                    </a>
                </div>
            </div>

        </div>
    </div>
</div>
