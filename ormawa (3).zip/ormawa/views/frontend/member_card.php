<?php
/** @var array $member @var array $organization @var string|null $photoPath @var array $values */
$orgName = $member['organization_name'] ?? $organization['name'] ?? 'ORMAWA';
$orgLogo = $member['organization_logo'] ?? $organization['logo'] ?? null;
$memberNum = $member['member_number'] ?? '00000000';
$fullName = $member['full_name'] ?? 'Nama Anggota';
$faculty = $member['faculty_name'] ?? '-';
$prodi = $member['prodi_name'] ?? '-';
$angkatan = $member['batch_year'] ?? date('Y');
$reference = $member['public_reference'] ?? ('ID #' . $member['id']);
$approvedDate = format_date_id($member['reviewed_at'] ?: $member['created_at']);
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-xl-7">

            <!-- Welcome Header -->
            <div class="text-center mb-4">
                <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3 py-1.5 fw-bold mb-2">
                    <i class="bi bi-shield-check me-1"></i> Sesi Aktif 1 Tahun (Login Otomatis)
                </span>
                <h1 class="h3 fw-bold text-dark mb-1">Kartu Tanda Anggota Digital</h1>
                <p class="text-secondary small mb-0">Kartu resmi keanggotaan <?= e($orgName) ?></p>
            </div>

            <?php if ($flash_success): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i><?= e($flash_success) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Digital ID Card Container -->
            <div class="card border-0 shadow-lg rounded-5 overflow-hidden mb-4" id="printableMemberCard" style="background: linear-gradient(135deg, #1c1c1e 0%, #2c2c2e 100%); color: #ffffff; position: relative;">
                
                <!-- Background Metallic Accent Overlay -->
                <div style="position: absolute; top: -50px; right: -50px; width: 220px; height: 220px; background: radial-gradient(circle, rgba(0,122,255,0.25) 0%, rgba(0,0,0,0) 70%); border-radius: 50%; pointer-events: none;"></div>
                <div style="position: absolute; bottom: -60px; left: -60px; width: 260px; height: 260px; background: radial-gradient(circle, rgba(52,199,89,0.2) 0%, rgba(0,0,0,0) 70%); border-radius: 50%; pointer-events: none;"></div>

                <!-- Card Top Header Bar -->
                <div class="p-4 border-bottom border-secondary border-opacity-25 d-flex align-items-center justify-content-between relative-z">
                    <div class="d-flex align-items-center gap-3">
                        <?php if ($orgLogo): ?>
                            <img src="<?= e(media_url($orgLogo)) ?>" alt="Logo" class="rounded-3 bg-white p-1" style="width: 44px; height: 44px; object-fit: contain;">
                        <?php else: ?>
                            <div class="bg-primary text-white rounded-3 d-grid place-items-center fw-bold" style="width: 44px; height: 44px; font-size: 1.2rem; display: grid;">
                                <i class="bi bi-buildings"></i>
                            </div>
                        <?php endif; ?>
                        <div>
                            <div class="fw-bold text-white mb-0" style="font-size: 0.95rem; letter-spacing: -0.01em;"><?= e($orgName) ?></div>
                            <div class="text-secondary small" style="font-size: 0.72rem; letter-spacing: 0.08em; text-transform: uppercase;">KARTU TANDA ANGGOTA RESMI</div>
                        </div>
                    </div>
                    <span class="badge rounded-pill bg-success text-white px-3 py-1.5 fw-bold" style="font-size: 0.72rem;">
                        ● AKTIF
                    </span>
                </div>

                <!-- Card Main Body -->
                <div class="p-4 p-md-5 relative-z">
                    <div class="row align-items-center g-4">
                        
                        <!-- Left: Photo & Member Number -->
                        <div class="col-md-4 text-center">
                            <div class="position-relative d-inline-block mb-3">
                                <?php if ($photoPath): ?>
                                    <img src="<?= e(media_url($photoPath)) ?>" alt="Foto Anggota" class="rounded-4 border border-2 border-white shadow" style="width: 120px; height: 145px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="rounded-4 border border-2 border-white shadow bg-secondary bg-opacity-25 d-grid place-items-center text-white" style="width: 120px; height: 145px; display: grid;">
                                        <i class="bi bi-person-fill display-4 opacity-75"></i>
                                    </div>
                                <?php endif; ?>
                                <span class="position-absolute bottom-0 start-50 translate-middle-x badge bg-primary rounded-pill px-2.5 py-1 text-white shadow" style="font-size: 0.65rem;">
                                    Angkatan <?= e($angkatan) ?>
                                </span>
                            </div>

                            <div class="small text-secondary fw-semibold text-uppercase" style="font-size: 0.68rem; letter-spacing: 0.08em;">Nomor Anggota</div>
                            <div class="font-monospace fw-bold text-warning h5 mb-0" style="letter-spacing: 0.1em; text-shadow: 0 2px 4px rgba(0,0,0,0.5);" id="cardMemberNumText">
                                <?= e($memberNum) ?>
                            </div>
                        </div>

                        <!-- Right: Details Grid -->
                        <div class="col-md-8">
                            <div class="mb-3">
                                <div class="text-secondary small fw-semibold text-uppercase" style="font-size: 0.68rem; letter-spacing: 0.08em;">Nama Lengkap</div>
                                <div class="h4 fw-bold text-white mb-0" style="letter-spacing: -0.02em;"><?= e($fullName) ?></div>
                            </div>

                            <div class="row g-3">
                                <div class="col-6">
                                    <div class="text-secondary small fw-semibold text-uppercase" style="font-size: 0.68rem; letter-spacing: 0.08em;">Fakultas</div>
                                    <div class="fw-semibold text-light small text-truncate"><?= e($faculty) ?></div>
                                </div>
                                <div class="col-6">
                                    <div class="text-secondary small fw-semibold text-uppercase" style="font-size: 0.68rem; letter-spacing: 0.08em;">Program Studi</div>
                                    <div class="fw-semibold text-light small text-truncate"><?= e($prodi) ?></div>
                                </div>
                                <div class="col-6">
                                    <div class="text-secondary small fw-semibold text-uppercase" style="font-size: 0.68rem; letter-spacing: 0.08em;">WhatsApp</div>
                                    <div class="fw-semibold text-success small font-monospace"><?= e($member['whatsapp'] ?: '-') ?></div>
                                </div>
                                <div class="col-6">
                                    <div class="text-secondary small fw-semibold text-uppercase" style="font-size: 0.68rem; letter-spacing: 0.08em;">Ref Pendaftaran</div>
                                    <div class="fw-semibold text-light small font-monospace"><?= e($reference) ?></div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Card Bottom Footer Bar with Barcode/QR Representation -->
                <div class="p-3 px-4 bg-black bg-opacity-40 border-top border-secondary border-opacity-25 d-flex align-items-center justify-content-between relative-z">
                    <div class="small text-secondary" style="font-size: 0.72rem;">
                        <i class="bi bi-check-circle-fill text-success me-1"></i> Terverifikasi Sistem • Tanggal Disetujui: <?= e($approvedDate) ?>
                    </div>
                    <div class="font-monospace text-secondary small opacity-75" style="font-size: 0.7rem;">
                        <?= e($memberNum) ?>
                    </div>
                </div>

            </div>

            <!-- Action Buttons -->
            <div class="d-flex flex-wrap gap-2 justify-content-center">
                <button type="button" class="btn btn-dark rounded-pill px-4 py-2 fw-bold d-inline-flex align-items-center gap-2 shadow-sm" onclick="window.print()">
                    <i class="bi bi-printer-fill"></i>
                    <span>Cetak / Simpan Kartu</span>
                </button>
                <button type="button" class="btn btn-outline-secondary rounded-pill px-3 py-2 fw-semibold d-inline-flex align-items-center gap-1.5" onclick="copyMemberNumber('<?= e($memberNum) ?>')">
                    <i class="bi bi-clipboard"></i>
                    <span>Salin Nomor Anggota</span>
                </button>
                <a href="<?= url('/kartu-anggota/logout') ?>" class="btn btn-light rounded-pill px-3 py-2 text-danger fw-semibold d-inline-flex align-items-center gap-1.5 border">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Keluar Sesi</span>
                </a>
            </div>

        </div>
    </div>
</div>

<style>
@media print {
    body * { visibility: hidden; }
    #printableMemberCard, #printableMemberCard * { visibility: visible; }
    #printableMemberCard {
        position: absolute;
        left: 0;
        top: 0;
        width: 100% !important;
        margin: 0 !important;
        box-shadow: none !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
}
</style>

<script>
function copyMemberNumber(num) {
    navigator.clipboard.writeText(num).then(function() {
        alert('Nomor Anggota (' + num + ') berhasil disalin ke clipboard!');
    }).catch(function() {
        alert('Nomor Anggota: ' + num);
    });
}
</script>
