<section class="section-editorial pt-4">
  <div class="container-editorial">
    <div class="mb-4">
      <a class="btn-editorial-secondary" href="<?= org_url($organization, '/gallery') ?>">
        <i class="bi bi-chevron-left"></i>
        <span>Kembali ke Galeri</span>
      </a>
    </div>

    <div class="album-header mb-5">
      <span class="editorial-label mb-2"><i class="bi bi-images me-1"></i> Detail Album</span>
      <h1 class="display-title mb-2" style="font-size: clamp(2rem, 4vw, 3rem);"><?= e($album['title']) ?></h1>
      <div class="small text-secondary mb-3">
        <i class="bi bi-calendar3 me-1"></i> <?= e(format_date_id($album['event_date'])) ?> • <?= count($items) ?> Foto Dokumentasi
        <?php if (!empty($album['category'])): ?>
          • <span class="badge rounded-pill bg-light text-primary border"><?= e($album['category']) ?></span>
        <?php endif; ?>
        <?php if ($album['source_type'] === 'google_drive'): ?>
          • <span class="badge rounded-pill bg-success text-white border"><i class="bi bi-google-drive me-1"></i>Google Drive</span>
        <?php elseif ($album['source_type'] === 'remote_url'): ?>
          • <span class="badge rounded-pill bg-info text-white border"><i class="bi bi-link-45deg me-1"></i>URL Gambar</span>
        <?php endif; ?>
      </div>
      <?php if ($album['description']): ?>
        <div class="p-3 rounded-4 bg-light border editorial-body" style="line-height: 1.7; max-width: 720px;">
          <?= clean_rich($album['description']) ?>
        </div>
      <?php endif; ?>
    </div>

    <div class="gallery-masonry" style="--gallery-columns:<?= (int)($settings['gallery_columns'] ?? 3) ?>;--gallery-gap:<?= (int)($settings['gallery_gap'] ?? 16) ?>px;--gallery-radius:<?= (int)($settings['gallery_radius'] ?? 20) ?>px;">
      <?php foreach ($items as $item): 
        $thumbSrc = '';
        $fullSrc = '';
        if ($item['source_type'] === 'google_drive') {
            $thumbSrc = !empty($item['thumbnail_url']) ? $item['thumbnail_url'] : ($item['drive_url'] ?: '');
            $fullSrc = $item['drive_url'] ?: $thumbSrc;
        } elseif ($item['source_type'] === 'remote_url') {
            $thumbSrc = !empty($item['thumbnail_url']) ? $item['thumbnail_url'] : ($item['remote_url'] ?: '');
            $fullSrc = $item['remote_url'] ?: $thumbSrc;
        } else {
            $thumbSrc = thumbnail_url($item['file_path']);
            $fullSrc = media_url($item['file_path']);
        }
      ?>
        <button type="button" class="gallery-item-editorial border-0 p-0" data-lightbox-item data-src="<?= e($fullSrc) ?>" data-caption="<?= e($item['caption'] ?: $album['title']) ?>" aria-label="Lihat foto">
          <img src="<?= e($thumbSrc) ?>" loading="lazy" alt="<?= e($item['alt_text'] ?: $item['caption'] ?: $album['title']) ?>">
        </button>
      <?php endforeach; ?>
    </div>
  </div>
</section>
