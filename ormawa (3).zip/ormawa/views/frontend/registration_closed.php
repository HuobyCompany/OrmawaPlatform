<div class="public-reg-bg py-5 min-vh-50 d-flex align-items-center">
  <div class="container" style="max-width: 600px;">
    <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white">
      <div class="d-inline-flex align-items-center justify-content-center mb-4 mx-auto" style="width: 80px; height: 80px; border-radius: 50%; background: rgba(220,53,69,.08);">
        <i class="bi bi-clipboard-x fs-1 text-danger"></i>
      </div>
      <h2 class="fw-bold text-dark mb-2">Pendaftaran Ditutup</h2>
      <p class="fs-6 text-secondary mb-3">Pendaftaran anggota untuk <strong><?= e($organization['short_name'] ?: $organization['name']) ?></strong> saat ini sedang tidak dibuka.</p>
      <?php if ($registrationEnabled === false): ?>
        <p class="small text-muted mb-4">Pengurus organisasi belum mengaktifkan periode pendaftaran. Silakan cek kembali di lain waktu.</p>
      <?php else: ?>
        <p class="small text-muted mb-4">Formulir pendaftaran sedang disiapkan oleh pengurus. Silakan hubungi kontak organisasi jika ada pertanyaan.</p>
      <?php endif; ?>
      <div>
        <a href="<?= e(org_url($organization)) ?>" class="btn btn-dark rounded-pill px-4 py-2 fw-semibold">
          <i class="bi bi-house-door me-1"></i> Kembali ke Beranda
        </a>
      </div>
    </div>
  </div>
</div>
