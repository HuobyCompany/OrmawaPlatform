<?php 
$sectionMap = []; 
foreach ($sections as $sx) {
    $sectionMap[$sx['section_key']] = $sx;
}

$upcomingEvents = array_values(array_filter($events ?? [], fn($e) => strtotime($e['event_date']) >= strtotime('today')));
$featuredEvent = $upcomingEvents[0] ?? null;
$moreEvents = array_slice($upcomingEvents, 1, 3);
$albumsPreview = array_slice($albums ?? [], 0, 4);
$roots = array_values(array_filter($positions, fn($p) => empty($p['parent_id'])));
?>

<?php if (($sectionMap['hero']['status'] ?? 1) || !empty($organization['hero_image']) || !empty($organization['hero_title']) || !empty($organization['description'])): ?>
<!-- Hero Section -->
<section class="hero-editorial">
  <div class="hero-media">
    <?php if (!empty($organization['hero_image'])): ?>
      <img src="<?= e(upload_url($organization['hero_image'])) ?>" alt="<?= e($organization['name']) ?>" loading="eager">
    <?php elseif (DEBUG_DUMMY_IMAGES): ?>
      <img src="<?= dummy_image_url('hero-fallback', 1600, 900) ?>" alt="<?= e($organization['name']) ?>" loading="eager">
    <?php else: ?>
      <div class="hero-media-fallback">
        <div class="hero-icon"><i class="bi bi-mortarboard"></i></div>
        <div class="hero-fallback-text"><?= e($organization['short_name'] ?: $organization['name']) ?></div>
      </div>
    <?php endif; ?>
    <div class="hero-media-overlay"></div>
  </div>
  <div class="container-editorial">
    <div class="hero-content">
      <?php if (!empty($organization['tagline'])): ?>
        <div class="editorial-label mb-3">
          <span class="hero-dot"></span>
          <?= e($organization['tagline']) ?>
        </div>
      <?php endif; ?>
      <h1 class="display-display text-white mb-4">
        <?= e($organization['website_name'] ?: $organization['name']) ?>
      </h1>
      <p class="editorial-lead text-white opacity-90 mb-5" style="max-width: 580px;">
        <?= e($organization['description']) ?>
      </p>
      <div class="d-flex flex-wrap gap-3">
                      <a href="<?= e(org_url($organization, 'login')) ?>" class="btn-editorial-primary">
                <span>Login</span>
                <i class="bi bi-box-arrow-in-right"></i>
            </a>
          <?php if ($upcomingEvents): ?>
              <a href="#upcoming" class="btn-editorial-ghost text-white">
                  <span>Agenda &amp; Prokerja</span>
                  <i class="bi bi-calendar2-event"></i>
              </a>
          <?php endif; ?>
        </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if ($featuredEvent || ($sectionMap['events']['status'] ?? 1)): ?>
<!-- Upcoming Activity -->
<section class="section-editorial" id="upcoming">
  <div class="container-editorial">
    <div class="section-header">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-calendar2-event me-1"></i> Agenda & Kegiatan</div>
        <h2 class="section-title">Kegiatan Mendatang</h2>
      </div>
      <?php if ($moreEvents): ?>
        <a href="<?= e(org_url($organization, 'kegiatan')) ?>" class="btn-editorial-secondary">
          <span>Semua Kegiatan</span>
          <i class="bi bi-arrow-right"></i>
        </a>
      <?php endif; ?>
    </div>

    <?php if ($featuredEvent): 
      $dt = strtotime($featuredEvent['event_date']);
      $monthName = date('F', $dt);
      $dayNum = date('d', $dt);
      $year = date('Y', $dt);
    ?>
      <article class="event-featured">
        <a href="<?= e(org_url($organization, 'kegiatan/' . $featuredEvent['slug'])) ?>" class="event-featured-link">
          <div class="event-featured-media">
            <?php if ($featuredEvent['poster']): ?>
              <img src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('event-poster', 1200, 675) : e(upload_url($featuredEvent['poster'])) ?>" alt="Poster <?= e($featuredEvent['title']) ?>" loading="lazy">
            <?php elseif (DEBUG_DUMMY_IMAGES): ?>
              <img src="<?= dummy_image_url('event-poster-fallback', 1200, 675) ?>" alt="Poster <?= e($featuredEvent['title']) ?>" loading="lazy">
            <?php else: ?>
              <div class="event-featured-fallback">
                <i class="bi bi-calendar-event"></i>
              </div>
            <?php endif; ?>
            <div class="event-date-badge">
              <div class="event-date-month"><?= e(ucfirst(substr($monthName, 0, 3))) ?></div>
              <div class="event-date-day"><?= e($dayNum) ?></div>
              <div class="event-date-year"><?= e($year) ?></div>
            </div>
          </div>
          <div class="event-featured-body">
            <div class="event-meta">
              <?php if (!empty($featuredEvent['location'])): ?>
                <span><i class="bi bi-geo-alt me-1"></i><?= e($featuredEvent['location']) ?></span>
              <?php endif; ?>
              <span><i class="bi bi-clock me-1"></i><?= e(substr($featuredEvent['start_time'], 0, 5)) ?> WIB</span>
            </div>
            <h3 class="event-featured-title"><?= e($featuredEvent['title']) ?></h3>
            <p class="editorial-body"><?= e(excerpt(strip_tags($featuredEvent['description']), 140)) ?></p>
            <div class="event-cta">
              <span>Lihat Detail Agenda</span>
              <i class="bi bi-arrow-right"></i>
            </div>
          </div>
        </a>
      </article>
    <?php endif; ?>

    <?php if ($moreEvents): ?>
      <div class="event-list">
        <?php foreach ($moreEvents as $ev): 
          $dt = strtotime($ev['event_date']);
          $m = date('M', $dt);
          $d = date('d', $dt);
        ?>
          <a href="<?= e(org_url($organization, 'kegiatan/' . $ev['slug'])) ?>" class="event-list-item">
            <div class="event-list-date">
              <div class="event-list-month"><?= e($m) ?></div>
              <div class="event-list-day"><?= e($d) ?></div>
            </div>
            <div class="event-list-body">
              <h4 class="event-list-title"><?= e($ev['title']) ?></h4>
              <div class="event-list-meta">
                <?php if (!empty($ev['location'])): ?>
                  <span><i class="bi bi-geo-alt me-1"></i><?= e(excerpt($ev['location'], 25)) ?></span>
                <?php endif; ?>
                <span><i class="bi bi-clock me-1"></i><?= e(substr($ev['start_time'], 0, 5)) ?> WIB</span>
              </div>
            </div>
            <div class="event-list-arrow"><i class="bi bi-chevron-right"></i></div>
          </a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if (!$upcomingEvents && ($sectionMap['events']['status'] ?? 1)): ?>
      <div class="empty-state-editorial">
        <i class="bi bi-calendar2-check"></i>
        <p class="editorial-body">Belum ada agenda kegiatan yang dipublikasikan.</p>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<?php if (($sectionMap['about']['status'] ?? 1) || ($sectionMap['vision_mission']['status'] ?? 1)): ?>
<!-- Profil Organisasi -->
<section class="section-editorial" id="about">
  <div class="container-editorial">
    <div class="section-header">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-info-circle me-1"></i> Tentang Kami</div>
        <h2 class="section-title">Profil & Peran Organisasi</h2>
      </div>
      <?php if ($sectionMap['about']['status'] ?? 1): ?>
        <a href="<?= e(org_url($organization, 'tentang')) ?>" class="btn-editorial-secondary">
          <span>Profil Selengkapnya</span>
          <i class="bi bi-arrow-right"></i>
        </a>
      <?php endif; ?>
    </div>

    <div class="row g-4 g-lg-5 align-items-center">
      <div class="col-lg-5">
        <p class="editorial-lead">
          <?= e($organization['description']) ?>
        </p>
        <div class="editorial-body mt-3">
          <?= e(excerpt(strip_tags($organization['about']), 220)) ?>
        </div>
      </div>
      <div class="col-lg-7">
        <div class="about-visual">
           <?php if (!empty($organization['hero_image'])): ?>
             <img src="<?= e(upload_url($organization['hero_image'])) ?>" alt="<?= e($organization['name']) ?>" loading="lazy">
           <?php elseif (DEBUG_DUMMY_IMAGES): ?>
             <img src="<?= dummy_image_url('about-hero-fallback', 1200, 900) ?>" alt="<?= e($organization['name']) ?>" loading="lazy">
           <?php else: ?>
             <div class="about-visual-fallback">
               <i class="bi bi-mortarboard"></i>
             </div>
           <?php endif; ?>
          <div class="about-visual-caption">
            <div class="editorial-label">Inkubator Mahasiswa</div>
            <div class="about-visual-caption-text"><?= e($organization['short_name'] ?: $organization['name']) ?> berkomitmen membina intelektualitas, karakter kepemimpinan, dan kontribusi nyata bagi kampus.</div>
          </div>
        </div>
      </div>
    </div>

    <?php if ($sectionMap['vision_mission']['status'] ?? 1): ?>
      <div class="row g-4 g-lg-5 mt-2">
        <div class="col-md-6">
          <div class="editorial-block">
            <div class="editorial-block-icon"><i class="bi bi-eye"></i></div>
            <h3 class="h4 fw-bold mb-2">Visi Organisasi</h3>
            <p class="editorial-body"><?= e(excerpt(strip_tags($organization['vision']), 180)) ?></p>
          </div>
        </div>
        <div class="col-md-6">
          <div class="editorial-block">
            <div class="editorial-block-icon"><i class="bi bi-flag"></i></div>
            <h3 class="h4 fw-bold mb-2">Misi Utama</h3>
            <p class="editorial-body"><?= e(excerpt(strip_tags($organization['mission']), 180)) ?></p>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<?php if ($albumsPreview && ($sectionMap['gallery']['status'] ?? 1)): ?>
<!-- Moments / Gallery -->
<section class="section-editorial" id="gallery">
  <div class="container-editorial">
    <div class="section-header">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-images me-1"></i> Dokumentasi Aktivitas</div>
        <h2 class="section-title">Galeri Rekam Jejak</h2>
      </div>
      <a href="<?= e(org_url($organization, 'gallery')) ?>" class="btn-editorial-secondary">
        <span>Lihat Seluruh Galeri</span>
        <i class="bi bi-arrow-right"></i>
      </a>
    </div>

    <div class="gallery-masonry">
      <?php foreach ($albumsPreview as $a): ?>
        <a href="<?= e(org_url($organization, 'gallery/' . $a['slug'])) ?>" class="gallery-item-editorial">
           <div class="gallery-item-media">
             <?php if ($a['cover_image']): ?>
               <img src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('gallery-cover', 800, 600) : e(upload_url($a['cover_image'])) ?>" alt="<?= e($a['title']) ?>" loading="lazy">
             <?php elseif (DEBUG_DUMMY_IMAGES): ?>
               <img src="<?= dummy_image_url('gallery-fallback', 800, 600) ?>" alt="<?= e($a['title']) ?>" loading="lazy">
             <?php else: ?>
               <div class="gallery-item-fallback"><i class="bi bi-images"></i></div>
             <?php endif; ?>
            <div class="gallery-item-overlay">
              <span class="gallery-item-count"><i class="bi bi-camera me-1"></i> <?= (int)$a['photo_count'] ?> Dokumentasi</span>
            </div>
          </div>
          <div class="gallery-item-meta">
            <div class="small text-secondary mb-1"><i class="bi bi-calendar3 me-1"></i> <?= e(format_date_id($a['event_date'])) ?></div>
            <h3 class="h6 fw-bold mb-0"><?= e($a['title']) ?></h3>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (($sectionMap['structure']['status'] ?? 1)): ?>
<!-- People / Structure -->
<section class="section-editorial" id="structure">
  <div class="container-editorial">
    <div class="section-header">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-people me-1"></i> Kepengurusan</div>
        <h2 class="section-title">Pengurus Periode Aktif</h2>
      </div>
      <?php if ($roots): ?>
        <a href="<?= e(org_url($organization, 'struktur')) ?>" class="btn-editorial-secondary">
          <span>Struktur Lengkap</span>
          <i class="bi bi-arrow-right"></i>
        </a>
      <?php endif; ?>
    </div>

    <?php if ($roots): ?>
      <div class="row g-4 g-lg-5">
        <?php foreach (array_slice($roots, 0, 6) as $p): ?>
          <div class="col-6 col-md-4 col-lg-2">
             <article class="portrait-card">
               <div class="portrait-card-media">
                 <?php if ($p['photo']): ?>
                   <img src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('structure-' . ($p['id'] ?? $p['person_name']), 400, 400) : e(upload_url($p['photo'])) ?>" alt="<?= e($p['person_name'] ?: $p['position_name']) ?>" loading="lazy">
                 <?php elseif (DEBUG_DUMMY_IMAGES): ?>
                   <img src="<?= dummy_image_url('structure-fallback-' . ($p['id'] ?? $p['person_name']), 400, 400) ?>" alt="<?= e($p['person_name'] ?: $p['position_name']) ?>" loading="lazy">
                 <?php else: ?>
                   <div class="portrait-card-fallback"><i class="bi bi-person"></i></div>
                 <?php endif; ?>
              </div>
              <div class="portrait-card-body">
                <h3 class="h6 fw-bold mb-0 text-truncate"><?= e($p['person_name'] ?: 'Belum diisi') ?></h3>
                <div class="small text-secondary text-truncate"><?= e($p['position_name']) ?></div>
              </div>
            </article>
          </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="empty-state-editorial">
        <i class="bi bi-diagram-3"></i>
        <p class="editorial-body">Struktur pengurus belum dikonfigurasi.</p>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php endif; ?>

<?php if (($sectionMap['contact']['status'] ?? 1)): ?>
<!-- Connect -->
<section class="section-editorial section-editorial-connect" id="connect">
  <div class="container-editorial">
    <div class="connect-card">
      <div class="row g-4 align-items-center">
        <div class="col-lg-8">
          <div class="editorial-label mb-2"><i class="bi bi-chat-dots me-1"></i> Kontak & Komunikasi</div>
          <h2 class="section-title mb-2">Ruang Temu & Sekretariat</h2>
          <p class="editorial-body mb-0" style="max-width: 520px;">
            <?= e($organization['email'] ?: 'Hubungi kami untuk kolaborasi, informasi kemahasiswaan, dan aspirasi.') ?>
            <?php if ($organization['phone']): ?>
              • <?= e($organization['phone']) ?>
            <?php endif; ?>
          </p>
        </div>
        <div class="col-lg-4 text-lg-end">
            <a href="<?= e(org_url($organization, 'kontak')) ?>" class="btn-editorial-primary">
              <span>Sekretariat &amp; Kontak</span>
              <i class="bi bi-arrow-up-right"></i>
            </a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<?php if (($sectionMap['calendar']['status'] ?? 1) && !empty($month_events)): ?>
<!-- Calendar Glance -->
<section class="section-editorial">
  <div class="container-editorial">
    <div class="section-header">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-calendar3 me-1"></i> Kalender Aktivitas</div>
        <h2 class="section-title">Agenda Bulan Ini</h2>
      </div>
      <a href="<?= e(org_url($organization, 'kalender')) ?>" class="btn-editorial-secondary">
        <span>Buka Kalender Aktivitas</span>
        <i class="bi bi-calendar-check"></i>
      </a>
    </div>

    <div class="calendar-preview">
      <div class="calendar-preview-header">
        <strong><i class="bi bi-clock-history me-1 text-primary"></i> <?= e(date('F Y')) ?></strong>
        <span class="badge-count"><?= count($month_events) ?> kegiatan</span>
      </div>
      <div class="vstack gap-2">
        <?php foreach (array_slice($month_events, 0, 3) as $me): ?>
          <a href="<?= e(org_url($organization, 'kegiatan/' . $me['slug'])) ?>" class="calendar-preview-item">
            <div class="calendar-preview-item-body">
              <div class="fw-semibold text-dark text-truncate"><?= e($me['title']) ?></div>
              <div class="small text-secondary" style="font-size: 0.72rem;"><?= e(format_date_id($me['event_date'])) ?> • <?= e(substr($me['start_time'], 0, 5)) ?> WIB</div>
            </div>
            <i class="bi bi-chevron-right text-secondary small opacity-50"></i>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>
