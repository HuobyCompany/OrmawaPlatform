<div class="section-editorial pt-4 min-vh-50 d-flex align-items-center">
  <div class="container-editorial">
    <div class="text-center mx-auto" style="max-width: 580px;">
      <div class="d-inline-flex align-items-center justify-content-center mb-5" style="width: 88px; height: 88px; border-radius: 50%; background: rgba(40,167,69,.08);">
        <i class="bi bi-check-circle-fill fs-2 text-success"></i>
      </div>
      <h1 class="display-title mb-2">Terima Kasih!</h1>
      <p class="editorial-lead mb-4" id="thanksRefText">
        <?php if (!empty($publicReference)): ?>
          Nomor pendaftaran Anda: <strong><?= e($publicReference) ?></strong>
        <?php elseif (!empty($submissionId)): ?>
          Pendaftaran Anda <strong>#<?= $submissionId ?></strong> telah berhasil dikirimkan dan sedang menunggu tinjauan dari pengurus <?= e($organization['short_name'] ?: $organization['name']) ?>.
        <?php else: ?>
          Pendaftaran Anda telah berhasil dikirimkan dan sedang menunggu tinjauan.
        <?php endif; ?>
      </p>
      <div class="alert alert-light border rounded-4 text-start small mb-4" id="thanksNotice">
        <i class="bi bi-info-circle me-2"></i>
        <ul class="mb-0 ps-3">
          <li class="mb-1">Tim kami akan meninjau berkas Anda dalam 1&ndash;3 hari kerja.</li>
          <li class="mb-1">Anda akan menerima konfirmasi melalui email atau nomor HP yang terdaftar.</li>
          <li>Pastikan inbox (dan folder spam) Anda tidak terlupakan.</li>
        </ul>
      </div>
      <div class="d-flex justify-content-center gap-2 flex-wrap">
        <a href="<?= e(org_url($organization)) ?>" class="btn btn-outline-dark rounded-pill px-3">
          <i class="bi bi-house-door me-1"></i> Beranda
        </a>
        <?php if (current_user()): ?>
          <a href="<?= url('member/dashboard') ?>" class="btn btn-dark rounded-pill px-3">
            <i class="bi bi-tachometer-alt me-1"></i> Dashboard
          </a>
        <?php endif; ?>
        <a href="<?= e(org_url($organization, 'join')) ?>" class="btn btn-primary rounded-pill px-3">
          <i class="bi bi-clipboard-data me-1"></i> Lihat Status Pendaftaran
        </a>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var orgSlug = '<?php echo e($organization["slug"] ?? ""); ?>';
    var storageKey = 'registration_status_' + orgSlug;
    var statusUrl = '<?php echo e(org_url($organization, "join/status")); ?>';
    var orgName = '<?php echo e($organization["short_name"] ?: $organization["name"]); ?>';

    var phpRef = <?php echo json_encode($publicReference ?? null); ?>;
    var phpToken = <?php echo json_encode($publicToken ?? null); ?>;

    // If PHP supplied credentials on initial submit redirect, save to localStorage
    if (phpRef && phpToken) {
        localStorage.setItem(storageKey, JSON.stringify({ reference: phpRef, token: phpToken }));
    }

    // Try reading credentials from localStorage
    var stored = localStorage.getItem(storageKey);
    var regData = null;
    if (stored) {
        try { regData = JSON.parse(stored); } catch(e) {}
    }
    if (!regData && phpRef && phpToken) {
        regData = { reference: phpRef, token: phpToken };
    }

    if (!regData || !regData.reference || !regData.token) {
        return;
    }

    // Update reference display if available from localStorage
    var refTextEl = document.getElementById('thanksRefText');
    if (refTextEl && regData.reference) {
        refTextEl.innerHTML = 'Nomor pendaftaran Anda: <strong>' + regData.reference + '</strong>';
    }

    function renderApproved() {
        var container = document.querySelector('.section-editorial');
        if (!container) return;
        container.innerHTML = `
            <div class="container-editorial">
                <div class="text-center mx-auto" style="max-width: 580px;">
                    <div class="d-inline-flex align-items-center justify-content-center mb-4" style="width: 88px; height: 88px; border-radius: 50%; background: rgba(40,167,69,.12);">
                        <i class="bi bi-patch-check-fill fs-1 text-success"></i>
                    </div>
                    <h1 class="display-title mb-2 text-success">Selamat!</h1>
                    <p class="editorial-lead mb-4 fs-4 fw-semibold text-dark">
                        Kamu berhasil menjadi anggota <strong>` + orgName + `</strong>.
                    </p>
                    <div class="alert alert-success border-0 rounded-4 text-start small mb-4 bg-success bg-opacity-10 text-success p-3">
                        <i class="bi bi-check-circle-fill me-2"></i> Pendaftaran Anda telah disetujui oleh pengurus organisasi. Selamat bergabung!
                    </div>
                    <div class="d-flex justify-content-center gap-2 flex-wrap">
                        <a href="<?php echo e(org_url($organization, 'kartu-anggota')); ?>" class="btn btn-success rounded-pill px-4 py-2.5 fw-bold shadow-sm d-inline-flex align-items-center gap-2">
                            <i class="bi bi-person-vcard fs-5"></i>
                            <span>Lihat &amp; Cetak Kartu Anggota Digital (KTA)</span>
                        </a>
                        <a href="<?php echo e(org_url($organization)); ?>" class="btn btn-outline-dark rounded-pill px-4 py-2">
                            <i class="bi bi-house-door me-1"></i> Beranda
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    function renderRejected() {
        var container = document.querySelector('.section-editorial');
        if (!container) return;
        container.innerHTML = `
            <div class="container-editorial">
                <div class="text-center mx-auto" style="max-width: 580px;">
                    <div class="d-inline-flex align-items-center justify-content-center mb-4" style="width: 88px; height: 88px; border-radius: 50%; background: rgba(220,53,69,.12);">
                        <i class="bi bi-x-circle-fill fs-1 text-danger"></i>
                    </div>
                    <h1 class="display-title mb-2 text-danger">Pendaftaran Ditolak</h1>
                    <p class="editorial-lead mb-4 text-dark">
                        Mohon maaf, pendaftaran Anda di <strong>` + orgName + `</strong> tidak disetujui oleh pengurus.
                    </p>
                    <div class="d-flex justify-content-center gap-2 flex-wrap">
                        <a href="<?php echo e(org_url($organization)); ?>" class="btn btn-outline-dark rounded-pill px-4 py-2">
                            <i class="bi bi-house-door me-1"></i> Beranda
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    function checkStatus() {
        var fd = new FormData();
        fd.append('reference', regData.reference);
        fd.append('token', regData.token);

        fetch(statusUrl, {
            method: 'POST',
            body: fd,
            credentials: 'same-origin'
        })
        .then(function(r) { return r.json(); })
        .then(function(res) {
            if (res && res.ok) {
                regData.status = res.status;
                localStorage.setItem(storageKey, JSON.stringify(regData));
                if (res.status === 'approved') {

                    renderApproved();
                } else if (res.status === 'rejected') {
                    renderRejected();
                }
            }
        })
        .catch(function(err) {
            console.error('Status check error:', err);
        });
    }

    checkStatus();
    setInterval(checkStatus, 10000);
});
</script>
