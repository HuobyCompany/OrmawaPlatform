<section class="section-editorial pt-4">
  <div class="container-editorial">
    <div class="section-header mb-5">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-chat-heart me-1"></i> Informasi & Layanan</div>
        <h1 class="display-title mb-2">Hubungi Kami</h1>
        <p class="editorial-lead">Saluran resmi untuk komunikasi, kerja sama kemitraan, dan konsultasi kegiatan.</p>
      </div>
    </div>

    <div class="row g-4 g-lg-5">
      <div class="col-lg-5">
        <div class="contact-info">
          <h2 class="h4 fw-bold mb-4">Kontak Resmi</h2>
          
          <div class="contact-list">
            <?php if ($organization['address']): ?>
              <div class="contact-list-item">
                <div class="contact-list-icon bg-danger-subtle text-danger">
                  <i class="bi bi-geo-alt-fill"></i>
                </div>
                <div>
                  <div class="editorial-label">Sekretariat</div>
                  <div class="fw-semibold"><?= e($organization['address']) ?></div>
                </div>
              </div>
            <?php endif; ?>

            <?php if ($organization['email']): ?>
              <a class="contact-list-item" href="mailto:<?= e($organization['email']) ?>">
                <div class="contact-list-icon bg-primary-subtle text-primary">
                  <i class="bi bi-envelope-fill"></i>
                </div>
                <div>
                  <div class="editorial-label">Email</div>
                  <div class="fw-semibold text-truncate"><?= e($organization['email']) ?></div>
                </div>
                <i class="bi bi-chevron-right ms-auto text-secondary small opacity-50"></i>
              </a>
            <?php endif; ?>

            <?php if ($organization['phone']): ?>
              <a class="contact-list-item" href="tel:<?= e($organization['phone']) ?>">
                <div class="contact-list-icon bg-success-subtle text-success">
                  <i class="bi bi-telephone-fill"></i>
                </div>
                <div>
                  <div class="editorial-label">Telepon / WhatsApp</div>
                  <div class="fw-semibold"><?= e($organization['phone']) ?></div>
                </div>
                <i class="bi bi-chevron-right ms-auto text-secondary small opacity-50"></i>
              </a>
            <?php endif; ?>
          </div>

          <div class="mt-4">
            <div class="editorial-label mb-3">Media Sosial</div>
            <div class="d-flex gap-2 flex-wrap">
              <?php foreach (['instagram', 'facebook', 'youtube', 'tiktok', 'linkedin', 'website'] as $social): 
                if (!empty($organization[$social])): 
              ?>
                <a target="_blank" rel="noopener" class="btn-editorial-secondary" href="<?= e(absolute_url($organization[$social])) ?>" aria-label="<?= e(ucfirst($social)) ?>">
                  <i class="bi bi-<?= $social === 'website' ? 'globe2' : e($social) ?> me-1"></i>
                  <span><?= e(ucfirst($social)) ?></span>
                </a>
              <?php endif; endforeach; ?>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-7">
        <?php $mapUrl = $organization['map_embed_url'] ?: ($settings['google_maps_embed'] ?? ''); ?>
        <?php if ($mapUrl): ?>
          <div class="contact-map">
            <iframe src="<?= e($mapUrl) ?>" loading="lazy" style="border:0; width: 100%; height: 100%; min-height: 420px;" allowfullscreen referrerpolicy="no-referrer-when-downgrade" title="Peta lokasi organisasi"></iframe>
          </div>
        <?php else: ?>
          <div class="contact-map-empty">
            <i class="bi bi-map"></i>
            <h3 class="h5 fw-bold text-dark mb-1">Peta Lokasi</h3>
            <p class="editorial-body"><?= e($organization['address'] ?: 'Alamat belum diatur dalam pengaturan organisasi.') ?></p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
