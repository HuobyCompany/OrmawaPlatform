<?php
/**
 * Public Structure Page
 *
 * Variables provided by FrontendController::structure():
 *   - $terms: array of organization term records (id, name, ...)
 *   - $selectedTermId: int ID of the term currently selected
 *   - $structureTree: hierarchical array of groups → positions → assignments
 */
?>
<?php // Include external stylesheet for public structure page ?>
<link rel="stylesheet" href="<?= asset('css/structure.css') ?>">

<!-- HERO SECTION -->
<div class="struct-hero">
  <div class="container">
    <div class="struct-hero-badge">
      <i class="bi bi-diagram-3-fill"></i> Kepengurusan Resmi
    </div>
    <h1 class="struct-hero-title">Struktur Organisasi</h1>
    <p class="struct-hero-subtitle">
      Jajaran pengurus yang berdedikasi memimpin, mengarahkan, dan menjalankan seluruh program kerja <strong><?= e($organization['name'] ?? '') ?></strong>.
    </p>
    <!-- Term selector -->
    <form method="GET" class="term-selector">
      <select name="term" class="form-select" onchange="this.form.submit()">
        <?php foreach ($terms as $term): ?>
          <option value="<?= e($term['id']) ?>" <?= $term['id'] == $selectedTermId ? 'selected' : '' ?>>
            <?= e($term['name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </form>
  </div>
</div>

<section class="py-5 bg-light-subtle">
  <div class="container">
    <?php if (empty($structureTree)): ?>
      <div class="text-center py-5 bg-white rounded-5 border p-5 shadow-sm">
        <i class="bi bi-diagram-3 fs-1 text-muted opacity-25 d-block mb-3"></i>
        <h4 class="fw-bold text-dark mb-1">Struktur Organisasi Belum Dikonfigurasi</h4>
        <p class="text-secondary small mb-0">Informasi kepengurusan akan segera ditampilkan setelah administrator mengatur posisi dan pengurus.</p>
      </div>
    <?php else: ?>
      <?php foreach ($structureTree as $group): ?>
        <?php if (empty($group['positions'])): ?>
          <?php continue; // Skip empty groups entirely ?>
        <?php endif; ?>
        <?php $mode = \StructureService::determinePresentationMode($group); ?>
<div class="mb-5 group-<?= e($mode) ?>">
          <?php if (!empty($group['banner_media_id'])): ?>
            <img src="<?= e(media_url($group['banner_media_id'])) ?>" alt="<?= e($group['name']) ?> banner" class="group-banner">
          <?php endif; ?>
          <h2 class="struct-tier-title mb-3"><?= e($group['name']) ?></h2>
          <?php if (!empty($group['description'])): ?>
            <p class="text-muted mb-4"><?= e($group['description']) ?></p>
          <?php endif; ?>
          <div class="row g-3 g-md-4">
            <?php 
            $vacantCount = 0;
            $maxVacant = 10; // Limit vacant positions to prevent flooding
            foreach ($group['positions'] as $position): 
              $assignments = $position['assignments'] ?? [];
              if (empty($assignments)): 
                $vacantCount++;
                if ($vacantCount > $maxVacant) continue; // Skip after limit
            ?>
                <!-- Vacant position card -->
                <div class="col-sm-6 col-md-4 col-xl-3">
                  <div class="fe-struct-card">
                    <span class="badge bg-secondary rounded-pill px-2.5 py-1 mb-3 small fw-semibold">Posisi tersedia</span>
                    <h3 class="fe-pos-title text-truncate w-100" title="<?= e($position['title']) ?>"><?= e($position['title']) ?></h3>
                    <div class="fe-person-fullname text-truncate w-100">—</div>
                  </div>
                </div>
              <?php else: ?>
                <?php foreach ($assignments as $as): ?>
                  <div class="col-sm-6 col-md-4 col-xl-3">
                    <div class="fe-struct-card">
                      <div class="fe-avatar-wrap">
                        <?php if (!empty($as['photo_media_id'])): ?>
                          <img src="<?= e(media_url($as['photo'])) ?>" class="fe-avatar-img" alt="<?= e($as['person_name']) ?>" loading="lazy">
                        <?php else: ?>
                          <div class="fe-avatar-fallback"><i class="bi bi-person"></i></div>
                        <?php endif; ?>
                      </div>
                      <h3 class="fe-pos-title text-truncate w-100" title="<?= e($position['title']) ?>"><?= e($position['title']) ?></h3>
                      <div class="fe-person-fullname text-truncate w-100" title="<?= e($as['person_name'] ?: '—') ?>"><?= e($as['person_name'] ?: '—') ?></div>
                      <?php if (!empty($as['start_date'])): ?>
                        <div class="fe-period-tag"><i class="bi bi-calendar2-week"></i> <?= e($as['start_date']) ?></div>
                      <?php endif; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php endif; ?>
            <?php endforeach; ?>
            <?php if ($vacantCount > $maxVacant): ?>
              <div class="col-12">
                <p class="text-muted small">Dan <?= $vacantCount - $maxVacant ?> posisi lainnya yang tersedia...</p>
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</section>
