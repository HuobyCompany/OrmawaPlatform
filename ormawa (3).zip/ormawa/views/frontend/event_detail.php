<section class="section-editorial pt-4">
  <div class="container-editorial">
    <div class="mb-4">
      <a class="btn-editorial-secondary" href="<?= org_url($organization, '/kegiatan') ?>">
        <i class="bi bi-chevron-left"></i>
        <span>Kembali ke Kegiatan</span>
      </a>
    </div>

    <article class="event-detail">
      <div class="row g-4 g-lg-5">
        <div class="col-lg-6">
          <div class="event-detail-media rounded-4 overflow-hidden bg-light">
            <?php if ($event['poster']): ?>
              <img src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('event-detail', 1200, 675) : e(media_url($event['poster'])) ?>" alt="Poster <?= e($event['title']) ?>" style="object-fit: cover; width: 100%; height: auto;">
            <?php elseif (DEBUG_DUMMY_IMAGES): ?>
              <img src="<?= dummy_image_url('event-detail-fallback', 1200, 675) ?>" alt="Poster <?= e($event['title']) ?>" style="object-fit: cover; width: 100%; height: auto;">
            <?php else: ?>
              <div class="d-flex align-items-center justify-content-center text-secondary" style="min-height: 320px;">
                <i class="bi bi-calendar-event fs-1 opacity-40"></i>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <div class="col-lg-6">
          <div class="mb-3">
            <span class="editorial-label"><i class="bi bi-calendar-check me-1"></i> Detail Agenda</span>
          </div>

          <h1 class="display-title mb-4" style="font-size: clamp(2rem, 4vw, 3rem); line-height: 1.15;">
            <?= e($event['title']) ?>
          </h1>

          <div class="d-flex flex-wrap gap-2 mb-4">
            <span class="badge-editorial">
              <i class="bi bi-calendar3 me-1"></i> <?= e(format_date_id($event['event_date'])) ?>
            </span>
            <span class="badge-editorial">
              <i class="bi bi-clock me-1"></i> <?= e(substr($event['start_time'], 0, 5)) ?> – <?= e(substr($event['end_time'], 0, 5)) ?> WIB
            </span>
            <?php if ($event['location']): ?>
              <span class="badge-editorial">
                <i class="bi bi-geo-alt me-1"></i> <?= e($event['location']) ?>
              </span>
            <?php endif; ?>
          </div>

          <div class="p-4 rounded-4 bg-light border editorial-body mb-4" style="line-height: 1.8; max-width: 640px;">
            <?= clean_rich($event['description']) ?>
          </div>

          <div>
            <div class="editorial-label mb-2">Bagikan Agenda</div>
            <div class="d-flex flex-wrap gap-2">
              <a class="btn-editorial-secondary" target="_blank" rel="noopener" href="https://wa.me/?text=<?= rawurlencode($event['title'] . ' - ' . $canonical) ?>">
                <i class="bi bi-whatsapp text-success me-1"></i> WhatsApp
              </a>
              <a class="btn-editorial-secondary" target="_blank" rel="noopener" href="https://twitter.com/intent/tweet?url=<?= rawurlencode($canonical) ?>&text=<?= rawurlencode($event['title']) ?>">
                <i class="bi bi-twitter-x me-1"></i> X
              </a>
              <button class="btn-editorial-secondary" type="button" data-copy-link="<?= e($canonical) ?>">
                <i class="bi bi-link-45deg me-1"></i> Salin Link
              </button>
            </div>
          </div>
        </div>
      </div>
    </article>
  </div>
</section>
