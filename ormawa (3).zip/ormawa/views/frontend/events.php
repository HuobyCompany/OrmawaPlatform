<section class="section-editorial pt-4">
  <div class="container-editorial">
    <div class="section-header mb-5">
      <div>
        <div class="editorial-label mb-2"><i class="bi bi-calendar2-event me-1"></i> Agenda Organisasi</div>
        <h1 class="display-title mb-2">Kegiatan</h1>
        <p class="editorial-lead">Temukan kegiatan terbaru, workshop, dan agenda resmi kemahasiswaan.</p>
      </div>
    </div>

    <!-- Filter Bar -->
    <div class="filter-bar mb-5">
      <form class="d-flex flex-column flex-lg-row align-items-stretch align-items-lg-center justify-content-between gap-3" method="get">
        <div class="filter-tabs">
          <?php 
          $currentFilter = $filters['filter'] ?? 'all';
          $filterTabs = [
            'all' => 'Semua',
            'upcoming' => 'Upcoming',
            'past' => 'Selesai',
            'month' => 'Bulan Ini',
            'year' => 'Tahun Ini'
          ];
          foreach ($filterTabs as $fVal => $fLabel): 
            $isActive = ($currentFilter === $fVal);
            $queryUrl = '?filter=' . $fVal . (!empty($filters['q']) ? '&q=' . urlencode($filters['q']) : '');
          ?>
            <a href="<?= e($queryUrl) ?>" class="filter-tab <?= $isActive ? 'active' : '' ?>">
              <?= e($fLabel) ?>
            </a>
          <?php endforeach; ?>
        </div>

        <div class="d-flex gap-2 align-items-center">
          <div class="search-box">
            <i class="bi bi-search"></i>
            <input type="text" name="q" value="<?= e($filters['q'] ?? '') ?>" placeholder="Cari kegiatan...">
          </div>
          <button type="submit" class="btn-editorial-secondary">
            <span>Cari</span>
          </button>
        </div>
      </form>
    </div>

    <?php if (!$events): ?>
      <div class="empty-state-editorial">
        <i class="bi bi-calendar2-x"></i>
        <p class="editorial-body">Tidak ada kegiatan ditemukan. Coba ubah kata kunci atau filter.</p>
      </div>
    <?php else: ?>
      <div class="events-list">
        <?php foreach ($events as $event): 
          $dt = strtotime($event['event_date']);
          $monthName = date('F', $dt);
          $dayNum = date('d', $dt);
          $year = date('Y', $dt);
          $monthShort = date('M', $dt);
        ?>
          <article class="event-list-editorial">
            <a href="<?= org_url($organization, '/kegiatan/' . $event['slug']) ?>" class="event-list-editorial-link">
              <div class="event-list-editorial-media">
                <?php if ($event['poster']): ?>
                  <img src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('event-list', 1200, 675) : e(media_url($event['poster'])) ?>" alt="Poster <?= e($event['title']) ?>" loading="lazy">
                <?php elseif (DEBUG_DUMMY_IMAGES): ?>
                  <img src="<?= dummy_image_url('event-list-fallback', 1200, 675) ?>" alt="Poster <?= e($event['title']) ?>" loading="lazy">
                <?php else: ?>
                  <div class="event-list-editorial-fallback">
                    <i class="bi bi-calendar-event"></i>
                  </div>
                <?php endif; ?>
                <div class="event-date-badge">
                  <div class="event-date-month"><?= e(ucfirst(substr($monthName, 0, 3))) ?></div>
                  <div class="event-date-day"><?= e($dayNum) ?></div>
                  <div class="event-date-year"><?= e($year) ?></div>
                </div>
              </div>
              <div class="event-list-editorial-body">
                <div class="event-meta mb-2">
                  <?php if (!empty($event['location'])): ?>
                    <span><i class="bi bi-geo-alt me-1"></i><?= e(excerpt($event['location'], 25)) ?></span>
                  <?php endif; ?>
                  <span><i class="bi bi-clock me-1"></i><?= e(substr($event['start_time'], 0, 5)) ?> WIB</span>
                </div>
                <h2 class="h5 fw-bold text-dark mb-2" style="line-height: 1.35;"><?= e($event['title']) ?></h2>
                <p class="editorial-body mb-3"><?= e(excerpt(strip_tags($event['description']), 120)) ?></p>
                <div class="event-cta-editorial">
                  <span>Lihat Detail</span>
                  <i class="bi bi-arrow-right"></i>
                </div>
              </div>
            </a>
          </article>
        <?php endforeach; ?>
      </div>

      <?php if (($pagination['total_pages'] ?? 1) > 1): ?>
        <nav class="mt-5" aria-label="Pagination">
          <ul class="pagination justify-content-center gap-1">
            <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
              <li class="page-item <?= $i == ($pagination['page'] ?? 1) ? 'active' : '' ?>">
                <a class="page-link-editorial" href="<?= e(org_url($organization, '/kegiatan') . '?page=' . $i . '&q=' . urlencode($filters['q'] ?? '') . '&filter=' . urlencode($filters['filter'] ?? 'all')) ?>">
                  <?= $i ?>
                </a>
              </li>
            <?php endfor; ?>
          </ul>
        </nav>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>
