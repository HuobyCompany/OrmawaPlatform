<?php
$code = 403;
$title = 'Akses ditolak';
$message = 'Anda tidak memiliki izin untuk mengakses halaman ini.';
?>
