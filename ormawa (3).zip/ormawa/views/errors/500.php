<?php
$code = 500;
$title = 'Terjadi kesalahan';
$message = 'Server mengalami kesalahan saat memproses permintaan.';
?>
