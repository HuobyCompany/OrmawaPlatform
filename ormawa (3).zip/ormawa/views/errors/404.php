<?php
$code = 404;
$title = 'Halaman tidak ditemukan';
$message = 'Halaman yang Anda cari tidak tersedia.';
?>
