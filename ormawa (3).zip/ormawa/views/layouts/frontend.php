<!doctype html>
<html lang="id" class="no-js">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="robots" content="index, follow">
  <meta name="referrer" content="strict-origin-when-cross-origin">
  <title><?= e(($title ?? $organization['name']) . ' · ' . ($organization['name'] ?? APP_NAME)) ?></title>
  <meta name="description" content="<?= e($meta_description ?? $organization['description'] ?? '') ?>">
  <meta name="keywords" content="<?= e($settings['default_meta_keywords'] ?? 'organisasi mahasiswa, ORMAWA, HIMA, UKM') ?>">
  <?php $requestPath = request_path(); ?>
  <link rel="canonical" href="<?= e(org_url($organization, $requestPath === '/' . trim($organization['slug'], '/') ? '' : preg_replace('#^/' . preg_quote(trim($organization['slug'], '/'), '#') . '#', '', $requestPath))) ?>">
  <meta property="og:title" content="<?= e($title ?? $organization['name']) ?>">
  <meta property="og:description" content="<?= e($organization['description'] ?? '') ?>">
  <meta property="og:type" content="website">
  <?php if (!empty($organization['logo'])): ?>
    <meta property="og:image" content="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('org-logo', 1200, 630) : e(upload_url($organization['logo'])) ?>">
  <?php endif; ?>
  <meta name="twitter:card" content="summary_large_image">
  <link rel="icon" href="<?= e(!empty($organization['favicon']) ? (DEBUG_DUMMY_IMAGES ? dummy_image_url('favicon', 64, 64) : upload_url($organization['favicon'])) : asset('icons/favicon.svg')) ?>">
  
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&family=Inter:wght@400;500;600;700;800&family=Newsreader:ital,opsz,wght@0,6..72,300;0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400;1,6..72,500&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  
  <?php 
  $structShape = $settings['structure_photo_shape'] ?? 'circle';
  $structRadius = match($structShape) { 'square' => '16px', 'rounded' => '24px', default => '50%' };
  $structPreset = $settings['structure_photo_size'] ?? 'Medium';
  $structWidth = match($structPreset) { 'Small' => '84px', 'Large' => '140px', 'Custom' => ((int)($settings['structure_photo_width'] ?? 110)) . 'px', default => '110px' };
  $structHeight = match($structPreset) { 'Small' => '84px', 'Large' => '140px', 'Custom' => ((int)($settings['structure_photo_height'] ?? 110)) . 'px', default => '110px' };
  ?>
  
  <link href="<?= e(asset('css/app.css')) ?>" rel="stylesheet">
  <style>
    :root {
      --primary-color: <?= e($organization['primary_color'] ?? '#0a84ff') ?>;
      --secondary-color: <?= e($organization['secondary_color'] ?? '#5e5ce6') ?>;
      --accent-color: <?= e($organization['accent_color'] ?? '#30d158') ?>;
      --background-color: <?= e($organization['background_color'] ?? '#f5f4f0') ?>;
      --text-color: <?= e($organization['text_color'] ?? '#1a1a1a') ?>;
      --font-body: -apple-system, BlinkMacSystemFont, "SF Pro Text", '<?= e($organization['font_family'] ?? 'Plus Jakarta Sans') ?>', system-ui, sans-serif;
      --font-display: "Newsreader", "Georgia", "Times New Roman", serif;
      --font-sans: -apple-system, BlinkMacSystemFont, "SF Pro Text", '<?= e($organization['font_family'] ?? 'Plus Jakarta Sans') ?>', system-ui, sans-serif;
      --gallery-columns: <?= (int)($settings['gallery_columns'] ?? 3) ?>;
      --gallery-gap: <?= (int)($settings['gallery_gap'] ?? 16) ?>px;
      --gallery-radius: <?= (int)($settings['gallery_radius'] ?? 20) ?>px;
      --structure-radius: <?= $structRadius ?>;
      --structure-photo-width: <?= $structWidth ?>;
      --structure-photo-height: <?= $structHeight ?>;
      <?php 
      $galleryObjFit = $settings['gallery_object_fit'] ?? 'cover';
      $posterObjFit = $settings['event_poster_object_fit'] ?? ($settings['event_poster_fit'] ?? 'cover');
      ?>
      --gallery-ratio: <?= e($settings['gallery_ratio'] ?? '4/3') ?>;
      --gallery-object-fit: <?= e(in_array($galleryObjFit, ['cover', 'contain'], true) ? $galleryObjFit : 'cover') ?>;
      --event-poster-ratio: <?= (float)($settings['event_poster_width'] ?? 1200) / max(1, (float)($settings['event_poster_height'] ?? 800)) ?>;
      --event-poster-fit: <?= e(in_array($posterObjFit, ['cover', 'contain'], true) ? $posterObjFit : 'cover') ?>;
    }
  </style>
</head>
<body>
  <a href="#content" class="skip-link">Lewati ke konten</a>
  
  <?php include BASE_PATH . '/views/components/frontend_nav.php'; ?>
  
  <main id="content">
    <?= $content ?>
  </main>
  
  <?php include BASE_PATH . '/views/components/frontend_footer.php'; ?>

  <!-- iOS Photos Style Lightbox Overlay -->
  <div class="lightbox" id="lightbox" hidden role="dialog" aria-modal="true" aria-label="Pratinjau foto">
    <button class="lightbox-close" data-close aria-label="Tutup"><i class="bi bi-x-lg"></i></button>
    <button class="lightbox-nav-btn lightbox-prev" data-lightbox-prev aria-label="Sebelumnya"><i class="bi bi-chevron-left"></i></button>
    <figure>
      <img src="" alt="">
      <figcaption data-caption></figcaption>
    </figure>
    <button class="lightbox-nav-btn lightbox-next" data-lightbox-next aria-label="Selanjutnya"><i class="bi bi-chevron-right"></i></button>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= e(asset('js/app.js')) ?>"></script>
  <?php if (($title ?? '') === 'Kalender'): ?>
    <script src="<?= e(asset('js/calendar.js')) ?>"></script>
  <?php endif; ?>
</body>
</html>
