<?php
$appName = defined('APP_NAME') ? APP_NAME : 'ORMAWA Platform';
$title = $title ?? $appName;
$message = $message ?? 'Terjadi kesalahan.';
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?> · <?= e($appName) ?></title>
    <meta name="robots" content="noindex">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= asset('css/app.css') ?>">
    <style>
        body { min-height:100vh; display:grid; place-items:center; padding:1.5rem; }
        .error-shell { width:min(700px,100%); text-align:center; }
        .error-code { font-size:clamp(5rem,15vw,9rem); font-weight:800; line-height:.9; letter-spacing:-.07em; }
        .error-card { padding:clamp(1.5rem,5vw,3rem); border:1px solid rgba(15,23,42,.08); background:rgba(255,255,255,.76); border-radius:28px; box-shadow:0 24px 70px rgba(15,23,42,.10); backdrop-filter: blur(14px); }
        .btn-main { background:#111827;color:#fff;border-radius:14px;padding:.8rem 1.2rem;text-decoration:none;display:inline-flex;align-items:center;gap:.5rem; }
        .btn-main:hover { color:#fff; opacity:.92; }
    </style>
</head>
<body>
<main class="error-shell">
    <div class="error-card">
        <div class="error-code"><?= e($code ?? '500') ?></div>
        <p class="text-uppercase small fw-bold text-secondary mt-4 mb-2"><?= e($title) ?></p>
        <h1 class="h3 fw-bold mb-3"><?= e($message) ?></h1>
        <p class="text-secondary mb-4">Silakan kembali ke halaman sebelumnya atau coba lagi.</p>
        <a class="btn-main" href="<?= url('/') ?>"><i class="bi bi-house"></i> Kembali ke Beranda</a>
    </div>
</main>
</body>
</html>
