<?php
$organization = $organization ?? null;
$user = auth_user();
$title = $title ?? 'Admin';
$content = $content ?? '';
$hide_nav = $hide_nav ?? false;
$orgName = $organization['short_name'] ?? $organization['name'] ?? APP_NAME;
?>
<!doctype html>
<html lang="id" class="no-js">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?= e(Csrf::token()) ?>">
    <title><?= e($title) ?> · <?= e($orgName) ?></title>
    <link rel="icon" href="<?= !empty($organization['favicon']) ? media_url($organization['favicon']) : asset('icons/favicon.svg') ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="<?= asset('css/admin.css') ?>">
</head>
<body class="admin-body" style="<?= e(theme_vars($organization)) ?>">

<?php if ($hide_nav || !$user): ?>
    <!-- Standalone Login Layout without Sidebar or Topbar -->
    <div class="d-flex align-items-center justify-content-center min-vh-100 p-3" style="background: radial-gradient(circle at 50% 25%, color-mix(in srgb, var(--primary-color, #007aff) 10%, #f2f2f7), #e5e5ea);">
        <div class="w-100" style="max-width: 440px;">
            <?php if ($message = flash('success')): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4 mb-3 shadow-sm border-0" role="alert">
                    <i class="bi bi-check-circle me-2"></i><?= e($message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($message = flash('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4 mb-3 shadow-sm border-0" role="alert">
                    <i class="bi bi-exclamation-circle me-2"></i><?= e($message) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?= $content ?>
        </div>
    </div>
<?php else: ?>
    <!-- Main Admin Shell with Sidebar and Topbar -->
    <div class="admin-shell">
        <?php require __DIR__ . '/../components/admin_sidebar.php'; ?>
        <div class="admin-main">
            <header class="admin-topbar">
                <button class="btn btn-light d-lg-none js-sidebar-toggle rounded-circle p-2" type="button" aria-label="Buka menu" style="width: 40px; height: 40px;">
                    <i class="bi bi-list fs-5"></i>
                </button>
                <div class="min-w-0">
                    <div class="small text-secondary fw-semibold">Panel Pengurus</div>
                    <h1 class="h5 mb-0 text-truncate fw-bold text-dark"><?= e($title) ?></h1>
                </div>
                <div class="ms-auto d-flex align-items-center gap-2">
                    <?php if ($organization): ?>
                        <a class="btn btn-light btn-sm rounded-pill border px-3 d-inline-flex align-items-center gap-1" href="<?= org_url($organization) ?>" target="_blank">
                            <i class="bi bi-safari text-primary"></i>
                            <span>Preview Web</span>
                        </a>
                    <?php endif; ?>
                    <?php
                        $userDisplayName = $user['name'] ?? 'Admin';
                        if ($userDisplayName === 'Admin HMTI' || str_contains($userDisplayName, 'HMTI')) {
                            $userDisplayName = 'Admin ' . ($organization['short_name'] ?? $organization['name'] ?? 'ORMAWA');
                        }
                        if (!str_starts_with($userDisplayName, '@')) {
                            $userDisplayName = '@' . $userDisplayName;
                        }
                    ?>
                    <span class="badge rounded-pill text-bg-light border px-3 py-2 d-none d-md-inline-flex align-items-center gap-2 fw-semibold text-secondary">
                        <i class="bi bi-person-circle me-1.5 text-primary"></i>
                        <?= e($userDisplayName) ?>
                    </span>
                    <form method="post" action="<?= url('/admin/logout') ?>" class="d-inline">
                        <?= Csrf::field() ?>
                        <button class="btn btn-dark btn-sm rounded-pill px-3 d-inline-flex align-items-center gap-1" type="submit">
                            <i class="bi bi-power"></i>
                            <span class="d-none d-sm-inline">Keluar</span>
                        </button>
                    </form>
                </div>
            </header>
            <main class="admin-content">
                <?php if ($message = flash('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show rounded-4 mb-4 border-0 shadow-sm" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i><?= e($message) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                <?php if ($message = flash('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show rounded-4 mb-4 border-0 shadow-sm" role="alert">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($message) ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>
                
                <?= $content ?>
            </main>
        </div>
    </div>

    <!-- Delete Confirmation Modal (iOS Sheet Style) -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-5 shadow-lg overflow-hidden">
                <div class="modal-body p-4 text-center">
                    <div class="rounded-circle bg-danger-subtle text-danger mx-auto mb-3 d-grid place-items-center" style="width: 56px; height: 56px;">
                        <i class="bi bi-trash3 fs-4"></i>
                    </div>
                    <h2 class="h5 fw-bold text-dark mb-1">Konfirmasi Penghapusan</h2>
                    <p class="text-secondary small mb-4" id="confirmMessage">Apakah Anda yakin ingin menghapus data ini? Tindakan ini tidak dapat dibatalkan.</p>
                    <div class="d-flex justify-content-center gap-2">
                        <button class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                        <form id="confirmForm" method="post" class="d-inline">
                            <?= Csrf::field() ?>
                            <button class="btn btn-danger rounded-pill px-4">Hapus Data</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= asset('js/editor.js') ?>"></script>
<script src="<?= asset('js/admin.js') ?>"></script>
</body>
</html>
