<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> - <?= e($organization['name']) ?></title>
    <link rel="stylesheet" href="<?= e(asset_url('css/app.css')) ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body>
    <div class="member-profile-container">
        <div class="container-editorial">
            <!-- Back Button -->
            <div class="member-profile-nav">
                <a href="<?= e(org_url($organization, 'member')) ?>" class="btn-editorial-secondary">
                    <i class="bi bi-arrow-left"></i> Kembali ke Portal
                </a>
            </div>

            <!-- Profile Header -->
            <div class="member-profile-header">
                <h1>Profil Anggota</h1>
                <p>Kelola informasi profil Anda</p>
            </div>

            <!-- Flash Alerts -->
            <?php if ($success = flash('success')): ?>
                <div class="alert alert-success" style="padding: 1rem; margin-bottom: 1.5rem; background: #d1fae5; color: #065f46; border-radius: var(--radius-md); border: 1px solid #34d399;">
                    <i class="bi bi-check-circle"></i> <?= e($success) ?>
                </div>
            <?php endif; ?>
            <?php if ($error = flash('error')): ?>
                <div class="alert alert-danger" style="padding: 1rem; margin-bottom: 1.5rem; background: #fee2e2; color: #991b1b; border-radius: var(--radius-md); border: 1px solid #f87171;">
                    <i class="bi bi-exclamation-triangle"></i> <?= e($error) ?>
                </div>
            <?php endif; ?>

            <!-- Profile Card Form -->
            <form action="<?= e(org_url($organization, 'member/profile/update')) ?>" method="POST" enctype="multipart/form-data" class="member-profile-card">
                <?= Csrf::field() ?>

                <!-- Profile Photo Section -->
                <div class="member-profile-section" style="text-align: center;">
                    <h2>Foto Profil</h2>
                    <div class="member-profile-photo-wrapper" style="margin-bottom: 1rem;">
                        <?php if (!empty($person['photo_path'])): ?>
                            <img src="<?= e(upload_url($person['photo_path'])) ?>" alt="Foto Profil" class="member-profile-avatar-img">
                        <?php else: ?>
                            <div class="member-profile-avatar-placeholder">
                                <i class="bi bi-person-circle"></i>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="member-profile-field" style="max-width: 320px; margin: 0 auto;">
                        <label for="photo_input">Unggah Foto Baru</label>
                        <input type="file" id="photo_input" name="photo" accept="image/jpeg,image/png,image/webp" class="form-control-file">
                        <small class="member-profile-note">Format: JPG, PNG, WebP. Maks 2MB.</small>
                    </div>
                </div>

                <div class="member-profile-section">
                    <h2>Informasi Pribadi (Dapat Diubah)</h2>
                    <div class="member-profile-field">
                        <label for="full_name_input">Nama Lengkap *</label>
                        <input type="text" id="full_name_input" name="full_name" class="form-control-editorial" value="<?= e($person['full_name'] ?? $user['name']) ?>" required>
                    </div>
                    <div class="member-profile-field">
                        <label for="email_input">Email *</label>
                        <input type="email" id="email_input" name="email" class="form-control-editorial" value="<?= e($person['email'] ?? $user['email']) ?>" required>
                    </div>
                    <div class="member-profile-field">
                        <label for="phone_input">Nomor Telepon</label>
                        <input type="text" id="phone_input" name="phone" class="form-control-editorial" value="<?= e($person['phone'] ?? '') ?>" placeholder="08xxxxxxxxxx">
                    </div>
                </div>

                <div class="member-profile-section">
                    <h2>Informasi Keanggotaan (Tidak Dapat Diubah)</h2>
                    <div class="member-profile-field">
                        <label>Nomor Anggota</label>
                        <p class="readonly-value"><?= e($member['member_number'] ?? '-') ?></p>
                        <small class="member-profile-note">Nomor anggota bersifat permanen</small>
                    </div>
                    <div class="member-profile-field">
                        <label>Status Keanggotaan</label>
                        <p>
                            <span class="member-status-badge member-status-<?= e($member['status'] ?? 'pending') ?>">
                                <?= e(ucfirst($member['status'] ?? 'Pending')) ?>
                            </span>
                        </p>
                        <small class="member-profile-note">Status keanggotaan dikelola oleh pengurus</small>
                    </div>
                    <div class="member-profile-field">
                        <label>Fakultas</label>
                        <p class="readonly-value"><?= e($member['faculty_name'] ?? '-') ?></p>
                    </div>
                    <div class="member-profile-field">
                        <label>Program Studi</label>
                        <p class="readonly-value"><?= e($member['prodi_name'] ?? '-') ?></p>
                    </div>
                    <div class="member-profile-field">
                        <label>Angkatan</label>
                        <p class="readonly-value"><?= e($member['batch_year'] ?? '-') ?></p>
                    </div>
                    <div class="member-profile-field">
                        <label>Periode Saat Ini</label>
                        <p class="readonly-value"><?= e($member['term_name'] ?? '-') ?></p>
                    </div>
                </div>

                <div class="member-profile-section">
                    <h2>Informasi Organisasi</h2>
                    <div class="member-profile-field">
                        <label>Organisasi</label>
                        <p class="readonly-value"><?= e($organization['name']) ?></p>
                    </div>
                    <div class="member-profile-field">
                        <label>Tanggal Bergabung</label>
                        <p class="readonly-value"><?= !empty($member['joined_at']) ? date('d F Y', strtotime($member['joined_at'])) : '-' ?></p>
                    </div>
                </div>

                <!-- Profile Actions -->
                <div class="member-profile-actions">
                    <button type="submit" class="btn-editorial-primary">
                        <i class="bi bi-check-lg"></i> Simpan Perubahan
                    </button>
                    <a href="<?= e(org_url($organization, 'member/card')) ?>" class="btn-editorial-secondary">
                        <i class="bi bi-card-heading"></i> Lihat Kartu Anggota
                    </a>
                    <a href="/admin/logout" class="btn-editorial-ghost" style="color: #dc3545;">
                        <i class="bi bi-box-arrow-right"></i> Keluar
                    </a>
                </div>
            </form>
        </div>
    </div>

    <style>
        .member-profile-container {
            min-height: 100vh;
            background: var(--background-color);
            padding: 2rem 0;
        }

        .member-profile-nav {
            margin-bottom: 2rem;
        }

        .member-profile-header {
            margin-bottom: 2rem;
        }

        .member-profile-header h1 {
            font-size: 2rem;
            font-weight: 700;
            margin: 0 0 0.5rem 0;
            color: var(--text-color);
        }

        .member-profile-header p {
            font-size: 1rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .member-profile-card {
            background: var(--surface-color);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-xl);
            padding: 2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        .member-profile-section {
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--border-subtle);
        }

        .member-profile-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .member-profile-section h2 {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            color: var(--text-color);
        }

        .member-profile-field {
            margin-bottom: 1.5rem;
        }

        .member-profile-field label {
            display: block;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .member-profile-field p {
            font-size: 1rem;
            color: var(--text-color);
            margin: 0;
        }

        .member-profile-note {
            display: block;
            font-size: 0.8rem;
            color: var(--text-tertiary);
            margin-top: 0.25rem;
        }

        .member-status-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .member-status-active {
            background: #10b981;
            color: white;
        }

        .member-status-pending {
            background: #f59e0b;
            color: white;
        }

        .member-status-rejected {
            background: #ef4444;
            color: white;
        }

        .member-status-suspended {
            background: #f97316;
            color: white;
        }

        .member-status-inactive {
            background: #6b7280;
            color: white;
        }

        .member-status-alumni {
            background: #8b5cf6;
            color: white;
        }

        .form-control-editorial {
            width: 100%;
            padding: 0.75rem 1rem;
            font-size: 0.95rem;
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-md);
            background: var(--surface-warm);
            color: var(--text-color);
            transition: border-color 0.2s, box-shadow 0.2s;
        }

        .form-control-editorial:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.15);
        }

        .form-control-file {
            display: block;
            width: 100%;
            font-size: 0.85rem;
            color: var(--text-secondary);
        }

        .readonly-value {
            font-size: 1rem;
            color: var(--text-color);
            margin: 0;
            padding: 0.5rem 0;
        }

        .member-profile-avatar-img {
            width: 96px;
            height: 96px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--border-subtle);
            margin: 0 auto 0.5rem;
            display: block;
        }

        .member-profile-avatar-placeholder {
            width: 96px;
            height: 96px;
            border-radius: 50%;
            background: var(--surface-warm);
            display: grid;
            place-items: center;
            font-size: 2.5rem;
            color: var(--text-tertiary);
            margin: 0 auto 0.5rem;
        }

        .member-profile-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 1px solid var(--border-subtle);
        }

        @media (max-width: 768px) {
            .member-profile-card {
                padding: 1.5rem;
            }

            .member-profile-actions {
                flex-direction: column;
            }

            .member-profile-actions a,
            .member-profile-actions button {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</body>
</html>