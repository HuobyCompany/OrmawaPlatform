<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> - <?= e($organization['name']) ?></title>
    <link rel="stylesheet" href="<?= e(asset_url('css/app.css')) ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body>
    <div class="member-portal-container">
        <!-- Member Portal Header -->
        <header class="member-portal-header">
            <div class="container-editorial">
                <div class="member-portal-brand">
                    <?php if(!empty($organization['logo'])): ?>
                        <img class="member-portal-logo" src="<?= e(upload_url($organization['logo'])) ?>" alt="<?= e($organization['name']) ?>">
                    <?php else: ?>
                        <div class="member-portal-logo-placeholder">
                            <i class="bi bi-buildings"></i>
                        </div>
                    <?php endif; ?>
                    <div class="member-portal-brand-text">
                        <h1><?= e($organization['name']) ?></h1>
                        <p>Portal Anggota</p>
                    </div>
                </div>
                <div class="member-portal-nav">
                    <a href="<?= e(org_url($organization, 'member')) ?>" class="member-portal-nav-item active">
                        <i class="bi bi-house"></i> Beranda
                    </a>
                    <a href="<?= e(org_url($organization, 'member/card')) ?>" class="member-portal-nav-item">
                        <i class="bi bi-card-heading"></i> Kartu Anggota
                    </a>
                    <a href="<?= e(org_url($organization, 'member/profile')) ?>" class="member-portal-nav-item">
                        <i class="bi bi-person"></i> Profil
                    </a>
                    <a href="/admin/logout" class="member-portal-nav-item member-portal-logout">
                        <i class="bi bi-box-arrow-right"></i> Keluar
                    </a>
                </div>
            </div>
        </header>

        <!-- Member Portal Content -->
        <main class="member-portal-main">
            <div class="container-editorial">
                <!-- Member Overview Card -->
                <div class="member-overview-card">
                    <div class="member-overview-header">
                        <div class="member-overview-avatar">
                            <?php if(!empty($person['photo_path'])): ?>
                                <img src="<?= e(upload_url($person['photo_path'])) ?>" alt="<?= e($person['full_name'] ?? $user['name']) ?>" style="width: 100%; height: 100%; object-fit: cover;">
                            <?php else: ?>
                                <div class="member-overview-avatar-placeholder">
                                    <i class="bi bi-person-circle"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="member-overview-info">
                            <h2><?= e($person['full_name'] ?? $user['name']) ?></h2>
                            <p class="member-overview-subtitle">
                                <?php if($member): ?>
                                    <?= e($member['member_number']) ?> • 
                                    <span class="member-status member-status-<?= e($member['status']) ?>">
                                        <?= e(ucfirst($member['status'])) ?>
                                    </span>
                                <?php else: ?>
                                    Anggota
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>

                    <!-- Status Messages -->
                    <?php if($member): ?>
                        <?php if($member['status'] === 'pending'): ?>
                            <div class="member-status-banner member-status-pending">
                                <i class="bi bi-clock-history"></i>
                                <span>Status keanggotaan Anda masih menunggu persetujuan pengurus.</span>
                            </div>
                        <?php elseif($member['status'] === 'rejected'): ?>
                            <div class="member-status-banner member-status-rejected">
                                <i class="bi bi-x-circle"></i>
                                <span>Status keanggotaan Anda ditolak. Silakan hubungi pengurus untuk informasi lebih lanjut.</span>
                            </div>
                        <?php elseif($member['status'] === 'suspended'): ?>
                            <div class="member-status-banner member-status-suspended">
                                <i class="bi bi-exclamation-triangle"></i>
                                <span>Status keanggotaan Anda ditangguhkan. Akses terbatas.</span>
                            </div>
                        <?php elseif($member['status'] === 'inactive'): ?>
                            <div class="member-status-banner member-status-inactive">
                                <i class="bi bi-person-x"></i>
                                <span>Status keanggotaan Anda tidak aktif. Akses terbatas.</span>
                            </div>
                        <?php elseif($member['status'] === 'alumni'): ?>
                            <div class="member-status-banner member-status-alumni">
                                <i class="bi bi-mortarboard"></i>
                                <span>Status keanggotaan Anda sebagai Alumni.</span>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <!-- Member Details Grid -->
                    <div class="member-details-grid">
                        <div class="member-detail-item">
                            <label>Nomor Anggota</label>
                            <p><?= e($member['member_number'] ?? '-') ?></p>
                        </div>
                        <div class="member-detail-item">
                            <label>Organisasi</label>
                            <p><?= e($organization['name']) ?></p>
                        </div>
                        <div class="member-detail-item">
                            <label>Status Keanggotaan</label>
                            <p><?= e(ucfirst($member['status'] ?? '-')) ?></p>
                        </div>
                        <div class="member-detail-item">
                            <label>Periode Saat Ini</label>
                            <p><?= e($member['term_name'] ?? '-') ?></p>
                        </div>
                        <div class="member-detail-item">
                            <label>Angkatan</label>
                            <p><?= e($member['batch_year'] ?? '-') ?></p>
                        </div>
                        <div class="member-detail-item">
                            <label>Fakultas</label>
                            <p><?= e($member['faculty_name'] ?? '-') ?></p>
                        </div>
                        <div class="member-detail-item">
                            <label>Program Studi</label>
                            <p><?= e($member['prodi_name'] ?? '-') ?></p>
                        </div>
                        <div class="member-detail-item">
                            <label>WhatsApp</label>
                            <p><?= e($member['whatsapp'] ?? $person['phone'] ?? '-') ?></p>
                        </div>
                    </div>

                    <!-- Structure Assignments -->
                    <?php if(!empty($assignments)): ?>
                        <div class="member-assignments-section">
                            <h3>Jabatan Struktur</h3>
                            <div class="member-assignments-list">
                                <?php foreach($assignments as $assignment): ?>
                                    <div class="member-assignment-item">
                                        <div class="member-assignment-icon">
                                            <i class="bi bi-person-badge"></i>
                                        </div>
                                        <div class="member-assignment-details">
                                            <h4><?= e($assignment['position_title']) ?></h4>
                                            <p><?= e($assignment['group_name']) ?> 
                                            <?php if($assignment['term_name']): ?>
                                                • <?= e($assignment['term_name']) ?>
                                            <?php endif; ?>
                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Quick Actions -->
                    <div class="member-quick-actions">
                        <a href="<?= e(org_url($organization, 'member/card')) ?>" class="btn-editorial-primary">
                            <i class="bi bi-card-heading"></i> Lihat Kartu Anggota
                        </a>
                        <a href="<?= e(org_url($organization, 'member/profile')) ?>" class="btn-editorial-secondary">
                            <i class="bi bi-person-gear"></i> Edit Profil
                        </a>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <style>
        .member-portal-container {
            min-height: 100vh;
            background: var(--background-color);
        }

        .member-portal-header {
            background: var(--surface-color);
            border-bottom: 1px solid var(--border-subtle);
            padding: 1rem 0;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .member-portal-header .container-editorial {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1.5rem;
        }

        .member-portal-brand {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .member-portal-logo, .member-portal-logo-placeholder {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            object-fit: contain;
        }

        .member-portal-logo-placeholder {
            background: var(--primary-color);
            color: white;
            display: grid;
            place-items: center;
            font-size: 1.5rem;
        }

        .member-portal-brand-text h1 {
            font-size: 1.1rem;
            font-weight: 700;
            margin: 0;
            color: var(--text-color);
        }

        .member-portal-brand-text p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .member-portal-nav {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .member-portal-nav-item {
            display: flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.5rem 1rem;
            border-radius: var(--radius-pill);
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-decoration: none;
            transition: all 0.25s ease;
        }

        .member-portal-nav-item:hover,
        .member-portal-nav-item.active {
            background: var(--primary-color);
            color: white;
        }

        .member-portal-logout {
            color: #dc3545;
        }

        .member-portal-logout:hover {
            background: #dc3545;
            color: white;
        }

        .member-portal-main {
            padding: 2rem 0;
        }

        .member-overview-card {
            background: var(--surface-color);
            border: 1px solid var(--border-subtle);
            border-radius: var(--radius-xl);
            padding: 2rem;
            max-width: 800px;
            margin: 0 auto;
        }

        .member-overview-header {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--border-subtle);
        }

        .member-overview-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            overflow: hidden;
            flex-shrink: 0;
        }

        .member-overview-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .member-overview-avatar-placeholder {
            width: 100%;
            height: 100%;
            background: var(--surface-warm);
            display: grid;
            place-items: center;
            font-size: 2rem;
            color: var(--text-tertiary);
        }

        .member-overview-info h2 {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0 0 0.5rem 0;
            color: var(--text-color);
        }

        .member-overview-subtitle {
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .member-status {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .member-status-active {
            background: #10b981;
            color: white;
        }

        .member-status-pending {
            background: #f59e0b;
            color: white;
        }

        .member-status-rejected {
            background: #ef4444;
            color: white;
        }

        .member-status-suspended {
            background: #f97316;
            color: white;
        }

        .member-status-inactive {
            background: #6b7280;
            color: white;
        }

        .member-status-alumni {
            background: #8b5cf6;
            color: white;
        }

        .member-status-banner {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
            border-radius: var(--radius-md);
            margin-bottom: 1.5rem;
            font-size: 0.9rem;
        }

        .member-status-pending {
            background: #fef3c7;
            color: #92400e;
            border: 1px solid #fbbf24;
        }

        .member-status-rejected {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #f87171;
        }

        .member-status-suspended {
            background: #ffedd5;
            color: #9a3412;
            border: 1px solid #fb923c;
        }

        .member-status-inactive {
            background: #f3f4f6;
            color: #374151;
            border: 1px solid #9ca3af;
        }

        .member-status-alumni {
            background: #ede9fe;
            color: #5b21b6;
            border: 1px solid #a78bfa;
        }

        .member-details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .member-detail-item label {
            display: block;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-secondary);
            margin-bottom: 0.25rem;
        }

        .member-detail-item p {
            font-size: 0.95rem;
            color: var(--text-color);
            margin: 0;
        }

        .member-assignments-section {
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid var(--border-subtle);
        }

        .member-assignments-section h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--text-color);
        }

        .member-assignments-list {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }

        .member-assignment-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: var(--surface-warm);
            border-radius: var(--radius-md);
            border: 1px solid var(--border-subtle);
        }

        .member-assignment-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary-color);
            color: white;
            display: grid;
            place-items: center;
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        .member-assignment-details h4 {
            font-size: 0.95rem;
            font-weight: 700;
            margin: 0 0 0.25rem 0;
            color: var(--text-color);
        }

        .member-assignment-details p {
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .member-quick-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        @media (max-width: 768px) {
            .member-portal-header .container-editorial {
                flex-direction: column;
                align-items: flex-start;
            }

            .member-portal-nav {
                width: 100%;
                overflow-x: auto;
                padding-bottom: 0.5rem;
            }

            .member-overview-header {
                flex-direction: column;
                text-align: center;
            }

            .member-details-grid {
                grid-template-columns: 1fr;
            }

            .member-quick-actions {
                flex-direction: column;
            }

            .member-quick-actions a {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</body>
</html>