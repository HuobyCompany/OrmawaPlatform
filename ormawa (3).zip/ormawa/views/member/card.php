<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($title) ?> - <?= e($organization['name']) ?></title>
    <link rel="stylesheet" href="<?= e(asset_url('css/app.css')) ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body>
    <div class="member-card-container">
        <div class="container-editorial">
            <!-- Back Button -->
            <div class="member-card-nav">
                <a href="<?= e(org_url($organization, 'member')) ?>" class="btn-editorial-secondary">
                    <i class="bi bi-arrow-left"></i> Kembali ke Portal
                </a>
            </div>

            <!-- Member Card -->
            <div class="member-card-wrapper">
                <div class="member-card <?= $member ? 'member-status-' . e($member['status']) : '' ?>">
                    <!-- Card Header -->
                    <div class="member-card-header">
                        <div class="member-card-logo">
                            <?php if(!empty($organization['logo'])): ?>
                                <img src="<?= e(upload_url($organization['logo'])) ?>" alt="<?= e($organization['name']) ?>">
                            <?php else: ?>
                                <div class="member-card-logo-placeholder">
                                    <i class="bi bi-buildings"></i>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="member-card-org-info">
                            <h2><?= e($organization['name']) ?></h2>
                            <p><?= e($organization['short_name'] ?? $organization['name']) ?></p>
                        </div>
                    </div>

                    <!-- Card Body -->
                    <div class="member-card-body">
                        <div class="member-card-photo">
                            <?php if(!empty($person['photo_path'])): ?>
                                <img src="<?= e(upload_url($person['photo_path'])) ?>" alt="<?= e($person['full_name'] ?? $user['name']) ?>">
                            <?php else: ?>
                                <div class="member-card-photo-placeholder">
                                    <i class="bi bi-person-circle"></i>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="member-card-info">
                            <h3><?= e($person['full_name'] ?? $user['name']) ?></h3>
                            <div class="member-card-number">
                                <span class="member-card-label">Nomor Anggota</span>
                                <span class="member-card-value"><?= e($member['member_number'] ?? '-') ?></span>
                            </div>
                            <div class="member-card-period">
                                <span class="member-card-label">Periode</span>
                                <span class="member-card-value"><?= e($member['term_name'] ?? '-') ?></span>
                            </div>
                            <div class="member-card-status">
                                <span class="member-card-label">Status</span>
                                <span class="member-card-status-badge member-status-<?= e($member['status'] ?? 'pending') ?>">
                                    <?= e(ucfirst($member['status'] ?? 'Pending')) ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Card Footer -->
                    <div class="member-card-footer">
                        <div class="member-card-footer-info">
                            <p>Kartu Anggota Digital</p>
                            <p><?= date('d F Y') ?></p>
                        </div>
                        <div class="member-card-footer-actions">
                            <button onclick="window.print()" class="btn-editorial-ghost">
                                <i class="bi bi-printer"></i> Cetak
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card Actions -->
            <div class="member-card-actions">
                <a href="<?= e(org_url($organization, 'member/profile')) ?>" class="btn-editorial-secondary">
                    <i class="bi bi-person-gear"></i> Edit Profil
                </a>
                <a href="/admin/logout" class="btn-editorial-ghost" style="color: #dc3545;">
                    <i class="bi bi-box-arrow-right"></i> Keluar
                </a>
            </div>
        </div>
    </div>

    <style>
        .member-card-container {
            min-height: 100vh;
            background: var(--background-color);
            padding: 2rem 0;
        }

        .member-card-nav {
            margin-bottom: 2rem;
        }

        .member-card-wrapper {
            max-width: 400px;
            margin: 0 auto;
        }

        .member-card {
            background: white;
            border-radius: var(--radius-xl);
            overflow: hidden;
            box-shadow: var(--shadow-card);
            position: relative;
        }

        .member-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 8px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
        }

        .member-card-header {
            padding: 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            border-bottom: 1px solid var(--border-subtle);
            background: var(--surface-warm);
        }

        .member-card-logo, .member-card-logo-placeholder {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            object-fit: contain;
        }

        .member-card-logo-placeholder {
            background: var(--primary-color);
            color: white;
            display: grid;
            place-items: center;
            font-size: 1.2rem;
        }

        .member-card-org-info h2 {
            font-size: 1rem;
            font-weight: 700;
            margin: 0 0 0.25rem 0;
            color: var(--text-color);
        }

        .member-card-org-info p {
            font-size: 0.8rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .member-card-body {
            padding: 2rem 1.5rem;
            text-align: center;
        }

        .member-card-photo {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            margin: 0 auto 1.5rem;
            overflow: hidden;
            border: 4px solid var(--border-subtle);
        }

        .member-card-photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .member-card-photo-placeholder {
            width: 100%;
            height: 100%;
            background: var(--surface-warm);
            display: grid;
            place-items: center;
            font-size: 3rem;
            color: var(--text-tertiary);
        }

        .member-card-info h3 {
            font-size: 1.25rem;
            font-weight: 700;
            margin: 0 0 1.5rem 0;
            color: var(--text-color);
        }

        .member-card-number,
        .member-card-period,
        .member-card-status {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.75rem 0;
            border-bottom: 1px solid var(--border-subtle);
        }

        .member-card-number:last-child,
        .member-card-period:last-child,
        .member-card-status:last-child {
            border-bottom: none;
        }

        .member-card-label {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }

        .member-card-value {
            font-size: 0.95rem;
            font-weight: 700;
            color: var(--text-color);
        }

        .member-card-status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .member-status-active {
            background: #10b981;
            color: white;
        }

        .member-status-pending {
            background: #f59e0b;
            color: white;
        }

        .member-status-rejected {
            background: #ef4444;
            color: white;
        }

        .member-status-suspended {
            background: #f97316;
            color: white;
        }

        .member-status-inactive {
            background: #6b7280;
            color: white;
        }

        .member-status-alumni {
            background: #8b5cf6;
            color: white;
        }

        .member-card-footer {
            padding: 1rem 1.5rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--surface-warm);
            border-top: 1px solid var(--border-subtle);
        }

        .member-card-footer-info p {
            font-size: 0.75rem;
            color: var(--text-secondary);
            margin: 0;
        }

        .member-card-footer-info p:last-child {
            font-weight: 600;
            color: var(--text-color);
        }

        .member-card-actions {
            max-width: 400px;
            margin: 2rem auto 0;
            display: flex;
            gap: 1rem;
            justify-content: center;
        }

        @media print {
            .member-card-nav,
            .member-card-actions {
                display: none;
            }

            .member-card-container {
                background: white;
                padding: 0;
            }

            .member-card-wrapper {
                max-width: none;
            }

            .member-card {
                box-shadow: none;
                border: 1px solid var(--border-subtle);
            }
        }

        @media (max-width: 768px) {
            .member-card-wrapper {
                max-width: 100%;
            }

            .member-card-actions {
                flex-direction: column;
            }

            .member-card-actions a {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</body>
</html>