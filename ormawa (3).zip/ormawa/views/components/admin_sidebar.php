<aside class="admin-sidebar" id="adminSidebar">
    <div class="sidebar-head">
        <a class="brand-link" href="<?= url('/admin/dashboard') ?>">
            <?php if (!empty($organization['logo'])): ?>
                <img src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('sidebar-logo', 200, 200) : e(media_url($organization['logo'])) ?>" alt="Logo <?= e($organization['short_name'] ?? $organization['name'] ?? '') ?>">
            <?php else: ?>
                <div class="brand-mark"><i class="bi bi-buildings"></i></div>
            <?php endif; ?>
            <div class="min-w-0">
                <strong><?= e($organization['short_name'] ?? $organization['name'] ?? APP_NAME) ?></strong>
                <span>ORMAWA Platform</span>
            </div>
        </a>
        <button class="btn btn-sm btn-light d-lg-none js-sidebar-close" type="button" aria-label="Tutup menu">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>

    <nav class="sidebar-nav">
        <a href="<?= url('/admin/dashboard') ?>" class="sidebar-link <?= request_path() === '/admin/dashboard' ? 'active' : '' ?>">
            <i class="bi bi-grid-fill"></i>
            <span>Dashboard</span>
        </a>

        <div class="sidebar-label">Tampilan & Identitas</div>
        <a href="<?= url('/admin/organization') ?>" class="sidebar-link <?= request_path() === '/admin/organization' ? 'active' : '' ?>">
            <i class="bi bi-sliders"></i>
            <span>Profil, Logo & Warna</span>
        </a>
        <a href="<?= url('/admin/settings') ?>" class="sidebar-link <?= request_path() === '/admin/settings' ? 'active' : '' ?>">
            <i class="bi bi-aspect-ratio"></i>
            <span>Ukuran Foto & Layout</span>
        </a>

        <div class="sidebar-label">Konten & Kegiatan</div>
        <a href="<?= url('/admin/events') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/events') ? 'active' : '' ?>">
            <i class="bi bi-calendar-event"></i>
            <span>Agenda Kegiatan</span>
        </a>
        <a href="<?= url('/admin/calendar') ?>" class="sidebar-link <?= request_path() === '/admin/calendar' ? 'active' : '' ?>">
            <i class="bi bi-calendar3"></i>
            <span>Jadwal Kalender</span>
        </a>
        <a href="<?= url('/admin/gallery') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/gallery') ? 'active' : '' ?>">
            <i class="bi bi-images"></i>
            <span>Galeri Foto</span>
        </a>
        <a href="<?= url('/admin/structure') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/structure') ? 'active' : '' ?>">
            <i class="bi bi-diagram-3"></i>
            <span>Struktur Pengurus</span>
         </a>

         <div class="sidebar-label">Keanggotaan</div>
         <a href="<?= url('/admin/registration') ?>" class="sidebar-link <?= (str_starts_with(request_path(), '/admin/registration') && !str_starts_with(request_path(), '/admin/registration/submiss')) ? 'active' : '' ?>">
             <i class="bi bi-person-plus"></i>
             <span>Form Pendaftaran</span>
         </a>
         <a href="<?= url('/admin/registration/submissions') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/registration/submiss') ? 'active' : '' ?>">
             <i class="bi bi-clipboard-data"></i>
             <span>Daftar Pendaftar</span>
         </a>
         <a href="<?= url('/admin/members') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/members') ? 'active' : '' ?>">
             <i class="bi bi-people-fill"></i>
             <span>Data Anggota</span>
         </a>
         <a href="<?= url('/admin/faculties') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/faculties') ? 'active' : '' ?>">
             <i class="bi bi-buildings"></i>
             <span>Fakultas & Prodi</span>
         </a>

         <div class="sidebar-label">Arsip & Dokumen</div>
        <a href="<?= url('/admin/letters') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/letters') ? 'active' : '' ?>">
            <i class="bi bi-file-earmark-text"></i>
            <span>Arsip Surat</span>
        </a>

        <div class="sidebar-label">Sistem & Media</div>
        <a href="<?= url('/admin/media') ?>" class="sidebar-link <?= request_path() === '/admin/media' ? 'active' : '' ?>">
            <i class="bi bi-folder2-open"></i>
            <span>Media File</span>
        </a>
        <?php if (can('manage_users')): ?>
            <a href="<?= url('/admin/users') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/users') ? 'active' : '' ?>">
                <i class="bi bi-people"></i>
                <span>Kelola Admin</span>
            </a>
        <?php endif; ?>
        <?php if (auth_user()['role'] === 'super_admin'): ?>
            <a href="<?= url('/admin/organizations') ?>" class="sidebar-link <?= str_starts_with(request_path(), '/admin/organizations') ? 'active' : '' ?>">
                <i class="bi bi-buildings"></i>
                <span>Daftar Organisasi</span>
            </a>
        <?php endif; ?>
    </nav>

    <div class="sidebar-foot">
        <div class="d-flex align-items-center gap-2 small text-secondary">
            <span class="badge rounded-circle bg-success p-1" style="width: 8px; height: 8px;"></span>
            <span>Admin Mode • Aktif</span>
        </div>
    </div>
</aside>
