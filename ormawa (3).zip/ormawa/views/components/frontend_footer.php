<footer class="site-footer">
  <div class="container-editorial">
    <div class="footer-grid">
      <div class="footer-brand">
        <div class="d-flex align-items-center gap-3 mb-3">
          <?php if (!empty($organization['logo'])): ?>
            <img class="brand-logo-footer" src="<?= e(upload_url($organization['logo'])) ?>" alt="Logo <?= e($organization['name']) ?>">
          <?php elseif (DEBUG_DUMMY_IMAGES): ?>
            <img class="brand-logo-footer" src="<?= dummy_image_url('footer-logo', 200, 200) ?>" alt="Logo <?= e($organization['name']) ?>">
          <?php else: ?>
            <span class="brand-mark"><i class="bi bi-buildings"></i></span>
          <?php endif; ?>
          <div>
            <div class="fw-bold"><?= e($organization['name']) ?></div>
            <div class="small text-secondary"><?= e($organization['website_name'] ?: 'ORMAWA Platform') ?></div>
          </div>
        </div>
        <p class="editorial-body mb-4"><?= e($organization['description']) ?></p>
        <div class="footer-socials">
          <?php foreach (['instagram', 'facebook', 'youtube', 'tiktok', 'linkedin'] as $s): 
            if (!empty($organization[$s])): 
          ?>
            <a class="social-link" href="<?= e(absolute_url($organization[$s])) ?>" target="_blank" rel="noopener" aria-label="<?= e(ucfirst($s)) ?>">
              <i class="bi bi-<?= e($s) ?>"></i>
            </a>
          <?php endif; endforeach; ?>
        </div>
      </div>

      <div class="footer-nav">
        <div class="editorial-label mb-3">Navigasi Utama</div>
        <div class="vstack gap-2">
          <?php foreach ([['tentang', 'Tentang Organisasi'], ['kegiatan', 'Agenda Kegiatan'], ['kalender', 'Kalender Aktivitas'], ['gallery', 'Galeri Foto'], ['struktur', 'Struktur Pengurus'], ['kontak', 'Kontak']] as [$p, $l]): ?>
            <a class="footer-link" href="<?= e(org_url($organization, $p)) ?>"><?= e($l) ?></a>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="footer-contact">
        <div class="editorial-label mb-3">Sekretariat & Kontak</div>
        <div class="vstack gap-2 small editorial-body">
          <?php if ($organization['address']): ?>
            <div><i class="bi bi-geo-alt me-2 text-primary"></i><?= e($organization['address']) ?></div>
          <?php endif; ?>
          <?php if ($organization['email']): ?>
            <div><i class="bi bi-envelope me-2 text-primary"></i><a href="mailto:<?= e($organization['email']) ?>"><?= e($organization['email']) ?></a></div>
          <?php endif; ?>
          <?php if ($organization['phone']): ?>
            <div><i class="bi bi-telephone me-2 text-primary"></i><a href="tel:<?= e($organization['phone']) ?>"><?= e($organization['phone']) ?></a></div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- Copyright & Credits -->
    <div class="footer-bottom">
      <div class="footer-bottom-links ms-auto">
        <a href="<?= e(url('admin/login')) ?>"><i class="bi bi-box-arrow-in-right me-1"></i> Login</a>
        <span class="footer-sep">•</span>
        <span>Created by <strong>Huoby Company</strong></span>
      </div>
    </div>
  </div>
</footer>
