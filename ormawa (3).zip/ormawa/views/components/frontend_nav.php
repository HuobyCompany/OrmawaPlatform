<header class="site-header">
  <div class="container-editorial">
      <a class="brand" href="<?= e(org_url($organization)) ?>">
        <?php if(!empty($organization['logo'])): ?>
          <img class="brand-logo" src="<?= e(upload_url($organization['logo'])) ?>" alt="Logo <?= e($organization['name']) ?>">
        <?php elseif(DEBUG_DUMMY_IMAGES): ?>
          <img class="brand-logo" src="<?= dummy_image_url('brand-logo', 200, 200) ?>" alt="Logo <?= e($organization['name']) ?>">
        <?php else: ?>
          <span class="brand-mark"><i class="bi bi-buildings"></i></span>
        <?php endif; ?>
      <span class="brand-copy">
        <strong><?= e($organization['short_name'] ?: $organization['name']) ?></strong>
        <span><?= e($organization['website_name'] ?: 'ORMAWA Platform') ?></span>
      </span>
    </a>

    <nav class="nav-menu" id="siteNavMenu" data-nav-menu>
      <?php
      $navItems = [['','Beranda'],['tentang','Profil'],['kegiatan','Agenda'],['kalender','Kalender'],['gallery','Galeri'],['struktur','Struktur'],['kontak','Kontak']];
      foreach ($navItems as [$path,$label]):
        $isActive = ($path!=='' && str_contains(request_path(),'/'.$path)) || ($path==='' && request_path()==='/'.trim($organization['slug'],'/'));
      ?>
        <a href="<?= e(org_url($organization,$path)) ?>" class="nav-link-item <?= $isActive ? 'active' : '' ?>">
          <?= e($label) ?>
        </a>
      <?php endforeach; ?>

      <?php if ($registration_available ?? false): ?>
        <a href="<?= e(org_url($organization, 'join')) ?>" class="nav-link-item">
          Pendaftaran
        </a>
      <?php endif; ?>

      <a href="<?= e(org_url($organization, 'login')) ?>" class="nav-link-item">
        Login
      </a>
    </nav>










    <div class="nav-actions">
      <button class="nav-toggle" type="button" data-nav-toggle aria-controls="siteNavMenu" aria-expanded="false" aria-label="Buka navigasi">
        <span class="nav-toggle-bar"></span>
        <span class="nav-toggle-bar"></span>
        <span class="nav-toggle-bar"></span>
      </button>
    </div>
  </div>
</header>
