<?php
/** @var string $editorType @var string $editorLabel @var string $editorName @var string $editorPlaceholder @var string $editorHelpText @var int $editorRequired @var int $editorActive @var int $editorSortOrder @var array $editorOptions @var array $editorConfig @var array $editorValidation */
$fieldTypeLabels = [
    'text' => 'Teks Singkat', 'textarea' => 'Teks Panjang', 'number' => 'Angka',
    'phone' => 'Nomor Telepon', 'date' => 'Tanggal', 'email' => 'Email',
    'select' => 'Pilihan Ganda (Select Dropdown)', 'radio' => 'Pilihan Ganda (Radio Button)',
    'checkbox' => 'Kotak Centang (Checkbox Multiple)', 'file_image' => 'Upload Foto', 'file' => 'Upload Dokumen',
    'social_media' => 'Media Sosial', 'faculty_selector' => 'Pemilih Fakultas',
    'program_study_selector' => 'Pemilih Program Studi',
];
$typeGroups = [
    'Teks & Kontak' => ['text', 'textarea', 'email', 'phone', 'date', 'number'],
    'Pilihan Jawaban' => ['select', 'radio', 'checkbox'],
    'Upload File' => ['file_image', 'file'],
    'Master Data Universitas' => ['faculty_selector', 'program_study_selector'],
    'Lainnya' => ['social_media'],
];
$isEditMode = isset($editorFieldId);
?>

<div class="row g-3">
    <!-- Question Title / Label -->
    <div class="col-md-8">
        <label class="form-label fw-semibold small text-dark">Judul Pertanyaan / Label <span class="text-danger">*</span></label>
        <input type="text" name="label" class="form-control border-0 bg-light rounded-3 px-3 py-2 fw-semibold" value="<?= e($editorLabel ?? '') ?>" required placeholder="Misal: Nama Lengkap, NPM, No WhatsApp">
    </div>

    <!-- Question Key / Field Name -->
    <div class="col-md-4">
        <label class="form-label fw-semibold small text-dark">Nama Key Data <span class="text-muted small">(Auto)</span></label>
        <input type="text" name="name" class="form-control border-0 bg-light rounded-3 px-3 py-2 text-muted" value="<?= e($editorName ?? '') ?>" placeholder="Diisi otomatis">
    </div>

    <!-- Field Type Selection -->
    <div class="col-12">
        <label class="form-label fw-semibold small text-dark">Jenis Jawaban / Tipe Input <span class="text-danger">*</span></label>
        <select name="field_type" class="form-select border-0 bg-light rounded-3 px-3 py-2 field-type-select fw-semibold" required>
            <option value="">-- Pilih jenis input --</option>
            <?php foreach ($typeGroups as $group => $types): ?>
                <optgroup label="<?= e($group) ?>">
                    <?php foreach ($types as $t): ?>
                        <option value="<?= e($t) ?>" <?= ($editorType ?? '') === $t ? 'selected' : '' ?>><?= e($fieldTypeLabels[$t] ?? $t) ?></option>
                    <?php endforeach; ?>
                </optgroup>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- Placeholder & Sort Order -->
    <div class="col-md-8">
        <label class="form-label fw-semibold small text-dark">Placeholder (Hint Teks)</label>
        <input type="text" name="placeholder" class="form-control border-0 bg-light rounded-3 px-3" value="<?= e($editorPlaceholder ?? '') ?>" placeholder="Contoh: Contoh: 0812xxxxxxxx">
    </div>
    <div class="col-md-4">
        <label class="form-label fw-semibold small text-dark">Urutan (Sort Order)</label>
        <input type="number" name="sort_order" class="form-control border-0 bg-light rounded-3 px-3" value="<?= e($editorSortOrder ?? 0) ?>">
    </div>

    <!-- Help Text -->
    <div class="col-12">
        <label class="form-label fw-semibold small text-dark">Petunjuk Pengisian / Instruksi Tambahan</label>
        <textarea name="help_text" class="form-control border-0 bg-light rounded-3 px-3" rows="2" placeholder="Tampilkan pesan bantuan di bawah field untuk memudahkan pendaftar..."><?= e($editorHelpText ?? '') ?></textarea>
    </div>

    <!-- Dynamic Options Group (select/radio/checkbox) -->
    <div class="col-12 options-group" style="display: none;">
        <div class="card border-0 bg-primary bg-opacity-10 rounded-4 p-3">
            <label class="form-label fw-bold text-primary small mb-1">
                <i class="bi bi-list-stars me-1"></i>Pilihan Jawaban (Opsi)
            </label>
            <p class="small text-secondary mb-2">Tuliskan pilihan jawaban, pisahkan setiap opsi dengan menekan <strong>Enter</strong> (satu opsi per baris):</p>
            <textarea name="options[]" class="form-control border-0 bg-white rounded-3 shadow-none px-3" rows="4" placeholder="Pilihan Opsi A&#10;Pilihan Opsi B&#10;Pilihan Opsi C"><?= e(implode("\n", array_filter((array)($editorOptions ?? [])))) ?></textarea>
        </div>
    </div>

    <!-- Dynamic File Config Group (file_image/file) -->
    <div class="col-12 file-config-group" style="display: none;">
        <div class="card border-0 bg-primary bg-opacity-10 rounded-4 p-3">
            <label class="form-label fw-bold text-primary small mb-2">
                <i class="bi bi-file-earmark-check me-1"></i>Batasan File Upload
            </label>
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label fw-semibold small text-dark">Format yang Diizinkan</label>
                    <input type="text" name="file_accept" class="form-control border-0 bg-white rounded-3 shadow-none" value="<?= e($editorConfig['file_accept'] ?? '') ?>" placeholder="jpg,jpeg,png,webp,pdf">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-semibold small text-dark">Batas Ukuran (MB)</label>
                    <input type="number" name="file_max_mb" class="form-control border-0 bg-white rounded-3 shadow-none" value="<?= e(isset($editorConfig['file_max_bytes']) ? (int)($editorConfig['file_max_bytes'] / 1048576) : 5) ?>" min="1" max="50">
                </div>
            </div>
        </div>
    </div>

    <!-- Dynamic Depends Group (program_study_selector) -->
    <div class="col-12 depends-group" style="display: none;">
        <div class="card border-0 bg-primary bg-opacity-10 rounded-4 p-3">
            <label class="form-label fw-bold text-primary small mb-1">
                <i class="bi bi-diagram-2 me-1"></i>Sumber Relasi Fakultas
            </label>
            <p class="small text-secondary mb-2">Pilih field Fakultas yang menjadi acuan daftar Program Studi ini:</p>
            <select name="program_study_depends_on" class="form-select border-0 bg-white rounded-3 shadow-none">
                <option value="">-- Pilih Field Fakultas --</option>
                <?php foreach ($faculties ?? [] as $facField): ?>
                    <?php $isDep = isset($editorConfig['depends_on']) && $editorConfig['depends_on'] === $facField['name']; ?>
                    <option value="<?= e($facField['name']) ?>" <?= $isDep ? 'selected' : '' ?>>Field: <?= e($facField['label'] ?? $facField['name']) ?> (<?= e($facField['name']) ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
    </div>

    <!-- Validation Settings -->
    <div class="col-12">
        <div class="card border-0 bg-light rounded-4 p-3">
            <label class="form-label fw-bold text-dark small mb-2">
                <i class="bi bi-shield-check me-1"></i>Aturan Validasi Tambahan (Opsional)
            </label>
            <div class="row g-2">
                <div class="col-md-6">
                    <input type="number" name="max_length" class="form-control border-0 bg-white rounded-3 form-control-sm" placeholder="Maksimal Panjang Karakter">
                </div>
                <div class="col-md-6">
                    <input type="number" name="min_length" class="form-control border-0 bg-white rounded-3 form-control-sm" placeholder="Minimal Panjang Karakter">
                </div>
            </div>
        </div>
    </div>

    <!-- Switches: Required & Active -->
    <div class="col-12 pt-2">
        <div class="d-flex gap-4 p-3 bg-light rounded-4">
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="is_required_<?= $isEditMode ? $editorFieldId : 'new' ?>" name="is_required" <?= ($editorRequired ?? 0) ? 'checked' : '' ?>>
                <label class="form-check-label fw-bold small text-dark" for="is_required_<?= $isEditMode ? $editorFieldId : 'new' ?>">Wajib Diisi (Required)</label>
            </div>
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" id="is_active_<?= $isEditMode ? $editorFieldId : 'new' ?>" name="is_active" <?= ($editorActive ?? 1) ? 'checked' : '' ?>>
                <label class="form-check-label fw-bold small text-dark" for="is_active_<?= $isEditMode ? $editorFieldId : 'new' ?>">Field Aktif</label>
            </div>
        </div>
    </div>
</div>
