<?php 
// views/admin/structure.php
$termList = $terms ?? [];
$activeTerm = $selectedTerm ?? ($termList[0] ?? []);
$groupList = $groups ?? [];
?>

<!-- Page Header & Level 1: Term Selector Bar -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="editorial-label text-primary mb-1"><i class="bi bi-layers me-1"></i> Panel Admin Struktur</div>
        <h2 class="h3 fw-bold text-dark mb-1">Struktur Organisasi</h2>
        <p class="text-secondary small mb-0">Kelola periode kepengurusan, kelompok divisi/bph, dan pengurus secara fleksibel.</p>
    </div>

    <!-- Level 1: Term Switcher & Controls -->
    <div class="d-flex flex-nowrap align-items-center gap-2">
        <div class="dropdown">
            <button class="btn btn-outline-dark rounded-pill px-3.5 py-2 d-inline-flex align-items-center gap-2 fw-semibold dropdown-toggle shadow-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-calendar-event text-primary"></i>
                <span>Periode: <?= e($activeTerm['name'] ?? 'Pilih Periode') ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow-lg rounded-4 p-2" style="min-width: 240px;">
                <li class="dropdown-header small text-muted text-uppercase">Pilih Periode Kepengurusan</li>
                <?php foreach ($termList as $t): ?>
                    <li>
                        <a class="dropdown-item rounded-3 py-2 px-3 small d-flex align-items-center justify-content-between <?= (int)$t['id'] === (int)$activeTerm['id'] ? 'active fw-bold' : '' ?>" href="<?= url('/admin/structure?term=' . $t['id']) ?>">
                            <span><?= e($t['name']) ?></span>
                            <?php if ((int)$t['id'] === (int)$activeTerm['id']): ?>
                                <i class="bi bi-check-lg"></i>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endforeach; ?>
                <li><hr class="dropdown-divider"></li>
                <li>
                    <button type="button" class="dropdown-item rounded-3 py-2 px-3 small text-primary fw-semibold d-flex align-items-center gap-2" data-bs-toggle="modal" data-bs-target="#modalTerm">
                        <i class="bi bi-plus-circle"></i>
                        <span>Tambah Periode Baru</span>
                    </button>
                </li>
            </ul>
        </div>

        <button type="button" class="btn btn-primary rounded-pill px-4 py-2 d-inline-flex align-items-center gap-2 shadow-sm fw-semibold text-nowrap" data-bs-toggle="modal" data-bs-target="#modalGroup">
            <i class="bi bi-plus-lg"></i>
            <span>Tambah Divisi</span>
        </button>
    </div>
</div>

<!-- Active Term Status Banner -->
<div class="bg-white p-3 rounded-4 shadow-sm border mb-4 d-flex align-items-center justify-content-between flex-wrap gap-2">
    <div class="d-flex align-items-center gap-2">
        <span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-1.5 small fw-semibold">
            <i class="bi bi-calendar-check me-1"></i>Periode Aktif: <?= e($activeTerm['name'] ?? '-') ?>
        </span>
        <span class="small text-secondary">
            <?= !empty($activeTerm['start_date']) ? date('d M Y', strtotime($activeTerm['start_date'])) : '' ?>
            <?= !empty($activeTerm['end_date']) ? ' s/d ' . date('d M Y', strtotime($activeTerm['end_date'])) : '' ?>
        </span>
    </div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-sm btn-light border rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#modalTerm" data-id="<?= $activeTerm['id'] ?>" data-name="<?= e($activeTerm['name']) ?>" data-slug="<?= e($activeTerm['slug']) ?>" data-start="<?= e($activeTerm['start_date']) ?>" data-end="<?= e($activeTerm['end_date']) ?>">
            <i class="bi bi-pencil me-1"></i>Edit Periode Ini
        </button>
    </div>
</div>

<!-- Level 2: Structure Group Cards Grid -->
<?php if (!$groupList): ?>
    <div class="card border-0 shadow-sm rounded-4 p-5 bg-white text-center">
        <div class="avatar-circle-lg bg-primary bg-opacity-10 text-primary mx-auto mb-3">
            <i class="bi bi-diagram-3 fs-2"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1">Belum Ada Kelompok Struktur</h5>
        <p class="small text-muted mb-4">Buat kelompok pertama seperti BPH, Divisi, Departemen, atau Dewan Pembina.</p>
        <div>
            <button type="button" class="btn btn-primary rounded-pill px-4 py-2 fw-semibold" data-bs-toggle="modal" data-bs-target="#modalGroup">
                <i class="bi bi-plus-lg me-1"></i>Tambah Kelompok Pertama
            </button>
        </div>
    </div>
<?php else: ?>

    <div class="row g-3 g-md-4">
        <?php foreach ($groupList as $g): ?>
            <?php 
                $gId = (int)$g['id'];
                $personCount = (int)($g['person_count'] ?? 0);
                $vacantCount = (int)($g['vacant_count'] ?? 0);
                $posCount = (int)($g['position_count'] ?? 0);
            ?>
            <div class="col-md-6 col-xl-4">
                <div class="card border-0 shadow-sm rounded-4 h-100 bg-white hover-lift transition-all">
                    <div class="card-body p-4 d-flex flex-column">
                        
                        <!-- Card Header -->
                        <div class="d-flex align-items-start justify-content-between mb-3">
                            <div class="d-flex align-items-center gap-3">
                                <div class="avatar-circle bg-primary bg-opacity-10 text-primary rounded-4 p-3 d-flex align-items-center justify-content-center" style="width: 48px; height: 48px;">
                                    <i class="bi bi-people-fill fs-4"></i>
                                </div>
                                <div>
                                    <h3 class="h5 fw-bold text-dark mb-0 text-truncate" style="max-width: 200px;" title="<?= e($g['name']) ?>">
                                        <?= e($g['name']) ?>
                                    </h3>
                                    <span class="small text-muted"><?= $posCount ?> Jabatan / Posisi</span>
                                </div>
                            </div>
                            
                            <!-- Group Controls Dropdown -->
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light rounded-circle p-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow-sm rounded-3 p-2">
                                    <li>
                                        <button type="button" class="dropdown-item rounded-2 small text-dark btn-edit-group" data-id="<?= $gId ?>" data-name="<?= e($g['name']) ?>" data-desc="<?= e($g['description'] ?? '') ?>" data-sort="<?= (int)$g['sort_order'] ?>">
                                            <i class="bi bi-pencil me-2"></i>Edit Kelompok
                                        </button>
                                    </li>
                                    <li>
                                        <form method="post" action="<?= url('/admin/structure/group/move/' . $gId . '/up') ?>">
                                            <?= Csrf::field() ?>
                                            <button type="submit" class="dropdown-item rounded-2 small text-dark"><i class="bi bi-arrow-up me-2"></i>Geser Ke Atas</button>
                                        </form>
                                    </li>
                                    <li>
                                        <form method="post" action="<?= url('/admin/structure/group/move/' . $gId . '/down') ?>">
                                            <?= Csrf::field() ?>
                                            <button type="submit" class="dropdown-item rounded-2 small text-dark"><i class="bi bi-arrow-down me-2"></i>Geser Ke Bawah</button>
                                        </form>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <button type="button" class="dropdown-item rounded-2 small text-danger" data-confirm-url="<?= url('/admin/structure/group/delete/' . $gId) ?>" data-confirm-message="Hapus kelompok <?= e($g['name']) ?>?">
                                            <i class="bi bi-trash3 me-2"></i>Hapus Kelompok
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <!-- Short Description -->
                        <p class="small text-secondary mb-4 flex-grow-1 line-clamp-2">
                            <?= e($g['description'] ?: 'Tidak ada deskripsi singkat.') ?>
                        </p>

                        <!-- Footer Info & Primary Manage Button -->
                        <div class="pt-3 border-top d-flex align-items-center justify-content-between">
                            <div class="d-flex align-items-center gap-2">
                                <span class="badge bg-success-subtle text-success rounded-pill px-3 py-1.5 small fw-semibold">
                                    <i class="bi bi-person-check me-1"></i><?= $personCount ?> Pengurus
                                </span>
                                <?php if ($vacantCount > 0): ?>
                                    <span class="badge bg-warning-subtle text-warning-emphasis rounded-pill px-2.5 py-1.5 small fw-semibold">
                                        <?= $vacantCount ?> Vacant
                                    </span>
                                <?php endif; ?>
                            </div>

                            <a href="<?= url('/admin/structure/group/' . $gId . '?term=' . $activeTerm['id']) ?>" class="btn btn-primary rounded-pill px-4 py-2 small fw-bold d-inline-flex align-items-center gap-2 shadow-sm">
                                <span>Kelola (Manage)</span>
                                <i class="bi bi-arrow-right"></i>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

<?php endif; ?>

<!-- MODAL: PERIODE (TERM) -->
<div class="modal fade" id="modalTerm" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="<?= url('/admin/structure/term/save') ?>" class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <?= Csrf::field() ?>
            <input type="hidden" name="id" id="term_modal_id" value="">
            <div class="modal-header border-bottom bg-light px-4 py-3">
                <h5 class="modal-title fw-bold text-dark fs-6" id="term_modal_title">Tambah Periode Kepengurusan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Nama Periode / Term</label>
                    <input type="text" name="name" id="term_modal_name" class="form-control rounded-3 py-2" placeholder="Contoh: Periode 2026/2027" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Slug Kode (Opsional)</label>
                    <input type="text" name="slug" id="term_modal_slug" class="form-control rounded-3 py-2" placeholder="Contoh: 2026-2027">
                </div>
                <div class="row g-2">
                    <div class="col-6 mb-3">
                        <label class="form-label fw-semibold small text-dark">Tanggal Mulai</label>
                        <input type="date" name="start_date" id="term_modal_start" class="form-control rounded-3 py-2" value="<?= date('Y-01-01') ?>" required>
                    </div>
                    <div class="col-6 mb-3">
                        <label class="form-label fw-semibold small text-dark">Tanggal Selesai</label>
                        <input type="date" name="end_date" id="term_modal_end" class="form-control rounded-3 py-2">
                    </div>
                </div>
            </div>
            <div class="modal-footer bg-light border-top px-4 py-3">
                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Simpan Periode</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: KELOMPOK STRUKTUR (GROUP) -->
<div class="modal fade" id="modalGroup" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="<?= url('/admin/structure/group/save') ?>" class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <?= Csrf::field() ?>
            <input type="hidden" name="id" id="group_modal_id" value="">
            <input type="hidden" name="term_id" value="<?= $activeTerm['id'] ?>">
            <div class="modal-header border-bottom bg-light px-4 py-3">
                <h5 class="modal-title fw-bold text-dark fs-6" id="group_modal_title">Tambah Kelompok Struktur / Divisi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Nama Kelompok / Divisi</label>
                    <input type="text" name="name" id="group_modal_name" class="form-control rounded-3 py-2" placeholder="Contoh: Badan Pengurus Harian (BPH), Divisi Syiar, PSDM" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Deskripsi Singkat</label>
                    <textarea name="description" id="group_modal_desc" class="form-control rounded-3 py-2" rows="3" placeholder="Jelaskan peran atau fungsi kelompok ini..."></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Urutan Tampilan</label>
                    <input type="number" name="sort_order" id="group_modal_sort" class="form-control rounded-3 py-2" value="0">
                </div>
            </div>
            <div class="modal-footer bg-light border-top px-4 py-3">
                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Simpan Kelompok</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Edit Term Modal pre-fill
    const modalTermEl = document.getElementById('modalTerm');
    if (modalTermEl) {
        modalTermEl.addEventListener('show.bs.modal', (e) => {
            const btn = e.relatedTarget;
            if (btn && btn.dataset.id) {
                document.getElementById('term_modal_id').value = btn.dataset.id;
                document.getElementById('term_modal_name').value = btn.dataset.name || '';
                document.getElementById('term_modal_slug').value = btn.dataset.slug || '';
                document.getElementById('term_modal_start').value = btn.dataset.start || '';
                document.getElementById('term_modal_end').value = btn.dataset.end || '';
                document.getElementById('term_modal_title').textContent = 'Edit Periode Kepengurusan';
            } else {
                document.getElementById('term_modal_id').value = '';
                document.getElementById('term_modal_name').value = '';
                document.getElementById('term_modal_slug').value = '';
                document.getElementById('term_modal_title').textContent = 'Tambah Periode Kepengurusan';
            }
        });
    }

    // Edit Group Modal pre-fill
    document.querySelectorAll('.btn-edit-group').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('group_modal_id').value = btn.dataset.id;
            document.getElementById('group_modal_name').value = btn.dataset.name || '';
            document.getElementById('group_modal_desc').value = btn.dataset.desc || '';
            document.getElementById('group_modal_sort').value = btn.dataset.sort || '0';
            document.getElementById('group_modal_title').textContent = 'Edit Kelompok Struktur';
            
            const modal = new bootstrap.Modal(document.getElementById('modalGroup'));
            modal.show();
        });
    });
});
</script>
