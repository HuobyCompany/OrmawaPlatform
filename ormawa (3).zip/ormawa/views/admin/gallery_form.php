<?php 
$a = $album ?? []; 
$get = fn($k, $d = '') => $a[$k] ?? $d; 
$sourceType = $get('source_type', 'local');
$items = $items ?? [];
?>

<form method="post" action="<?= url('/admin/gallery/save') ?>" enctype="multipart/form-data" id="albumMainForm">
    <input type="hidden" name="id" value="<?= (int)($a['id'] ?? 0) ?>">
    <?= Csrf::field() ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
        <div>
            <div class="text-secondary small fw-semibold">Galeri & Dokumentasi</div>
            <h2 class="h3 fw-bold text-dark mb-1"><?= $a ? 'Edit Album Galeri' : 'Tambah Album Baru' ?></h2>
            <p class="text-secondary small mb-0">Kelola album foto, foto sampul, dan sumber dokumentasi kegiatan.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/admin/gallery') ?>" class="btn btn-light rounded-pill px-3.5">Batal</a>
            <button type="submit" class="btn btn-dark rounded-pill px-4 fw-bold d-inline-flex align-items-center gap-1.5">
                <i class="bi bi-check2"></i>
                <span>Simpan Album</span>
            </button>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-7">
            <div class="admin-card p-4 h-100">
                <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom">
                    <div class="stat-icon bg-primary-subtle text-primary" style="width: 36px; height: 36px; border-radius: 10px;">
                        <i class="bi bi-journal-text"></i>
                    </div>
                    <div>
                        <h3 class="h6 fw-bold text-dark mb-0">Informasi Album</h3>
                        <div class="small text-secondary">Detail utama album kegiatan</div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Nama Album <span class="text-danger">*</span></label>
                    <input class="form-control" name="title" value="<?= e($get('title')) ?>" placeholder="Misal: Makrab Angkatan 2026..." required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Slug URL</label>
                    <input class="form-control font-monospace" name="slug" value="<?= e($get('slug')) ?>" placeholder="makrab-angkatan-2026">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Deskripsi Album</label>
                    <textarea class="form-control" name="description" rows="4" placeholder="Tuliskan ringkasan momentum kegiatan pada album ini..."><?= e($get('description')) ?></textarea>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Tanggal Kegiatan</label>
                        <input class="form-control" type="date" name="event_date" value="<?= e($get('event_date')) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Kategori Album</label>
                        <input class="form-control" name="category" value="<?= e($get('category')) ?>" placeholder="Kaderisasi / Workshop / Lomba">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="admin-card p-4 h-100">
                <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom">
                    <div class="stat-icon bg-success-subtle text-success" style="width: 36px; height: 36px; border-radius: 10px;">
                        <i class="bi bi-image"></i>
                    </div>
                    <div>
                        <h3 class="h6 fw-bold text-dark mb-0">Sampul & Sumber Foto</h3>
                        <div class="small text-secondary">Cover album dan pilihan metode tambah foto</div>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label fw-semibold">Foto Sampul (Cover Album)</label>
                    <input class="form-control" type="file" name="cover_image" accept="image/jpeg,image/png,image/webp">
                    <?php if (!empty($a['cover_image'])): ?>
                        <div class="mt-3 text-center p-2 rounded-3 bg-light border">
                            <img class="w-100 rounded-3 shadow-sm" src="<?= e(media_url($a['cover_image'])) ?>" alt="Cover" style="max-height: 140px; object-fit: cover;">
                        </div>
                    <?php endif; ?>
                </div>

                <hr class="my-3 text-muted opacity-25">

                <div class="mb-3">
                    <label class="form-label fw-bold text-dark">Sumber Foto Default</label>
                    <div class="d-grid gap-2">
                        <div class="p-2.5 rounded-3 border bg-light d-flex align-items-center gap-2 cursor-pointer">
                            <input class="form-check-input m-0" type="radio" name="source_type" id="source_local" value="local" <?= $sourceType === 'local' ? 'checked' : '' ?>>
                            <label class="form-check-label small fw-semibold text-dark mb-0 cursor-pointer w-100" for="source_local">
                                <i class="bi bi-upload me-1 text-primary"></i> Upload File Lokal
                            </label>
                        </div>
                        <div class="p-2.5 rounded-3 border bg-light d-flex align-items-center gap-2 cursor-pointer">
                            <input class="form-check-input m-0" type="radio" name="source_type" id="source_drive" value="google_drive" <?= $sourceType === 'google_drive' ? 'checked' : '' ?>>
                            <label class="form-check-label small fw-semibold text-dark mb-0 cursor-pointer w-100" for="source_drive">
                                <i class="bi bi-google-drive me-1 text-success"></i> Link File Google Drive (1 Link = 1 Foto)
                            </label>
                        </div>
                        <div class="p-2.5 rounded-3 border bg-light d-flex align-items-center gap-2 cursor-pointer">
                            <input class="form-check-input m-0" type="radio" name="source_type" id="source_remote" value="remote_url" <?= $sourceType === 'remote_url' ? 'checked' : '' ?>>
                            <label class="form-check-label small fw-semibold text-dark mb-0 cursor-pointer w-100" for="source_remote">
                                <i class="bi bi-link-45deg me-1 text-info"></i> Direct URL Gambar
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Input Panel: Local Upload -->
                <div id="localSettings" class="<?= $sourceType === 'local' ? '' : 'd-none' ?>">
                    <div class="p-3 rounded-3 bg-primary bg-opacity-10 border border-primary-subtle">
                        <label class="form-label fw-bold text-primary small mb-1">Unggah Foto Lokal</label>
                        <input class="form-control form-control-sm mb-2" type="file" name="photos[]" accept="image/jpeg,image/png,image/webp" multiple>
                        <input class="form-control form-control-sm" name="caption" placeholder="Caption foto baru (opsional)">
                        <div class="form-text small mt-1 text-secondary">Pilih satu atau beberapa file foto langsung dari perangkat Anda.</div>
                    </div>
                </div>

                <!-- Input Panel: Google Drive Individual File -->
                <div id="driveSettings" class="<?= $sourceType === 'google_drive' ? '' : 'd-none' ?>">
                    <?php if ($a): ?>
                        <div class="p-3 rounded-3 bg-success bg-opacity-10 border border-success-subtle">
                            <div class="d-flex align-items-center gap-2 mb-2 text-success fw-bold small">
                                <i class="bi bi-google-drive fs-5"></i>
                                <span>Tambah Foto Google Drive</span>
                            </div>
                            <div class="small text-secondary mb-3">
                                <i class="bi bi-info-circle me-1 text-success"></i> 
                                <strong>1 Link = 1 Foto.</strong> Masukkan link file foto Google Drive individual (bukan folder). Pastikan akses file di-set <em>"Siapa saja yang memiliki link dapat melihat"</em>.
                            </div>

                            <div class="mb-2">
                                <label class="form-label small fw-semibold text-dark">Link File Google Drive <span class="text-danger">*</span></label>
                                <input class="form-control form-control-sm font-monospace" id="driveFileUrlInput" placeholder="https://drive.google.com/file/d/FILE_ID/view">
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-semibold text-dark">Caption Foto (Opsional)</label>
                                <input class="form-control form-control-sm" id="driveCaptionInput" placeholder="Keterangan foto...">
                            </div>

                            <!-- Interactive Live Preview Card for Drive File -->
                            <div id="drivePreviewCard" class="p-2.5 rounded-3 bg-white border mb-3 d-none">
                                <div class="d-flex align-items-center gap-3">
                                    <img id="drivePreviewImg" src="" alt="Preview Drive" class="rounded-2 border shadow-sm" style="width: 56px; height: 56px; object-fit: cover;">
                                    <div class="overflow-hidden flex-fill">
                                        <div class="fw-bold text-dark text-truncate small" id="drivePreviewTitle">Nama File</div>
                                        <div class="small text-muted font-monospace" id="drivePreviewMeta">0 KB • image/jpeg</div>
                                        <span class="badge bg-success-subtle text-success border border-success-subtle rounded-pill" style="font-size: 0.65rem;" id="drivePreviewBadge">
                                            <i class="bi bi-check-circle me-1"></i>File Dapat Diakses
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div id="driveErrorAlert" class="p-2 rounded-3 bg-danger bg-opacity-10 border border-danger text-danger small mb-3 d-none">
                                <i class="bi bi-exclamation-triangle-fill me-1"></i>
                                <span id="driveErrorMsg">Link tidak valid.</span>
                            </div>

                            <div class="d-flex gap-2">
                                <button type="button" class="btn btn-sm btn-outline-dark rounded-pill flex-fill fw-semibold" id="btnVerifyDrive">
                                    <i class="bi bi-search me-1"></i>Cek Link
                                </button>
                                <button type="button" class="btn btn-sm btn-success text-white rounded-pill flex-fill fw-bold" id="btnAddDrive">
                                    <i class="bi bi-plus-lg me-1"></i>Tambahkan Foto
                                </button>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="p-3 rounded-3 bg-light border">
                            <div class="small text-secondary">
                                <i class="bi bi-info-circle me-1 text-primary"></i>
                                Simpan album terlebih dahulu sebelum menambahkan foto via link Google Drive.
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Input Panel: Remote URL -->
                <div id="remoteSettings" class="<?= $sourceType === 'remote_url' ? '' : 'd-none' ?>">
                    <?php if ($a): ?>
                        <div class="p-3 rounded-3 bg-info bg-opacity-10 border border-info-subtle">
                            <div class="d-flex align-items-center gap-2 mb-2 text-info-emphasis fw-bold small">
                                <i class="bi bi-link-45deg fs-5"></i>
                                <span>Tambah URL Gambar Remote</span>
                            </div>
                            <div class="mb-2">
                                <label class="form-label small fw-semibold text-dark">URL Gambar <span class="text-danger">*</span></label>
                                <div class="input-group input-group-sm mb-2">
                                    <input class="form-control font-monospace" id="remoteUrlInput" placeholder="https://domain.com/gambar.jpg">
                                    <button type="button" class="btn btn-dark" id="btnPreviewRemote">
                                        <i class="bi bi-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-semibold text-dark">Caption Foto (Opsional)</label>
                                <input class="form-control form-control-sm" id="remoteCaptionInput" placeholder="Keterangan foto...">
                            </div>

                            <div id="remotePreview" class="mt-2 d-none">
                                <div class="p-2 rounded-3 bg-white border text-center mb-3">
                                    <img id="remotePreviewImg" src="" alt="Preview" style="max-height: 140px; max-width: 100%; object-fit: contain;">
                                    <div class="small text-secondary mt-1">Pratinjau gambar remote</div>
                                </div>
                            </div>
                            <div id="remoteError" class="mt-2 d-none">
                                <div class="p-2 rounded-3 bg-danger bg-opacity-10 border border-danger text-danger small mb-3">
                                    <i class="bi bi-exclamation-triangle me-1"></i>
                                    <span id="remoteErrorText"></span>
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-info text-white rounded-pill fw-bold w-100" id="btnAddRemote">
                                <i class="bi bi-plus-lg me-1"></i>Tambahkan Gambar
                            </button>
                        </div>
                    <?php else: ?>
                        <div class="p-3 rounded-3 bg-light border">
                            <div class="small text-secondary">
                                <i class="bi bi-info-circle me-1"></i>
                                Simpan album terlebih dahulu sebelum menambahkan gambar via URL remote.
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if ($a): ?>
            <div class="col-12">
                <div class="admin-card p-4">
                    <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                        <div>
                            <h3 class="h6 fw-bold text-dark mb-0">Daftar Foto dalam Album</h3>
                            <div class="small text-secondary">Seluruh foto dari berbagai sumber (Lokal, Google Drive File, & Remote URL)</div>
                        </div>
                        <span class="badge rounded-pill bg-dark text-white px-3 py-1.5 fw-semibold"><?= count($items) ?> Foto</span>
                    </div>

                    <?php if (empty($items)): ?>
                        <div class="text-center py-5 rounded-4 bg-light border border-dashed">
                            <i class="bi bi-images fs-1 text-secondary opacity-50 d-block mb-2"></i>
                            <div class="fw-semibold text-dark mb-1">Belum ada foto dalam album ini</div>
                            <div class="small text-secondary mb-3">Pilih sumber foto di atas untuk menambahkan foto dokumentasi.</div>
                        </div>
                    <?php else: ?>
                        <div class="row g-3">
                            <?php foreach ($items as $item): 
                                $srcType = $item['source_type'] ?? 'local';
                                $imgSrc = '';
                                if ($srcType === 'google_drive') {
                                    $imgSrc = !empty($item['thumbnail_url']) ? $item['thumbnail_url'] : ($item['drive_url'] ?: '');
                                } elseif ($srcType === 'remote_url') {
                                    $imgSrc = !empty($item['thumbnail_url']) ? $item['thumbnail_url'] : ($item['remote_url'] ?: '');
                                } else {
                                    $imgSrc = media_url($item['file_path']);
                                }
                            ?>
                                <div class="col-6 col-md-4 col-lg-3">
                                    <div class="card h-100 rounded-4 overflow-hidden border shadow-sm">
                                        <div class="position-relative bg-dark" style="height: 170px;">
                                            <img class="w-100 h-100 object-fit-cover opacity-90" src="<?= e($imgSrc) ?>" alt="<?= e($item['alt_text'] ?: $item['title']) ?>" loading="lazy" onerror="this.src='<?= asset('images/placeholder.png') ?>';">
                                            
                                            <!-- Source Badge -->
                                            <?php if ($srcType === 'google_drive'): ?>
                                                <span class="badge rounded-pill bg-success text-white position-absolute top-0 start-0 m-2 shadow-sm" style="font-size: 0.65rem;">
                                                    <i class="bi bi-google-drive me-1"></i>Drive File
                                                </span>
                                            <?php elseif ($srcType === 'remote_url'): ?>
                                                <span class="badge rounded-pill bg-info text-white position-absolute top-0 start-0 m-2 shadow-sm" style="font-size: 0.65rem;">
                                                    <i class="bi bi-link-45deg me-1"></i>URL Remote
                                                </span>
                                            <?php else: ?>
                                                <span class="badge rounded-pill bg-primary text-white position-absolute top-0 start-0 m-2 shadow-sm" style="font-size: 0.65rem;">
                                                    <i class="bi bi-hdd me-1"></i>Lokal
                                                </span>
                                            <?php endif; ?>

                                            <!-- Delete Button -->
                                            <button type="button" class="btn btn-sm btn-danger position-absolute top-0 end-0 m-2 rounded-circle p-1 d-grid place-items-center shadow-sm" style="width: 30px; height: 30px;" data-confirm-url="<?= url('/admin/gallery/' . $a['id'] . '/delete-item/' . $item['id']) ?>" data-confirm-message="Hapus foto ini dari album?">
                                                <i class="bi bi-trash3 fs-6"></i>
                                            </button>
                                        </div>
                                        
                                        <div class="card-body p-2.5">
                                            <form method="post" action="<?= url('/admin/gallery/' . $a['id'] . '/item/' . $item['id'] . '/update') ?>">
                                                <?= Csrf::field() ?>
                                                <input type="hidden" name="title" value="<?= e($item['title']) ?>">
                                                <input class="form-control form-control-sm mb-2 rounded-3 small" name="caption" value="<?= e($item['caption']) ?>" placeholder="Tulis caption foto...">
                                                <button type="submit" class="btn btn-sm btn-light border rounded-pill w-100 small fw-semibold">
                                                    <i class="bi bi-check2 me-1"></i>Simpan Caption
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sourceLocal = document.getElementById('source_local');
    const sourceDrive = document.getElementById('source_drive');
    const sourceRemote = document.getElementById('source_remote');
    const localSettings = document.getElementById('localSettings');
    const driveSettings = document.getElementById('driveSettings');
    const remoteSettings = document.getElementById('remoteSettings');

    function toggleSourceSettings() {
        if (localSettings) localSettings.classList.toggle('d-none', !sourceLocal.checked);
        if (driveSettings) driveSettings.classList.toggle('d-none', !sourceDrive.checked);
        if (remoteSettings) remoteSettings.classList.toggle('d-none', !sourceRemote.checked);
    }

    if (sourceLocal && sourceDrive && sourceRemote) {
        sourceLocal.addEventListener('change', toggleSourceSettings);
        sourceDrive.addEventListener('change', toggleSourceSettings);
        sourceRemote.addEventListener('change', toggleSourceSettings);
    }

    // Google Drive Individual File Link logic
    const driveInput = document.getElementById('driveFileUrlInput');
    const driveCaption = document.getElementById('driveCaptionInput');
    const btnVerifyDrive = document.getElementById('btnVerifyDrive');
    const btnAddDrive = document.getElementById('btnAddDrive');
    const drivePreviewCard = document.getElementById('drivePreviewCard');
    const drivePreviewImg = document.getElementById('drivePreviewImg');
    const drivePreviewTitle = document.getElementById('drivePreviewTitle');
    const drivePreviewMeta = document.getElementById('drivePreviewMeta');
    const driveErrorAlert = document.getElementById('driveErrorAlert');
    const driveErrorMsg = document.getElementById('driveErrorMsg');

    if (btnVerifyDrive && driveInput) {
        btnVerifyDrive.addEventListener('click', function() {
            const url = driveInput.value.trim();
            if (!url) {
                alert('Masukkan link file Google Drive terlebih dahulu.');
                return;
            }

            btnVerifyDrive.disabled = true;
            btnVerifyDrive.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Memeriksa...';
            drivePreviewCard.classList.add('d-none');
            driveErrorAlert.classList.add('d-none');

            const formData = new FormData();
            formData.append('_csrf', '<?= e(Csrf::token()) ?>');
            formData.append('drive_file_url', url);

            fetch('<?= url('/admin/gallery/verify-drive-file') ?>', {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                btnVerifyDrive.disabled = false;
                btnVerifyDrive.innerHTML = '<i class="bi bi-search me-1"></i>Cek Link';

                if (data.ok && data.data) {
                    const meta = data.data;
                    drivePreviewImg.src = meta.previewUrl || meta.thumbnailLink;
                    drivePreviewTitle.textContent = meta.name || 'Google Drive Photo';
                    const sizeMb = (meta.size / (1024 * 1024)).toFixed(2);
                    drivePreviewMeta.textContent = `${sizeMb > 0 ? sizeMb + ' MB' : 'Visual Size OK'} • ${meta.mimeType}`;
                    drivePreviewCard.classList.remove('d-none');
                } else {
                    driveErrorMsg.textContent = data.error || 'File tidak dapat diakses.';
                    driveErrorAlert.classList.remove('d-none');
                }
            })
            .catch(err => {
                btnVerifyDrive.disabled = false;
                btnVerifyDrive.innerHTML = '<i class="bi bi-search me-1"></i>Cek Link';
                driveErrorMsg.textContent = 'Gagal menghubungi server: ' + err.message;
                driveErrorAlert.classList.remove('d-none');
            });
        });
    }

    if (btnAddDrive && driveInput) {
        btnAddDrive.addEventListener('click', function() {
            const url = driveInput.value.trim();
            if (!url) {
                alert('Masukkan link file Google Drive terlebih dahulu.');
                return;
            }
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '<?= url('/admin/gallery/add-drive-file/' . ($a['id'] ?? 0)) ?>';
            const csrfDrive = '<?= e(Csrf::token()) ?>';
            const cap = driveCaption ? driveCaption.value.trim() : '';
            form.innerHTML = `
                <input type="hidden" name="_csrf" value="${csrfDrive}">
                <input type="hidden" name="drive_file_url" value="${url}">
                <input type="hidden" name="caption" value="${cap}">
            `;
            document.body.appendChild(form);
            form.submit();
        });
    }

    // Remote Image URL logic
    const btnPreviewRemote = document.getElementById('btnPreviewRemote');
    if (btnPreviewRemote) {
        btnPreviewRemote.addEventListener('click', function() {
            const urlInput = document.getElementById('remoteUrlInput');
            const url = urlInput ? urlInput.value.trim() : '';
            const preview = document.getElementById('remotePreview');
            const previewImg = document.getElementById('remotePreviewImg');
            const errorDiv = document.getElementById('remoteError');
            const errorText = document.getElementById('remoteErrorText');

            if (!url) {
                alert('Masukkan URL gambar terlebih dahulu.');
                return;
            }

            preview.classList.add('d-none');
            errorDiv.classList.add('d-none');
            previewImg.src = url;

            previewImg.onload = function() {
                preview.classList.remove('d-none');
                errorDiv.classList.add('d-none');
            };

            previewImg.onerror = function() {
                preview.classList.add('d-none');
                errorDiv.classList.remove('d-none');
                errorText.textContent = 'Gambar tidak dapat dimuat dari URL tersebut.';
            };
        });
    }

    const btnAddRemote = document.getElementById('btnAddRemote');
    if (btnAddRemote) {
        btnAddRemote.addEventListener('click', function() {
            const urlInput = document.getElementById('remoteUrlInput');
            const url = urlInput ? urlInput.value.trim() : '';
            if (!url) {
                alert('Masukkan URL gambar terlebih dahulu.');
                return;
            }
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = '<?= url('/admin/gallery/add-remote-url/' . ($a['id'] ?? 0)) ?>';
            const csrfRemote = '<?= e(Csrf::token()) ?>';
            const remoteCapInput = document.getElementById('remoteCaptionInput');
            const cap = remoteCapInput ? remoteCapInput.value.trim() : '';
            form.innerHTML = `
                <input type="hidden" name="_csrf" value="${csrfRemote}">
                <input type="hidden" name="remote_url" value="${url}">
                <input type="hidden" name="caption" value="${cap}">
            `;
            document.body.appendChild(form);
            form.submit();
        });
    }
});
</script>
