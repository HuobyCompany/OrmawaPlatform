<?php
/** @var array|null $form @var array $fields @var array $fieldTypes @var array $faculties */
$fieldTypeLabels = [
    'text' => 'Teks Singkat', 'textarea' => 'Teks Panjang', 'number' => 'Angka',
    'phone' => 'Nomor Telepon', 'date' => 'Tanggal', 'email' => 'Email',
    'select' => 'Pilihan Ganda (Dropdown)', 'radio' => 'Pilihan Ganda (Radio)', 'checkbox' => 'Kotak Centang (Multiple)',
    'file_image' => 'Upload Foto', 'file' => 'Upload Dokumen', 'social_media' => 'Media Sosial',
    'faculty_selector' => 'Pemilih Fakultas', 'program_study_selector' => 'Pemilih Program Studi',
];

$fieldTypeIcons = [
    'text' => 'bi-fonts', 'textarea' => 'bi-text-paragraph', 'number' => 'bi-123',
    'phone' => 'bi-telephone', 'date' => 'bi-calendar-date', 'email' => 'bi-envelope',
    'select' => 'bi-menu-button-wide', 'radio' => 'bi-ui-radios', 'checkbox' => 'bi-ui-checks',
    'file_image' => 'bi-image', 'file' => 'bi-file-earmark-arrow-up', 'social_media' => 'bi-share',
    'faculty_selector' => 'bi-buildings', 'program_study_selector' => 'bi-mortarboard',
];
?>

<style>
.gform-header-card {
    border-top: 6px solid #0d6efd !important;
    background: #ffffff;
    transition: all 0.2s ease-in-out;
}
.gform-card {
    border-left: 4px solid #e0e0e0;
    background: #ffffff;
    transition: all 0.2s ease;
}
.gform-card:hover, .gform-card:focus-within {
    border-left-color: #0d6efd;
    box-shadow: 0 0.5rem 1.2rem rgba(0,0,0,0.08) !important;
}
.gform-drag-handle {
    cursor: grab;
    user-select: none;
    color: #a0a0a0;
}
.gform-drag-handle:active {
    cursor: grabbing;
}
.gform-preview-box {
    background: #f8f9fa;
    border: 1px dashed #dee2e6;
    border-radius: 10px;
}
</style>

<!-- Top Subnav -->
<div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
    <div class="d-flex gap-2">
        <a href="<?= url('/admin/registration') ?>" class="btn btn-sm btn-primary rounded-pill px-3 fw-semibold">
            <i class="bi bi-ui-checks me-1"></i> Form Builder
        </a>
        <a href="<?= url('/admin/registration/submissions') ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-people me-1"></i> Data Pendaftar
        </a>
        <a href="<?= url('/admin/faculties') ?>" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
            <i class="bi bi-buildings me-1"></i> Kelola Fakultas & Prodi
        </a>
    </div>
    <?php if ($form): ?>
        <div class="d-flex gap-2">
            <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#shareQrModal">
                <i class="bi bi-qr-code-scan me-1"></i> Bagikan & Kode QR
            </button>
            <a href="<?= e(org_url($organization, 'join')) ?>" target="_blank" class="btn btn-sm btn-outline-dark rounded-pill px-3">
                <i class="bi bi-eye me-1"></i> Pratinjau Formulir Publik
            </a>
        </div>
    <?php endif; ?>
</div>

<?php if ($flash_success): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i><?= e($flash_success) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php if ($flash_error): ?>
    <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-exclamation-circle-fill me-2"></i><?= e($flash_error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if (!$form): ?>
    <!-- Empty State: Create Form -->
    <div class="card border-0 shadow-sm rounded-4 p-5 text-center my-4">
        <div class="mb-3">
            <div class="d-inline-flex p-3 rounded-circle bg-primary bg-opacity-10 text-primary">
                <i class="bi bi-file-earmark-plus fs-1"></i>
            </div>
        </div>
        <h3 class="h4 fw-bold mb-2">Belum ada Formulir Pendaftaran</h3>
        <p class="text-secondary mb-4" style="max-width: 480px; margin: 0 auto;">Buat formulir baru untuk mulai menerima pendaftaran calon anggota secara online dengan tampilan profesional.</p>
        <form method="post" action="<?= url('admin/registration/form/create') ?>">
            <?= Csrf::field() ?>
            <button type="submit" class="btn btn-primary rounded-pill px-4 py-2 fw-semibold shadow-sm">
                <i class="bi bi-plus-lg me-1"></i>Buat Formulir Sekarang
            </button>
        </form>
    </div>
<?php else: ?>

    <!-- Form Container -->
    <div class="mx-auto" style="max-width: 860px;">

        <!-- 1. Google Forms Header Card -->
        <div class="card gform-header-card border-0 shadow-sm rounded-4 p-4 mb-4">
            <form method="post" action="<?= url('admin/registration/form/save') ?>">
                <?= Csrf::field() ?>
                <input type="hidden" name="form_id" value="<?= $form['id'] ?>">

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-3 py-1 fw-semibold">
                        <i class="bi bi-card-heading me-1"></i> Pengaturan Utama Formulir
                    </span>
                    <div class="form-check form-switch m-0">
                        <input class="form-check-input" type="checkbox" id="regIsActive" name="is_active" <?= $form['is_active'] ? 'checked' : '' ?> onchange="this.form.submit()">
                        <label class="form-check-label fw-semibold small text-dark" for="regIsActive">
                            <?= $form['is_active'] ? '<span class="text-success"><i class="bi bi-check-circle-fill me-1"></i>Pendaftaran Berlangsung (Aktif)</span>' : '<span class="text-secondary"><i class="bi bi-pause-circle me-1"></i>Pendaftaran Ditutup (Nonaktif)</span>' ?>
                        </label>
                    </div>
                </div>

                <div class="mb-3">
                    <input type="text" name="title" class="form-control form-control-lg border-0 bg-light rounded-3 fw-bold text-dark px-3 py-2" value="<?= e($form['title']) ?>" placeholder="Judul Formulir Pendaftaran" required style="font-size: 1.5rem;">
                </div>

                <div class="mb-3">
                    <textarea name="description" class="form-control border-0 bg-light rounded-3 px-3 py-2" rows="2" placeholder="Deskripsi formulir / petunjuk untuk calon pendaftar..."><?= e($form['description'] ?? '') ?></textarea>
                </div>

                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary rounded-pill px-4 btn-sm fw-semibold">
                        <i class="bi bi-check2-circle me-1"></i> Simpan Judul & Deskripsi
                    </button>
                </div>
            </form>
        </div>

        <!-- System Mandatory Fields Info Card -->
        <div class="card border-0 shadow-sm rounded-4 p-3 mb-4" style="background: #f8fafc; border-left: 4px solid #007aff !important;">
            <div class="d-flex align-items-start gap-3">
                <div class="stat-icon bg-primary text-white rounded-3 p-2 d-grid place-items-center flex-shrink-0" style="width: 36px; height: 36px; display: grid;">
                    <i class="bi bi-shield-check"></i>
                </div>
                <div>
                    <div class="fw-bold text-dark mb-1" style="font-size: 0.9rem;">
                        <i class="bi bi-check-circle-fill text-primary me-1"></i> Data Utama Wajib Sistem (Default System Fields)
                    </div>
                    <p class="text-secondary small mb-2" style="font-size: 0.8rem;">
                        Setiap formulir pendaftaran publik secara otomatis menyertakan 5 data utama wajib di bawah ini yang disimpan langsung ke database anggota resmi:
                    </p>
                    <div class="d-flex flex-wrap gap-1.5">
                        <span class="badge bg-white text-dark border rounded-pill px-2.5 py-1 small fw-semibold"><i class="bi bi-person me-1 text-primary"></i>1. Nama Lengkap</span>
                        <span class="badge bg-white text-dark border rounded-pill px-2.5 py-1 small fw-semibold"><i class="bi bi-buildings me-1 text-success"></i>2. Fakultas</span>
                        <span class="badge bg-white text-dark border rounded-pill px-2.5 py-1 small fw-semibold"><i class="bi bi-mortarboard me-1 text-info"></i>3. Program Studi</span>
                        <span class="badge bg-white text-dark border rounded-pill px-2.5 py-1 small fw-semibold"><i class="bi bi-whatsapp me-1 text-success"></i>4. Kontak WhatsApp</span>
                        <span class="badge bg-white text-dark border rounded-pill px-2.5 py-1 small fw-semibold"><i class="bi bi-calendar-check me-1 text-warning"></i>5. Angkatan Kuliah</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. Sticky Action Toolbar -->
        <div class="d-flex justify-content-between align-items-center mb-3 px-1">
            <h5 class="fw-bold text-dark mb-0">
                <i class="bi bi-list-nested me-2 text-primary"></i>Pertanyaan Tambahan / Custom Field (<?= count($fields) ?>)
            </h5>
            <button type="button" class="btn btn-primary rounded-pill px-3 shadow-sm d-inline-flex align-items-center gap-1" data-bs-toggle="modal" data-bs-target="#addFieldModal">
                <i class="bi bi-plus-circle-fill fs-6"></i>
                <span>Tambah Field</span>
            </button>
        </div>

        <!-- 3. Question Cards Stack -->
        <?php if (empty($fields)): ?>
            <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white my-3">
                <i class="bi bi-question-circle fs-1 opacity-20 mb-2 text-primary"></i>
                <h5 class="fw-bold text-dark mb-1">Belum Ada Pertanyaan</h5>
                <p class="text-secondary small mb-3">Klik tombol "Tambah Field" untuk menambahkan pertanyaan pendaftaran.</p>
                <div>
                    <button type="button" class="btn btn-outline-primary rounded-pill px-4 py-2" data-bs-toggle="modal" data-bs-target="#addFieldModal">
                        <i class="bi bi-plus-lg me-1"></i>Tambah Field Pertama
                    </button>
                </div>
            </div>
        <?php else: ?>
            <div id="fieldList">
                <?php foreach ($fields as $i => $f): ?>
                    <?php
                    $ft = $f['field_type'];
                    $icon = $fieldTypeIcons[$ft] ?? 'bi-input-cursor';
                    $opts = RegistrationFieldModel::parseOptions($f['options_json']);
                    ?>
                    <div class="card gform-card border-0 shadow-sm rounded-4 p-3 mb-3 field-row" data-id="<?= $f['id'] ?>" data-sort="<?= $i ?>">
                        <!-- Top Drag Handle -->
                        <div class="text-center pb-2 gform-drag-handle" title="Geser untuk mengubah urutan">
                            <i class="bi bi-grip-horizontal fs-5 opacity-50"></i>
                        </div>

                        <!-- Card Body / Question Content -->
                        <div class="px-2">
                            <!-- Question Header Info -->
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div class="d-flex align-items-center gap-2 flex-wrap">
                                    <span class="badge bg-light text-dark border rounded-pill px-2.5 py-1 small fw-semibold">
                                        #<?= $i + 1 ?>
                                    </span>
                                    <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-2.5 py-1 small fw-semibold">
                                        <i class="bi <?= $icon ?> me-1"></i><?= e($fieldTypeLabels[$ft] ?? $ft) ?>
                                    </span>
                                    <?php if ($f['is_required']): ?>
                                        <span class="badge bg-danger bg-opacity-10 text-danger rounded-pill px-2 py-0.5 small">Wajib</span>
                                    <?php endif; ?>
                                    <?php if (!$f['is_active']): ?>
                                        <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-2 py-0.5 small">Nonaktif</span>
                                    <?php endif; ?>
                                </div>
                                <div class="text-end">
                                    <code class="small text-muted bg-light px-2 py-1 rounded-2">field_<?= e($f['name']) ?></code>
                                </div>
                            </div>

                            <!-- Question Label -->
                            <h5 class="fw-bold text-dark mb-1">
                                <?= e($f['label']) ?>
                                <?php if ($f['is_required']): ?><span class="text-danger">*</span><?php endif; ?>
                            </h5>
                            <?php if (!empty($f['help_text'])): ?>
                                <p class="text-secondary small mb-2"><i class="bi bi-info-circle me-1"></i><?= e($f['help_text']) ?></p>
                            <?php endif; ?>

                            <!-- Visual Mock Preview of how applicants see it -->
                            <div class="gform-preview-box p-3 my-3">
                                <?php if ($ft === 'text' || $ft === 'email' || $ft === 'phone' || $ft === 'number'): ?>
                                    <input type="text" class="form-control border-0 bg-white shadow-none rounded-3" placeholder="<?= e($f['placeholder'] ?: 'Jawaban teks singkat...') ?>" disabled>
                                <?php elseif ($ft === 'textarea'): ?>
                                    <textarea class="form-control border-0 bg-white shadow-none rounded-3" rows="2" placeholder="<?= e($f['placeholder'] ?: 'Jawaban teks panjang...') ?>" disabled></textarea>
                                <?php elseif ($ft === 'date'): ?>
                                    <input type="date" class="form-control border-0 bg-white shadow-none rounded-3" disabled>
                                <?php elseif ($ft === 'select'): ?>
                                    <select class="form-select border-0 bg-white shadow-none rounded-3" disabled>
                                        <option>-- <?= e($f['placeholder'] ?: 'Pilih Opsi...') ?> --</option>
                                        <?php foreach ($opts as $o): ?>
                                            <option><?= e($o) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php elseif ($ft === 'radio'): ?>
                                    <div class="d-flex flex-wrap gap-3">
                                        <?php foreach ($opts as $o): ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" disabled>
                                                <label class="form-check-label text-dark small"><?= e($o) ?></label>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php elseif ($ft === 'checkbox'): ?>
                                    <div class="d-flex flex-wrap gap-3">
                                        <?php foreach ($opts as $o): ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" disabled>
                                                <label class="form-check-label text-dark small"><?= e($o) ?></label>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php elseif ($ft === 'file_image' || $ft === 'file'): ?>
                                    <div class="text-center text-secondary py-2">
                                        <i class="bi bi-cloud-arrow-up fs-3 d-block text-primary opacity-50 mb-1"></i>
                                        <span class="small">Pengunjung akan mengunggah file di sini</span>
                                    </div>
                                <?php elseif ($ft === 'faculty_selector' || $ft === 'program_study_selector'): ?>
                                    <div class="d-flex align-items-center gap-2 text-secondary small">
                                        <i class="bi bi-database-check text-primary"></i>
                                        <span>Dropdown otomatis terhubung ke Master Data <?= $ft === 'faculty_selector' ? 'Fakultas' : 'Program Studi' ?></span>
                                    </div>
                                <?php else: ?>
                                    <input type="text" class="form-control border-0 bg-white" placeholder="Input jawaban..." disabled>
                                <?php endif; ?>
                            </div>

                            <!-- Card Bottom Action Toolbar -->
                            <div class="d-flex justify-content-between align-items-center pt-2 border-top">
                                <!-- Left Actions: Quick Toggle Required & Active -->
                                <div class="d-flex align-items-center gap-3">
                                    <form method="post" action="<?= url('admin/registration/form/field/edit') ?>" class="d-inline">
                                        <?= Csrf::field() ?>
                                        <input type="hidden" name="form_id" value="<?= $form['id'] ?>">
                                        <input type="hidden" name="field_id" value="<?= $f['id'] ?>">
                                        <input type="hidden" name="field_type" value="<?= $f['field_type'] ?>">
                                        <input type="hidden" name="label" value="<?= e($f['label']) ?>">
                                        <input type="hidden" name="is_active" value="<?= $f['is_active'] ?>">
                                        <input type="hidden" name="is_required" value="<?= $f['is_required'] ? '0' : '1' ?>">
                                        <div class="form-check form-switch m-0">
                                            <input class="form-check-input" type="checkbox" id="req_<?= $f['id'] ?>" <?= $f['is_required'] ? 'checked' : '' ?> onchange="this.form.submit()">
                                            <label class="form-check-label small text-secondary fw-semibold" for="req_<?= $f['id'] ?>">Wajib</label>
                                        </div>
                                    </form>
                                    <form method="post" action="<?= url('admin/registration/form/field/toggle') ?>" class="d-inline">
                                        <?= Csrf::field() ?>
                                        <input type="hidden" name="form_id" value="<?= $form['id'] ?>">
                                        <input type="hidden" name="field_id" value="<?= $f['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-link text-decoration-none p-0 text-secondary small fw-semibold">
                                            <i class="bi bi-power me-1 <?= $f['is_active'] ? 'text-success' : 'text-secondary' ?>"></i>
                                            <?= $f['is_active'] ? 'Aktif' : 'Nonaktif' ?>
                                        </button>
                                    </form>
                                </div>

                                <!-- Right Actions: Edit & Delete -->
                                <div class="d-flex align-items-center gap-2">
                                    <button type="button" class="btn btn-sm btn-light border rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#editFieldModal<?= $f['id'] ?>">
                                        <i class="bi bi-pencil me-1"></i> Edit
                                    </button>

                                    <?php $hasSubs = RegistrationFieldModel::hasSubmissions((int)$f['id']); ?>
                                    <form method="post" action="<?= url('admin/registration/form/field/delete') ?>" class="d-inline" onsubmit="return confirm('Hapus field &quot;<?= e($f['label']) ?>&quot;?<?= $hasSubs ? '\nData submission tetap tersimpan (soft-delete).' : '' ?>')">
                                        <?= Csrf::field() ?>
                                        <input type="hidden" name="form_id" value="<?= $form['id'] ?>">
                                        <input type="hidden" name="field_id" value="<?= $f['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger border-0 rounded-circle p-2" title="Hapus Pertanyaan">
                                            <i class="bi bi-trash3"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Reorder Form -->
            <form method="post" action="<?= url('admin/registration/form/field/reorder') ?>" id="reorderForm">
                <?= Csrf::field() ?>
                <input type="hidden" name="form_id" value="<?= $form['id'] ?>">
                <input type="hidden" name="order" id="fieldOrder">
                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-sm btn-outline-secondary rounded-pill px-4">
                        <i class="bi bi-save me-1"></i>Simpan Urutan Field
                    </button>
                </div>
            </form>
        <?php endif; ?>

    </div>

<?php endif; ?>

<!-- Add Field Modal -->
<div class="modal fade" id="addFieldModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-4 shadow">
            <form method="post" action="<?= url('admin/registration/form/field/add') ?>">
                <?= Csrf::field() ?>
                <input type="hidden" name="form_id" value="<?= $form ? $form['id'] : 0 ?>">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-dark">
                        <i class="bi bi-plus-circle-fill text-primary me-2"></i>Tambah Pertanyaan Baru
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <?php
                    $editorType = 'text'; $editorLabel = ''; $editorName = '';
                    $editorPlaceholder = ''; $editorHelpText = '';
                    $editorRequired = 0; $editorActive = 1; $editorSortOrder = 0;
                    $editorOptions = []; $editorConfig = []; $editorValidation = [];
                    $faculties = array_filter($fields ?? [], fn($fld) => $fld['field_type'] === 'faculty_selector' && $fld['is_active'] === 1 && $fld['deleted_at'] === null);
                    include BASE_PATH . '/views/components/registration_field_editor.php';
                    ?>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Tambah Pertanyaan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Field Modals -->
<?php foreach ($fields ?? [] as $f): ?>
<div class="modal fade" id="editFieldModal<?= $f['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-4 shadow">
            <form method="post" action="<?= url('admin/registration/form/field/edit') ?>">
                <?= Csrf::field() ?>
                <input type="hidden" name="form_id" value="<?= $form['id'] ?>">
                <input type="hidden" name="field_id" value="<?= $f['id'] ?>">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-dark">
                        <i class="bi bi-pencil-square text-primary me-2"></i>Edit Pertanyaan: <?= e($f['label']) ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <?php
                    $editorFieldId = $f['id'];
                    $editorType = $f['field_type'];
                    $editorLabel = $f['label'];
                    $editorName = $f['name'];
                    $editorPlaceholder = $f['placeholder'] ?? '';
                    $editorHelpText = $f['help_text'] ?? '';
                    $editorRequired = (int)$f['is_required'];
                    $editorActive = (int)$f['is_active'];
                    $editorSortOrder = (int)$f['sort_order'];
                    $editorOptions = RegistrationFieldModel::parseOptions($f['options_json']);
                    $editorConfig = $f['config_json'] ? json_decode($f['config_json'], true) : [];
                    $editorValidation = $f['validation_rules'] ? json_decode($f['validation_rules'], true) : [];
                    $faculties = array_filter($fields, fn($fld) => $fld['field_type'] === 'faculty_selector' && $fld['id'] !== $f['id'] && $fld['is_active'] === 1 && $fld['deleted_at'] === null);
                    include BASE_PATH . '/views/components/registration_field_editor.php';
                    ?>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Dynamic dependent group toggles
    document.querySelectorAll('.field-type-select').forEach(function(sel) {
        function toggle() {
            var modal = sel.closest('.modal-content');
            if (!modal) return;
            var t = sel.value;
            var opt = modal.querySelector('.options-group');
            var fl = modal.querySelector('.file-config-group');
            var dep = modal.querySelector('.depends-group');
            if (opt) opt.style.display = ['select','radio','checkbox'].includes(t) ? 'block' : 'none';
            if (fl) fl.style.display = ['file_image','file'].includes(t) ? 'block' : 'none';
            if (dep) dep.style.display = t === 'program_study_selector' ? 'block' : 'none';
        }
        sel.addEventListener('change', toggle);
        toggle();
    });

    // Reorder Form Handler
    var reorderForm = document.getElementById('reorderForm');
    if (reorderForm) {
        reorderForm.addEventListener('submit', function() {
            var order = [];
            document.querySelectorAll('#fieldList .field-row').forEach(function(row) {
                order.push(row.dataset.id);
            });
            document.getElementById('fieldOrder').value = order.join(',');
        });
    }

    // Drag-and-drop support
    var list = document.getElementById('fieldList');
    if (list) {
        var dragging = null;
        list.querySelectorAll('.field-row').forEach(function(row) {
            row.draggable = true;
            row.addEventListener('dragstart', function() { dragging = this; this.classList.add('opacity-50'); });
            row.addEventListener('dragend', function() {
                this.classList.remove('opacity-50');
                if (reorderForm) reorderForm.requestSubmit();
            });
            row.addEventListener('dragover', function(e) {
                e.preventDefault();
                var after = getDragAfter(this, e.clientY);
                if (after == null) list.appendChild(dragging);
                else list.insertBefore(dragging, after);
            });
        });
        function getDragAfter(c, y) {
            var items = [...list.querySelectorAll('.field-row:not(.opacity-50)')];
            var closest = { offset: null, el: null };
            items.forEach(function(child) {
                var r = child.getBoundingClientRect();
                var o = y - r.top - r.height / 2;
                if (o < 0 && (closest.offset === null || o > closest.offset)) {
                    closest = { offset: o, el: child };
                }
            });
            return closest.el;
        }
    }
});
</script>

<?php if ($form): ?>
<!-- Modal Bagikan & Kode QR -->
<div class="modal fade" id="shareQrModal" tabindex="-1" aria-labelledby="shareQrModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg overflow-hidden">
            <div class="modal-header bg-primary text-white border-0 py-3">
                <h5 class="modal-title fw-bold fs-6 d-flex align-items-center gap-2" id="shareQrModalLabel">
                    <i class="bi bi-qr-code-scan fs-5"></i> Bagikan Formulir Pendaftaran
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body p-4 text-center">
                <?php $publicFormUrl = org_url($organization, 'join'); ?>
                <p class="text-secondary small mb-3">Bagikan link atau scan Kode QR di bawah untuk langsung mengarahkan calon anggota ke halaman pengisian formulir pendaftaran.</p>
                
                <div class="p-3 bg-light rounded-4 d-inline-block border mb-3 shadow-sm position-relative">
                    <img id="builderQrCodeImg" src="https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=<?= urlencode($publicFormUrl) ?>" alt="Kode QR Pendaftaran" class="img-fluid rounded-3" style="width: 200px; height: 200px;">
                </div>

                <div class="mb-3">
                    <label class="form-label text-start d-block small fw-bold text-dark mb-1">Tautan Publik Formulir</label>
                    <div class="input-group">
                        <input type="text" id="publicFormUrlInput" class="form-control rounded-start-3 bg-light border-end-0 small" value="<?= e($publicFormUrl) ?>" readonly>
                        <button class="btn btn-outline-primary rounded-end-3 px-3 fw-semibold" type="button" onclick="copyFormLink()">
                            <i class="bi bi-clipboard me-1" id="copyBtnIcon"></i> <span id="copyBtnText">Salin Link</span>
                        </button>
                    </div>
                </div>

                <div class="d-flex justify-content-center gap-2">
                    <a id="downloadQrBtn" href="https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=<?= urlencode($publicFormUrl) ?>" download="QR_Code_Pendaftaran_<?= e($organization['slug']) ?>.png" target="_blank" class="btn btn-outline-dark btn-sm rounded-pill px-3">
                        <i class="bi bi-download me-1"></i> Unduh Kode QR
                    </a>
                    <a href="<?= e($publicFormUrl) ?>" target="_blank" class="btn btn-primary btn-sm rounded-pill px-3">
                        <i class="bi bi-box-arrow-up-right me-1"></i> Buka Formulir
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyFormLink() {
    var input = document.getElementById('publicFormUrlInput');
    if (!input) return;
    input.select();
    input.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(input.value).then(function() {
        var btnText = document.getElementById('copyBtnText');
        var btnIcon = document.getElementById('copyBtnIcon');
        if (btnText && btnIcon) {
            btnText.innerText = 'Tersalin!';
            btnIcon.className = 'bi bi-check-lg text-success';
            setTimeout(function() {
                btnText.innerText = 'Salin Link';
                btnIcon.className = 'bi bi-clipboard';
            }, 2000);
        }
    });
}
</script>
<?php endif; ?>
