<?php 
$e = $event ?? []; 
$get = fn($k, $d = '') => $e[$k] ?? $d; 
?>

<form method="post" action="<?= url('/admin/events/save') ?>" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= (int)($e['id'] ?? 0) ?>">
    <?= Csrf::field() ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <div class="small text-secondary fw-semibold">Agenda Kegiatan</div>
            <h2 class="h3 fw-bold text-dark mb-1"><?= $e ? 'Edit Agenda Kegiatan' : 'Tambah Agenda Kegiatan Baru' ?></h2>
            <p class="text-secondary small mb-0">Lengkapi judul, waktu pelaksanaan, deskripsi, dan poster kegiatan.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/admin/events') ?>" class="btn btn-light rounded-pill px-3.5">Batal</a>
            <button type="submit" class="btn btn-dark rounded-pill px-4 fw-bold d-inline-flex align-items-center gap-1.5">
                <i class="bi bi-check2"></i>
                <span>Simpan Kegiatan</span>
            </button>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="admin-card p-4">
                <div class="mb-3">
                    <label class="form-label">Judul Kegiatan <span class="text-danger">*</span></label>
                    <input class="form-control" name="title" value="<?= e($get('title')) ?>" placeholder="Misal: Seminar Nasional Teknologi..." required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Slug URL</label>
                    <input class="form-control font-monospace" name="slug" value="<?= e($get('slug')) ?>" placeholder="seminar-nasional-teknologi">
                    <div class="form-text small">Biarkan kosong untuk membuat slug otomatis dari judul.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Deskripsi & Rincian Kegiatan</label>
                    <textarea class="form-control" name="description" rows="6" placeholder="Tuliskan detail jadwal acara, narasumber, target peserta, dan informasi penting lainnya..."><?= e($get('description')) ?></textarea>
                    <div class="form-text small">Teks normal tanpa toolbar formatting yang rumit. Gunakan baris baru (enter) untuk membuat paragraf.</div>
                </div>

                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Tanggal Pelaksanaan <span class="text-danger">*</span></label>
                        <input class="form-control" type="date" name="event_date" value="<?= e($get('event_date', date('Y-m-d'))) ?>" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Waktu Mulai</label>
                        <input class="form-control" type="time" name="start_time" value="<?= e(substr((string)$get('start_time'), 0, 5)) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Waktu Selesai</label>
                        <input class="form-control" type="time" name="end_time" value="<?= e(substr((string)$get('end_time'), 0, 5)) ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Lokasi / Tempat Pelaksanaan</label>
                        <input class="form-control" name="location" value="<?= e($get('location')) ?>" placeholder="Auditorium Utama / Zoom Meeting">
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="admin-card p-4">
                <div class="mb-4">
                    <label class="form-label">Poster / Flyer Acara</label>
                    <input class="form-control" type="file" name="poster" accept="image/jpeg,image/png,image/webp">
                    <?php if ($e['poster'] ?? null): ?>
                        <div class="mt-3 text-center p-2 rounded-3 bg-light border">
                            <img class="w-100 rounded-3 shadow-sm" src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('admin-event-poster-' . ($e['id'] ?? 'x'), 1200, 675) : e(media_url($e['poster'])) ?>" alt="Poster Saat Ini" style="max-height: 180px; object-fit: cover;">
                        </div>
                    <?php endif; ?>
                    <div class="form-text small mt-2">Format JPG, PNG, atau WebP (maks. 8 MB).</div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Ukuran Tampilan</label>
                    <select name="poster_size" class="form-select">
                        <option value="Small" <?= $get('poster_size') === 'Small' ? 'selected' : '' ?>>Small (Kecil)</option>
                        <option value="Medium" <?= $get('poster_size', 'Medium') === 'Medium' ? 'selected' : '' ?>>Medium (Sedang)</option>
                        <option value="Large" <?= $get('poster_size') === 'Large' ? 'selected' : '' ?>>Large (Besar)</option>
                        <option value="Custom" <?= $get('poster_size') === 'Custom' ? 'selected' : '' ?>>Custom (Kustom)</option>
                    </select>
                </div>

                <div class="mb-2">
                    <label class="form-label">Status Publikasi</label>
                    <select name="status" class="form-select">
                        <option value="draft" <?= $get('status', 'draft') === 'draft' ? 'selected' : '' ?>>Draft (Konsep)</option>
                        <option value="published" <?= $get('status') === 'published' ? 'selected' : '' ?>>Published (Tayang)</option>
                        <option value="cancelled" <?= $get('status') === 'cancelled' ? 'selected' : '' ?>>Cancelled (Dibatalkan)</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</form>
