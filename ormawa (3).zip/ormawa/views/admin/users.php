<?php 
$me = auth_user();
?>

<!-- Page Header -->
<div class="d-flex flex-column flex-md-row align-items-start align-items-md-center justify-content-between gap-3 mb-4">
    <div>
        <p class="text-secondary small fw-semibold mb-1" style="letter-spacing:0.05em; text-transform:uppercase; font-size:0.7rem;">Sistem &amp; Keanggotaan</p>
        <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing:-0.02em;">Pengelola &amp; Akses Pengurus</h2>
        <p class="text-secondary small mb-0">Kelola daftar akun pengurus, peran (role), dan hak akses tenant organisasi.</p>
    </div>
    <div class="flex-shrink-0">
        <a class="btn btn-dark rounded-pill px-3.5 py-2 text-nowrap fw-bold d-inline-flex align-items-center gap-1.5 shadow-sm" href="<?= url('/admin/users/create') ?>">
            <i class="bi bi-person-plus-fill"></i>
            <span>Tambah User Baru</span>
        </a>
    </div>
</div>

<!-- Users Table Card -->
<div class="admin-card overflow-hidden">
    <div class="table-responsive">
        <table class="table admin-table align-middle mb-0">
            <thead>
                <tr>
                    <th style="padding-left: 1.25rem;">Pengguna</th>
                    <th>Organisasi / Tenant</th>
                    <th>Peran (Role)</th>
                    <th>Status</th>
                    <th>Terakhir Login</th>
                    <th class="text-end" style="padding-right: 1.25rem;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$users): ?>
                    <tr>
                        <td colspan="6" class="text-center text-secondary py-5">
                            <i class="bi bi-people fs-2 d-block mb-2 text-muted opacity-50"></i>
                            <span>Belum ada user pengurus yang terdaftar.</span>
                        </td>
                    </tr>
                <?php else: foreach ($users as $u): 
                    $initials = strtoupper(substr($u['name'] ?? 'U', 0, 2));
                    $roleLabel = match($u['role']) {
                        'super_admin' => 'Super Admin',
                        'organization_admin' => 'Admin Organisasi',
                        'editor' => 'Editor Content',
                        default => ucfirst($u['role'])
                    };
                    $roleBadgeClass = match($u['role']) {
                        'super_admin' => 'bg-danger-subtle text-danger border border-danger-subtle',
                        'organization_admin' => 'bg-primary-subtle text-primary border border-primary-subtle',
                        default => 'bg-secondary-subtle text-secondary border border-secondary-subtle'
                    };
                ?>
                    <tr>
                        <td style="padding-left: 1.25rem;">
                            <div class="d-flex align-items-center gap-2.5">
                                <div class="avatar-circle bg-dark text-white fw-bold rounded-circle d-grid place-items-center flex-shrink-0" style="width: 36px; height: 36px; font-size: 0.8rem; display: grid;">
                                    <?= e($initials) ?>
                                </div>
                                <div>
                                    <div class="fw-bold text-dark mb-0" style="font-size: 0.88rem;"><?= e($u['name']) ?></div>
                                    <div class="small text-secondary font-monospace"><?= e($u['email']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-1.5 text-secondary small fw-semibold">
                                <i class="bi bi-building"></i>
                                <span><?= e($u['organization_name'] ?: 'Global (Super Admin)') ?></span>
                            </div>
                        </td>
                        <td>
                            <span class="badge rounded-pill px-2.5 py-1.5 <?= e($roleBadgeClass) ?>" style="font-size: 0.72rem; font-weight: 600;">
                                <?= e($roleLabel) ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($u['status'] === 'active'): ?>
                                <span class="badge rounded-pill bg-success-subtle text-success border border-success-subtle px-2.5 py-1.5" style="font-size: 0.72rem; font-weight: 600;">
                                    🟢 Aktif
                                </span>
                            <?php else: ?>
                                <span class="badge rounded-pill bg-secondary-subtle text-secondary border border-secondary-subtle px-2.5 py-1.5" style="font-size: 0.72rem; font-weight: 600;">
                                    ⚪ Nonaktif
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="small text-secondary font-monospace">
                                <?= $u['last_login'] ? e($u['last_login']) : '<span class="text-muted opacity-50">- Belum Login -</span>' ?>
                            </div>
                        </td>
                        <td class="text-end" style="padding-right: 1.25rem;">
                            <div class="d-inline-flex gap-1">
                                <a class="btn btn-sm btn-light border rounded-3 px-2.5 py-1" href="<?= url('/admin/users/edit/' . $u['id']) ?>" title="Edit User">
                                    <i class="bi bi-pencil me-1 text-secondary"></i> Edit
                                </a>
                                <?php if ((int)$u['id'] !== (int)$me['id']): ?>
                                    <button class="btn btn-sm btn-outline-danger rounded-3 px-2 py-1" data-confirm-url="<?= url('/admin/users/delete/' . $u['id']) ?>" data-confirm-message="Hapus user <?= e($u['name']) ?>?" title="Hapus User">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
