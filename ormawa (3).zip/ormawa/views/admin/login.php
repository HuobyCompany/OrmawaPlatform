<div class="text-center mb-4">
    <?php if (!empty($organization['logo'])): ?>
        <img src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('admin-logo', 200, 200) : e(upload_url($organization['logo'])) ?>" alt="Logo" class="rounded-4 mb-3 shadow-sm mx-auto border" style="width: 68px; height: 68px; object-fit: contain; background: color-mix(in srgb, var(--primary-color) 8%, #ffffff); padding: 10px;">
    <?php else: ?>
        <div class="brand-mark mx-auto mb-3 rounded-4 shadow-sm bg-dark text-white d-grid place-items-center" style="width: 60px; height: 60px;">
            <i class="bi bi-buildings fs-3"></i>
        </div>
    <?php endif; ?>
    <h1 class="h4 fw-bold text-dark mb-1">Masuk Pengurus / Anggota</h1>
    <p class="text-secondary small mb-0"><?= e($organization['name'] ?? APP_NAME) ?></p>
</div>

<div class="admin-card p-4 p-md-5 rounded-5 border shadow-sm bg-white">
    <form method="post" action="<?= url('/login') ?>">
        <?= Csrf::field() ?>
        
        <div class="mb-3">
            <label class="form-label small fw-semibold text-secondary">Email Pengurus / Nama Lengkap / Nomor Anggota</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-0 rounded-start-pill ps-3 text-secondary"><i class="bi bi-person-badge"></i></span>
                <input class="form-control border-0 bg-light rounded-end-pill py-2.5 font-sans text-dark" type="text" name="login_input" placeholder="admin@example.com atau 24260001" required autocomplete="username">
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label small fw-semibold text-secondary">Kata Sandi / Nomor Anggota 8-Digit</label>
            <div class="input-group">
                <span class="input-group-text bg-light border-0 rounded-start-pill ps-3 text-secondary"><i class="bi bi-lock"></i></span>
                <input class="form-control border-0 bg-light rounded-end-pill py-2.5 font-monospace text-dark" type="password" name="password" placeholder="8-Digit Nomor Anggota / Password Admin" autocomplete="current-password">
            </div>
            <div class="form-text small opacity-75 mt-2" style="font-size: 0.75rem;">
                <i class="bi bi-info-circle me-1"></i>Sistem akan otomatis mendeteksi akses Anda sebagai <strong>Pengurus (Admin)</strong> atau <strong>Anggota (Member)</strong>.
            </div>
        </div>

        <button type="submit" class="btn btn-dark w-100 py-3 rounded-pill fw-bold d-flex align-items-center justify-content-center gap-2 shadow-sm">
            <span>Masuk ke Akun</span>
            <i class="bi bi-arrow-right"></i>
        </button>
    </form>

    <div class="mt-4 pt-3 border-top text-center">
        <a href="<?= e(org_url($organization ?? null)) ?>" class="text-secondary small text-decoration-none">
            <i class="bi bi-arrow-left me-1"></i> Kembali ke Website Publik
        </a>
    </div>
</div>
