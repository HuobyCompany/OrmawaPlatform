<!-- Dashboard Header -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="text-primary small fw-bold text-uppercase" style="letter-spacing: 0.5px;">Panel Pengurus</div>
        <h2 class="h3 fw-bold text-dark mb-1">Dashboard <?= e($organization['short_name'] ?: $organization['name']) ?></h2>
        <p class="text-secondary small mb-0">Ringkasan aktivitas, statistik pendaftaran, dan operasional organisasi.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-primary rounded-pill px-3.5 d-inline-flex align-items-center gap-2 shadow-sm fw-semibold" href="<?= url('/admin/registration/submissions') ?>">
            <i class="bi bi-people-fill me-1.5"></i>
            <span>Tinjau Pendaftar</span>
        </a>
        <a class="btn btn-outline-dark rounded-pill px-3.5 d-inline-flex align-items-center gap-2 fw-semibold" href="<?= url('/admin/events/create') ?>">
            <i class="bi bi-plus-lg me-1.5"></i>
            <span>Tambah Event</span>
        </a>
    </div>
</div>

<!-- Apple / iOS Style Stat Grid Cards -->
<div class="row g-3 mb-4">
    <?php 
    $metricCards = [
        ['reg_pending', 'Pendaftar Baru', 'clock-history', 'bg-warning bg-opacity-10 text-warning', 'border-warning'],
        ['reg_approved', 'Anggota Aktif', 'people-fill', 'bg-success bg-opacity-10 text-success', 'border-success'],
        ['events', 'Total Event', 'calendar-event', 'bg-primary bg-opacity-10 text-primary', 'border-primary'],
        ['upcoming', 'Upcoming Event', 'alarm', 'bg-info bg-opacity-10 text-info', 'border-info'],
        ['albums', 'Album Foto', 'images', 'bg-purple bg-opacity-10 text-purple', 'border-purple'],
        ['positions', 'Struktur Pengurus', 'diagram-3', 'bg-secondary bg-opacity-10 text-dark', 'border-secondary']
    ];
    foreach ($metricCards as $c): 
        $val = (int)($counts[$c[0]] ?? 0);
    ?>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 h-100 bg-white">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="small text-secondary fw-semibold"><?= e($c[1]) ?></span>
                    <div class="d-inline-flex align-items-center justify-content-center rounded-circle p-2 <?= $c[3] ?>" style="width: 34px; height: 34px;">
                        <i class="bi bi-<?= e($c[2]) ?> fs-6"></i>
                    </div>
                </div>
                <div>
                    <div class="fs-2 fw-extrabold text-dark" style="letter-spacing: -0.03em;"><?= $val ?></div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="row g-4">
    <!-- Left Column: Quick Actions & Log Activity -->
    <div class="col-lg-8">
        <!-- Quick Feature Matrix -->
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4 bg-white">
            <h5 class="fw-bold text-dark mb-3">
                <i class="bi bi-grid-fill text-primary me-2"></i>Akses Pintas Fitur Utama
            </h5>
            <div class="row g-2">
                <div class="col-6 col-md-3">
                    <a href="<?= url('/admin/registration') ?>" class="btn btn-light w-100 p-3 text-start rounded-4 border-0 bg-light d-flex flex-column gap-2 text-decoration-none">
                        <i class="bi bi-ui-checks fs-3 text-primary"></i>
                        <div>
                            <div class="fw-bold text-dark small">Form Builder</div>
                            <div class="text-muted" style="font-size: 0.75rem;">Atur formulir</div>
                        </div>
                    </a>
                </div>
                <div class="col-6 col-md-3">
                    <a href="<?= url('/admin/registration/submissions') ?>" class="btn btn-light w-100 p-3 text-start rounded-4 border-0 bg-light d-flex flex-column gap-2 text-decoration-none">
                        <i class="bi bi-people fs-3 text-success"></i>
                        <div>
                            <div class="fw-bold text-dark small">Pendaftar Masuk</div>
                            <div class="text-muted" style="font-size: 0.75rem;">Tinjau berkas</div>
                        </div>
                    </a>
                </div>
                <div class="col-6 col-md-3">
                    <a href="<?= url('/admin/faculties') ?>" class="btn btn-light w-100 p-3 text-start rounded-4 border-0 bg-light d-flex flex-column gap-2 text-decoration-none">
                        <i class="bi bi-buildings fs-3 text-warning"></i>
                        <div>
                            <div class="fw-bold text-dark small">Fakultas & Prodi</div>
                            <div class="text-muted" style="font-size: 0.75rem;">Master data</div>
                        </div>
                    </a>
                </div>
                <div class="col-6 col-md-3">
                    <a href="<?= url('/admin/events') ?>" class="btn btn-light w-100 p-3 text-start rounded-4 border-0 bg-light d-flex flex-column gap-2 text-decoration-none">
                        <i class="bi bi-calendar-event fs-3 text-info"></i>
                        <div>
                            <div class="fw-bold text-dark small">Agenda Kegiatan</div>
                            <div class="text-muted" style="font-size: 0.75rem;">Jadwal event</div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <!-- Recent Activity Feed -->
        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h5 class="fw-bold text-dark mb-0"><i class="bi bi-clock-history me-2 text-primary"></i>Aktivitas Pengurus Terbaru</h5>
                    <div class="small text-secondary">Log perubahan dan operasi sitem</div>
                </div>
                <a class="btn btn-sm btn-outline-secondary rounded-pill px-3" href="<?= url('/admin/media') ?>">
                    <i class="bi bi-folder2-open me-1"></i> Media Manager
                </a>
            </div>

            <?php if (!$logs): ?>
                <div class="text-center py-4 text-secondary">
                    <i class="bi bi-check-circle fs-2 opacity-30 mb-2 d-block"></i>
                    <p class="mb-0 small">Belum ada aktivitas yang tercatat dalam log sistem.</p>
                </div>
            <?php else: ?>
                <div class="vstack gap-2">
                    <?php foreach ($logs as $log): ?>
                        <div class="p-3 rounded-4 bg-light d-flex gap-3 align-items-center border-0">
                            <div class="d-inline-flex align-items-center justify-content-center bg-white rounded-circle shadow-sm p-2 flex-shrink-0" style="width: 38px; height: 38px;">
                                <i class="bi bi-activity fs-6 text-primary"></i>
                            </div>
                            <div class="min-w-0 flex-grow-1">
                                <div class="fw-bold text-dark small"><?= e($log['description']) ?></div>
                                <div class="small text-muted mt-0.5">
                                    <span class="fw-semibold text-dark"><?= e($log['name'] ?: 'System') ?></span> • 
                                    <span class="badge rounded-pill bg-white text-dark border px-2 py-0.5"><?= e($log['action']) ?></span> • 
                                    <?= e($log['created_at']) ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Right Column: Settings & Public Link -->
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm rounded-4 p-4 h-100 bg-white">
            <div class="d-flex align-items-center gap-2 mb-3">
                <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle p-2" style="width: 40px; height: 40px;">
                    <i class="bi bi-gear-wide-connected fs-5"></i>
                </div>
                <div>
                    <h5 class="fw-bold text-dark mb-0">Navigasi Pengaturan</h5>
                    <div class="small text-secondary">Kelola identitas & tata letak</div>
                </div>
            </div>

            <div class="vstack gap-2 my-2">
                <a class="btn btn-light text-start rounded-4 p-3 border-0 bg-light d-flex align-items-center justify-content-between text-decoration-none" href="<?= url('/admin/organization') ?>">
                    <span class="d-flex align-items-center gap-3 small fw-bold text-dark">
                        <i class="bi bi-sliders text-primary fs-5 me-2"></i>
                        <span>Profil, Logo &amp; Warna</span>
                    </span>
                    <i class="bi bi-chevron-right text-muted small"></i>
                </a>

                <a class="btn btn-light text-start rounded-4 p-3 border-0 bg-light d-flex align-items-center justify-content-between text-decoration-none" href="<?= url('/admin/settings') ?>">
                    <span class="d-flex align-items-center gap-3 small fw-bold text-dark">
                        <i class="bi bi-aspect-ratio text-info fs-5 me-2"></i>
                        <span>Ukuran Foto &amp; Layout</span>
                    </span>
                    <i class="bi bi-chevron-right text-muted small"></i>
                </a>

                <a class="btn btn-light text-start rounded-4 p-3 border-0 bg-light d-flex align-items-center justify-content-between text-decoration-none" href="<?= url('/admin/letters') ?>">
                    <span class="d-flex align-items-center gap-3 small fw-bold text-dark">
                        <i class="bi bi-file-earmark-text text-success fs-5 me-2"></i>
                        <span>Arsip Surat Organisasi</span>
                    </span>
                    <i class="bi bi-chevron-right text-muted small"></i>
                </a>
            </div>

            <div class="mt-auto pt-3 border-top text-center">
                <a class="btn btn-dark w-100 rounded-pill py-2.5 fw-bold shadow-sm d-inline-flex align-items-center justify-content-center gap-2" target="_blank" href="<?= e(org_url($organization)) ?>">
                    <i class="bi bi-globe"></i>
                    <span>Buka Website Publik</span>
                </a>
            </div>
        </div>
    </div>
</div>
