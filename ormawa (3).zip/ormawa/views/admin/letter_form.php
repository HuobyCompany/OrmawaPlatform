<?php
$isEdit = !empty($letter);
$type = $letter['type'] ?? ($defaultType ?? 'incoming');
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <a href="<?= url('/admin/letters') ?>" class="text-secondary text-decoration-none small fw-semibold">
            <i class="bi bi-arrow-left me-1"></i> Kembali ke Arsip Surat
        </a>
        <h2 class="fw-bold mb-0 mt-1"><?= $isEdit ? 'Edit Surat' : 'Tambah Surat Baru' ?></h2>
    </div>
</div>

<form method="post" action="<?= url('/admin/letters/save') ?>" enctype="multipart/form-data">
    <?= Csrf::field() ?>
    <?php if ($isEdit): ?>
        <input type="hidden" name="id" value="<?= (int)$letter['id'] ?>">
    <?php endif; ?>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="admin-card p-4 mb-4">
                <h3 class="h5 fw-bold mb-3">Informasi Utama Surat</h3>

                <!-- Jenis Surat Selection -->
                <div class="mb-4">
                    <label class="form-label fw-semibold">Jenis Surat</label>
                    <div class="d-flex gap-3">
                        <label class="border rounded-4 p-3 flex-fill cursor-pointer <?= $type === 'incoming' ? 'border-primary bg-primary-subtle' : 'bg-light' ?>">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="type" value="incoming" <?= $type === 'incoming' ? 'checked' : '' ?>>
                                <span class="form-check-label fw-bold">
                                    <i class="bi bi-inbox text-primary me-1"></i> Surat Masuk
                                </span>
                            </div>
                            <div class="small text-secondary mt-1">Surat yang diterima dari pihak eksternal / internal kampus.</div>
                        </label>
                        <label class="border rounded-4 p-3 flex-fill cursor-pointer <?= $type === 'outgoing' ? 'border-success bg-success-subtle' : 'bg-light' ?>">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="type" value="outgoing" <?= $type === 'outgoing' ? 'checked' : '' ?>>
                                <span class="form-check-label fw-bold">
                                    <i class="bi bi-send text-success me-1"></i> Surat Keluar
                                </span>
                            </div>
                            <div class="small text-secondary mt-1">Surat yang dikeluarkan oleh pengurus organisasi.</div>
                        </label>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nomor Surat <span class="text-danger">*</span></label>
                        <input type="text" name="letter_number" class="form-control rounded-4 font-monospace" placeholder="Contoh: 001/<?= e($organization['short_name'] ?? 'ORMAWA') ?>/IX/2026" value="<?= e($letter['letter_number'] ?? '') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Kategori Surat</label>
                        <input type="text" name="category" class="form-control rounded-4" list="categoryOptions" placeholder="Pilih atau ketik kategori..." value="<?= e($letter['category'] ?? 'Umum') ?>">
                        <datalist id="categoryOptions">
                            <option value="Undangan">
                            <option value="Permohonan">
                            <option value="Keputusan">
                            <option value="Keterangan">
                            <option value="Pemberitahuan">
                            <option value="Edaran">
                            <option value="Notulensi">
                        </datalist>
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Perihal / Judul Surat <span class="text-danger">*</span></label>
                        <input type="text" name="title" class="form-control rounded-4" placeholder="Contoh: Permohonan Izin Pemakaian Auditorium" value="<?= e($letter['title'] ?? '') ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Pengirim</label>
                        <input type="text" name="sender" class="form-control rounded-4" placeholder="Instansi / Nama Pengirim" value="<?= e($letter['sender'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Penerima</label>
                        <input type="text" name="recipient" class="form-control rounded-4" placeholder="Instansi / Nama Penerima" value="<?= e($letter['recipient'] ?? '') ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Tanggal Surat</label>
                        <input type="date" name="letter_date" class="form-control rounded-4" value="<?= e($letter['letter_date'] ?? date('Y-m-d')) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Tanggal Diterima / Dikirim</label>
                        <input type="date" name="received_or_sent_date" class="form-control rounded-4" value="<?= e($letter['received_or_sent_date'] ?? date('Y-m-d')) ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-semibold">Ringkasan / Catatan Isi Surat</label>
                        <textarea name="description" class="form-control rounded-4" rows="4" placeholder="Tambahkan ringkasan singkat atau catatan mengenai isi surat..."><?= e($letter['description'] ?? '') ?></textarea>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <!-- Upload File Lampiran -->
            <div class="admin-card p-4 mb-4">
                <h3 class="h5 fw-bold mb-3">File Lampiran</h3>
                <div class="mb-3">
                    <label class="form-label fw-semibold">Upload Dokumen / Berkas</label>
                    <input type="file" name="file" class="form-control rounded-4" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.webp">
                    <div class="form-text">Format didukung: PDF, DOC, DOCX, JPG, PNG (Maks 15 MB).</div>
                </div>

                <?php if ($isEdit && !empty($letter['file_path'])): ?>
                    <div class="p-3 bg-light rounded-4 border mb-3">
                        <div class="small text-secondary mb-1">File Terpasang Saat Ini:</div>
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="min-w-0">
                                <i class="bi bi-file-earmark-text text-primary me-1"></i>
                                <span class="small fw-bold text-truncate d-inline-block" style="max-width: 150px;"><?= basename($letter['file_path']) ?></span>
                            </div>
                            <a href="<?= url('/admin/letters/download/' . $letter['id']) ?>" class="btn btn-sm btn-dark rounded-3" title="Unduh File">
                                <i class="bi bi-download"></i>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label fw-semibold">Status Arsip</label>
                    <select name="status" class="form-select rounded-4">
                        <option value="active" <?= ($letter['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>Aktif</option>
                        <option value="archived" <?= ($letter['status'] ?? '') === 'archived' ? 'selected' : '' ?>>Diarsipkan</option>
                    </select>
                </div>
            </div>

            <!-- Save Action -->
            <div class="admin-card p-4">
                <button type="submit" class="btn btn-dark w-100 rounded-4 py-2.5 fw-bold d-flex align-items-center justify-content-center gap-2">
                    <i class="bi bi-check2-circle fs-5"></i>
                    <span>Simpan Surat</span>
                </button>
                <a href="<?= url('/admin/letters') ?>" class="btn btn-light w-100 rounded-4 py-2 mt-2 text-secondary">Batal</a>
            </div>
        </div>
    </div>
</form>
