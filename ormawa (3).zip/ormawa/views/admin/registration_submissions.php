<?php
/** @var array $submissions @var string $currentStatus @var array $counts @var array $organization */
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Keanggotaan</div>
        <h2 class="h3 fw-bold text-dark mb-1">Daftar Pendaftar Masuk</h2>
        <p class="text-secondary small mb-0">Kelola dan tinjau berkas calon anggota yang mendaftar secara online.</p>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-outline-dark rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm" href="<?= url('admin/registration') ?>">
            <i class="bi bi-ui-checks me-1"></i><span>Form Builder</span>
        </a>
        <a class="btn btn-outline-secondary rounded-pill px-3 d-inline-flex align-items-center gap-1" href="<?= url('admin/faculties') ?>">
            <i class="bi bi-buildings me-1"></i><span>Fakultas & Prodi</span>
        </a>
    </div>
</div>

<?php if ($flash_success): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i><?= e($flash_success) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php if ($flash_error): ?>
    <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($flash_error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Status Filter Pills -->
<div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-4 border-bottom pb-3">
    <div class="d-flex gap-2 flex-wrap">
        <?php
        $tabs = [
            'all' => ['label' => 'Semua Pendaftar', 'count' => ($counts['pending'] + $counts['approved'] + $counts['rejected']), 'icon' => 'bi-people-fill'],
            'pending' => ['label' => 'Menunggu Review', 'count' => $counts['pending'], 'icon' => 'bi-hourglass-split'],
            'approved' => ['label' => 'Disetujui (Anggota)', 'count' => $counts['approved'], 'icon' => 'bi-check-circle-fill'],
            'rejected' => ['label' => 'Ditolak', 'count' => $counts['rejected'], 'icon' => 'bi-x-circle-fill'],
        ];
        foreach ($tabs as $key => $tab):
            $isActive = $currentStatus === $key;
        ?>
            <a href="?status=<?= $key ?>" class="btn btn-sm rounded-pill px-3 py-1.5 fw-semibold d-inline-flex align-items-center gap-1.5 <?= $isActive ? 'btn-dark shadow-sm' : 'btn-light border text-secondary' ?>">
                <i class="<?= $tab['icon'] ?>"></i>
                <span><?= e($tab['label']) ?></span>
                <span class="badge rounded-pill <?= $isActive ? 'bg-white text-dark' : 'bg-secondary bg-opacity-10 text-secondary' ?> ms-1"><?= $tab['count'] ?></span>
            </a>
        <?php endforeach; ?>
    </div>

    <div style="max-width: 260px; width: 100%;">
        <div class="input-group input-group-sm">
            <span class="input-group-text bg-white border-end-0 rounded-start-pill text-muted"><i class="bi bi-search"></i></span>
            <input type="text" id="submissionSearch" class="form-control border-start-0 rounded-end-pill" placeholder="Cari nama pendaftar...">
        </div>
    </div>
</div>

<?php if (empty($submissions)): ?>
    <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white my-3">
        <div class="d-inline-flex p-3 rounded-circle bg-light text-muted mb-3 mx-auto">
            <i class="bi bi-inbox fs-1 opacity-50"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1">Belum ada pendaftar</h5>
        <p class="text-secondary small mb-0">Formulir pendaftaran yang dikirim oleh calon anggota akan tampil di sini.</p>
    </div>
<?php else: ?>
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0" id="submissionTable">
                <thead class="bg-light">
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>Calon Anggota</th>
                        <th>Kontak</th>
                        <th>Fakultas & Program Studi</th>
                        <th>Tanggal Daftar</th>
                        <th class="text-center">Status</th>
                        <th class="text-end" style="width: 100px;">Detail</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($submissions as $i => $s): ?>
                        <?php
                        $vals = RegistrationSubmissionModel::values((int)$s['id']);
                        $vmap = [];
                        foreach ($vals as $v) { $vmap[$v['field_name']] = $v['value'] ?? $v['file_path']; }

                        // Smart lookup for name
                        $displayName = null;
                        foreach ($vmap as $k => $val) {
                            if ($val && preg_match('/(nama|name)/i', $k)) { $displayName = $val; break; }
                        }
                        if (!$displayName) {
                            foreach ($vals as $v) {
                                if (!empty($v['value']) && $v['field_type'] === 'text') { $displayName = $v['value']; break; }
                            }
                        }
                        $displayName = $displayName ?: 'Pendaftar #' . $s['id'];

                        // Smart lookup for email & phone
                        $email = null; $phone = null;
                        foreach ($vmap as $k => $val) {
                            if ($val && preg_match('/(email)/i', $k)) $email = $val;
                            if ($val && preg_match('/(phone|telepon|hp|wa)/i', $k)) $phone = $val;
                        }

                        // Smart lookup for faculty & prodi
                        $faculty = null; $prodi = null;
                        foreach ($vmap as $k => $val) {
                            if ($val && preg_match('/(fakultas|faculty)/i', $k)) $faculty = $val;
                            if ($val && preg_match('/(prodi|program_studi|study_program)/i', $k)) $prodi = $val;
                        }
                        ?>
                        <tr class="submission-row">
                            <td><span class="text-muted small fw-semibold"><?= $i + 1 ?></span></td>
                            <td>
                                <div class="d-flex align-items-center gap-2.5">
                                    <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary fw-bold rounded-circle" style="width: 36px; height: 36px; font-size: 0.9rem;">
                                        <?= e(strtoupper(substr(trim($displayName), 0, 1))) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark search-target"><?= e($displayName) ?></div>
                                        <div class="small text-muted">ID: #<?= $s['id'] ?> <?= !empty($s['public_reference']) ? '• ' . e($s['public_reference']) : '' ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="small">
                                    <?php if ($email): ?>
                                        <div class="text-dark"><i class="bi bi-envelope me-1 text-muted"></i><?= e($email) ?></div>
                                    <?php endif; ?>
                                    <?php if ($phone): ?>
                                        <div class="text-secondary"><i class="bi bi-whatsapp me-1 text-success"></i><?= e($phone) ?></div>
                                    <?php endif; ?>
                                    <?php if (!$email && !$phone): ?>
                                        <span class="text-muted fst-italic">-</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <?php if ($faculty || $prodi): ?>
                                    <span class="badge bg-light text-dark border rounded-pill px-3 py-1 small">
                                        <i class="bi bi-buildings me-1 text-primary"></i><?= e($faculty ?: '-') ?> / <?= e($prodi ?: '-') ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted fst-italic small">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="small text-dark"><?= e(format_date_id($s['created_at'])) ?></div>
                            </td>
                            <td class="text-center">
                                <?php if ($s['status'] === 'approved'): ?>
                                    <span class="badge rounded-pill bg-success bg-opacity-10 text-success px-3 py-1 small fw-semibold"><i class="bi bi-check-circle-fill me-1"></i>Disetujui</span>
                                <?php elseif ($s['status'] === 'rejected'): ?>
                                    <span class="badge rounded-pill bg-danger bg-opacity-10 text-danger px-3 py-1 small fw-semibold"><i class="bi bi-x-circle-fill me-1"></i>Ditolak</span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-warning bg-opacity-10 text-warning px-3 py-1 small fw-semibold"><i class="bi bi-clock-history me-1"></i>Menunggu</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="<?= url('admin/registration/submission/' . $s['id']) ?>" class="btn btn-sm btn-primary rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm">
                                    <i class="bi bi-eye-fill"></i> Review
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('submissionSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            var filter = this.value.toLowerCase().trim();
            document.querySelectorAll('#submissionTable .submission-row').forEach(function(row) {
                var target = row.querySelector('.search-target');
                var text = target ? target.textContent.toLowerCase() : '';
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
});
</script>
