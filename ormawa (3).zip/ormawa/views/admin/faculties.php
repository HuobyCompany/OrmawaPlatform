<?php
/** @var array $faculties @var array $studyPrograms @var array $organization */
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Master Data Universitas</div>
        <h2 class="h3 fw-bold text-dark mb-1">Fakultas & Program Studi</h2>
        <p class="text-secondary small mb-0">Kelola data fakultas dan program studi yang terhubung langsung ke formulir pendaftaran.</p>
    </div>
    <div class="d-flex gap-2">
        <button type="button" class="btn btn-primary rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm text-nowrap" data-bs-toggle="modal" data-bs-target="#addFacultyModal">
            <i class="bi bi-buildings-fill"></i><span>Tambah Fakultas</span>
        </button>
        <button type="button" class="btn btn-outline-primary rounded-pill px-3 d-inline-flex align-items-center gap-1 text-nowrap" data-bs-toggle="modal" data-bs-target="#addProgramModal">
            <i class="bi bi-mortarboard-fill"></i><span>Tambah Program Studi</span>
        </button>
    </div>
</div>

<?php if ($flash_success): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i><?= e($flash_success) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php if ($flash_error): ?>
    <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($flash_error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Tabs Navigation -->
<ul class="nav nav-pills mb-4 gap-2 border-bottom pb-3" id="masterDataTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active rounded-pill px-4 fw-semibold" id="faculties-tab" data-bs-toggle="tab" data-bs-target="#facultiesTabContent" type="button" role="tab">
            <i class="bi bi-buildings me-2"></i>Daftar Fakultas (<?= count($faculties) ?>)
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link rounded-pill px-4 fw-semibold" id="programs-tab" data-bs-toggle="tab" data-bs-target="#programsTabContent" type="button" role="tab">
            <i class="bi bi-mortarboard me-2"></i>Daftar Program Studi (<?= count($studyPrograms) ?>)
        </button>
    </li>
</ul>

<!-- Tab Contents -->
<div class="tab-content" id="masterDataTabContent">

    <!-- 1. Faculties Tab -->
    <div class="tab-pane fade show active" id="facultiesTabContent" role="tabpanel">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <?php if (empty($faculties)): ?>
                <div class="p-5 text-center text-secondary">
                    <i class="bi bi-buildings fs-1 opacity-20 mb-3 d-block"></i>
                    <h5 class="fw-bold text-dark">Belum ada data Fakultas</h5>
                    <p class="small mb-3">Klik tombol "Tambah Fakultas" untuk mulai memasukkan data.</p>
                    <button type="button" class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addFacultyModal">
                        <i class="bi bi-plus-lg me-1"></i>Tambah Fakultas
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table admin-table align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th style="width: 60px;">#</th>
                                <th style="width: 120px;">Kode</th>
                                <th>Nama Fakultas</th>
                                <th class="text-center" style="width: 140px;">Jumlah Prodi</th>
                                <th class="text-center" style="width: 120px;">Status</th>
                                <th class="text-end" style="width: 140px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($faculties as $i => $fac): ?>
                                <?php
                                $prodiCount = count(array_filter($studyPrograms, fn($sp) => (int)$sp['faculty_id'] === (int)$fac['id']));
                                ?>
                                <tr>
                                    <td><span class="text-muted small fw-semibold"><?= $i + 1 ?></span></td>
                                    <td><span class="badge bg-primary bg-opacity-10 text-primary fw-bold px-2.5 py-1 rounded-3"><?= e($fac['code']) ?></span></td>
                                    <td class="fw-bold text-dark"><?= e($fac['name']) ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-light text-dark border rounded-pill px-3 py-1"><?= $prodiCount ?> Prodi</span>
                                    </td>
                                    <td class="text-center">
                                        <?php if ($fac['is_active']): ?>
                                            <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2.5 py-1 small">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-2.5 py-1 small">Nonaktif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="d-inline-flex gap-1">
                                            <button type="button" class="btn btn-sm btn-light border rounded-circle p-2" title="Edit" data-bs-toggle="modal" data-bs-target="#editFacultyModal<?= $fac['id'] ?>">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <form method="post" action="<?= url('admin/faculties/delete') ?>" class="d-inline" onsubmit="return confirm('Hapus Fakultas <?= e($fac['name']) ?>?')">
                                                <?= Csrf::field() ?>
                                                <input type="hidden" name="id" value="<?= $fac['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger border-0 rounded-circle p-2" title="Hapus">
                                                    <i class="bi bi-trash3"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- 2. Study Programs Tab -->
    <div class="tab-pane fade" id="programsTabContent" role="tabpanel">
        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <?php if (empty($studyPrograms)): ?>
                <div class="p-5 text-center text-secondary">
                    <i class="bi bi-mortarboard fs-1 opacity-20 mb-3 d-block"></i>
                    <h5 class="fw-bold text-dark">Belum ada data Program Studi</h5>
                    <p class="small mb-3">Klik tombol "Tambah Program Studi" untuk memasukkan data prodi.</p>
                    <button type="button" class="btn btn-primary rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addProgramModal">
                        <i class="bi bi-plus-lg me-1"></i>Tambah Program Studi
                    </button>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table admin-table align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th style="width: 60px;">#</th>
                                <th>Fakultas Naungan</th>
                                <th style="width: 120px;">Kode Prodi</th>
                                <th>Nama Program Studi</th>
                                <th class="text-center" style="width: 120px;">Status</th>
                                <th class="text-end" style="width: 140px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($studyPrograms as $i => $sp): ?>
                                <tr>
                                    <td><span class="text-muted small fw-semibold"><?= $i + 1 ?></span></td>
                                    <td>
                                        <span class="badge bg-light text-dark border rounded-pill px-3 py-1">
                                            <i class="bi bi-buildings me-1 text-primary"></i><?= e($sp['faculty_name'] ?? 'Fakultas') ?>
                                        </span>
                                    </td>
                                    <td><code class="fw-bold text-primary"><?= e($sp['code']) ?></code></td>
                                    <td class="fw-bold text-dark"><?= e($sp['name']) ?></td>
                                    <td class="text-center">
                                        <?php if ($sp['is_active']): ?>
                                            <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2.5 py-1 small">Aktif</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-2.5 py-1 small">Nonaktif</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <div class="d-inline-flex gap-1">
                                            <button type="button" class="btn btn-sm btn-light border rounded-circle p-2" title="Edit" data-bs-toggle="modal" data-bs-target="#editProgramModal<?= $sp['id'] ?>">
                                                <i class="bi bi-pencil"></i>
                                            </button>
                                            <form method="post" action="<?= url('admin/programs/delete') ?>" class="d-inline" onsubmit="return confirm('Hapus Program Studi <?= e($sp['name']) ?>?')">
                                                <?= Csrf::field() ?>
                                                <input type="hidden" name="id" value="<?= $sp['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-outline-danger border-0 rounded-circle p-2" title="Hapus">
                                                    <i class="bi bi-trash3"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal: Tambah Fakultas -->
<div class="modal fade" id="addFacultyModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <form method="post" action="<?= url('admin/faculties/save') ?>">
                <?= Csrf::field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-dark"><i class="bi bi-buildings-fill text-primary me-2"></i>Tambah Fakultas Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Kode Fakultas <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control border-0 bg-light rounded-3 px-3 py-2 fw-bold text-uppercase" placeholder="Misal: FTI, FEB, FH" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Nama Fakultas <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control border-0 bg-light rounded-3 px-3 py-2" placeholder="Misal: Fakultas Teknik Informatika" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-dark">Urutan (Sort Order)</label>
                            <input type="number" name="sort_order" class="form-control border-0 bg-light rounded-3 px-3" value="0">
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="facIsActiveAdd" name="is_active" checked>
                                <label class="form-check-label fw-semibold small text-dark" for="facIsActiveAdd">Status Aktif</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Simpan Fakultas</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Edit Fakultas -->
<?php foreach ($faculties as $fac): ?>
<div class="modal fade" id="editFacultyModal<?= $fac['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <form method="post" action="<?= url('admin/faculties/save') ?>">
                <?= Csrf::field() ?>
                <input type="hidden" name="id" value="<?= $fac['id'] ?>">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-dark"><i class="bi bi-pencil-square text-primary me-2"></i>Edit Fakultas</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Kode Fakultas <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control border-0 bg-light rounded-3 px-3 py-2 fw-bold text-uppercase" value="<?= e($fac['code']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Nama Fakultas <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control border-0 bg-light rounded-3 px-3 py-2" value="<?= e($fac['name']) ?>" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-dark">Urutan (Sort Order)</label>
                            <input type="number" name="sort_order" class="form-control border-0 bg-light rounded-3 px-3" value="<?= (int)($fac['sort_order'] ?? 0) ?>">
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="facIsActive<?= $fac['id'] ?>" name="is_active" <?= $fac['is_active'] ? 'checked' : '' ?>>
                                <label class="form-check-label fw-semibold small text-dark" for="facIsActive<?= $fac['id'] ?>">Status Aktif</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<!-- Modal: Tambah Program Studi -->
<div class="modal fade" id="addProgramModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <form method="post" action="<?= url('admin/programs/save') ?>">
                <?= Csrf::field() ?>
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-dark"><i class="bi bi-mortarboard-fill text-primary me-2"></i>Tambah Program Studi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Fakultas Naungan <span class="text-danger">*</span></label>
                        <select name="faculty_id" class="form-select border-0 bg-light rounded-3 px-3 py-2 fw-semibold" required>
                            <option value="">-- Pilih Fakultas --</option>
                            <?php foreach ($faculties as $fac): ?>
                                <option value="<?= $fac['id'] ?>"><?= e($fac['name']) ?> (<?= e($fac['code']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Kode Program Studi <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control border-0 bg-light rounded-3 px-3 py-2 fw-bold text-uppercase" placeholder="Misal: IF, SI, MNJ" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Nama Program Studi <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control border-0 bg-light rounded-3 px-3 py-2" placeholder="Misal: Teknik Informatika" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-dark">Urutan (Sort Order)</label>
                            <input type="number" name="sort_order" class="form-control border-0 bg-light rounded-3 px-3" value="0">
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="prodiIsActiveAdd" name="is_active" checked>
                                <label class="form-check-label fw-semibold small text-dark" for="prodiIsActiveAdd">Status Aktif</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Simpan Program Studi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal: Edit Program Studi -->
<?php foreach ($studyPrograms as $sp): ?>
<div class="modal fade" id="editProgramModal<?= $sp['id'] ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow">
            <form method="post" action="<?= url('admin/programs/save') ?>">
                <?= Csrf::field() ?>
                <input type="hidden" name="id" value="<?= $sp['id'] ?>">
                <div class="modal-header border-0 pb-0">
                    <h5 class="modal-title fw-bold text-dark"><i class="bi bi-pencil-square text-primary me-2"></i>Edit Program Studi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Fakultas Naungan <span class="text-danger">*</span></label>
                        <select name="faculty_id" class="form-select border-0 bg-light rounded-3 px-3 py-2 fw-semibold" required>
                            <option value="">-- Pilih Fakultas --</option>
                            <?php foreach ($faculties as $fac): ?>
                                <option value="<?= $fac['id'] ?>" <?= (int)$sp['faculty_id'] === (int)$fac['id'] ? 'selected' : '' ?>><?= e($fac['name']) ?> (<?= e($fac['code']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Kode Program Studi <span class="text-danger">*</span></label>
                        <input type="text" name="code" class="form-control border-0 bg-light rounded-3 px-3 py-2 fw-bold text-uppercase" value="<?= e($sp['code']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Nama Program Studi <span class="text-danger">*</span></label>
                        <input type="text" name="name" class="form-control border-0 bg-light rounded-3 px-3 py-2" value="<?= e($sp['name']) ?>" required>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold small text-dark">Urutan (Sort Order)</label>
                            <input type="number" name="sort_order" class="form-control border-0 bg-light rounded-3 px-3" value="<?= (int)($sp['sort_order'] ?? 0) ?>">
                        </div>
                        <div class="col-md-6 d-flex align-items-end">
                            <div class="form-check form-switch mb-2">
                                <input class="form-check-input" type="checkbox" id="prodiIsActive<?= $sp['id'] ?>" name="is_active" <?= $sp['is_active'] ? 'checked' : '' ?>>
                                <label class="form-check-label fw-semibold small text-dark" for="prodiIsActive<?= $sp['id'] ?>">Status Aktif</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 pt-0">
                    <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary rounded-pill px-4 fw-semibold">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>
