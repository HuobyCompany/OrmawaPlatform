<?php
/** @var array $submission @var array $values @var array $organization */
$vals = RegistrationSubmissionModel::values((int)$submission['id']);
$vmap = [];
foreach ($vals as $v) { $vmap[$v['field_name']] = $v; }

// Smart lookup for candidate name
$displayName = null;
foreach ($vmap as $k => $vobj) {
    if (!empty($vobj['value']) && preg_match('/(nama|name)/i', $k)) { $displayName = $vobj['value']; break; }
}
if (!$displayName) {
    foreach ($vals as $v) {
        if (!empty($v['value']) && $v['field_type'] === 'text') { $displayName = $v['value']; break; }
    }
}
$displayName = $displayName ?: 'Pendaftar #' . $submission['id'];
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Pendaftaran Anggota</div>
        <h2 class="h3 fw-bold text-dark mb-1">
            <?= e($displayName) ?>
            <span class="fs-6 fw-normal text-muted ms-2">#<?= $submission['id'] ?></span>
        </h2>
        <div class="d-flex align-items-center gap-2 small text-secondary">
            <span>Dikirim <?= e(format_date_id($submission['created_at'])) ?></span>
            <span>•</span>
            <?php if (!empty($submission['public_reference'])): ?>
                <code><?= e($submission['public_reference']) ?></code>
                <span>•</span>
            <?php endif; ?>
            <?php if ($submission['status'] === 'approved'): ?>
                <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2.5 py-0.5 fw-semibold"><i class="bi bi-check-circle-fill me-1"></i>Disetujui</span>
            <?php elseif ($submission['status'] === 'rejected'): ?>
                <span class="badge bg-danger bg-opacity-10 text-danger rounded-pill px-2.5 py-0.5 fw-semibold"><i class="bi bi-x-circle-fill me-1"></i>Ditolak</span>
            <?php else: ?>
                <span class="badge bg-warning bg-opacity-10 text-warning rounded-pill px-2.5 py-0.5 fw-semibold"><i class="bi bi-clock-history me-1"></i>Menunggu Tinjauan</span>
            <?php endif; ?>
        </div>
    </div>
    <div>
        <a class="btn btn-outline-dark rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm" href="<?= url('admin/registration/submissions') ?>">
            <i class="bi bi-arrow-left"></i><span>Kembali ke Daftar</span>
        </a>
    </div>
</div>

<?php if ($flash_success): ?>
    <div class="alert alert-success alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-check-circle-fill me-2"></i><?= e($flash_success) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
<?php if ($flash_error): ?>
    <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 mb-4 shadow-sm" role="alert">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($flash_error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Left Column: Applicant Response Cards -->
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
            <h5 class="fw-bold text-dark mb-3">
                <i class="bi bi-card-checklist text-primary me-2"></i>Jawaban Formulir Pendaftaran (<?= count($values) ?> Data)
            </h5>

            <?php if (empty($values)): ?>
                <div class="text-center py-5 text-secondary">
                    <i class="bi bi-inbox fs-1 opacity-20 mb-2 d-block"></i>
                    <p class="mb-0">Tidak ada jawaban formulir yang tersimpan.</p>
                </div>
            <?php else: ?>
                <div class="vstack gap-3">
                    <?php foreach ($values as $v): ?>
                        <div class="p-3 rounded-4 bg-light border border-light-subtle">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="fw-bold text-dark small"><?= e($v['field_label']) ?></span>
                                <span class="badge bg-white text-secondary border rounded-pill px-2 py-0.5 small" style="font-size: 0.75rem;"><?= e($v['field_type']) ?></span>
                            </div>

                            <div class="mt-2 text-dark fs-6">
                                <?php
                                $val = $v['value'];
                                $fp = $v['file_path'];
                                $ft = $v['field_type'];

                                if (in_array($ft, ['file_image', 'file']) && $fp):
                                ?>
                                    <div class="p-2 bg-white rounded-3 border d-inline-block">
                                        <a href="<?= e(media_url($fp)) ?>" target="_blank" class="d-inline-flex align-items-center gap-2 text-decoration-none text-primary fw-semibold">
                                            <?php
                                            $imageMimes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
                                            $isImage = false;
                                            if ($fp && is_file(UPLOAD_PATH . '/' . ltrim($fp, '/'))) {
                                                $isImage = in_array((new finfo(FILEINFO_MIME_TYPE))->file(UPLOAD_PATH . '/' . ltrim($fp, '/')), $imageMimes);
                                            }
                                            ?>
                                            <?php if ($isImage): ?>
                                                <img src="<?= e(thumbnail_url($fp)) ?>" alt="File Upload" class="rounded-2 shadow-sm me-1" style="max-width: 120px; max-height: 120px; object-fit: cover;">
                                                <span><i class="bi bi-box-arrow-up-right ms-1"></i> Lihat Foto Full</span>
                                            <?php else: ?>
                                                <i class="bi bi-file-earmark-text fs-3 text-primary"></i>
                                                <span><i class="bi bi-download me-1"></i> Unduh Dokumen</span>
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                <?php elseif ($ft === 'checkbox' && $val): ?>
                                    <?php $opts = json_decode($val, true); ?>
                                    <?php if (is_array($opts)): ?>
                                        <div class="d-flex flex-wrap gap-1">
                                            <?php foreach ($opts as $o): ?>
                                                <span class="badge bg-primary bg-opacity-10 text-primary border rounded-pill px-3 py-1.5 fw-semibold small"><?= e($o) ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <?= e($val) ?>
                                    <?php endif; ?>
                                <?php elseif ($ft === 'social_media' && $val): ?>
                                    <?php $socials = json_decode($val, true); ?>
                                    <?php if (is_array($socials)): ?>
                                        <div class="d-flex flex-wrap gap-2">
                                            <?php foreach ($socials as $platform => $handle): ?>
                                                <span class="badge bg-white text-dark border rounded-pill px-3 py-1.5 small">
                                                    <i class="bi bi-<?= $platform === 'instagram' ? 'instagram text-danger' : ($platform === 'tiktok' ? 'tiktok text-dark' : 'globe text-primary') ?> me-1"></i>
                                                    <strong><?= e(ucfirst($platform)) ?>:</strong> <?= e($handle) ?>
                                                </span>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <?= e($val) ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if (trim((string)$val) !== ''): ?>
                                        <span class="fw-semibold text-dark"><?= nl2br(e($val)) ?></span>
                                    <?php else: ?>
                                        <span class="text-muted fst-italic small">Kosong / Tidak diisi</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

        <!-- Member Lifecycle Trace Card -->
        <?php if (!empty($lifecycle)): ?>
            <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                <h5 class="fw-bold text-dark mb-3">
                    <i class="bi bi-diagram-3-fill text-primary me-2"></i>Lifecycle Integrasi Keanggotaan
                </h5>
                <div class="vstack gap-3 small">
                    <!-- Person Entity -->
                    <div class="p-3 bg-light rounded-3 border border-light-subtle">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-secondary fw-semibold"><i class="bi bi-person-badge me-1"></i>1. Person Profile</span>
                            <?php if (!empty($lifecycle['person'])): ?>
                                <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2 py-0.5">Terhubung</span>
                            <?php else: ?>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-2 py-0.5">Belum Dibuat</span>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($lifecycle['person'])): ?>
                            <div class="fw-bold text-dark mt-1"><?= e($lifecycle['person']['full_name']) ?></div>
                            <div class="text-muted" style="font-size: 0.8rem;">
                                Person ID: #<?= $lifecycle['person']['id'] ?><br>
                                Email: <?= e($lifecycle['person']['email'] ?? '-') ?><br>
                                Phone: <?= e($lifecycle['person']['phone'] ?? '-') ?>
                            </div>
                        <?php else: ?>
                            <div class="text-muted fst-italic">Profil Person akan otomatis dibuat saat pendaftaran disetujui.</div>
                        <?php endif; ?>
                    </div>

                    <!-- Member Entity -->
                    <div class="p-3 bg-light rounded-3 border border-light-subtle">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-secondary fw-semibold"><i class="bi bi-card-heading me-1"></i>2. Anggota Resmi (Member)</span>
                            <?php if (!empty($lifecycle['member'])): ?>
                                <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2 py-0.5"><?= e(ucfirst($lifecycle['member']['status'])) ?></span>
                            <?php else: ?>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-2 py-0.5">Belum Terdaftar</span>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($lifecycle['member'])): ?>
                            <div class="fw-bold text-dark mt-1">NPA: <code><?= e($lifecycle['member']['member_number']) ?></code></div>
                            <div class="text-muted" style="font-size: 0.8rem;">
                                Member ID: #<?= $lifecycle['member']['id'] ?><br>
                                Status: <?= e($lifecycle['member']['status']) ?><br>
                                Periode: <?= e($lifecycle['member']['term_name'] ?? '-') ?>
                            </div>
                        <?php else: ?>
                            <div class="text-muted fst-italic">Nomor Anggota (NPA) & status resmi diterbitkan saat persetujuan.</div>
                        <?php endif; ?>
                    </div>

                    <!-- User Account Entity -->
                    <div class="p-3 bg-light rounded-3 border border-light-subtle">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <span class="text-secondary fw-semibold"><i class="bi bi-key me-1"></i>3. User Account (Portal)</span>
                            <?php if (!empty($lifecycle['user'])): ?>
                                <span class="badge bg-info bg-opacity-10 text-info rounded-pill px-2 py-0.5">Aktif</span>
                            <?php else: ?>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-2 py-0.5">Opsional</span>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($lifecycle['user'])): ?>
                            <div class="fw-bold text-dark mt-1"><?= e($lifecycle['user']['email']) ?></div>
                            <div class="text-muted" style="font-size: 0.8rem;">
                                User ID: #<?= $lifecycle['user']['id'] ?> | Role: <?= e($lifecycle['user']['role']) ?>
                            </div>
                        <?php else: ?>
                            <div class="text-muted fst-italic">Akun User bersifat opsional dan tidak memblokir persetujuan pendaftaran.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Reviewer Decision Card -->
        <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
            <h5 class="fw-bold text-dark mb-3">
                <i class="bi bi-shield-check text-primary me-2"></i>Keputusan Pengurus
            </h5>

            <?php if ($submission['status'] === 'pending'): ?>
                <form method="post" action="<?= url('admin/registration/submission/approve') ?>" class="mb-3">
                    <?= Csrf::field() ?>
                    <input type="hidden" name="id" value="<?= $submission['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Catatan Persetujuan (Opsional)</label>
                        <textarea name="reviewer_notes" class="form-control border-0 bg-light rounded-3 px-3 py-2" rows="2" placeholder="Contoh: Selamat bergabung di divisi..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-success w-100 rounded-pill py-2.5 fw-bold shadow-sm d-flex align-items-center justify-content-center gap-2">
                        <i class="bi bi-check-circle-fill"></i> Setujui Pendaftar
                    </button>
                </form>

                <hr class="my-3">

                <form method="post" action="<?= url('admin/registration/submission/reject') ?>">
                    <?= Csrf::field() ?>
                    <input type="hidden" name="id" value="<?= $submission['id'] ?>">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Alasan Penolakan <span class="text-danger">*</span></label>
                        <textarea name="reviewer_notes" class="form-control border-0 bg-light rounded-3 px-3 py-2" rows="2" placeholder="Tuliskan alasan penolakan..." required></textarea>
                    </div>
                    <button type="submit" class="btn btn-outline-danger w-100 rounded-pill py-2.5 fw-semibold d-flex align-items-center justify-content-center gap-2" onclick="return confirm('Apakah Anda yakin ingin menolak pendaftar ini?')">
                        <i class="bi bi-x-circle-fill"></i> Tolak Pendaftar
                    </button>
                </form>
            <?php else: ?>
                <div class="p-3 rounded-4 <?= $submission['status'] === 'approved' ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger' ?> mb-3">
                    <div class="fw-bold mb-1">
                        <i class="bi bi-<?= $submission['status'] === 'approved' ? 'check-circle-fill' : 'x-circle-fill' ?> me-1"></i>
                        Status: <?= $submission['status'] === 'approved' ? 'Disetujui' : 'Ditolak' ?>
                    </div>
                    <?php if (!empty($submission['reviewer_notes'])): ?>
                        <div class="small mt-1 text-dark">
                            <strong>Catatan Reviewer:</strong><br>
                            <?= e($submission['reviewer_notes']) ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Danger Zone: Delete Submission -->
                <form method="post" action="<?= url('admin/registration/submission/delete') ?>" onsubmit="return confirm('Hapus data pendaftar ini dari database secara permanen?')">
                    <?= Csrf::field() ?>
                    <input type="hidden" name="id" value="<?= $submission['id'] ?>">
                    <button type="submit" class="btn btn-sm btn-outline-danger w-100 rounded-pill py-2">
                        <i class="bi bi-trash3 me-1"></i> Hapus Submission Permanen
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
