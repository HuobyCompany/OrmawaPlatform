<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Dokumentasi & Media</div>
        <h2 class="h3 fw-bold text-dark mb-1">Galeri Album Dokumentasi</h2>
        <p class="text-secondary small mb-0">Kelola album dokumentasi foto kegiatan dan aktivitas organisasi.</p>
    </div>
    <a class="btn btn-primary rounded-pill px-4 py-2 d-inline-flex align-items-center gap-2 shadow-sm fw-semibold" href="<?= url('/admin/gallery/create') ?>">
        <i class="bi bi-plus-circle-fill"></i>
        <span>Tambah Album Baru</span>
    </a>
</div>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4 bg-white">
    <div class="table-responsive">
        <table class="table admin-table align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="ps-4">Cover & Judul Album</th>
                    <th>Tanggal Kegiatan</th>
                    <th>Kategori</th>
                    <th>Sumber Foto</th>
                    <th class="text-center">Total Foto</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$albums): ?>
                    <tr>
                        <td colspan="6" class="text-center text-secondary py-5">
                            <i class="bi bi-images fs-1 opacity-20 mb-2 d-block text-primary"></i>
                            <div class="fw-bold text-dark mb-1">Belum ada album dokumentasi yang dibuat</div>
                            <p class="small text-muted mb-0">Klik tombol "Tambah Album Baru" untuk mengunggah dokumentasi foto.</p>
                        </td>
                    </tr>
                <?php else: foreach ($albums as $a): ?>
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center gap-3">
                                <?php if ($a['cover_image']): ?>
                                    <img class="rounded-3 shadow-sm" src="<?= e(media_url($a['cover_image'])) ?>" alt="" style="width: 56px; height: 56px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="rounded-3 d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary" style="width: 56px; height: 56px;">
                                        <i class="bi bi-images fs-4"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="min-w-0">
                                    <div class="fw-bold text-dark text-truncate fs-6"><?= e($a['title']) ?></div>
                                    <code class="small text-muted">/gallery/<?= e($a['slug']) ?></code>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="fw-bold text-dark small"><i class="bi bi-calendar3 me-1 text-primary"></i><?= e(format_date_id($a['event_date'])) ?></div>
                        </td>
                        <td>
                            <span class="badge rounded-pill bg-light text-dark border px-3 py-1 fw-semibold">
                                <?= e($a['category'] ?: 'Umum') ?>
                            </span>
                        </td>
                        <td>
                            <?php if (($a['source_type'] ?? 'local') === 'google_drive'): ?>
                                <span class="badge rounded-pill bg-success bg-opacity-10 text-success border border-success-subtle px-3 py-1 fw-semibold">
                                    <i class="bi bi-google-drive me-1"></i>Google Drive
                                </span>
                            <?php elseif (($a['source_type'] ?? 'local') === 'remote_url'): ?>
                                <span class="badge rounded-pill bg-info bg-opacity-10 text-info border border-info-subtle px-3 py-1 fw-semibold">
                                    <i class="bi bi-link-45deg me-1"></i>URL Remote
                                </span>
                            <?php else: ?>
                                <span class="badge rounded-pill bg-primary bg-opacity-10 text-primary border border-primary-subtle px-3 py-1 fw-semibold">
                                    <i class="bi bi-cloud-arrow-up me-1"></i>Upload Lokal
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <span class="badge rounded-pill bg-dark text-white px-3 py-1">
                                <i class="bi bi-camera me-1"></i><?= (int)$a['photo_count'] ?> Foto
                            </span>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-inline-flex gap-1">
                                <a class="btn btn-sm btn-light border rounded-circle p-2" href="<?= url('/admin/gallery/edit/' . $a['id']) ?>" title="Edit Album & Kelola Foto">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <button class="btn btn-sm btn-outline-danger border-0 rounded-circle p-2" data-confirm-url="<?= url('/admin/gallery/delete/' . $a['id']) ?>" data-confirm-message="Hapus album <?= e($a['title']) ?> beserta seluruh fotonya?" title="Hapus">
                                    <i class="bi bi-trash3"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
