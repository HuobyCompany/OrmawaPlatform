<?php 
$u = $user ?? []; 
$get = fn($k, $d = '') => $u[$k] ?? $d; 
$me = auth_user(); 
$isEdit = !empty($u['id']);
?>

<!-- Page Header with Back Button -->
<div class="d-flex align-items-center gap-3 mb-4">
    <a href="<?= url('/admin/users') ?>" class="btn btn-light border rounded-circle d-inline-flex align-items-center justify-content-center p-0 flex-shrink-0 shadow-sm" style="width: 38px; height: 38px;" title="Kembali">
        <i class="bi bi-arrow-left text-dark fs-6 lh-1"></i>
    </a>
    <div>
        <p class="text-secondary small fw-semibold mb-0" style="letter-spacing:0.05em; text-transform:uppercase; font-size:0.7rem;">Sistem &amp; Keanggotaan</p>
        <h2 class="h4 fw-bold text-dark mb-0" style="letter-spacing:-0.02em;"><?= $isEdit ? 'Edit Akun Pengurus' : 'Tambah User Pengurus Baru' ?></h2>
    </div>
</div>

<form method="post" action="<?= url('/admin/users/save') ?>">
    <?= Csrf::field() ?>
    <input type="hidden" name="id" value="<?= (int)($u['id'] ?? 0) ?>">

    <div class="row g-4">
        <div class="col-lg-8 col-xl-7">
            <div class="admin-card p-4">
                <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom">
                    <div class="stat-icon bg-primary-subtle text-primary" style="width: 34px; height: 34px; border-radius: 9px; display: grid; place-items: center;">
                        <i class="bi bi-person-badge fs-6"></i>
                    </div>
                    <div>
                        <h3 class="h6 fw-bold text-dark mb-0">Informasi Kredensial &amp; Hak Akses</h3>
                        <div class="small text-secondary">Isi data akun untuk mengizinkan login pengurus</div>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small text-dark">Nama Lengkap Pengurus <span class="text-danger">*</span></label>
                        <input class="form-control" name="name" value="<?= e($get('name')) ?>" placeholder="Misal: Ahmad Fajar" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold small text-dark">Email Resmi / Login <span class="text-danger">*</span></label>
                        <input class="form-control font-monospace" type="email" name="email" value="<?= e($get('email')) ?>" placeholder="admin@example.com" required>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-semibold small text-dark">Password <?= $isEdit ? '<span class="text-muted fw-normal">(Kosongkan jika tidak diubah)</span>' : '<span class="text-danger">*</span>' ?></label>
                        <input class="form-control" type="password" name="password" minlength="10" <?= $isEdit ? '' : 'required' ?> autocomplete="new-password" placeholder="Minimal 10 karakter...">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-semibold small text-dark">Peran (Role)</label>
                        <select class="form-select" name="role">
                            <option value="editor" <?= $get('role', 'editor') === 'editor' ? 'selected' : '' ?>>Editor Content</option>
                            <option value="organization_admin" <?= $get('role') === 'organization_admin' ? 'selected' : '' ?>>Admin Organisasi</option>
                            <?php if ($me['role'] === 'super_admin'): ?>
                                <option value="super_admin" <?= $get('role') === 'super_admin' ? 'selected' : '' ?>>Super Admin</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-semibold small text-dark">Status Akun</label>
                        <select class="form-select" name="status">
                            <option value="active" <?= $get('status', 'active') === 'active' ? 'selected' : '' ?>>Aktif (Bisa Login)</option>
                            <option value="inactive" <?= $get('status') === 'inactive' ? 'selected' : '' ?>>Nonaktif (Blokir)</option>
                        </select>
                    </div>

                    <?php if ($me['role'] === 'super_admin'): ?>
                        <div class="col-12 mt-3">
                            <label class="form-label fw-semibold small text-dark">Organisasi (Tenant)</label>
                            <select class="form-select" name="organization_id">
                                <?php foreach ($organizations as $o): ?>
                                    <option value="<?= (int)$o['id'] ?>" <?= (int)$get('organization_id') === (int)$o['id'] ? 'selected' : '' ?>>
                                        <?= e($o['name']) ?> (<?= e($o['slug']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text small">User ini hanya dapat mengelola data organisasi yang dipilih.</div>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="d-flex align-items-center justify-content-end gap-2 mt-4 pt-3 border-top">
                    <a href="<?= url('/admin/users') ?>" class="btn btn-light rounded-pill px-3.5">
                        Batal
                    </a>
                    <button type="submit" class="btn btn-dark rounded-pill px-4 fw-bold d-inline-flex align-items-center gap-1.5 shadow-sm">
                        <i class="bi bi-check2"></i>
                        <span>Simpan Akun User</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</form>
