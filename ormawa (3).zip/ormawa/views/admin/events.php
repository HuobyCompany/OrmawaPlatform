<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Konten & Agenda</div>
        <h2 class="h3 fw-bold text-dark mb-1">Agenda Kegiatan</h2>
        <p class="text-secondary small mb-0">Kelola daftar kegiatan, jadwal pelaksanaan, status, dan poster flyer.</p>
    </div>
    <a class="btn btn-primary rounded-pill px-4 py-2 d-inline-flex align-items-center gap-2 shadow-sm fw-semibold" href="<?= url('/admin/events/create') ?>">
        <i class="bi bi-plus-circle-fill"></i>
        <span>Tambah Kegiatan Baru</span>
    </a>
</div>

<!-- Search & Filter Bar -->
<div class="card border-0 shadow-sm rounded-4 p-3 mb-4 bg-white">
    <form class="row g-2 align-items-center" method="get">
        <div class="col-md-7">
            <div class="input-group input-group-sm">
                <span class="input-group-text bg-light border-0 rounded-start-pill ps-3"><i class="bi bi-search text-muted"></i></span>
                <input class="form-control border-0 bg-light rounded-end-pill py-2" name="q" value="<?= e($search) ?>" placeholder="Cari judul kegiatan...">
            </div>
        </div>
        <div class="col-md-3">
            <select class="form-select form-select-sm border-0 bg-light rounded-pill py-2 fw-semibold" name="filter" aria-label="Filter status">
                <option value="all" <?= $filter === 'all' ? 'selected' : '' ?>>Semua Jadwal</option>
                <option value="upcoming" <?= $filter === 'upcoming' ? 'selected' : '' ?>>Akan Datang (Upcoming)</option>
                <option value="past" <?= $filter === 'past' ? 'selected' : '' ?>>Selesai (Past)</option>
                <option value="month" <?= $filter === 'month' ? 'selected' : '' ?>>Bulan Ini</option>
            </select>
        </div>
        <div class="col-md-2">
            <button class="btn btn-sm btn-dark rounded-pill w-100 py-2 fw-semibold">
                <i class="bi bi-funnel me-1"></i>Filter
            </button>
        </div>
    </form>
</div>

<!-- Events Table Card -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4 bg-white">
    <div class="table-responsive">
        <table class="table admin-table align-middle mb-0">
            <thead class="bg-light">
                <tr>
                    <th class="ps-4">Poster & Kegiatan</th>
                    <th>Jadwal Pelaksanaan</th>
                    <th class="text-center">Status</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$list['items']): ?>
                    <tr>
                        <td colspan="4" class="text-center text-secondary py-5">
                            <i class="bi bi-calendar2-x fs-1 opacity-20 mb-2 d-block text-primary"></i>
                            <div class="fw-bold text-dark mb-1">Belum ada data agenda kegiatan</div>
                            <p class="small text-muted mb-0">Klik tombol "Tambah Kegiatan Baru" untuk menjadwalkan event.</p>
                        </td>
                    </tr>
                <?php else: foreach ($list['items'] as $e): ?>
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center gap-3">
                                <?php if ($e['poster']): ?>
                                    <img class="rounded-3 shadow-sm" src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('admin-event-' . $e['id'], 400, 300) : e(media_url($e['poster'])) ?>" alt="" style="width: 54px; height: 54px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="rounded-3 d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary" style="width: 54px; height: 54px;">
                                        <i class="bi bi-calendar-event fs-4"></i>
                                    </div>
                                <?php endif; ?>
                                <div class="min-w-0">
                                    <div class="fw-bold text-dark text-truncate fs-6"><?= e($e['title']) ?></div>
                                    <code class="small text-muted">/kegiatan/<?= e($e['slug']) ?></code>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="fw-bold text-dark small"><i class="bi bi-calendar3 me-1 text-primary"></i><?= e(format_date_id($e['event_date'])) ?></div>
                            <div class="small text-secondary"><i class="bi bi-clock me-1 text-muted"></i><?= e(format_time($e['start_time'])) ?> WIB</div>
                        </td>
                        <td class="text-center">
                            <?php if ($e['status'] === 'published'): ?>
                                <span class="badge rounded-pill bg-success bg-opacity-10 text-success px-3 py-1 small fw-semibold">Publik (Aktif)</span>
                            <?php elseif ($e['status'] === 'cancelled'): ?>
                                <span class="badge rounded-pill bg-danger bg-opacity-10 text-danger px-3 py-1 small fw-semibold">Dibatalkan</span>
                            <?php else: ?>
                                <span class="badge rounded-pill bg-secondary bg-opacity-10 text-secondary px-3 py-1 small fw-semibold">Draft</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end pe-4">
                            <div class="d-inline-flex gap-1">
                                <a class="btn btn-sm btn-light border rounded-circle p-2" href="<?= url('/admin/events/edit/' . $e['id']) ?>" title="Edit">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <button class="btn btn-sm btn-outline-danger border-0 rounded-circle p-2" data-confirm-url="<?= url('/admin/events/delete/' . $e['id']) ?>" data-confirm-message="Hapus kegiatan <?= e($e['title']) ?>?" title="Hapus">
                                    <i class="bi bi-trash3"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
