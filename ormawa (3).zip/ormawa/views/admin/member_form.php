<?php
/** @var array|null $member @var array $faculties @var array $organization */
$errors = $_SESSION['_errors'] ?? [];
$old = $_SESSION['_old'] ?? [];
unset($_SESSION['_errors'], $_SESSION['_old']);
$isEdit = $member !== null;
$formAction = $isEdit ? url('admin/members/update') : url('admin/members/store');
?>

<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold mb-1" style="letter-spacing: 0.05em; text-transform: uppercase; font-size: 0.7rem;">Keanggotaan & Database</div>
        <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;"><?= $isEdit ? 'Edit Anggota' : 'Tambah Anggota Baru' ?></h2>
        <p class="text-secondary small mb-0"><?= $isEdit ? 'Perbarui data anggota resmi organisasi' : 'Masukkan data anggota baru secara manual' ?></p>
    </div>
    <a href="<?= url('admin/members') ?>" class="btn btn-outline-secondary rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm">
        <i class="bi bi-arrow-left me-1"></i><span>Kembali ke Daftar</span>
    </a>
</div>

<?php if (isset($_SESSION['_flash']['error'])): ?>
    <?php $msg = flash('error'); ?>
    <div class="alert alert-danger alert-dismissible fade show rounded-4 border-0 mb-4" role="alert">
        <i class="bi bi-exclamation-circle me-2"></i><?= e($msg) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="card-body p-4 p-md-5">
        <form method="post" action="<?= e($formAction) ?>" id="memberForm" novalidate>
            <?= Csrf::field() ?>
            <?php if ($isEdit): ?>
                <input type="hidden" name="id" value="<?= e($member['id']) ?>">
            <?php endif; ?>

            <div class="row g-4">
                <div class="col-md-8">
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark small text-uppercase" for="full_name">
                            Nama Lengkap <span class="text-danger">*</span>
                        </label>
                        <input type="text" id="full_name" name="full_name" class="form-control border-0 bg-light rounded-3 <?= isset($errors['full_name']) ? 'is-invalid' : '' ?>" placeholder="Masukkan nama lengkap" value="<?= e($old['full_name'] ?? $member['full_name'] ?? '') ?>" required>
                        <?php if (isset($errors['full_name'])): ?>
                            <div class="invalid-feedback d-block mt-1 small text-danger"><?= e($errors['full_name']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark small text-uppercase" for="member_number">
                            Nomor Anggota
                        </label>
                        <input type="text" id="member_number" name="member_number" class="form-control border-0 bg-light rounded-3" placeholder="Auto / Manual" value="<?= e($old['member_number'] ?? $member['member_number'] ?? '') ?>">
                        <div class="form-text small">Kosongkan untuk generate otomatis</div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark small text-uppercase" for="faculty_name">
                            Fakultas
                        </label>
                        <select id="faculty_name" name="faculty_name" class="form-select border-0 bg-light rounded-3">
                            <option value="">-- Pilih Fakultas --</option>
                            <?php foreach ($faculties as $fac): ?>
                                <option value="<?= e($fac['name']) ?>" <?= ($old['faculty_name'] ?? $member['faculty_name'] ?? '') === $fac['name'] ? 'selected' : '' ?>><?= e($fac['name']) ?> (<?= e($fac['code']) ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark small text-uppercase" for="prodi_name">
                            Program Studi
                        </label>
                        <input type="text" id="prodi_name" name="prodi_name" class="form-control border-0 bg-light rounded-3" placeholder="Contoh: Teknik Industri" value="<?= e($old['prodi_name'] ?? $member['prodi_name'] ?? '') ?>">
                        <div class="form-text small">Masukkan nama program studi secara manual</div>
                    </div>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark small text-uppercase" for="whatsapp">
                            WhatsApp
                        </label>
                        <input type="tel" id="whatsapp" name="whatsapp" class="form-control border-0 bg-light rounded-3" placeholder="08xx-xxxx-xxxx" value="<?= e($old['whatsapp'] ?? $member['whatsapp'] ?? '') ?>">
                        <div class="form-text small">Format: 08xxxxxxxxxx (untuk link wa.me)</div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-4">
                        <label class="form-label fw-semibold text-dark small text-uppercase" for="batch_year">
                            Angkatan / Tahun Masuk
                        </label>
                        <input type="number" id="batch_year" name="batch_year" class="form-control border-0 bg-light rounded-3" min="2000" max="<?= date('Y') + 5 ?>" placeholder="<?= date('Y') ?>" value="<?= e($old['batch_year'] ?? $member['batch_year'] ?? '') ?>">
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-end gap-2 pt-4 border-top">
                <a href="<?= url('admin/members') ?>" class="btn btn-outline-secondary rounded-pill px-4">
                    Batal
                </a>
                <button type="submit" class="btn btn-dark rounded-pill px-4 fw-bold d-inline-flex align-items-center gap-1.5">
                    <i class="bi bi-check2"></i>
                    <span><?= $isEdit ? 'Simpan Perubahan' : 'Tambah Anggota' ?></span>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('memberForm');
    if (!form) return;

    // Auto-generate member number if empty on submit
    form.addEventListener('submit', function(e) {
        var memberNumber = document.getElementById('member_number');
        if (memberNumber && memberNumber.value.trim() === '') {
            // Generate: ANG-YYYY-XXX
            var year = new Date().getFullYear();
            var random = Math.floor(Math.random() * 900) + 100;
            memberNumber.value = 'ANG-' + year + '-' + random;
        }
    });
});
</script>