<?php
/** @var array $list @var string $type @var string $search @var string $category @var array $categories @var array $counts */
?>

<!-- Header -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Arsip & Dokumen</div>
        <h2 class="h3 fw-bold text-dark mb-1">Arsip Surat Organisasi</h2>
        <p class="text-secondary small mb-0">Kelola dan simpan dokumen surat masuk serta surat keluar secara terorganisir.</p>
    </div>
    <a href="<?= url('/admin/letters/create?type=' . e($type === 'all' ? 'incoming' : $type)) ?>" class="btn btn-primary rounded-pill px-4 py-2 d-inline-flex align-items-center gap-2 shadow-sm fw-semibold">
        <i class="bi bi-plus-circle-fill"></i>
        <span>Tambah Surat Baru</span>
    </a>
</div>

<!-- Stat Cards Grid -->
<div class="row g-3 mb-4">
    <div class="col-12 col-sm-4">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <span class="small text-secondary fw-semibold">Total Surat</span>
                <div class="d-inline-flex align-items-center justify-content-center bg-light text-dark rounded-circle" style="width: 36px; height: 36px;">
                    <i class="bi bi-archive-fill fs-6"></i>
                </div>
            </div>
            <div class="fs-2 fw-extrabold text-dark" style="letter-spacing: -0.03em;"><?= (int)$counts['total'] ?></div>
        </div>
    </div>
    <div class="col-12 col-sm-4">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <span class="small text-secondary fw-semibold">Surat Masuk</span>
                <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle" style="width: 36px; height: 36px;">
                    <i class="bi bi-inbox-fill fs-6"></i>
                </div>
            </div>
            <div class="fs-2 fw-extrabold text-primary" style="letter-spacing: -0.03em;"><?= (int)$counts['incoming'] ?></div>
        </div>
    </div>
    <div class="col-12 col-sm-4">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <span class="small text-secondary fw-semibold">Surat Keluar</span>
                <div class="d-inline-flex align-items-center justify-content-center bg-success bg-opacity-10 text-success rounded-circle" style="width: 36px; height: 36px;">
                    <i class="bi bi-send-fill fs-6"></i>
                </div>
            </div>
            <div class="fs-2 fw-extrabold text-success" style="letter-spacing: -0.03em;"><?= (int)$counts['outgoing'] ?></div>
        </div>
    </div>
</div>

<!-- Filter & Search Toolbar -->
<div class="card border-0 shadow-sm rounded-4 p-3 mb-4 bg-white">
    <form method="get" action="<?= url('/admin/letters') ?>" class="row g-2 align-items-center">
        <input type="hidden" name="type" value="<?= e($type) ?>">

        <!-- Segmented Control -->
        <div class="col-12 col-md-5">
            <div class="d-flex p-1 bg-light rounded-pill border">
                <a href="<?= url('/admin/letters?type=all&q=' . urlencode($search) . '&category=' . urlencode($category)) ?>"
                   class="btn btn-sm flex-fill rounded-pill fw-semibold border-0 <?= $type === 'all' ? 'bg-white shadow-sm text-dark' : 'text-secondary' ?>">
                    Semua
                </a>
                <a href="<?= url('/admin/letters?type=incoming&q=' . urlencode($search) . '&category=' . urlencode($category)) ?>"
                   class="btn btn-sm flex-fill rounded-pill fw-semibold border-0 <?= $type === 'incoming' ? 'bg-white shadow-sm text-primary' : 'text-secondary' ?>">
                    <i class="bi bi-inbox me-1"></i> Surat Masuk
                </a>
                <a href="<?= url('/admin/letters?type=outgoing&q=' . urlencode($search) . '&category=' . urlencode($category)) ?>"
                   class="btn btn-sm flex-fill rounded-pill fw-semibold border-0 <?= $type === 'outgoing' ? 'bg-white shadow-sm text-success' : 'text-secondary' ?>">
                    <i class="bi bi-send me-1"></i> Surat Keluar
                </a>
            </div>
        </div>

        <!-- Category Dropdown -->
        <div class="col-6 col-md-3">
            <select name="category" class="form-select form-select-sm border-0 bg-light rounded-pill py-2 fw-semibold" onchange="this.form.submit()">
                <option value="">Semua Kategori</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= e($cat) ?>" <?= $category === $cat ? 'selected' : '' ?>><?= e($cat) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Search Input -->
        <div class="col-6 col-md-4">
            <div class="input-group input-group-sm">
                <span class="input-group-text bg-light border-0 rounded-start-pill ps-3"><i class="bi bi-search text-muted"></i></span>
                <input type="text" name="q" class="form-control border-0 bg-light rounded-end-pill py-2" placeholder="Cari nomor, perihal..." value="<?= e($search) ?>">
            </div>
        </div>
    </form>
</div>

<!-- Letters Table Card -->
<div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4 bg-white">
    <?php if (empty($list['items'])): ?>
        <div class="p-5 text-center text-secondary">
            <div class="d-inline-flex p-3 rounded-circle bg-light text-primary mb-3">
                <i class="bi bi-file-earmark-text fs-1 opacity-50"></i>
            </div>
            <h5 class="fw-bold text-dark mb-1">Belum Ada Surat Tersimpan</h5>
            <p class="small text-muted mb-3">Arsip surat masuk dan surat keluar akan tersimpan secara rapi di sini.</p>
            <a href="<?= url('/admin/letters/create?type=' . e($type === 'all' ? 'incoming' : $type)) ?>" class="btn btn-primary rounded-pill px-4 py-2 fw-semibold">
                <i class="bi bi-plus-lg me-1"></i> Tambah Surat Baru
            </a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4" style="width: 110px;">Tipe</th>
                        <th style="width: 160px;">No. Surat</th>
                        <th>Perihal & Detail</th>
                        <th>Pengirim / Penerima</th>
                        <th style="width: 130px;">Tgl Surat</th>
                        <th style="width: 120px;">Kategori</th>
                        <th style="width: 130px;">Lampiran</th>
                        <th class="pe-4 text-end" style="width: 100px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($list['items'] as $item): ?>
                        <tr>
                            <td class="ps-4">
                                <?php if ($item['type'] === 'incoming'): ?>
                                    <span class="badge rounded-pill bg-primary bg-opacity-10 text-primary border border-primary-subtle px-2.5 py-1 fw-semibold">
                                        <i class="bi bi-arrow-down-left me-1"></i>Masuk
                                    </span>
                                <?php else: ?>
                                    <span class="badge rounded-pill bg-success bg-opacity-10 text-success border border-success-subtle px-2.5 py-1 fw-semibold">
                                        <i class="bi bi-arrow-up-right me-1"></i>Keluar
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <code class="fw-bold text-dark small"><?= e($item['letter_number']) ?></code>
                            </td>
                            <td style="max-width: 260px;">
                                <div class="fw-bold text-dark text-truncate"><?= e($item['title']) ?></div>
                                <?php if (!empty($item['description'])): ?>
                                    <div class="small text-muted text-truncate" title="<?= e($item['description']) ?>"><?= e($item['description']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="small">
                                    <div class="text-dark"><span class="text-muted">Dari:</span> <strong><?= e($item['sender'] ?: '-') ?></strong></div>
                                    <div class="text-secondary"><span class="text-muted">Ke:</span> <strong><?= e($item['recipient'] ?: '-') ?></strong></div>
                                </div>
                            </td>
                            <td>
                                <div class="small fw-semibold text-dark"><?= e(format_date_id($item['letter_date'])) ?></div>
                            </td>
                            <td>
                                <span class="badge rounded-pill bg-light text-dark border px-2.5 py-1 small"><?= e($item['category'] ?: 'Umum') ?></span>
                            </td>
                            <td>
                                <?php if (!empty($item['file_path'])): ?>
                                    <a href="<?= url('/admin/letters/download/' . $item['id']) ?>" class="btn btn-sm btn-light border rounded-pill px-3 py-1 text-primary fw-semibold d-inline-flex align-items-center gap-1" title="Download Lampiran">
                                        <i class="bi bi-download"></i>
                                        <span>File</span>
                                    </a>
                                <?php else: ?>
                                    <span class="small text-muted fst-italic">Tidak ada</span>
                                <?php endif; ?>
                            </td>
                            <td class="pe-4 text-end">
                                <div class="d-inline-flex gap-1">
                                    <a href="<?= url('/admin/letters/edit/' . $item['id']) ?>" class="btn btn-sm btn-light border rounded-circle p-2" title="Edit Surat">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form method="post" action="<?= url('/admin/letters/delete/' . $item['id']) ?>" class="d-inline" onsubmit="return confirm('Hapus surat ini dari arsip?')">
                                        <?= Csrf::field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger border-0 rounded-circle p-2" title="Hapus Surat">
                                            <i class="bi bi-trash3"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
