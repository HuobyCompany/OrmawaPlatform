<?php
// views/admin/structure_group_manage.php
$g = $group ?? [];
$posList = $positions ?? [];
$personList = $persons ?? [];
$termList = $terms ?? [];
$activeTerm = $selectedTerm ?? [];
?>

<!-- Header & Breadcrumb -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <a href="<?= url('/admin/structure?term=' . $activeTerm['id']) ?>" class="btn btn-sm btn-light rounded-pill px-3 py-1.5 text-secondary d-inline-flex align-items-center gap-1 mb-2">
            <i class="bi bi-arrow-left"></i>
            <span>Kembali ke Daftar Kelompok</span>
        </a>
        <h2 class="h3 fw-bold text-dark mb-1">Kelola Kelompok: <?= e($g['name']) ?></h2>
        <p class="text-secondary small mb-0"><?= e($g['description'] ?: 'Atur daftar jabatan dan penugasan pengurus pada kelompok ini.') ?></p>
    </div>

    <!-- Actions & Term Context -->
    <div class="d-flex flex-wrap align-items-center gap-2">
        <span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-2 fw-semibold">
            <i class="bi bi-calendar-event me-1"></i>Periode: <?= e($activeTerm['name'] ?? '-') ?>
        </span>
        <button type="button" class="btn btn-primary rounded-pill px-4 py-2 d-inline-flex align-items-center gap-2 shadow-sm fw-semibold" data-bs-toggle="modal" data-bs-target="#modalPosition">
            <i class="bi bi-plus-circle"></i>
            <span>Tambah Posisi / Jabatan</span>
        </button>
    </div>
</div>

<!-- Level 3: Positions & People List -->
<?php if (!$posList): ?>
    <div class="card border-0 shadow-sm rounded-4 p-5 bg-white text-center">
        <div class="avatar-circle-lg bg-primary bg-opacity-10 text-primary mx-auto mb-3">
            <i class="bi bi-award fs-2"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1">Belum Ada Posisi / Jabatan</h5>
        <p class="small text-muted mb-4">Tambahkan posisi seperti Ketua, Wakil, atau Staff untuk kelompok ini.</p>
        <div>
            <button type="button" class="btn btn-primary rounded-pill px-4 py-2 fw-semibold" data-bs-toggle="modal" data-bs-target="#modalPosition">
                <i class="bi bi-plus-lg me-1"></i>Tambah Jabatan Pertama
            </button>
        </div>
    </div>
<?php else: ?>

    <div class="row g-4">
        <?php foreach ($posList as $pos): ?>
            <?php 
                $posId = (int)$pos['id'];
                $assigns = $pos['assignments'] ?? [];
            ?>
            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-4 bg-white overflow-hidden">
                    <div class="card-header bg-light bg-opacity-50 p-3.5 border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
                        <div class="d-flex align-items-center gap-3">
                            <span class="avatar-circle bg-primary bg-opacity-10 text-primary rounded-circle p-2 d-inline-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                                <i class="bi bi-award-fill fs-5"></i>
                            </span>
                            <div>
                                <h4 class="h6 fw-bold text-dark mb-0"><?= e($pos['title']) ?></h4>
                                <?php if (!empty($pos['description'])): ?>
                                    <span class="small text-muted"><?= e($pos['description']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Position Toolbar Actions -->
                        <div class="d-flex align-items-center gap-2">
                            <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 py-1.5 small fw-semibold d-inline-flex align-items-center gap-1 btn-assign-person" data-pos-id="<?= $posId ?>" data-pos-title="<?= e($pos['title']) ?>">
                                <i class="bi bi-person-plus-fill"></i>
                                <span>Assign Pengurus</span>
                            </button>

                            <!-- Set Vacant Direct Button -->
                            <form method="post" action="<?= url('/admin/structure/assignment/save') ?>" class="d-inline">
                                <?= Csrf::field() ?>
                                <input type="hidden" name="term_id" value="<?= $activeTerm['id'] ?>">
                                <input type="hidden" name="position_id" value="<?= $posId ?>">
                                <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
                                <input type="hidden" name="is_vacant" value="1">
                                <button type="submit" class="btn btn-sm btn-outline-secondary rounded-pill px-3 py-1.5 small fw-semibold">
                                    <i class="bi bi-slash-circle me-1"></i>Set Vacant
                                </button>
                            </form>

                            <!-- Position Options Dropdown -->
                            <div class="dropdown">
                                <button class="btn btn-sm btn-light rounded-circle p-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="bi bi-three-dots-vertical"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end shadow-sm rounded-3 p-2">
                                    <li>
                                        <button type="button" class="dropdown-item rounded-2 small text-dark btn-edit-pos" data-id="<?= $posId ?>" data-title="<?= e($pos['title']) ?>" data-desc="<?= e($pos['description'] ?? '') ?>" data-sort="<?= (int)$pos['sort_order'] ?>">
                                            <i class="bi bi-pencil me-2"></i>Edit Judul Posisi
                                        </button>
                                    </li>
                                    <li>
                                        <form method="post" action="<?= url('/admin/structure/position/move/' . $posId . '/up') ?>">
                                            <?= Csrf::field() ?>
                                            <button type="submit" class="dropdown-item rounded-2 small text-dark"><i class="bi bi-arrow-up me-2"></i>Geser Ke Atas</button>
                                        </form>
                                    </li>
                                    <li>
                                        <form method="post" action="<?= url('/admin/structure/position/move/' . $posId . '/down') ?>">
                                            <?= Csrf::field() ?>
                                            <button type="submit" class="dropdown-item rounded-2 small text-dark"><i class="bi bi-arrow-down me-2"></i>Geser Ke Bawah</button>
                                        </form>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <button type="button" class="dropdown-item rounded-2 small text-danger" data-confirm-url="<?= url('/admin/structure/position/delete/' . $posId) ?>" data-confirm-message="Hapus posisi <?= e($pos['title']) ?>?">
                                            <i class="bi bi-trash3 me-2"></i>Hapus Posisi
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Assigned People List in Position -->
                    <div class="card-body p-3">
                        <?php if (!$assigns): ?>
                            <div class="p-3 bg-light rounded-3 text-center">
                                <span class="badge bg-secondary bg-opacity-10 text-secondary rounded-pill px-3 py-1.5 small fw-normal">
                                    <i class="bi bi-info-circle me-1"></i>Posisi ini belum memiliki pengurus (Vacant / Belum Diisi)
                                </span>
                            </div>
                        <?php else: ?>
                            <div class="row g-3">
                                <?php foreach ($assigns as $as): ?>
                                    <?php 
                                        $isVacantStatus = ($as['status'] === 'vacant' || empty($as['person_id']));
                                        $personName = $as['person_name'] ?? 'Kosong / Vacant';
                                        $photoPath = $as['photo_path'] ?? null;
                                    ?>
                                    <div class="col-md-6 col-lg-4">
                                        <div class="p-3 border rounded-3 bg-white d-flex align-items-center justify-content-between gap-2 shadow-xs">
                                            <div class="d-flex align-items-center gap-3 text-truncate">
                                                <?php if (!$isVacantStatus && !empty($photoPath)): ?>
                                                    <img src="<?= media_url($photoPath) ?>" class="rounded-circle object-fit-cover" width="40" height="40" alt="<?= e($personName) ?>">
                                                <?php else: ?>
                                                    <div class="rounded-circle bg-secondary bg-opacity-10 text-secondary d-flex align-items-center justify-content-center fw-bold" style="width: 40px; height: 40px;">
                                                        <i class="bi <?= $isVacantStatus ? 'bi-person-dash' : 'bi-person' ?>"></i>
                                                    </div>
                                                <?php endif; ?>

                                                <div class="text-truncate">
                                                    <div class="fw-semibold text-dark small text-truncate" title="<?= e($personName) ?>">
                                                        <?= e($personName) ?>
                                                    </div>
                                                    <span class="badge rounded-pill <?= $isVacantStatus ? 'bg-warning-subtle text-warning-emphasis' : 'bg-success-subtle text-success' ?>" style="font-size: 0.7rem;">
                                                        <?= $isVacantStatus ? 'Vacant' : 'Aktif' ?>
                                                    </span>
                                                </div>
                                            </div>

                                            <!-- Remove Assignment Action -->
                                            <button type="button" class="btn btn-sm btn-outline-danger rounded-circle p-1.5" data-confirm-url="<?= url('/admin/structure/assignment/delete/' . $as['id'] . '?group_id=' . $g['id'] . '&term_id=' . $activeTerm['id']) ?>" data-confirm-message="Hapus penugasan <?= e($personName) ?> dari <?= e($pos['title']) ?>?" title="Hapus Penugasan">
                                                <i class="bi bi-x-lg"></i>
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

<?php endif; ?>

<!-- MODAL: TAMBAH/EDIT POSISI -->
<div class="modal fade" id="modalPosition" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="<?= url('/admin/structure/position/save') ?>" class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <?= Csrf::field() ?>
            <input type="hidden" name="id" id="pos_modal_id" value="">
            <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
            <input type="hidden" name="term_id" value="<?= $activeTerm['id'] ?>">
            <div class="modal-header border-bottom bg-light px-4 py-3">
                <h5 class="modal-title fw-bold text-dark fs-6" id="pos_modal_title">Tambah Posisi / Jabatan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body p-4">
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Judul Posisi / Jabatan</label>
                    <input type="text" name="title" id="pos_modal_title_input" class="form-control rounded-3 py-2" placeholder="Contoh: Ketua Umum, Staff Humas, Koordinator" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Deskripsi Posisi (Opsional)</label>
                    <textarea name="description" id="pos_modal_desc" class="form-control rounded-3 py-2" rows="2" placeholder="Tanggung jawab singkat posisi ini..."></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-dark">Urutan Posisi</label>
                    <input type="number" name="sort_order" id="pos_modal_sort" class="form-control rounded-3 py-2" value="0">
                </div>
            </div>
            <div class="modal-footer bg-light border-top px-4 py-3">
                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Simpan Posisi</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL: ASSIGN PENGURUS KE POSISI -->
<div class="modal fade" id="modalAssignPerson" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="<?= url('/admin/structure/assignment/save') ?>" enctype="multipart/form-data" class="modal-content border-0 shadow-lg rounded-4 overflow-hidden">
            <?= Csrf::field() ?>
            <input type="hidden" name="term_id" value="<?= $activeTerm['id'] ?>">
            <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
            <input type="hidden" name="position_id" id="assign_modal_pos_id" value="">
            
            <div class="modal-header border-bottom bg-light px-4 py-3">
                <h5 class="modal-title fw-bold text-dark fs-6" id="assign_modal_title">Assign Pengurus</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body p-4">
                
                <!-- Toggle Mode: Select Existing vs Create New Person -->
                <div class="nav nav-pills nav-fill gap-2 mb-3 bg-light p-1 rounded-3">
                    <button type="button" class="nav-link active rounded-3 py-1.5 small fw-semibold" id="tab-existing-person" onclick="switchPersonMode('existing')">
                        Pilih Person Eksisting
                    </button>
                    <button type="button" class="nav-link rounded-3 py-1.5 small fw-semibold text-secondary" id="tab-new-person" onclick="switchPersonMode('new')">
                        + Tambah Person Baru
                    </button>
                </div>

                <!-- Section A: Select Existing Person -->
                <div id="section-existing-person">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Pilih Pengurus / Person</label>
                        <select name="person_id" id="assign_select_person" class="form-select rounded-3 py-2">
                            <option value="">-- Pilih dari database --</option>
                            <?php foreach ($personList as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= e($p['full_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Section B: Create New Person -->
                <div id="section-new-person" class="d-none">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Nama Lengkap Pengurus</label>
                        <input type="text" name="new_person_name" id="assign_new_name" class="form-control rounded-3 py-2" placeholder="Nama lengkap pengurus...">
                    </div>
                    <div class="row g-2 mb-3">
                        <div class="col-6">
                            <label class="form-label fw-semibold small text-dark">Email (Opsional)</label>
                            <input type="email" name="email" class="form-control rounded-3 py-2" placeholder="email@example.com">
                        </div>
                        <div class="col-6">
                            <label class="form-label fw-semibold small text-dark">Telepon (Opsional)</label>
                            <input type="text" name="phone" class="form-control rounded-3 py-2" placeholder="0812...">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small text-dark">Foto Profil (Opsional)</label>
                        <input type="file" name="photo" class="form-control rounded-3 py-2" accept="image/*">
                    </div>
                </div>

                <div class="form-check form-switch mt-3 pt-2 border-top">
                    <input class="form-check-input" type="checkbox" name="is_vacant" id="assign_is_vacant" value="1" onchange="toggleVacant(this)">
                    <label class="form-check-label small fw-semibold text-dark" for="assign_is_vacant">
                        Tandai sebagai Vacant / Belum ada pengurus
                    </label>
                </div>

            </div>
            <div class="modal-footer bg-light border-top px-4 py-3">
                <button type="button" class="btn btn-light rounded-pill px-4" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-primary rounded-pill px-4 fw-bold">Simpan Penugasan</button>
            </div>
        </form>
    </div>
</div>

<script>
function switchPersonMode(mode) {
    const secExisting = document.getElementById('section-existing-person');
    const secNew = document.getElementById('section-new-person');
    const tabExisting = document.getElementById('tab-existing-person');
    const tabNew = document.getElementById('tab-new-person');

    if (mode === 'existing') {
        secExisting.classList.remove('d-none');
        secNew.classList.add('d-none');
        tabExisting.classList.add('active', 'btn-primary');
        tabExisting.classList.remove('text-secondary');
        tabNew.classList.remove('active', 'btn-primary');
        tabNew.classList.add('text-secondary');
    } else {
        secExisting.classList.add('d-none');
        secNew.classList.remove('d-none');
        tabNew.classList.add('active', 'btn-primary');
        tabNew.classList.remove('text-secondary');
        tabExisting.classList.remove('active', 'btn-primary');
        tabExisting.classList.add('text-secondary');
    }
}

function toggleVacant(chk) {
    const secExisting = document.getElementById('section-existing-person');
    const secNew = document.getElementById('section-new-person');
    if (chk.checked) {
        secExisting.classList.add('d-none');
        secNew.classList.add('d-none');
    } else {
        switchPersonMode('existing');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // Edit Position Modal pre-fill
    document.querySelectorAll('.btn-edit-pos').forEach(btn => {
        btn.addEventListener('click', () => {
            document.getElementById('pos_modal_id').value = btn.dataset.id;
            document.getElementById('pos_modal_title_input').value = btn.dataset.title || '';
            document.getElementById('pos_modal_desc').value = btn.dataset.desc || '';
            document.getElementById('pos_modal_sort').value = btn.dataset.sort || '0';
            document.getElementById('pos_modal_title').textContent = 'Edit Posisi / Jabatan';

            const modal = new bootstrap.Modal(document.getElementById('modalPosition'));
            modal.show();
        });
    });

    // Assign Person Modal trigger
    document.querySelectorAll('.btn-assign-person').forEach(btn => {
        btn.addEventListener('click', () => {
            const posId = btn.dataset.posId;
            const posTitle = btn.dataset.posTitle;

            document.getElementById('assign_modal_pos_id').value = posId;
            document.getElementById('assign_modal_title').textContent = `Assign Pengurus ke "${posTitle}"`;

            switchPersonMode('existing');
            document.getElementById('assign_is_vacant').checked = false;

            const modal = new bootstrap.Modal(document.getElementById('modalAssignPerson'));
            modal.show();
        });
    });
});
</script>
