<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Jadwal Publik</div>
        <h2 class="h3 fw-bold text-dark mb-1">Kalender Agenda</h2>
        <p class="text-secondary small mb-0">Tampilan kalender interaktif untuk seluruh event yang telah dipublikasikan.</p>
    </div>
    <a class="btn btn-dark rounded-pill px-4 d-inline-flex align-items-center gap-2" href="<?= url('/admin/events/create') ?>">
        <i class="bi bi-plus-lg"></i>
        <span>Tambah Kegiatan Baru</span>
    </a>
</div>

<div class="calendar-shell admin-calendar" data-calendar data-year="<?= (int)$year ?>" data-month="<?= (int)$month ?>" data-events='<?= e(json_encode(array_map(function($x) {
    $x['poster_url'] = $x['poster'] ? (DEBUG_DUMMY_IMAGES ? dummy_image_url('calendar-poster', 1200, 675) : media_url($x['poster'])) : '';
    return $x;
}, $events), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) ?>'>
    <div class="calendar-head">
        <button type="button" class="calendar-nav-btn" data-cal-prev aria-label="Bulan sebelumnya">
            <i class="bi bi-chevron-left"></i>
        </button>
        <div class="text-center">
            <div class="calendar-title-text" data-cal-title>Memuat Kalender...</div>
            <button type="button" class="calendar-today-btn" data-cal-today>Ke bulan ini</button>
        </div>
        <button type="button" class="calendar-nav-btn" data-cal-next aria-label="Bulan berikutnya">
            <i class="bi bi-chevron-right"></i>
        </button>
    </div>
    
    <div class="calendar-weekdays">
        <?php foreach (['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'] as $d): ?>
            <div><?= e($d) ?></div>
        <?php endforeach; ?>
    </div>
    
    <div class="calendar-grid" data-cal-grid></div>
    <div class="calendar-empty d-none" data-cal-empty>
        <i class="bi bi-calendar-x"></i>
        <span>Tidak ada kegiatan pada bulan ini.</span>
    </div>
</div>

<div class="modal fade" id="calendarEventModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-5 border-0 shadow-lg overflow-hidden">
            <div class="modal-body p-0" data-cal-modal-body></div>
        </div>
    </div>
</div>

<script src="<?= asset('js/calendar.js') ?>"></script>
