<?php 
$o = $organization ?? []; 
$isNew = empty($o['id']); 
$val = fn($k, $d = '') => $o[$k] ?? $d; 
?>

<style>
.org-tab-btn {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.6rem 1.1rem;
    border-radius: 10px;
    font-size: 0.82rem;
    font-weight: 600;
    border: none;
    background: transparent;
    color: #636366;
    cursor: pointer;
    transition: all 0.18s ease;
    white-space: nowrap;
}
.org-tab-btn.active {
    background: #fff;
    color: #1c1c1e;
    box-shadow: 0 1px 6px rgba(0,0,0,0.08);
}
.org-tab-btn:hover:not(.active) { background: rgba(0,0,0,0.04); color: #1c1c1e; }
.org-section-card {
    background: #fff;
    border-radius: 16px;
    border: 1px solid rgba(60,60,67,0.08);
    box-shadow: 0 1px 4px rgba(0,0,0,0.03);
    overflow: hidden;
}
.org-section-head {
    padding: 1rem 1.4rem;
    border-bottom: 1px solid rgba(60,60,67,0.07);
    display: flex;
    align-items: center;
    gap: 0.75rem;
}
.org-section-icon {
    width: 34px;
    height: 34px;
    border-radius: 9px;
    display: grid;
    place-items: center;
    font-size: 1rem;
    flex-shrink: 0;
}
.org-section-body { padding: 1.4rem; }
.color-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0.6rem 0.9rem;
    border-radius: 10px;
    border: 1px solid rgba(60,60,67,0.08);
    background: #fafafa;
    margin-bottom: 0.5rem;
}
.color-row:last-child { margin-bottom: 0; }
.social-card {
    background: #fafafa;
    border: 1px solid rgba(60,60,67,0.1);
    border-radius: 12px;
    padding: 0.85rem 1rem;
    transition: all 0.2s;
}
.social-card.is-active {
    border-color: rgba(52,199,89,0.35);
    background: #f0fdf4;
}
.upload-zone {
    border: 1.5px dashed rgba(60,60,67,0.2);
    border-radius: 10px;
    padding: 0.8rem 1rem;
    background: #fafafa;
    transition: border-color 0.2s;
}
.upload-zone:hover { border-color: #007aff; }
.preset-chip {
    padding: 0.28rem 0.8rem;
    border-radius: 999px;
    font-size: 0.75rem;
    font-weight: 600;
    border: 1px solid rgba(60,60,67,0.14);
    background: #fff;
    cursor: pointer;
    transition: all 0.15s;
    color: #1c1c1e;
}
.preset-chip:hover { background: #1c1c1e; color: #fff; border-color: #1c1c1e; }
.page-switcher-link {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    padding: 0.42rem 0.9rem;
    border-radius: 8px;
    font-size: 0.8rem;
    font-weight: 600;
    text-decoration: none;
    color: #636366;
    border: 1px solid rgba(60,60,67,0.14);
    background: #fff;
    transition: all 0.18s;
}
.page-switcher-link.current { background: #1c1c1e; color: #fff; border-color: #1c1c1e; }
.page-switcher-link:hover:not(.current) { background: #f2f2f7; color: #1c1c1e; }
</style>

<!-- Page Header -->
<div class="d-flex flex-column flex-sm-row align-items-start align-items-sm-center justify-content-between gap-3 mb-4">
    <div>
        <p class="text-secondary small fw-semibold mb-1" style="letter-spacing:0.05em;text-transform:uppercase;font-size:0.7rem;">Pengaturan Website</p>
        <h2 class="h4 fw-bold mb-0" style="letter-spacing:-0.02em;"><?= $isNew ? 'Tambah Organisasi Baru' : 'Profil & Identitas Organisasi' ?></h2>
    </div>
    <div class="d-flex gap-2 flex-shrink-0">
        <a href="<?= url('/admin/organization') ?>" class="page-switcher-link current">
            <i class="bi bi-building"></i> Profil & Identitas
        </a>
        <a href="<?= url('/admin/settings') ?>" class="page-switcher-link">
            <i class="bi bi-sliders"></i> Layout & Poster
        </a>
    </div>
</div>

<form method="post" action="<?= url('/admin/organization/save') ?>" enctype="multipart/form-data" id="orgForm">
    <input type="hidden" name="id" value="<?= (int)($o['id'] ?? 0) ?>">
    <?= Csrf::field() ?>

    <!-- Tab Nav -->
    <div class="nav nav-pills d-flex flex-wrap gap-1 mb-4 p-1" style="background:#f2f2f7;border-radius:13px;display:inline-flex!important;width:fit-content;" role="tablist">
        <button class="nav-link org-tab-btn active" id="tab-identitas-btn" data-bs-toggle="pill" data-bs-target="#tab-identitas" type="button" role="tab" aria-controls="tab-identitas" aria-selected="true">
            <i class="bi bi-buildings"></i> Identitas &amp; Logo
        </button>
        <button class="nav-link org-tab-btn" id="tab-profil-btn" data-bs-toggle="pill" data-bs-target="#tab-profil" type="button" role="tab" aria-controls="tab-profil" aria-selected="false">
            <i class="bi bi-file-text"></i> Profil &amp; Visi Misi
        </button>
        <button class="nav-link org-tab-btn" id="tab-tema-btn" data-bs-toggle="pill" data-bs-target="#tab-tema" type="button" role="tab" aria-controls="tab-tema" aria-selected="false">
            <i class="bi bi-palette"></i> Tema &amp; Warna
        </button>
        <button class="nav-link org-tab-btn" id="tab-kontak-btn" data-bs-toggle="pill" data-bs-target="#tab-kontak" type="button" role="tab" aria-controls="tab-kontak" aria-selected="false">
            <i class="bi bi-at"></i> Kontak &amp; Medsos
        </button>
    </div>

    <div class="tab-content mb-5" id="orgSubTabsContent">

        <!-- TAB 1: IDENTITAS & LOGO -->
        <div class="tab-pane fade show active" id="tab-identitas" role="tabpanel">
            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="org-section-card">
                        <div class="org-section-head">
                            <div class="org-section-icon bg-primary-subtle text-primary"><i class="bi bi-globe2"></i></div>
                            <div>
                                <div class="fw-semibold" style="font-size:0.88rem;">Nama &amp; Identitas Website</div>
                                <div class="text-secondary" style="font-size:0.76rem;">Informasi dasar organisasi dan URL website</div>
                            </div>
                        </div>
                        <div class="org-section-body">
                            <div class="row g-3">
                                <div class="col-md-8">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;">Nama Lengkap <span class="text-danger">*</span></label>
                                    <input class="form-control" name="name" value="<?= e($val('name')) ?>" placeholder="Nama Organisasi Mahasiswa" required>
                                </div>
                                <div class="col-md-4">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;">Singkatan</label>
                                    <input class="form-control" name="short_name" value="<?= e($val('short_name')) ?>" placeholder="ORMAWA">
                                </div>
                                <div class="col-md-7">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;">Nama di Judul Browser</label>
                                    <input class="form-control" name="website_name" value="<?= e($val('website_name')) ?>" placeholder="ORMAWA · Portal Resmi">
                                    <div class="form-text" style="font-size:0.73rem;">Tampil di tab browser dan bookmark.</div>
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;">Slug URL <span class="text-danger">*</span></label>
                                    <div class="input-group">
                                        <span class="input-group-text text-secondary" style="font-size:0.78rem;background:#fafafa;">/</span>
                                        <input class="form-control font-monospace" name="slug" value="<?= e($val('slug')) ?>" placeholder="ormawa" required>
                                    </div>
                                    <div class="form-text font-monospace" style="font-size:0.71rem;"><?= url('') ?>/<?= e($val('slug', 'slug-org')) ?></div>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;">Tagline / Slogan <span class="text-secondary fw-normal">(opsional)</span></label>
                                    <input class="form-control" name="tagline" value="<?= e($val('tagline')) ?>" placeholder="Wadah aspirasi dan inovasi mahasiswa...">
                                    <div class="form-text" style="font-size:0.73rem;">Tampil di bawah nama organisasi pada hero beranda jika diisi.</div>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;">Deskripsi Singkat</label>
                                    <textarea class="form-control" name="description" rows="2" placeholder="1–2 kalimat ringkasan untuk footer dan meta deskripsi."><?= e($val('description')) ?></textarea>
                                </div>
                                <div class="col-md-5">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;">Status Publikasi</label>
                                    <select class="form-select" name="status">
                                        <option value="active" <?= $val('status', 'active') === 'active' ? 'selected' : '' ?>>Aktif — Dipublikasikan</option>
                                        <option value="inactive" <?= $val('status') === 'inactive' ? 'selected' : '' ?>>Nonaktif — Draft</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="org-section-card h-100">
                        <div class="org-section-head">
                            <div class="org-section-icon bg-warning-subtle text-warning"><i class="bi bi-images"></i></div>
                            <div>
                                <div class="fw-semibold" style="font-size:0.88rem;">Aset Visual</div>
                                <div class="text-secondary" style="font-size:0.76rem;">Logo, favicon, dan banner beranda</div>
                            </div>
                        </div>
                        <div class="org-section-body d-flex flex-column gap-4">
                            <!-- Logo -->
                            <div>
                                <label class="form-label fw-semibold d-flex align-items-center gap-2 mb-2" style="font-size:0.82rem;">
                                    <i class="bi bi-image text-primary"></i> Logo Organisasi
                                </label>
                                <?php if (!empty($o['logo'])): ?>
                                <div class="d-flex align-items-center gap-3 p-2 rounded-3 bg-light border mb-2">
                                    <img src="<?= e(media_url($o['logo'])) ?>" alt="Logo" style="width:42px;height:42px;object-fit:contain;border-radius:8px;background:#fff;padding:3px;">
                                    <div>
                                        <div class="small fw-semibold">Logo aktif</div>
                                        <code class="small text-muted" style="font-size:0.7rem;"><?= e(basename($o['logo'])) ?></code>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="upload-zone">
                                    <input class="form-control form-control-sm border-0 bg-transparent p-0" type="file" name="logo" id="logoFileInput" accept="image/jpeg,image/png,image/webp">
                                </div>
                                <div id="logoPreviewContainer"></div>
                            </div>
                            <!-- Favicon -->
                            <div>
                                <label class="form-label fw-semibold d-flex align-items-center gap-2 mb-2" style="font-size:0.82rem;">
                                    <i class="bi bi-asterisk text-success"></i> Favicon Browser
                                </label>
                                <?php if (!empty($o['favicon'])): ?>
                                <div class="d-flex align-items-center gap-2 p-2 rounded-3 bg-light border mb-2">
                                    <img src="<?= e(media_url($o['favicon'])) ?>" alt="Favicon" style="width:20px;height:20px;object-fit:contain;">
                                    <span class="small fw-semibold text-secondary">Favicon aktif</span>
                                </div>
                                <?php endif; ?>
                                <div class="upload-zone">
                                    <input class="form-control form-control-sm border-0 bg-transparent p-0" type="file" name="favicon" id="faviconFileInput" accept="image/jpeg,image/png,image/webp,image/x-icon,image/svg+xml">
                                </div>
                                <div id="faviconPreviewContainer"></div>
                            </div>
                            <!-- Hero -->
                            <div>
                                <label class="form-label fw-semibold d-flex align-items-center gap-2 mb-2" style="font-size:0.82rem;">
                                    <i class="bi bi-panorama text-danger"></i> Hero / Banner Beranda
                                </label>
                                <?php if (!empty($o['hero_image'])): ?>
                                <div class="rounded-3 border overflow-hidden mb-2" style="height:80px;">
                                    <img src="<?= e(media_url($o['hero_image'])) ?>" alt="Banner" style="width:100%;height:80px;object-fit:cover;">
                                </div>
                                <?php endif; ?>
                                <div class="upload-zone">
                                    <input class="form-control form-control-sm border-0 bg-transparent p-0" type="file" name="hero_image" id="heroFileInput" accept="image/jpeg,image/png,image/webp">
                                </div>
                                <div id="heroPreviewContainer"></div>
                                <div class="form-text" style="font-size:0.72rem;">Rekomendasi: 1600×900px, rasio 16:9.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB 2: PROFIL & VISI MISI -->
        <div class="tab-pane fade" id="tab-profil" role="tabpanel">
            <div class="org-section-card">
                <div class="org-section-head">
                    <div class="org-section-icon bg-success-subtle text-success"><i class="bi bi-journal-text"></i></div>
                    <div>
                        <div class="fw-semibold" style="font-size:0.88rem;">Profil, Visi, Misi &amp; Nilai</div>
                        <div class="text-secondary" style="font-size:0.76rem;">Narasi yang tampil di halaman Tentang dan beranda · Format teks dengan toolbar di bawah ini</div>
                    </div>
                </div>
                <div class="org-section-body">
                    <!-- Quill CDN -->
                    <link href="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.snow.css" rel="stylesheet">
                    <style>
                    .ql-editor { min-height: 120px; font-size: 0.88rem; font-family: inherit; }
                    .ql-toolbar.ql-snow { border-radius: 10px 10px 0 0; border-color: #dee2e6; background: #f9f9fb; }
                    .ql-container.ql-snow { border-radius: 0 0 10px 10px; border-color: #dee2e6; }
                    .ql-toolbar.ql-snow + .ql-container.ql-snow { border-top: 0; }
                    .quill-wrap { margin-bottom: 0; }
                    .quill-wrap label { display: block; font-size:0.82rem; font-weight:600; margin-bottom:0.45rem; color:#1c1c1e; }
                    .quill-hint { font-size:0.72rem; color:#8e8e93; margin-top:0.35rem; }
                    </style>
                    <div class="row g-4">
                        <div class="col-12">
                            <div class="quill-wrap">
                                <label>Tentang Organisasi</label>
                                <!-- Hidden input yang dikirim ke server -->
                                <input type="hidden" name="about" id="about_input" value="<?= e($val('about')) ?>">
                                <div id="quill_about" class="quill-editor-container"><?= $val('about') ?></div>
                                <div class="quill-hint"><i class="bi bi-shield-check text-success me-1"></i>Format teks bebas — kode berbahaya otomatis diblokir saat disimpan.</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="quill-wrap">
                                <label>Visi Organisasi</label>
                                <input type="hidden" name="vision" id="vision_input" value="<?= e($val('vision')) ?>">
                                <div id="quill_vision" class="quill-editor-container"><?= $val('vision') ?></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="quill-wrap">
                                <label>Misi Organisasi</label>
                                <input type="hidden" name="mission" id="mission_input" value="<?= e($val('mission')) ?>">
                                <div id="quill_mission" class="quill-editor-container"><?= $val('mission') ?></div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="quill-wrap">
                                <label>Nilai Utama &amp; Prinsip Dasar</label>
                                <input type="hidden" name="values_text" id="values_text_input" value="<?= e($val('values_text')) ?>">
                                <div id="quill_values" class="quill-editor-container"><?= $val('values_text') ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- TAB 3: TEMA & WARNA -->
        <div class="tab-pane fade" id="tab-tema" role="tabpanel">
            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="org-section-card h-100">
                        <div class="org-section-head">
                            <div class="org-section-icon" style="background:#fff0f5;color:#e91e8c;"><i class="bi bi-palette2"></i></div>
                            <div>
                                <div class="fw-semibold" style="font-size:0.88rem;">Palet Warna Website</div>
                                <div class="text-secondary" style="font-size:0.76rem;">Diterapkan otomatis di seluruh halaman publik</div>
                            </div>
                        </div>
                        <div class="org-section-body">
                            <?php 
                            $colors = [
                                'primary_color'    => ['Warna Utama (Primary)', '#007aff'],
                                'secondary_color'  => ['Warna Sekunder', '#5856d6'],
                                'accent_color'     => ['Warna Aksen / Highlight', '#34c759'],
                                'background_color' => ['Warna Latar Belakang', '#f2f2f7'],
                                'text_color'       => ['Warna Teks Utama', '#1c1c1e'],
                            ];
                            foreach ($colors as $k => [$label, $defaultColor]): 
                                $curVal = $val($k, $defaultColor);
                            ?>
                            <div class="color-row">
                                <label class="mb-0 fw-semibold" style="font-size:0.82rem;"><?= e($label) ?></label>
                                <div class="d-flex align-items-center gap-2">
                                    <code class="text-secondary font-monospace color-hex-label" style="font-size:0.75rem;"><?= e($curVal) ?></code>
                                    <input class="form-control-color color-input rounded-3 border" style="width:36px;height:28px;padding:2px;cursor:pointer;" type="color" name="<?= e($k) ?>" value="<?= e($curVal) ?>">
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <div class="mt-4">
                                <p class="text-secondary fw-semibold mb-2" style="font-size:0.74rem;text-transform:uppercase;letter-spacing:0.06em;">Preset Tema Cepat</p>
                                <div class="d-flex flex-wrap gap-2">
                                    <?php 
                                    $presets = [
                                        'Apple Blue'   => ['#007aff','#5856d6','#34c759','#f2f2f7','#1c1c1e'],
                                        'Indigo Pro'   => ['#4f46e5','#7c3aed','#10b981','#f8fafc','#0f172a'],
                                        'Forest'       => ['#059669','#0d9488','#84cc16','#f0fdf4','#14532d'],
                                        'Amber'        => ['#ea580c','#d97706','#f59e0b','#fffbeb','#1c1917'],
                                        'Minimal Dark' => ['#18181b','#27272a','#0ea5e9','#fafafa','#09090b'],
                                    ];
                                    foreach ($presets as $pName => $pColors): ?>
                                        <button type="button" class="preset-chip" data-theme-preset='<?= e(json_encode($pColors)) ?>'><?= e($pName) ?></button>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="org-section-card">
                        <div class="org-section-head">
                            <div class="org-section-icon bg-warning-subtle text-warning"><i class="bi bi-fonts"></i></div>
                            <div>
                                <div class="fw-semibold" style="font-size:0.88rem;">Tipografi</div>
                                <div class="text-secondary" style="font-size:0.76rem;">Font yang digunakan di halaman publik</div>
                            </div>
                        </div>
                        <div class="org-section-body">
                            <label class="form-label fw-semibold mb-2" style="font-size:0.82rem;">Font Family</label>
                            <select class="form-select mb-4" name="font_family">
                                <?php foreach (['Plus Jakarta Sans', 'Inter', 'Poppins', 'DM Sans'] as $font): ?>
                                    <option value="<?= e($font) ?>" <?= $val('font_family', 'Plus Jakarta Sans') === $font ? 'selected' : '' ?>><?= e($font) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <div class="p-4 rounded-3 text-center" style="background:#f9f9fb;border:1px solid rgba(60,60,67,0.08);">
                                <div class="text-secondary mb-2" style="font-size:0.72rem;text-transform:uppercase;letter-spacing:0.06em;">Pratinjau Font</div>
                                <div class="fw-bold mb-1" style="font-size:1.1rem;letter-spacing:-0.02em;">Selamat Datang di ORMAWA</div>
                                <div class="text-secondary" style="font-size:0.83rem;line-height:1.55;">Berkarya bersama dengan integritas dan semangat kolaborasi.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- TAB 4: KONTAK & MEDSOS -->
        <div class="tab-pane fade" id="tab-kontak" role="tabpanel">
            <div class="row g-4">
                <div class="col-lg-5">
                    <div class="org-section-card h-100">
                        <div class="org-section-head">
                            <div class="org-section-icon bg-danger-subtle text-danger"><i class="bi bi-telephone-outbound"></i></div>
                            <div>
                                <div class="fw-semibold" style="font-size:0.88rem;">Informasi Kontak</div>
                                <div class="text-secondary" style="font-size:0.76rem;">Tampil di halaman Kontak dan footer website</div>
                            </div>
                        </div>
                        <div class="org-section-body">
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;"><i class="bi bi-envelope text-primary me-1"></i> Email Resmi</label>
                                    <input class="form-control" type="email" name="email" value="<?= e($val('email')) ?>" placeholder="admin@organisasi.ac.id">
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;"><i class="bi bi-telephone text-success me-1"></i> Nomor Telepon</label>
                                    <input class="form-control" type="text" name="phone" value="<?= e($val('phone')) ?>" placeholder="08123456789">
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;"><i class="bi bi-whatsapp text-success me-1"></i> WhatsApp Hotline</label>
                                    <input class="form-control" type="text" name="whatsapp" value="<?= e($val('whatsapp')) ?>" placeholder="6281234567890">
                                    <div class="form-text" style="font-size:0.73rem;">Format internasional tanpa +, contoh: 6281234567890</div>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;"><i class="bi bi-geo-alt text-danger me-1"></i> Alamat Sekretariat</label>
                                    <textarea class="form-control" name="address" rows="2" placeholder="Gedung PKM Lantai 2, Kampus..."><?= e($val('address')) ?></textarea>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-semibold" style="font-size:0.82rem;"><i class="bi bi-map text-primary me-1"></i> Google Maps Embed URL</label>
                                    <input class="form-control" type="text" name="map_embed_url" value="<?= e($val('map_embed_url')) ?>" placeholder="https://www.google.com/maps/embed?pb=...">
                                    <div class="form-text" style="font-size:0.73rem;">Salin dari Google Maps: Bagikan → Sematkan peta.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-7">
                    <div class="org-section-card h-100">
                        <div class="org-section-head">
                            <div class="org-section-icon bg-info-subtle text-info"><i class="bi bi-share"></i></div>
                            <div>
                                <div class="fw-semibold" style="font-size:0.88rem;">Media Sosial</div>
                                <div class="text-secondary" style="font-size:0.76rem;">Hanya platform yang diisi URL-nya yang akan tampil di web</div>
                            </div>
                        </div>
                        <div class="org-section-body">
                            <div class="p-3 rounded-3 mb-4 d-flex gap-2 align-items-start" style="background:#eff6ff;border:1px solid #bfdbfe;">
                                <i class="bi bi-lightbulb-fill text-primary flex-shrink-0" style="margin-top:1px;"></i>
                                <p class="mb-0 text-dark" style="font-size:0.79rem;">
                                    <strong>Tip:</strong> Kosongkan kolom platform yang tidak dipakai — otomatis disembunyikan dari footer dan kontak. Tekan <i class="bi bi-x"></i> untuk mengosongkan cepat.
                                </p>
                            </div>
                            <div class="row g-3">
                                <?php 
                                $socialPlatforms = [
                                    'instagram' => ['Instagram', 'bi-instagram', '#e1306c', 'https://instagram.com/username'],
                                    'facebook'  => ['Facebook', 'bi-facebook', '#1877f2', 'https://facebook.com/page'],
                                    'youtube'   => ['YouTube', 'bi-youtube', '#ff0000', 'https://youtube.com/@channel'],
                                    'tiktok'    => ['TikTok', 'bi-tiktok', '#010101', 'https://tiktok.com/@username'],
                                    'linkedin'  => ['LinkedIn', 'bi-linkedin', '#0a66c2', 'https://linkedin.com/company/...'],
                                    'website'   => ['Website Lain', 'bi-globe2', '#6c757d', 'https://...'],
                                ];
                                foreach ($socialPlatforms as $sKey => [$sLabel, $sIcon, $sColor, $sPlaceholder]):
                                    $sVal = $val($sKey);
                                    $hasVal = !empty($sVal);
                                ?>
                                <div class="col-sm-6">
                                    <div class="social-card <?= $hasVal ? 'is-active' : '' ?>" id="card-<?= e($sKey) ?>">
                                        <div class="d-flex align-items-center justify-content-between mb-2">
                                            <label class="mb-0 fw-semibold d-flex align-items-center gap-2" style="font-size:0.8rem;cursor:pointer;">
                                                <i class="bi <?= e($sIcon) ?>" style="color:<?= e($sColor) ?>;font-size:1rem;"></i>
                                                <span class="text-dark"><?= e($sLabel) ?></span>
                                            </label>
                                            <span class="badge rounded-pill px-2 social-status-badge <?= $hasVal ? 'bg-success text-white' : 'bg-light text-secondary border' ?>" id="badge-<?= e($sKey) ?>" style="font-size:0.68rem;">
                                                <?= $hasVal ? '● Tampil' : '○ Sembunyi' ?>
                                            </span>
                                        </div>
                                        <div class="input-group input-group-sm">
                                            <input class="form-control social-url-input" type="url" name="<?= e($sKey) ?>" value="<?= e($sVal) ?>" placeholder="<?= e($sPlaceholder) ?>" data-social-key="<?= e($sKey) ?>">
                                            <button class="btn btn-outline-secondary btn-clear-social" type="button" data-clear-target="<?= e($sKey) ?>" title="Kosongkan">
                                                <i class="bi bi-x"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Sticky Save Bar -->
    <div class="sticky-actions d-flex align-items-center justify-content-between">
        <div class="small text-secondary d-none d-md-flex align-items-center gap-2">
            <i class="bi bi-info-circle"></i>
            <span>Semua tab tersimpan sekaligus saat klik Simpan.</span>
        </div>
        <div class="d-flex gap-2 ms-auto">
            <a href="<?= url('/admin/dashboard') ?>" class="btn btn-light rounded-pill px-4">Batal</a>
            <button type="submit" class="btn btn-dark rounded-pill px-4 fw-bold d-inline-flex align-items-center gap-2">
                <i class="bi bi-check2-circle"></i>
                <span>Simpan Pengaturan</span>
            </button>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Tab switching (Explicit JS + Bootstrap 5 compatibility)
    document.querySelectorAll('.org-tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const targetSelector = btn.getAttribute('data-bs-target');
            if (!targetSelector) return;

            // 1. Update tab button active states
            document.querySelectorAll('.org-tab-btn').forEach(b => {
                b.classList.remove('active');
                b.setAttribute('aria-selected', 'false');
            });
            btn.classList.add('active');
            btn.setAttribute('aria-selected', 'true');

            // 2. Explicitly toggle tab-pane visibility
            const contentParent = document.getElementById('orgSubTabsContent');
            if (contentParent) {
                contentParent.querySelectorAll('.tab-pane').forEach(pane => {
                    pane.classList.remove('show', 'active');
                });
                const targetPane = contentParent.querySelector(targetSelector);
                if (targetPane) {
                    targetPane.classList.add('show', 'active');
                }
            }

            // 3. Fallback to Bootstrap Tab Instance if available
            if (typeof bootstrap !== 'undefined' && bootstrap.Tab) {
                try {
                    const tabInstance = bootstrap.Tab.getOrCreateInstance(btn);
                    tabInstance.show();
                } catch(err) {}
            }
        });
    });

    // Theme preset apply
    document.querySelectorAll('[data-theme-preset]').forEach(btn => {
        btn.addEventListener('click', () => {
            try {
                const colors = JSON.parse(btn.dataset.themePreset);
                const keys = ['primary_color', 'secondary_color', 'accent_color', 'background_color', 'text_color'];
                keys.forEach((k, idx) => {
                    const input = document.querySelector(`input[name="${k}"]`);
                    if (input && colors[idx]) {
                        input.value = colors[idx];
                        const label = input.closest('.color-row')?.querySelector('.color-hex-label');
                        if (label) label.textContent = colors[idx];
                    }
                });
            } catch(e) {}
        });
    });

    // Live hex label update on color picker change
    document.querySelectorAll('.color-input').forEach(input => {
        input.addEventListener('input', () => {
            const label = input.closest('.color-row')?.querySelector('.color-hex-label');
            if (label) label.textContent = input.value;
        });
    });

    // File upload preview
    function setupPreview(inputId, containerId, mode = 'logo') {
        const input = document.getElementById(inputId);
        const container = document.getElementById(containerId);
        if (!input || !container) return;
        input.addEventListener('change', function () {
            const file = this.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = e => {
                const mb = (file.size / 1048576).toFixed(2);
                if (mode === 'hero') {
                    container.innerHTML = `
                        <div class="mt-2 rounded-3 overflow-hidden border" style="height:80px;">
                            <img src="${e.target.result}" style="width:100%;height:80px;object-fit:cover;" alt="">
                        </div>
                        <div class="small text-primary fw-semibold mt-1"><i class="bi bi-check-circle me-1"></i>File dipilih: ${file.name} (${mb} MB)</div>
                    `;
                } else {
                    container.innerHTML = `
                        <div class="d-flex align-items-center gap-2 mt-2 p-2 rounded-3 bg-primary bg-opacity-10 border border-primary">
                            <img src="${e.target.result}" style="width:36px;height:36px;object-fit:contain;border-radius:6px;background:#fff;padding:2px;">
                            <div class="small"><span class="fw-semibold text-primary"><i class="bi bi-check-circle me-1"></i>File dipilih</span><br><code class="text-dark">${file.name} (${mb} MB)</code></div>
                        </div>
                    `;
                }
            };
            reader.readAsDataURL(file);
        });
    }
    setupPreview('logoFileInput', 'logoPreviewContainer', 'logo');
    setupPreview('faviconFileInput', 'faviconPreviewContainer', 'logo');
    setupPreview('heroFileInput', 'heroPreviewContainer', 'hero');

    // Social media live badge + card style toggle + clear button
    function updateSocial(key) {
        const input = document.querySelector(`input[name="${key}"]`);
        const badge = document.getElementById(`badge-${key}`);
        const card  = document.getElementById(`card-${key}`);
        if (!input || !badge) return;
        const hasVal = input.value.trim().length > 0;
        badge.textContent = hasVal ? '● Tampil' : '○ Sembunyi';
        badge.className = `badge rounded-pill px-2 social-status-badge ${hasVal ? 'bg-success text-white' : 'bg-light text-secondary border'}`;
        if (card) card.classList.toggle('is-active', hasVal);
    }

    document.querySelectorAll('.social-url-input').forEach(input => {
        const key = input.dataset.socialKey;
        updateSocial(key);
        input.addEventListener('input', () => updateSocial(key));
    });

    document.querySelectorAll('.btn-clear-social').forEach(btn => {
        btn.addEventListener('click', () => {
            const key = btn.dataset.clearTarget;
            const input = document.querySelector(`input[name="${key}"]`);
            if (input) { input.value = ''; input.dispatchEvent(new Event('input')); }
        });
    });
});
</script>

<!-- Quill.js WYSIWYG Editor -->
<script src="https://cdn.jsdelivr.net/npm/quill@2.0.3/dist/quill.js"></script>
<script>
(function() {
    // Toolbar yang diizinkan — hanya formatting aman, tanpa raw HTML
    const safeToolbar = [
        [{ 'header': [2, 3, 4, false] }],
        ['bold', 'italic', 'underline', 'strike'],
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        ['blockquote'],
        ['link'],
        ['clean']
    ];

    // Inisialisasi editor untuk setiap field
    const editors = [
        { editorId: 'quill_about',   inputId: 'about_input'      },
        { editorId: 'quill_vision',  inputId: 'vision_input'     },
        { editorId: 'quill_mission', inputId: 'mission_input'    },
        { editorId: 'quill_values',  inputId: 'values_text_input' },
    ];

    const quillInstances = [];

    editors.forEach(({ editorId, inputId }) => {
        const container = document.getElementById(editorId);
        const hiddenInput = document.getElementById(inputId);
        if (!container || !hiddenInput) return;

        // Ambil konten HTML awal dari container dan bersihkan
        const initialHtml = container.innerHTML.trim();

        // Buat Quill editor
        const quill = new Quill(container, {
            theme: 'snow',
            modules: { toolbar: safeToolbar },
            placeholder: 'Ketik di sini...'
        });

        // Set konten awal jika ada
        if (initialHtml && initialHtml !== '') {
            const delta = quill.clipboard.convert({ html: initialHtml });
            quill.setContents(delta, 'silent');
        }

        // Sync ke hidden input setiap ada perubahan
        quill.on('text-change', function() {
            hiddenInput.value = quill.getSemanticHTML();
        });

        // Set nilai awal ke hidden input juga
        hiddenInput.value = quill.getSemanticHTML();

        quillInstances.push({ quill, hiddenInput });
    });

    // Pastikan semua hidden input ter-update SEBELUM form submit
    const form = document.getElementById('orgForm');
    if (form) {
        form.addEventListener('submit', function() {
            quillInstances.forEach(({ quill, hiddenInput }) => {
                hiddenInput.value = quill.getSemanticHTML();
            });
        });
    }
})();
</script>
