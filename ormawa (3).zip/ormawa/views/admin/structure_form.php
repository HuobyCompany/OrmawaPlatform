<?php 
$p = $position ?? []; 
$get = fn($k, $d = '') => $p[$k] ?? $d; 
?>

<form method="post" action="<?= url('/admin/structure/save') ?>" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= (int)($p['id'] ?? 0) ?>">
    <?= Csrf::field() ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <div class="small text-secondary fw-semibold">Bagan Organisasi</div>
            <h2 class="h3 fw-bold text-dark mb-1"><?= $p ? 'Edit Jabatan Pengurus' : 'Tambah Jabatan Pengurus' ?></h2>
            <p class="text-secondary small mb-0">Atur hierarki posisi, pejabat yang mengemban, dan foto pengurus.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?= url('/admin/structure') ?>" class="btn btn-light rounded-pill px-3.5">Batal</a>
            <button type="submit" class="btn btn-dark rounded-pill px-4 fw-bold d-inline-flex align-items-center gap-1.5">
                <i class="bi bi-check2"></i>
                <span>Simpan Jabatan</span>
            </button>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="admin-card p-4">
                <div class="row g-3">
                    <div class="col-md-7">
                        <label class="form-label">Nama Jabatan / Posisi <span class="text-danger">*</span></label>
                        <input class="form-control" name="position_name" value="<?= e($get('position_name')) ?>" placeholder="Ketua Umum / Sekretaris / Pembina..." required>
                    </div>

                    <div class="col-md-5">
                        <label class="form-label">Nama Pejabat / Pengurus</label>
                        <input class="form-control" name="person_name" value="<?= e($get('person_name')) ?>" placeholder="Nama lengkap pengurus...">
                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Jabatan Atasan (Parent Hierarchy)</label>
                        <select class="form-select" name="parent_id">
                            <option value="0">Tingkat Teratas (Root)</option>
                            <?php foreach ($positions as $x): 
                                if ((int)$x['id'] === (int)($p['id'] ?? 0)) continue; 
                            ?>
                                <option value="<?= (int)$x['id'] ?>" <?= (int)$get('parent_id') === (int)$x['id'] ? 'selected' : '' ?>>
                                    <?= e($x['position_name']) ?> — <?= e($x['person_name'] ?: 'Belum diisi') ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Urutan Tampil</label>
                        <input class="form-control text-center" type="number" min="0" name="sort_order" value="<?= (int)$get('sort_order', 0) ?>">
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Periode Masa Bakti</label>
                        <input class="form-control" name="period" value="<?= e($get('period')) ?>" placeholder="2026–2027">
                    </div>

                    <div class="col-12">
                        <label class="form-label">Deskripsi / Peran Jabatan</label>
                        <textarea class="form-control" name="description" rows="4" placeholder="Tuliskan wewenang dan uraian tugas singkat posisi ini..."><?= e($get('description')) ?></textarea>
                        <div class="form-text small">Teks normal tanpa formatting toolbar yang mengganggu.</div>
                    </div>

                    <div class="col-12">
                        <div class="p-3 rounded-3 bg-light border border-light-subtle d-flex align-items-center gap-2">
                            <input class="form-check-input mt-0" id="active" type="checkbox" name="status" value="1" <?= $get('status', 'active') === 'active' ? 'checked' : '' ?>>
                            <label class="form-check-label fw-semibold text-dark small cursor-pointer" for="active">
                                Tampilkan jabatan ini pada halaman struktur publik organisasi
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="admin-card p-4">
                <label class="form-label">Foto Pengurus</label>
                <input class="form-control" type="file" name="photo" accept="image/jpeg,image/png,image/webp">
                <?php if ($p['photo'] ?? null): ?>
                    <div class="mt-3 text-center p-3 rounded-3 bg-light border">
                        <img class="rounded-circle shadow-sm" src="<?= DEBUG_DUMMY_IMAGES ? dummy_image_url('admin-structure-' . ($p['id'] ?? 'x'), 400, 400) : e(media_url($p['photo'])) ?>" alt="Foto Pengurus" style="width: 110px; height: 110px; object-fit: cover;">
                        <div class="small text-secondary mt-2">Foto saat ini</div>
                    </div>
                <?php endif; ?>
                <div class="form-text small mt-2">Format JPG, PNG, atau WebP (maks. 8 MB). Gunakan rasio 1:1 untuk hasil paling rapi.</div>
            </div>
        </div>
    </div>
</form>
