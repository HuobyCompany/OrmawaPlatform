<?php
/** @var array $members @var array $batches @var string|null $currentBatch @var string $searchQuery @var array $organization */
?>

<!-- Header -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold mb-1" style="letter-spacing: 0.05em; text-transform: uppercase; font-size: 0.7rem;">Keanggotaan &amp; Database</div>
        <h2 class="h4 fw-bold text-dark mb-1" style="letter-spacing: -0.02em;">Data Anggota Resmi</h2>
        <p class="text-secondary small mb-0">Database resmi anggota organisasi yang telah disetujui dari pendaftaran online.</p>
    </div>
    <div class="d-flex gap-2">
        <a class="btn btn-dark rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm" href="<?= url('admin/members/create') ?>">
            <i class="bi bi-person-plus-fill me-1"></i><span>Tambah Anggota</span>
        </a>
        <a class="btn btn-outline-dark rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm" href="<?= url('admin/registration/submissions?status=approved') ?>">
            <i class="bi bi-clipboard-check me-1"></i><span>Lihat Semua Pendaftar</span>
        </a>
    </div>
</div>

<!-- Metrics Cards -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon bg-success-subtle text-success rounded-3 d-grid place-items-center" style="width: 42px; height: 42px; font-size: 1.2rem; display: grid;">
                    <i class="bi bi-people-fill"></i>
                </div>
                <div>
                    <div class="small text-secondary fw-semibold">Total Anggota</div>
                    <div class="h4 fw-bold text-dark mb-0"><?= count($members) ?></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-6 col-md-3">
        <div class="card border-0 shadow-sm rounded-4 p-3 bg-white h-100">
            <div class="d-flex align-items-center gap-3">
                <div class="stat-icon bg-primary-subtle text-primary rounded-3 d-grid place-items-center" style="width: 42px; height: 42px; font-size: 1.2rem; display: grid;">
                    <i class="bi bi-mortarboard-fill"></i>
                </div>
                <div>
                    <div class="small text-secondary fw-semibold">Jumlah Angkatan</div>
                    <div class="h4 fw-bold text-dark mb-0"><?= count($batches) ?: 1 ?></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filter Bar -->
<div class="card border-0 shadow-sm rounded-4 p-3 mb-4 bg-white">
    <form class="row g-2 align-items-center" method="get" action="">
        <div class="col-md-5">
            <div class="input-group input-group-sm">
                <span class="input-group-text bg-light border-end-0 text-muted"><i class="bi bi-search"></i></span>
                <input type="text" name="q" value="<?= e($searchQuery) ?>" class="form-control bg-light border-start-0" placeholder="Cari nama, whatsapp, prodi, atau referensi...">
            </div>
        </div>
        <div class="col-6 col-md-3">
            <select name="batch" class="form-select form-select-sm bg-light" onchange="this.form.submit()">
                <option value="">Semua Angkatan</option>
                <?php foreach ($batches as $b): ?>
                    <option value="<?= e($b) ?>" <?= $currentBatch === $b ? 'selected' : '' ?>>Angkatan <?= e($b) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <button type="submit" class="btn btn-sm btn-dark rounded-pill w-100 fw-semibold">
                <i class="bi bi-funnel me-1"></i> Filter
            </button>
        </div>
        <?php if ($searchQuery || $currentBatch): ?>
            <div class="col-12 col-md-2">
                <a href="<?= url('admin/members') ?>" class="btn btn-sm btn-outline-secondary rounded-pill w-100">Reset</a>
            </div>
        <?php endif; ?>
    </form>
</div>

<!-- Members Table -->
<?php if (empty($members)): ?>
    <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white my-3">
        <div class="d-inline-flex p-3 rounded-circle bg-light text-muted mb-3 mx-auto">
            <i class="bi bi-person-x fs-1 opacity-50"></i>
        </div>
        <h5 class="fw-bold text-dark mb-1">Belum ada anggota resmi</h5>
        <p class="text-secondary small mb-0">Anggota yang telah disetujui dari pendaftaran online akan tampil di sini.</p>
    </div>
<?php else: ?>
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden mb-4">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead class="bg-light">
                    <tr>
                        <th style="width: 50px; padding-left: 1.25rem;">#</th>
                        <th>Nama Anggota</th>
                        <th>Fakultas &amp; Program Studi</th>
                        <th>Angkatan</th>
                        <th>Kontak WhatsApp</th>
                        <th>Tgl Disetujui</th>
                        <th class="text-end" style="padding-right: 1.25rem;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $i => $m): 
                        $name = $m['full_name'] ?: 'Anggota #' . $m['id'];
                        $initials = strtoupper(substr(trim($name), 0, 2));
                        $waNum = preg_replace('/[^0-9]/', '', $m['whatsapp'] ?? '');
                        if ($waNum && str_starts_with($waNum, '0')) {
                            $waNum = '62' . substr($waNum, 1);
                        }
                    ?>
                        <tr>
                            <td style="padding-left: 1.25rem;"><span class="text-muted small fw-semibold"><?= $i + 1 ?></span></td>
                            <td>
                                <div class="d-flex align-items-center gap-2.5">
                                    <div class="avatar-circle bg-success text-white fw-bold rounded-circle d-grid place-items-center flex-shrink-0" style="width: 36px; height: 36px; font-size: 0.82rem; display: grid;">
                                        <?= e($initials) ?>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark mb-0"><?= e($name) ?></div>
                                        <div class="small d-flex align-items-center gap-1.5 mt-0.5">
                                            <span class="badge bg-dark text-warning font-monospace px-2 py-0.5" style="font-size:0.72rem;">No. <?= e($m['member_number'] ?: '-') ?></span>
                                            <span class="text-muted font-monospace" style="font-size:0.72rem;"><?= e($m['public_reference'] ?: ('ID #' . $m['id'])) ?></span>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <?php if ($m['faculty_name'] || $m['prodi_name']): ?>
                                    <div>
                                        <span class="badge bg-light text-dark border rounded-pill px-2.5 py-1 small">
                                            <i class="bi bi-buildings me-1 text-primary"></i><?= e($m['faculty_name'] ?: '-') ?>
                                        </span>
                                        <div class="small text-secondary mt-0.5 ms-1"><?= e($m['prodi_name'] ?: '-') ?></div>
                                    </div>
                                <?php else: ?>
                                    <span class="text-muted fst-italic small">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($m['batch_year']): ?>
                                    <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-2.5 py-1 fw-bold" style="font-size: 0.75rem;">
                                        <?= e($m['batch_year']) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($waNum): ?>
                                    <a href="https://wa.me/<?= e($waNum) ?>" target="_blank" rel="noopener" class="btn btn-sm btn-outline-success rounded-pill px-2.5 py-1 small d-inline-flex align-items-center gap-1">
                                        <i class="bi bi-whatsapp"></i>
                                        <span><?= e($m['whatsapp']) ?></span>
                                    </a>
                                <?php else: ?>
                                    <span class="text-muted small">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="small text-dark"><?= e(format_date_id($m['reviewed_at'] ?: $m['created_at'])) ?></div>
                            </td>
                            <td class="text-end" style="padding-right: 1.25rem;">
                                <div class="d-flex justify-content-end gap-1">
                                    <a href="<?= url('admin/members/edit?id=' . $m['id']) ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm" title="Edit">
                                        <i class="bi bi-pencil-fill"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-primary rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm btn-view-member" data-member-id="<?= $m['id'] ?>" title="Lihat Detail">
                                        <i class="bi bi-eye-fill"></i>
                                    </button>
                                    <form method="post" action="<?= url('admin/members/delete') ?>" onsubmit="return confirm('Yakin hapus anggota ini? Tindakan ini tidak dapat dibatalkan.')" class="d-inline">
                                        <?= Csrf::field() ?>
                                        <input type="hidden" name="id" value="<?= $m['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-outline-danger rounded-pill px-3 d-inline-flex align-items-center gap-1 shadow-sm" title="Hapus">
                                            <i class="bi bi-trash-fill"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<!-- Member Detail Modal -->
<div class="modal fade" id="memberDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 rounded-4 shadow-lg overflow-hidden">
            <div class="modal-header bg-dark text-white p-3 px-4">
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-person-vcard fs-5 text-success"></i>
                    <h5 class="modal-title fw-bold mb-0 text-white" id="modalMemberName">Detail Profile Anggota</h5>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4" id="memberModalBody">
                <div class="text-center py-4">
                    <div class="spinner-border text-primary" role="status"></div>
                    <p class="text-secondary small mt-2">Memuat detail anggota...</p>
                </div>
            </div>
            <div class="modal-footer bg-light p-3 px-4">
                <button type="button" class="btn btn-secondary rounded-pill px-4" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var modalElement = document.getElementById('memberDetailModal');
    var modalInstance = modalElement ? new bootstrap.Modal(modalElement) : null;
    var modalBody = document.getElementById('memberModalBody');
    var modalName = document.getElementById('modalMemberName');

    document.querySelectorAll('.btn-view-member').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var memberId = btn.dataset.memberId;
            if (!modalInstance) return;

            modalBody.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary" role="status"></div><p class="text-secondary small mt-2">Memuat detail anggota...</p></div>';
            modalInstance.show();

            fetch('<?= url("admin/members/detail") ?>?id=' + memberId)
                .then(function(res) { return res.json(); })
                .then(function(data) {
                    if (!data.ok || !data.submission) {
                        modalBody.innerHTML = '<div class="alert alert-danger mb-0">Gagal memuat data anggota.</div>';
                        return;
                    }

                    var sub = data.submission;
                    var vals = data.values || [];
                    modalName.textContent = sub.full_name || ('Anggota #' + sub.id);

                    var html = `
                        <div class="d-flex align-items-center gap-3 p-3 bg-light rounded-4 mb-4 border">
                            <div class="avatar-circle bg-success text-white fw-bold rounded-circle d-grid place-items-center" style="width: 48px; height: 48px; font-size: 1.1rem; display: grid;">
                                ${(sub.full_name || 'A').substr(0, 2).toUpperCase()}
                            </div>
                            <div>
                                <h5 class="fw-bold text-dark mb-0">${sub.full_name || '-'}</h5>
                                <div class="small text-muted font-monospace">${sub.public_reference || ('ID #' + sub.id)} • Disetujui</div>
                            </div>
                            <span class="badge bg-success rounded-pill ms-auto px-3 py-1.5"><i class="bi bi-check-circle-fill me-1"></i>Anggota Resmi</span>
                        </div>

                        <h6 class="fw-bold text-dark border-bottom pb-2 mb-3"><i class="bi bi-person-lines-fill me-1 text-primary"></i> Data Utama Anggota</h6>
                        <div class="row g-3 mb-4">
                            <div class="col-md-6">
                                <div class="p-2.5 rounded-3 bg-light border">
                                    <div class="text-secondary small">Fakultas</div>
                                    <div class="fw-semibold text-dark">${sub.faculty_name || '-'}</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="p-2.5 rounded-3 bg-light border">
                                    <div class="text-secondary small">Program Studi</div>
                                    <div class="fw-semibold text-dark">${sub.prodi_name || '-'}</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="p-2.5 rounded-3 bg-light border">
                                    <div class="text-secondary small">WhatsApp</div>
                                    <div class="fw-semibold text-dark">${sub.whatsapp ? '<a href="https://wa.me/' + sub.whatsapp.replace(/[^0-9]/g, '') + '" target="_blank" class="text-success text-decoration-none"><i class="bi bi-whatsapp me-1"></i>' + sub.whatsapp + '</a>' : '-'}</div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="p-2.5 rounded-3 bg-light border">
                                    <div class="text-secondary small">Angkatan Kuliah</div>
                                    <div class="fw-semibold text-dark">${sub.batch_year ? ('Angkatan ' + sub.batch_year) : '-'}</div>
                                </div>
                            </div>
                        </div>

                        <h6 class="fw-bold text-dark border-bottom pb-2 mb-3"><i class="bi bi-list-stars me-1 text-primary"></i> Detail Isian Tambahan Form Pendaftaran</h6>
                    `;

                    if (vals.length === 0) {
                        html += '<p class="text-muted small fst-italic">Tidak ada data isian tambahan.</p>';
                    } else {
                        html += '<div class="row g-3">';
                        vals.forEach(function(v) {
                            var valDisplay = v.value || '-';
                            if (v.file_path) {
                                valDisplay = '<a href="<?= url("") ?>/' + v.file_path + '" target="_blank" class="btn btn-sm btn-outline-primary rounded-pill px-3"><i class="bi bi-download me-1"></i>Lihat Berkas / File</a>';
                            }
                            html += `
                                <div class="col-md-6">
                                    <div class="p-3 rounded-3 bg-light border h-100">
                                        <div class="text-secondary small fw-semibold mb-1">${v.field_label || v.field_name}</div>
                                        <div class="fw-semibold text-dark text-break" style="font-size: 0.9rem;">${valDisplay}</div>
                                    </div>
                                </div>
                            `;
                        });
                        html += '</div>';
                    }

                    modalBody.innerHTML = html;
                })
                .catch(function() {
                    modalBody.innerHTML = '<div class="alert alert-danger mb-0">Terjadi kesalahan koneksi.</div>';
                });
        });
    });
});
</script>
