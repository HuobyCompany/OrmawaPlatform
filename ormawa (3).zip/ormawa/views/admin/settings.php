<?php
$s = $settings;
$get = fn($k, $d = '') => $s[$k] ?? $d;
?>

<!-- Header -->
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
    <div>
        <div class="small text-secondary fw-semibold">Konfigurasi Tampilan</div>
        <h2 class="h3 fw-bold text-dark mb-1">Pengaturan Layout, Foto & SEO</h2>
        <p class="text-secondary small mb-0">Sesuaikan ukuran foto flyer, foto struktur, tata letak galeri, dan urutan section beranda.</p>
    </div>
    <div class="d-flex gap-2">
        <a href="<?= url('/admin/organization') ?>" class="btn btn-outline-secondary rounded-pill px-3.5 btn-sm fw-semibold">
            <i class="bi bi-sliders me-1"></i> Profil & Identitas
        </a>
        <a href="<?= e(org_url($organization)) ?>" target="_blank" class="btn btn-outline-dark rounded-pill px-3.5 btn-sm fw-semibold">
            <i class="bi bi-eye me-1"></i> Lihat Web Publik
        </a>
    </div>
</div>

<form method="post" action="<?= url('/admin/settings/save') ?>">
    <?= Csrf::field() ?>

    <!-- Navigation Pills Sub-Tabs -->
    <ul class="nav nav-pills gap-2 mb-4 border-bottom pb-3" id="settingsSubTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active rounded-pill px-4 fw-semibold d-inline-flex align-items-center gap-2" id="tab-media-btn" data-bs-toggle="pill" data-bs-target="#tab-media" type="button" role="tab">
                <i class="bi bi-image"></i>
                <span>Ukuran Foto & Media</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link rounded-pill px-4 fw-semibold d-inline-flex align-items-center gap-2" id="tab-sections-btn" data-bs-toggle="pill" data-bs-target="#tab-sections" type="button" role="tab">
                <i class="bi bi-layout-text-window-reverse"></i>
                <span>Tata Letak Beranda</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link rounded-pill px-4 fw-semibold d-inline-flex align-items-center gap-2" id="tab-seo-btn" data-bs-toggle="pill" data-bs-target="#tab-seo" type="button" role="tab">
                <i class="bi bi-search"></i>
                <span>SEO & Integrasi</span>
            </button>
        </li>
    </ul>

    <!-- Tab Content -->
    <div class="tab-content mb-4" id="settingsSubTabsContent">

        <!-- ==========================================================
             TAB 1: UKURAN FOTO & MEDIA
             ========================================================== -->
        <div class="tab-pane fade show active" id="tab-media" role="tabpanel">
            <div class="row g-4">
                <!-- 1. Event Poster / Flyer Settings -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100 bg-white">
                        <div class="d-flex align-items-center gap-2.5 mb-3 pb-2 border-bottom">
                            <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle p-2" style="width: 40px; height: 40px;">
                                <i class="bi bi-file-image fs-5"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold text-dark mb-0 fs-6">Poster / Flyer Event</h5>
                                <div class="small text-secondary">Rasio dan mode potong flyer</div>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label fw-semibold small text-dark">Preset Ukuran Display</label>
                                <select class="form-select border-0 bg-light rounded-3 px-3 py-2 fw-semibold" name="event_poster_size">
                                    <option value="Small" <?= $get('event_poster_size') === 'Small' ? 'selected' : '' ?>>Small (Kecil)</option>
                                    <option value="Medium" <?= $get('event_poster_size', 'Medium') === 'Medium' ? 'selected' : '' ?>>Medium (Sedang)</option>
                                    <option value="Large" <?= $get('event_poster_size') === 'Large' ? 'selected' : '' ?>>Large (Besar)</option>
                                    <option value="Custom" <?= $get('event_poster_size') === 'Custom' ? 'selected' : '' ?>>Custom (Kustom)</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Lebar (px)</label>
                                <input class="form-control border-0 bg-light rounded-3 px-3" type="number" name="event_poster_width" value="<?= e($get('event_poster_width', 1200)) ?>">
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Tinggi (px)</label>
                                <input class="form-control border-0 bg-light rounded-3 px-3" type="number" name="event_poster_height" value="<?= e($get('event_poster_height', 800)) ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold small text-dark">Mode Potong (Object Fit)</label>
                                <select class="form-select border-0 bg-light rounded-3 px-3 py-2" name="event_poster_object_fit">
                                    <option value="cover" <?= $get('event_poster_object_fit', 'cover') === 'cover' ? 'selected' : '' ?>>Cover (Isi Penuh)</option>
                                    <option value="contain" <?= $get('event_poster_object_fit') === 'contain' ? 'selected' : '' ?>>Contain (Skala Utuh / Proporsional)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 2. Structural Photo Customization -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100 bg-white">
                        <div class="d-flex align-items-center gap-2.5 mb-3 pb-2 border-bottom">
                            <div class="d-inline-flex align-items-center justify-content-center bg-success bg-opacity-10 text-success rounded-circle p-2" style="width: 40px; height: 40px;">
                                <i class="bi bi-person-badge fs-5"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold text-dark mb-0 fs-6">Foto Struktur Pengurus</h5>
                                <div class="small text-secondary">Bentuk avatar dan dimensi foto</div>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label fw-semibold small text-dark">Bentuk Avatar</label>
                                <select class="form-select border-0 bg-light rounded-3 px-3 py-2 fw-semibold" name="structure_photo_shape">
                                    <option value="circle" <?= $get('structure_photo_shape', 'circle') === 'circle' ? 'selected' : '' ?>>Lingkaran (Circle)</option>
                                    <option value="rounded" <?= $get('structure_photo_shape') === 'rounded' ? 'selected' : '' ?>>Sudut Membulat (Rounded)</option>
                                    <option value="square" <?= $get('structure_photo_shape') === 'square' ? 'selected' : '' ?>>Persegi (Square)</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold small text-dark">Preset Ukuran Avatar</label>
                                <select class="form-select border-0 bg-light rounded-3 px-3 py-2" name="structure_photo_size">
                                    <option value="Small" <?= $get('structure_photo_size') === 'Small' ? 'selected' : '' ?>>Small (84px)</option>
                                    <option value="Medium" <?= $get('structure_photo_size', 'Medium') === 'Medium' ? 'selected' : '' ?>>Medium (110px)</option>
                                    <option value="Large" <?= $get('structure_photo_size') === 'Large' ? 'selected' : '' ?>>Large (140px)</option>
                                    <option value="Custom" <?= $get('structure_photo_size') === 'Custom' ? 'selected' : '' ?>>Custom (Kustom Pixels)</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Lebar (px)</label>
                                <input class="form-control border-0 bg-light rounded-3 px-3" type="number" name="structure_photo_width" value="<?= e($get('structure_photo_width', 110)) ?>">
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Tinggi (px)</label>
                                <input class="form-control border-0 bg-light rounded-3 px-3" type="number" name="structure_photo_height" value="<?= e($get('structure_photo_height', 110)) ?>">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3. Gallery / Documentation Layout -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 p-4 h-100 bg-white">
                        <div class="d-flex align-items-center gap-2.5 mb-3 pb-2 border-bottom">
                            <div class="d-inline-flex align-items-center justify-content-center bg-warning bg-opacity-10 text-warning rounded-circle p-2" style="width: 40px; height: 40px;">
                                <i class="bi bi-grid-3x3-gap fs-5"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold text-dark mb-0 fs-6">Kisi Galeri Foto</h5>
                                <div class="small text-secondary">Kolom grid dan rasio thumbnail</div>
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Jumlah Kolom</label>
                                <input class="form-control border-0 bg-light rounded-3 px-3" type="number" min="1" max="6" name="gallery_columns" value="<?= e($get('gallery_columns', 3)) ?>">
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Jarak / Gap (px)</label>
                                <input class="form-control border-0 bg-light rounded-3 px-3" type="number" min="0" max="64" name="gallery_gap" value="<?= e($get('gallery_gap', 16)) ?>">
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Rasio Gambar</label>
                                <select class="form-select border-0 bg-light rounded-3 px-3" name="gallery_ratio">
                                    <option value="4/3" <?= $get('gallery_ratio', '4/3') === '4/3' ? 'selected' : '' ?>>4/3 (Landscape)</option>
                                    <option value="1/1" <?= $get('gallery_ratio') === '1/1' ? 'selected' : '' ?>>1/1 (Persegi)</option>
                                    <option value="16/9" <?= $get('gallery_ratio') === '16/9' ? 'selected' : '' ?>>16/9 (Widescreen)</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label class="form-label fw-semibold small text-dark">Radius Sudut (px)</label>
                                <input class="form-control border-0 bg-light rounded-3 px-3" type="number" name="gallery_radius" value="<?= e($get('gallery_radius', 20)) ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-semibold small text-dark">Mode Potong Foto</label>
                                <select class="form-select border-0 bg-light rounded-3 px-3" name="gallery_object_fit">
                                    <option value="cover" <?= $get('gallery_object_fit', 'cover') === 'cover' ? 'selected' : '' ?>>Cover (Penuh)</option>
                                    <option value="contain" <?= $get('gallery_object_fit') === 'contain' ? 'selected' : '' ?>>Contain (Skala Utuh)</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 2: TATA LETAK SECTION BERANDA
             ========================================== -->
        <div class="tab-pane fade" id="tab-sections" role="tabpanel">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <div class="d-flex align-items-center gap-2.5 mb-3 pb-2 border-bottom">
                    <div class="d-inline-flex align-items-center justify-content-center bg-primary bg-opacity-10 text-primary rounded-circle p-2" style="width: 40px; height: 40px;">
                        <i class="bi bi-layout-text-window-reverse fs-5"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold text-dark mb-0 fs-6">Urutan & Visibilitas Bagian Beranda (Homepage)</h5>
                        <div class="small text-secondary">Centang bagian yang ingin ditampilkan pada halaman beranda utama.</div>
                    </div>
                </div>

                <?php 
                $map = [];
                foreach ($sections as $x) $map[$x['section_key']] = $x;
                $labels = [
                    'hero' => ['Hero Banner Utama', 'bi bi-image'],
                    'about' => ['Tentang Kami (About)', 'bi bi-info-circle'],
                    'vision_mission' => ['Visi & Misi', 'bi bi-compass'],
                    'events' => ['Agenda Kegiatan Mendatang', 'bi bi-calendar-event'],
                    'calendar' => ['Widget Kalender Agenda', 'bi bi-calendar3'],
                    'gallery' => ['Galeri Dokumentasi Foto', 'bi bi-images'],
                    'structure' => ['Bagan Struktur Pengurus', 'bi bi-diagram-3'],
                    'contact' => ['Kartu Kontak & Hubungi Kami', 'bi bi-chat-dots']
                ]; 
                $autoOrder = 0;
                ?>

                <div class="row g-3">
                    <?php foreach ($labels as $key => [$label, $icon]): 
                        $x = $map[$key] ?? ['status' => 1, 'sort_order' => 99]; 
                        $displayOrder = $x['status'] ? ++$autoOrder : null;
                    ?>
                        <div class="col-md-6 col-lg-4">
                            <div class="p-3 rounded-4 border bg-light d-flex align-items-center justify-content-between">
                                <div class="form-check d-flex align-items-center gap-2 mb-0">
                                    <input class="form-check-input mt-0" type="checkbox" name="section_<?= e($key) ?>" id="sec_<?= e($key) ?>" <?= $x['status'] ? 'checked' : '' ?>>
                                    <label class="form-check-label fw-bold text-dark small cursor-pointer" for="sec_<?= e($key) ?>">
                                        <i class="<?= e($icon) ?> me-1 text-primary"></i> <?= e($label) ?>
                                    </label>
                                </div>
                                <div class="d-flex align-items-center gap-2" data-order-wrap>
                                    <span class="small text-secondary" style="font-size: 0.72rem;">Urutan</span>
                                    <span class="badge rounded-pill text-bg-primary px-3 py-1.5 fs-6" data-order="<?= e($key) ?>"><?= $displayOrder ?? '—' ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>

                    <div class="col-12 mt-4 pt-3 border-top">
                        <div class="card border-0 bg-primary bg-opacity-10 rounded-4 p-4">
                            <div class="d-flex align-items-center justify-content-between">
                                <div>
                                    <h6 class="fw-bold text-primary mb-1"><i class="bi bi-person-plus-fill me-2"></i>Status Akses Pendaftaran Anggota</h6>
                                    <div class="small text-secondary">Aktifkan tombol dan formulir pendaftaran anggota di beranda website.</div>
                                </div>
                                <div class="form-check form-switch m-0 fs-5">
                                    <input class="form-check-input" type="checkbox" id="regEnabled" name="registration_enabled" value="1" <?= ($get('registration_enabled', '0') === '1') ? 'checked' : '' ?>>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ==========================================
             TAB 3: SEO & INTEGRASI
             ========================================== -->
        <div class="tab-pane fade" id="tab-seo" role="tabpanel">
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <div class="d-flex align-items-center gap-2.5 mb-3 pb-2 border-bottom">
                    <div class="d-inline-flex align-items-center justify-content-center bg-warning bg-opacity-10 text-warning rounded-circle p-2" style="width: 40px; height: 40px;">
                        <i class="bi bi-search fs-5"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold text-dark mb-0 fs-6">Pengaturan SEO Mesin Pencari & Peta</h5>
                        <div class="small text-secondary">Optimasi kata kunci pencarian dan sematan Google Maps</div>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small text-dark">Default Meta Keywords</label>
                        <input class="form-control border-0 bg-light rounded-3 px-3 py-2" name="default_meta_keywords" value="<?= e($get('default_meta_keywords', 'organisasi mahasiswa, ORMAWA, HIMA, UKM')) ?>" placeholder="Pisahkan dengan koma">
                        <div class="form-text small text-muted">Kata kunci pencarian untuk Google & mesin pencari.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold small text-dark">Google Maps Embed URL / iFrame Src</label>
                        <input class="form-control border-0 bg-light rounded-3 px-3 py-2" name="google_maps_embed" value="<?= e($get('google_maps_embed')) ?>" placeholder="https://www.google.com/maps/embed?...">
                        <div class="form-text small text-muted">URL iframe embed lokasi sekretariat organisasi.</div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Save Action Bar Footer -->
    <div class="card border-0 shadow-sm rounded-4 p-3 bg-white d-flex flex-row align-items-center justify-content-between">
        <div class="small text-secondary d-none d-md-flex align-items-center gap-2">
            <i class="bi bi-check-circle-fill text-success fs-5"></i>
            <span>Seluruh perubahan pengaturan akan langsung aktif di halaman publik.</span>
        </div>
        <div class="d-flex gap-2 ms-auto">
            <a href="<?= url('/admin/dashboard') ?>" class="btn btn-light rounded-pill px-4 fw-semibold">
                Batal
            </a>
            <button type="submit" class="btn btn-primary rounded-pill px-4 py-2 fw-bold shadow-sm d-inline-flex align-items-center gap-2">
                <i class="bi bi-check2-circle"></i>
                <span>Simpan Seluruh Pengaturan</span>
            </button>
        </div>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const sectionInputs = [...document.querySelectorAll('#tab-sections input[type="checkbox"][name^="section_"]')];
    const updateOrders = () => {
        let order = 0;
        sectionInputs.forEach((checkbox) => {
            const key = checkbox.name.replace('section_', '');
            const badge = document.querySelector(`[data-order="${key}"]`);
            if (!badge) return;
            if (checkbox.checked) {
                badge.textContent = ++order;
                badge.closest('[data-order-wrap]')?.classList.remove('opacity-50');
            } else {
                badge.textContent = '—';
                badge.closest('[data-order-wrap]')?.classList.add('opacity-50');
            }
        });
    };
    sectionInputs.forEach((checkbox) => checkbox.addEventListener('change', updateOrders));
    updateOrders();
});
</script>
