<?php
// Production defaults. Override with config.local.php for local development.
// DO NOT commit config.php with real credentials to version control.

$local = __DIR__.'/config.local.php';
$localConfig = [];
if (file_exists($local)) {
    $c = require $local;
    if (is_array($c)) {
        $localConfig = $c;
    }
}

$defaults = [
    'app_url' => 'http://localhost/ormawa-platform',
    'app_env' => 'production',
    'app_debug' => false,
    'app_name' => 'ORMAWA Platform',
    'app_timezone' => 'Asia/Jakarta',
    'debug_dummy_images' => false,
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'ormawa_platform',
    'db_user' => 'root',
    'db_pass' => '',
    'default_organization_slug' => 'ormawa',
    'upload_max_bytes' => 8 * 1024 * 1024,
    'google_drive_client_id' => '',
    'google_drive_client_secret' => '',
    'google_drive_refresh_token' => '',
];

$map = [
    'app_url' => 'APP_URL',
    'app_env' => 'APP_ENV',
    'app_debug' => 'APP_DEBUG',
    'app_name' => 'APP_NAME',
    'app_timezone' => 'APP_TIMEZONE',
    'debug_dummy_images' => 'DEBUG_DUMMY_IMAGES',
    'db_host' => 'DB_HOST',
    'db_port' => 'DB_PORT',
    'db_name' => 'DB_NAME',
    'db_user' => 'DB_USER',
    'db_pass' => 'DB_PASS',
    'default_organization_slug' => 'DEFAULT_ORGANIZATION_SLUG',
    'upload_max_bytes' => 'UPLOAD_MAX_BYTES',
    'google_drive_client_id' => 'GOOGLE_DRIVE_CLIENT_ID',
    'google_drive_client_secret' => 'GOOGLE_DRIVE_CLIENT_SECRET',
    'google_drive_refresh_token' => 'GOOGLE_DRIVE_REFRESH_TOKEN',
];

foreach ($map as $key => $const) {
    $value = $localConfig[$key] ?? $defaults[$key];
    if (!defined($const)) {
        define($const, $value);
    }
}

// Production sanity checks
if (APP_ENV === 'production') {
    $warnings = [];
    if (str_contains(APP_URL, 'localhost') || str_contains(APP_URL, '127.0.0.1')) {
        $warnings[] = 'Production deployment detected with localhost APP_URL. Update config.php or config.local.php with the real domain.';
    }
    if (DEBUG_DUMMY_IMAGES === true) {
        $warnings[] = 'Production deployment detected with DEBUG_DUMMY_IMAGES enabled. Disable it in config.';
    }
    if (DB_PASS === '') {
        $warnings[] = 'Production deployment detected with empty database password. Set a strong DB_PASS.';
    }
    if ($warnings) {
        error_log('[ORMAWA PROD CHECK] ' . implode(' ', $warnings));
    }
}
