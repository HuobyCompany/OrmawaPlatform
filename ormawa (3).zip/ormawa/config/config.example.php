<?php
// Copy this file to config.local.php for local development.
// Do NOT commit config.local.php or config.php with real credentials.

return [
    // Application
    'app_url' => 'http://localhost/ormawa-platform',
    'app_debug' => true,
    'app_name' => 'ORMAWA Platform',
    'app_timezone' => 'Asia/Jakarta',

    // Database
    'db_host' => '127.0.0.1',
    'db_port' => '3306',
    'db_name' => 'ormawa_platform',
    'db_user' => 'root',
    'db_pass' => '',

    // Defaults
    'default_organization_slug' => 'hmti',
    'upload_max_bytes' => 8 * 1024 * 1024,

    // Development helpers
    'debug_dummy_images' => true,
];

