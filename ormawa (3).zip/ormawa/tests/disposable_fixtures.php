<?php
require_once 'C:/xampp/htdocs/ormawa-platform/config/config.php';
require_once 'C:/xampp/htdocs/ormawa-platform/app/core/Database.php';

$action = $argv[1] ?? 'seed';
$pdo = Database::connection();

if ($action === 'seed') {
    echo "=== SEEDING DISPOSABLE TEST FIXTURES ===\n";

    // 1. Ensure test-org exists
    $stmt = $pdo->prepare('SELECT id FROM organizations WHERE slug = "test-org" LIMIT 1');
    $stmt->execute();
    $testOrgId = $stmt->fetchColumn();

    if (!$testOrgId) {
        $pdo->exec('INSERT INTO organizations (name, slug, description, created_at, updated_at) VALUES ("Test Organization", "test-org", "Automated QA Test Organization", NOW(), NOW())');
        $testOrgId = (int)$pdo->lastInsertId();
    }

    // 2. Add settings for test-org & hmti
    $pdo->exec("INSERT IGNORE INTO organization_settings (organization_id, setting_key, setting_value, created_at, updated_at) VALUES
        (1, 'registration_enabled', '1', NOW(), NOW()),
        ({$testOrgId}, 'registration_enabled', '1', NOW(), NOW())
    ");

    // 3. Ensure active registration form for test-org & hmti
    $pdo->exec("INSERT IGNORE INTO registration_forms (id, organization_id, title, description, is_active, created_at, updated_at) VALUES
        (1, 1, 'Formulir Pendaftaran HMTI', 'Pendaftaran Calon Anggota HMTI', 1, NOW(), NOW()),
        (2, {$testOrgId}, 'Formulir Pendaftaran Test Org', 'Pendaftaran Test Org', 1, NOW(), NOW())
    ");

    // 4. Ensure Person for member@test.com
    $stmt = $pdo->prepare('SELECT id FROM persons WHERE organization_id = 1 AND email = "member@test.com" LIMIT 1');
    $stmt->execute();
    $personId = $stmt->fetchColumn();

    if (!$personId) {
        $pdo->exec('INSERT INTO persons (organization_id, full_name, email, phone, created_at, updated_at) VALUES (1, "Member Test User", "member@test.com", "081234567890", NOW(), NOW())');
        $personId = (int)$pdo->lastInsertId();
    }

    // 5. Ensure Member TEST001 for person
    $stmt = $pdo->prepare('SELECT id FROM members WHERE organization_id = 1 AND member_number = "TEST001" LIMIT 1');
    $stmt->execute();
    $memberId = $stmt->fetchColumn();

    if (!$memberId) {
        $termId = $pdo->query('SELECT id FROM organization_terms WHERE organization_id = 1 ORDER BY start_date DESC LIMIT 1')->fetchColumn();
        $pdo->prepare('INSERT INTO members (organization_id, person_id, member_number, status, joined_at, current_term_id, batch_year, faculty_name, prodi_name, whatsapp, created_at, updated_at) VALUES (1, :pid, "TEST001", "active", NOW(), :tid, "2026", "FTI", "Teknik Informatika", "081234567890", NOW(), NOW())')
            ->execute(['pid' => $personId, 'tid' => $termId]);
        $memberId = (int)$pdo->lastInsertId();
    }

    // 6. Ensure member@test.com user account (password: test123 -> $2y$10$wT8n... or hash)
    $passHash = password_hash('test123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = "member@test.com" LIMIT 1');
    $stmt->execute();
    $userId = $stmt->fetchColumn();

    if (!$userId) {
        $pdo->prepare('INSERT INTO users (organization_id, name, email, password, role, status, created_at, updated_at) VALUES (1, "Member Test User", "member@test.com", :p, "member", "active", NOW(), NOW())')
            ->execute(['p' => $passHash]);
        $userId = (int)$pdo->lastInsertId();
    }

    // Ensure super@example.com exists for isolation test
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = "super@example.com" LIMIT 1');
    $stmt->execute();
    if (!$stmt->fetchColumn()) {
        $superPassHash = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->prepare('INSERT INTO users (organization_id, name, email, password, role, status, created_at, updated_at) VALUES (1, "Super Admin", "super@example.com", :p, "super_admin", "active", NOW(), NOW())')
            ->execute(['p' => $superPassHash]);
    }

    // 7. Ensure user_account_members link
    $pdo->exec("INSERT IGNORE INTO user_account_members (user_id, member_id, person_id, is_primary, created_at, updated_at) VALUES
        ({$userId}, {$memberId}, {$personId}, 1, NOW(), NOW())
    ");

    // 8. Ensure test-org member (member@testorg.com / password test123)
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = "member@testorg.com" LIMIT 1');
    $stmt->execute();
    $testOrgUserId = $stmt->fetchColumn();
    if (!$testOrgUserId) {
        $pdo->prepare('INSERT INTO users (organization_id, name, email, password, role, status, created_at, updated_at) VALUES (:org, "TestOrg Member", "member@testorg.com", :p, "member", "active", NOW(), NOW())')
            ->execute(['org' => $testOrgId, 'p' => $passHash]);
        $testOrgUserId = (int)$pdo->lastInsertId();

        $pdo->exec("INSERT INTO persons (organization_id, full_name, email, created_at, updated_at) VALUES ({$testOrgId}, 'TestOrg Member', 'member@testorg.com', NOW(), NOW())");
        $testOrgPersonId = (int)$pdo->lastInsertId();

        $pdo->exec("INSERT INTO members (organization_id, person_id, member_number, status, joined_at, created_at, updated_at) VALUES ({$testOrgId}, {$testOrgPersonId}, 'TESTORG01', 'active', NOW(), NOW(), NOW())");
        $testOrgMemberId = (int)$pdo->lastInsertId();

        $pdo->exec("INSERT INTO user_account_members (user_id, member_id, person_id, is_primary, created_at, updated_at) VALUES ({$testOrgUserId}, {$testOrgMemberId}, {$testOrgPersonId}, 1, NOW(), NOW())");
    }

    // 9. Approved registration submission for legacy auth test
    $stmt = $pdo->prepare('SELECT id FROM registration_submissions WHERE organization_id = 1 AND member_number = "TEST001" LIMIT 1');
    $stmt->execute();
    $subId = $stmt->fetchColumn();
    if (!$subId) {
        $pdo->exec("INSERT INTO registration_submissions (form_id, organization_id, full_name, member_number, status, submitted_at, reviewed_at, created_at, updated_at) VALUES
            (1, 1, 'Member Test User', 'TEST001', 'approved', NOW(), NOW(), NOW(), NOW())
        ");
        $subId = (int)$pdo->lastInsertId();
    }

    // 10. Ensure test gallery album & item for final-qa.js
    $stmt = $pdo->prepare('SELECT id FROM gallery_albums WHERE organization_id = 1 LIMIT 1');
    $stmt->execute();
    $albumId = $stmt->fetchColumn();
    if (!$albumId) {
        $pdo->exec("INSERT INTO gallery_albums (organization_id, title, slug, created_at, updated_at) VALUES (1, 'Dokumentasi Kegiatan HMTI', 'dokumentasi-kegiatan', NOW(), NOW())");
        $albumId = (int)$pdo->lastInsertId();
    }

    $stmt = $pdo->prepare('SELECT id FROM gallery_items WHERE album_id = :a LIMIT 1');
    $stmt->execute(['a' => $albumId]);
    if (!$stmt->fetchColumn()) {
        $pdo->exec("INSERT INTO gallery_items (album_id, title, file_path, source_type, created_at, updated_at) VALUES ({$albumId}, 'Foto Kegiatan 1', 'uploads/gallery/sample.jpg', 'local', NOW(), NOW())");
    }

    // 11. Ensure test event for final-qa.js
    $stmt = $pdo->prepare('SELECT id FROM events WHERE organization_id = 1 LIMIT 1');
    $stmt->execute();
    if (!$stmt->fetchColumn()) {
        $pdo->exec("INSERT INTO events (organization_id, title, slug, event_date, status, created_at, updated_at) VALUES (1, 'Seminar Nasional Teknologi', 'seminar-nasional', '2026-10-15', 'published', NOW(), NOW())");
    }

    // 12. Ensure structure group & card for final-qa.js
    $stmt = $pdo->prepare('SELECT id FROM structure_groups WHERE organization_id = 1 LIMIT 1');
    $stmt->execute();
    $groupId = $stmt->fetchColumn();
    if (!$groupId) {
        $pdo->exec("INSERT INTO structure_groups (organization_id, name, sort_order, created_at, updated_at) VALUES (1, 'Pengurus Harian', 1, NOW(), NOW())");
        $groupId = (int)$pdo->lastInsertId();
    }

    $stmt = $pdo->prepare('SELECT id FROM positions WHERE group_id = :g LIMIT 1');
    $stmt->execute(['g' => $groupId]);
    $posId = $stmt->fetchColumn();
    if (!$posId) {
        $pdo->exec("INSERT INTO positions (organization_id, group_id, title, sort_order, created_at, updated_at) VALUES (1, {$groupId}, 'Ketua Umum', 1, NOW(), NOW())");
        $posId = (int)$pdo->lastInsertId();
    }

    $stmt = $pdo->prepare('SELECT id FROM position_assignments WHERE position_id = :p LIMIT 1');
    $stmt->execute(['p' => $posId]);
    if (!$stmt->fetchColumn()) {
        $termId = $pdo->query('SELECT id FROM organization_terms WHERE organization_id = 1 ORDER BY start_date DESC LIMIT 1')->fetchColumn();
        $pdo->exec("INSERT INTO position_assignments (organization_id, person_id, position_id, term_id, created_at, updated_at) VALUES (1, {$personId}, {$posId}, {$termId}, NOW(), NOW())");
    }

    echo "Disposable test fixtures seeded successfully.\n";

} elseif ($action === 'clean') {
    echo "=== CLEANING DISPOSABLE TEST FIXTURES ===\n";

    $pdo->exec("SET FOREIGN_KEY_CHECKS=0;");

    // Remove test organization & associated data
    $stmt = $pdo->prepare('SELECT id FROM organizations WHERE slug = "test-org" LIMIT 1');
    $stmt->execute();
    $testOrgId = $stmt->fetchColumn();

    if ($testOrgId) {
        $pdo->exec("DELETE FROM user_account_members WHERE user_id IN (SELECT id FROM users WHERE organization_id = {$testOrgId})");
        $pdo->exec("DELETE FROM users WHERE organization_id = {$testOrgId}");
        $pdo->exec("DELETE FROM members WHERE organization_id = {$testOrgId}");
        $pdo->exec("DELETE FROM persons WHERE organization_id = {$testOrgId}");
        $pdo->exec("DELETE FROM registration_submissions WHERE organization_id = {$testOrgId}");
        $pdo->exec("DELETE FROM registration_forms WHERE organization_id = {$testOrgId}");
        $pdo->exec("DELETE FROM organization_settings WHERE organization_id = {$testOrgId}");
        $pdo->exec("DELETE FROM organizations WHERE id = {$testOrgId}");
    }

    // Remove member@test.com test user & member TEST001
    $stmt = $pdo->prepare('SELECT id FROM users WHERE email = "member@test.com" LIMIT 1');
    $stmt->execute();
    $userId = $stmt->fetchColumn();

    if ($userId) {
        $pdo->exec("DELETE FROM user_account_members WHERE user_id = {$userId}");
        $pdo->exec("DELETE FROM users WHERE id = {$userId}");
    }

    $pdo->exec("DELETE FROM members WHERE member_number = 'TEST001'");
    $pdo->exec("DELETE FROM persons WHERE email = 'member@test.com'");
    $pdo->exec("DELETE FROM registration_submissions WHERE member_number = 'TEST001'");

    $pdo->exec("DELETE FROM users WHERE email = 'super@example.com'");

    // Clean test structures & events
    $pdo->exec("DELETE FROM position_assignments WHERE organization_id = 1");
    $pdo->exec("DELETE FROM positions WHERE group_id IN (SELECT id FROM structure_groups WHERE organization_id = 1)");
    $pdo->exec("DELETE FROM structure_groups WHERE organization_id = 1");
    $pdo->exec("DELETE FROM events WHERE organization_id = 1");
    $pdo->exec("DELETE FROM gallery_items WHERE album_id IN (SELECT id FROM gallery_albums WHERE organization_id = 1)");
    $pdo->exec("DELETE FROM gallery_albums WHERE organization_id = 1");
    $pdo->exec("TRUNCATE TABLE activity_logs;");
    $pdo->exec("TRUNCATE TABLE registration_member_mapping;");

    $pdo->exec("SET FOREIGN_KEY_CHECKS=1;");

    echo "Disposable test fixtures cleaned successfully.\n";
}
