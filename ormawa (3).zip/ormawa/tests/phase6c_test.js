const { chromium } = require('playwright');

const BASE_URL = 'http://localhost:8080';
const results = [];

function log(name, status, details = '') {
  results.push({ name, status, details });
  console.log(`[${status}] ${name}${details ? ' - ' + details : ''}`);
}

async function testPhase6C() {
  console.log('=== PHASE 6C AUTOMATED TEST SUITE ===\n');

  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Test 1: Member login & access portal
  console.log('Test 1: Member login (member@test.com)');
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');

  const emailInput = page.locator('input[name="email"], input[name="login_input"]').first();
  const passwordInput = page.locator('input[name="password"]').first();

  await emailInput.fill('member@test.com');
  await passwordInput.fill('test123');
  await page.click('button[type="submit"]');
  await page.waitForLoadState('networkidle');

  const loggedInUrl = page.url();
  const isLoggedIn = loggedInUrl.includes('/member');
  log('Member login success', isLoggedIn ? 'PASS' : 'FAIL', `url=${loggedInUrl}`);

  // Base member URL resolved after login (e.g. http://localhost:8080/test-org/member or http://localhost:8080/member)
  const memberBaseUrl = loggedInUrl.replace(/\/+$/, '');

  // Test 2: Edit member profile (full_name, phone)
  console.log('\nTest 2: Edit member profile details');
  await page.goto(memberBaseUrl + '/profile');
  await page.waitForLoadState('networkidle');

  const nameInput = page.locator('input[name="full_name"]');
  const phoneInput = page.locator('input[name="phone"]');

  await nameInput.fill('Member Test Updated');
  await phoneInput.fill('081234567890');
  await page.click('button[type="submit"]');
  await page.waitForLoadState('networkidle');

  const successAlert = await page.locator('.alert-success').count();
  const pageContent = await page.content();
  const nameUpdated = pageContent.includes('Member Test Updated');
  log('Profile update (full_name & phone)', successAlert > 0 && nameUpdated ? 'PASS' : 'FAIL', `alert=${successAlert} updated=${nameUpdated}`);

  // Test 3: Immutable field protection (member_number cannot be updated)
  console.log('\nTest 3: Immutable field protection');
  const readonlyMemberNum = await page.locator('.readonly-value').first().textContent();
  const memberNumInputCount = await page.locator('input[name="member_number"]').count();
  log('member_number is read-only in UI', memberNumInputCount === 0 && readonlyMemberNum.includes('TEST001') ? 'PASS' : 'FAIL', `readonlyVal=${readonlyMemberNum}`);

  // Test 4: CSRF security rejection
  console.log('\nTest 4: CSRF security rejection on profile update');
  const csrfResponse = await page.request.post(memberBaseUrl + '/profile/update', {
    form: {
      full_name: 'CSRF Attacker',
      email: 'member@test.com'
    }
  });
  const csrfStatus = csrfResponse.status();
  log('CSRF missing returns error code', csrfStatus === 419 || csrfStatus === 302 || csrfStatus >= 400 ? 'PASS' : 'FAIL', `http_status=${csrfStatus}`);

  // Test 5: Profile Photo Upload & Display across views
  console.log('\nTest 5: Profile photo upload and multi-view rendering');
  await page.goto(memberBaseUrl + '/profile');
  await page.waitForLoadState('networkidle');

  // Create a 1x1 transparent PNG buffer for testing photo upload
  const sampleImageBuffer = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64');
  
  await page.setInputFiles('input[name="photo"]', {
    name: 'test_avatar.png',
    mimeType: 'image/png',
    buffer: sampleImageBuffer
  });
  await page.click('button[type="submit"]');
  await page.waitForLoadState('networkidle');

  // Verify photo rendered on profile page
  const profileAvatarCount = await page.locator('.member-profile-avatar-img').count();
  
  // Verify photo rendered on portal page
  await page.goto(memberBaseUrl);
  await page.waitForLoadState('networkidle');
  const portalAvatarCount = await page.locator('.member-overview-avatar img').count();

  // Verify photo rendered on card page
  await page.goto(memberBaseUrl + '/card');
  await page.waitForLoadState('networkidle');
  const cardAvatarCount = await page.locator('.member-card-photo img').count();

  log('Profile photo uploaded and rendered in all 3 views', profileAvatarCount > 0 && portalAvatarCount > 0 && cardAvatarCount > 0 ? 'PASS' : 'FAIL', `profileImg=${profileAvatarCount}, portalImg=${portalAvatarCount}, cardImg=${cardAvatarCount}`);

  // Test 6: Membership status lifecycle display
  console.log('\nTest 6: Membership status badge display');
  await page.goto(memberBaseUrl);
  await page.waitForLoadState('networkidle');
  const statusBadgeCount = await page.locator('.member-status').count();
  log('Membership status badge rendered on portal', statusBadgeCount > 0 ? 'PASS' : 'FAIL', `count=${statusBadgeCount}`);

  // Test 7: Legacy Auth Hardening (Verify invalid fallback password fails)
  console.log('\nTest 7: Legacy auth hardening verification');
  await context.clearCookies();
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');

  const loginEmail = page.locator('input[name="email"], input[name="login_input"]').first();
  const loginPass = page.locator('input[name="password"]').first();

  // Wrong password (trying invalid credential)
  await loginEmail.fill('member@test.com');
  await loginPass.fill('wrongpassword123');
  await page.click('button[type="submit"]');
  await page.waitForLoadState('networkidle');

  const failedUrl = page.url();
  const loginDenied = failedUrl.includes('/login');
  log('Invalid password correctly rejected', loginDenied ? 'PASS' : 'FAIL', `url=${failedUrl}`);

  await browser.close();

  console.log('\n=== PHASE 6C RESULTS ===');
  const pass = results.filter(r => r.status === 'PASS').length;
  const fail = results.filter(r => r.status === 'FAIL').length;
  const blocked = results.filter(r => r.status === 'BLOCKED').length;

  console.log(`PASS: ${pass}`);
  console.log(`FAIL: ${fail}`);
  console.log(`BLOCKED: ${blocked}`);

  if (fail > 0) {
    console.log('\n=== FAILURES ===');
    results.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`- ${r.name}: ${r.details}`);
    });
    process.exit(1);
  }
}

testPhase6C().catch(e => {
  console.error('Test error:', e);
  process.exit(1);
});
