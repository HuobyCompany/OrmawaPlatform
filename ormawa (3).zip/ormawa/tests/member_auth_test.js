const { chromium } = require('playwright');

const BASE_URL = 'http://localhost:8080';
const results = [];

function log(name, status, details = '') {
  results.push({ name, status, details });
  console.log(`[${status}] ${name}${details ? ' - ' + details : ''}`);
}

async function testMemberPortalAccess() {
  console.log('=== MEMBER PORTAL AUTHORIZATION TESTS ===\n');
  
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Test 1: Anonymous user accessing /member redirects to login
  console.log('Test 1: Anonymous → /member redirects to login');
  await page.goto(BASE_URL + '/member');
  await page.waitForLoadState('networkidle');
  const currentUrl = page.url();
  const redirectsToLogin = currentUrl.includes('/login');
  log('Anonymous → /member redirects to login', redirectsToLogin ? 'PASS' : 'FAIL', `url=${currentUrl}`);

  // Test 2: Anonymous user accessing /admin redirects to login
  console.log('\nTest 2: Anonymous → /admin redirects to login');
  await page.goto(BASE_URL + '/admin');
  await page.waitForLoadState('networkidle');
  const adminUrl = page.url();
  const adminRedirectsToLogin = adminUrl.includes('/login');
  log('Anonymous → /admin redirects to login', adminRedirectsToLogin ? 'PASS' : 'FAIL', `url=${adminUrl}`);

  // Test 3: Member login
  console.log('\nTest 3: Member login (member@test.com)');
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  
  const emailInput = page.locator('input[name="email"], input[name="login_input"]').first();
  const passwordInput = page.locator('input[name="password"]').first();
  
  if (await emailInput.count() > 0 && await passwordInput.count() > 0) {
    await emailInput.fill('member@test.com');
    await passwordInput.fill('test123'); // Test password
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
    
    const afterLoginUrl = page.url();
    const memberLoggedIn = afterLoginUrl.includes('/member') || afterLoginUrl.includes('/test-org/member');
    log('Member login redirects to member portal', memberLoggedIn ? 'PASS' : 'FAIL', `url=${afterLoginUrl}`);
    
    // Test 4: Member accessing /admin is denied
    console.log('\nTest 4: Member → /admin access denied');
    await page.goto(BASE_URL + '/admin');
    await page.waitForLoadState('networkidle');
    const afterAdminAccess = page.url();
    const memberAdminDenied = afterAdminAccess.includes('/member') || afterAdminAccess.includes('/login');
    log('Member → /admin access denied', memberAdminDenied ? 'PASS' : 'FAIL', `url=${afterAdminAccess}`);
    
    // Test 5: Member can access /member
    console.log('\nTest 5: Member → /member access granted');
    await page.goto(BASE_URL + '/member');
    await page.waitForLoadState('networkidle');
    const memberPortalUrl = page.url();
    const memberCanAccess = memberPortalUrl.includes('/member');
    log('Member → /member access granted', memberCanAccess ? 'PASS' : 'FAIL', `url=${memberPortalUrl}`);
    
    // Test 6: Logout
    console.log('\nTest 6: Member logout');
    await page.goto(BASE_URL + '/admin/logout'); // Use GET for logout
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500); // Wait for session to clear
    
    // Clear cookies to ensure logout
    await context.clearCookies();
    
    // Try to access member portal again - should redirect to login
    await page.goto(BASE_URL + '/member');
    await page.waitForLoadState('networkidle');
    const afterLogoutAccess = page.url();
    const loggedOut = afterLogoutAccess.includes('/login');
    log('Member logout successful', loggedOut ? 'PASS' : 'FAIL', `after logout, /member redirects to login: ${afterLogoutAccess}`);
  } else {
    log('Member login test', 'BLOCKED', 'Login form not found');
  }

  // Test 7: Admin login
  console.log('\nTest 7: Admin login (admin@example.com)');
  // Clear context to ensure we're logged out
  await context.clearCookies();
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  
  if (await emailInput.count() > 0 && await passwordInput.count() > 0) {
    await emailInput.clear();
    await passwordInput.clear();
    await emailInput.fill('admin@example.com');
    await passwordInput.fill('admin123'); // Test password
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
    
    const afterAdminLoginUrl = page.url();
    const adminLoggedIn = afterAdminLoginUrl.includes('/admin/dashboard');
    log('Admin login redirects to admin dashboard', adminLoggedIn ? 'PASS' : 'FAIL', `url=${afterAdminLoginUrl}`);
    
    // Test 8: Admin can still access admin
    console.log('\nTest 8: Admin → /admin access granted');
    await page.goto(BASE_URL + '/admin');
    await page.waitForLoadState('networkidle');
    const adminAccessUrl = page.url();
    const adminCanAccess = adminAccessUrl.includes('/admin');
    log('Admin → /admin access granted', adminCanAccess ? 'PASS' : 'FAIL', `url=${adminAccessUrl}`);
    
    // Test 9: Admin logout
    console.log('\nTest 9: Admin logout');
    await page.goto(BASE_URL + '/admin/logout'); // Use GET for logout
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500); // Wait for session to clear
    
    // Clear cookies to ensure logout
    await context.clearCookies();
    
    // Try to access admin again - should redirect to login
    await page.goto(BASE_URL + '/admin');
    await page.waitForLoadState('networkidle');
    const afterAdminLogoutAccess = page.url();
    const adminLoggedOut = afterAdminLogoutAccess.includes('/login');
    log('Admin logout successful', adminLoggedOut ? 'PASS' : 'FAIL', `after logout, /admin redirects to login: ${afterAdminLogoutAccess}`);
  } else {
    log('Admin login test', 'BLOCKED', 'Login form not found');
  }

  await browser.close();
  
  console.log('\n=== MEMBER PORTAL AUTHORIZATION RESULTS ===');
  const pass = results.filter(r => r.status === 'PASS').length;
  const fail = results.filter(r => r.status === 'FAIL').length;
  const blocked = results.filter(r => r.status === 'BLOCKED').length;
  
  console.log(`PASS: ${pass}`);
  console.log(`FAIL: ${fail}`);
  console.log(`BLOCKED: ${blocked}`);
  
  if (fail > 0) {
    console.log('\n=== FAILURES ===');
    results.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`- ${r.name}: ${r.details}`);
    });
  }
}

testMemberPortalAccess().catch(e => {
  console.error('Test error:', e);
  process.exit(1);
});
