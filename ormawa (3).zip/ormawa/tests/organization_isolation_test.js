const { chromium } = require('playwright');

const BASE_URL = 'http://localhost:8080';
const results = [];

function log(name, status, details = '') {
  results.push({ name, status, details });
  console.log(`[${status}] ${name}${details ? ' - ' + details : ''}`);
}

async function testOrganizationIsolation() {
  console.log('=== ORGANIZATION ISOLATION TESTS ===\n');
  
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Test 1: Test Organization (test-org) member accessing KIMURA member portal
  console.log('Test 1: Test Organization member → KIMURA member portal');
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  
  const emailInput = page.locator('input[name="email"], input[name="login_input"]').first();
  const passwordInput = page.locator('input[name="password"]').first();
  
  if (await emailInput.count() > 0 && await passwordInput.count() > 0) {
    await emailInput.fill('member@test.com');
    await passwordInput.fill('test123');
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
    
    const loginUrl = page.url();
    const loggedIn = loginUrl.includes('/member') || loginUrl.includes('/test-org/member');
    log('Test Organization member login', loggedIn ? 'PASS' : 'FAIL', `url=${loginUrl}`);
    
    // Try to access KIMURA member portal directly
    console.log('\nTest 2: Test Organization member → KIMURA member portal (cross-org access)');
    await page.goto(BASE_URL + '/kimura/member');
    await page.waitForLoadState('networkidle');
    const kimuraAccessUrl = page.url();
    const kimuraAccessDenied = kimuraAccessUrl.includes('/login') || kimuraAccessUrl.includes('/test-org/member') || kimuraAccessUrl.endsWith('/member');
    log('Cross-org member access denied', kimuraAccessDenied ? 'PASS' : 'FAIL', `url=${kimuraAccessUrl}`);
    
    // Try to access KIMURA admin
    console.log('\nTest 3: Test Organization member → KIMURA admin (cross-org access)');
    await page.goto(BASE_URL + '/kimura/admin');
    await page.waitForLoadState('networkidle');
    const kimuraAdminUrl = page.url();
    const kimuraAdminDenied = kimuraAdminUrl.includes('/login') || kimuraAdminUrl.includes('/test-org/member') || kimuraAdminUrl.endsWith('/member');
    log('Cross-org admin access denied', kimuraAdminDenied ? 'PASS' : 'FAIL', `url=${kimuraAdminUrl}`);
    
    // Logout
    await context.clearCookies();
  } else {
    log('Organization isolation test', 'BLOCKED', 'Login form not found');
  }

  // Test 4: KIMURA admin accessing Test Organization admin
  console.log('\nTest 4: KIMURA admin → Test Organization admin (cross-org access)');
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  
  if (await emailInput.count() > 0 && await passwordInput.count() > 0) {
    await emailInput.clear();
    await passwordInput.clear();
    await emailInput.fill('admin@example.com');
    await passwordInput.fill('admin123');
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
    
    const adminLoginUrl = page.url();
    const adminLoggedIn = adminLoginUrl.includes('/admin/dashboard');
    log('KIMURA admin login', adminLoggedIn ? 'PASS' : 'FAIL', `url=${adminLoginUrl}`);
    
    // Try to access Test Organization admin directly
    console.log('\nTest 5: KIMURA admin → Test Organization admin (cross-org access)');
    await page.goto(BASE_URL + '/test-org/admin');
    await page.waitForLoadState('networkidle');
    const testOrgAdminUrl = page.url();
    const testOrgAdminDenied = testOrgAdminUrl.includes('/login') || testOrgAdminUrl.includes('/kimura/admin') || testOrgAdminUrl.includes('/admin');
    log('Cross-org admin access denied', testOrgAdminDenied ? 'PASS' : 'FAIL', `url=${testOrgAdminUrl}`);
    
    // Logout
    await context.clearCookies();
  } else {
    log('Admin isolation test', 'BLOCKED', 'Login form not found');
  }

  // Test 6: Super admin accessing both organizations
  console.log('\nTest 6: Super admin → KIMURA (should have access)');
  await page.goto(BASE_URL + '/login');
  await page.waitForLoadState('networkidle');
  
  if (await emailInput.count() > 0 && await passwordInput.count() > 0) {
    await emailInput.clear();
    await passwordInput.clear();
    await emailInput.fill('super@example.com');
    await passwordInput.fill('admin123');
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
    
    const superLoginUrl = page.url();
    const superLoggedIn = superLoginUrl.includes('/admin/dashboard');
    log('Super admin login', superLoggedIn ? 'PASS' : 'FAIL', `url=${superLoginUrl}`);
    
    // Super admin should be able to access any organization
    console.log('\nTest 7: Super admin → Test Organization (should have access)');
    await page.goto(BASE_URL + '/test-org/admin');
    await page.waitForLoadState('networkidle');
    const superTestOrgUrl = page.url();
    const superCanAccess = superTestOrgUrl.includes('/test-org/admin') || superTestOrgUrl.includes('/admin/dashboard');
    log('Super admin cross-org access granted', superCanAccess ? 'PASS' : 'FAIL', `url=${superTestOrgUrl}`);
    
    // Logout
    await context.clearCookies();
  } else {
    log('Super admin test', 'BLOCKED', 'Login form not found');
  }

  await browser.close();
  
  console.log('\n=== ORGANIZATION ISOLATION RESULTS ===');
  const pass = results.filter(r => r.status === 'PASS').length;
  const fail = results.filter(r => r.status === 'FAIL').length;
  const blocked = results.filter(r => r.status === 'BLOCKED').length;
  
  console.log(`PASS: ${pass}`);
  console.log(`FAIL: ${fail}`);
  console.log(`BLOCKED: ${blocked}`);
  
  if (fail > 0) {
    console.log('\n=== FAILURES ===');
    results.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`- ${r.name}: ${r.details}`);
    });
  }
}

testOrganizationIsolation().catch(e => {
  console.error('Test error:', e);
  process.exit(1);
});
