const { chromium } = require('playwright');
const { execSync } = require('child_process');

const BASE_URL = 'http://localhost:8080';
const results = [];

function log(name, status, details = '') {
  results.push({ name, status, details });
  console.log(`[${status}] ${name}${details ? ' - ' + details : ''}`);
}

async function testPhase7() {
  console.log('=== PHASE 7 AUTOMATED TEST SUITE ===\n');

  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();

  // Test 1: Admin login
  console.log('Test 1: Admin login (admin@example.com)');
  await page.goto(BASE_URL + '/admin/login');
  await page.waitForLoadState('networkidle');

  const loginInput = page.locator('input[name="login_input"], input[name="email"]').first();
  await loginInput.fill('admin@example.com');
  await page.fill('input[name="password"]', 'admin123');
  await page.click('button[type="submit"]');
  await page.waitForLoadState('networkidle');

  const adminUrl = page.url();
  const isAdminLoggedIn = adminUrl.includes('/admin/dashboard');
  log('Admin login success', isAdminLoggedIn ? 'PASS' : 'FAIL', `url=${adminUrl}`);

  // Test 2: Public registration submission
  console.log('\nTest 2: Public registration submission via /test-org/join');
  await page.goto(BASE_URL + '/test-org/join');
  await page.waitForLoadState('networkidle');

  const testName = 'Phase7 Candidate ' + Date.now();
  const testWa = '0877' + Math.floor(10000000 + Math.random() * 90000000);

  // Fill mandatory core registration fields if present
  const coreNameInput = page.locator('input[name="core_full_name"]');
  if (await coreNameInput.count() > 0) {
    await coreNameInput.fill(testName);
    await page.selectOption('select[name="core_faculty_id"]', { index: 1 });
    await page.waitForTimeout(300);
    await page.selectOption('select[name="core_program_id"]', { index: 1 });
    await page.fill('input[name="core_whatsapp"]', testWa);
    await page.selectOption('select[name="core_batch_year"]', { index: 1 });
    await page.click('button[type="submit"]');
    await page.waitForLoadState('networkidle');
  }

  // Test 3: Admin review & registration submission detail page
  console.log('\nTest 3: View pending submissions in admin panel');
  await page.goto(BASE_URL + '/admin/registration/submissions');
  await page.waitForLoadState('networkidle');

  const submissionRows = await page.locator('table tbody tr').count();
  log('Submissions list accessible', submissionRows > 0 ? 'PASS' : 'FAIL', `rows=${submissionRows}`);

  // Navigate to first detail page using Review button
  const detailLink = page.locator('a[href*="/admin/registration/submission/"]').first();
  await detailLink.click();
  await page.waitForLoadState('networkidle');

  const detailUrl = page.url();
  log('Submission detail view rendered', detailUrl.includes('/submission/') ? 'PASS' : 'FAIL', `url=${detailUrl}`);

  // Test 4: Member Lifecycle Trace Panel
  console.log('\nTest 4: Member Lifecycle Trace Panel rendering');
  const traceCardCount = await page.locator('.bi-diagram-3-fill').count();
  log('Lifecycle Trace Panel rendered on detail view', traceCardCount > 0 ? 'PASS' : 'FAIL', `traceCards=${traceCardCount}`);

  // Test 5: Transactional Approval
  console.log('\nTest 5: Transactional Approval execution');
  const approveForm = page.locator('form[action*="/submission/approve"]');
  if (await approveForm.count() > 0) {
    await page.fill('form[action*="/submission/approve"] textarea[name="reviewer_notes"]', 'Automated Phase 7 Approval Test');
    await page.click('form[action*="/submission/approve"] button[type="submit"]');
    await page.waitForLoadState('networkidle');

    const approveSuccess = await page.locator('.alert-success').count();
    const approvedBadge = await page.locator('.badge:has-text("Disetujui")').count();
    log('Submission approved transactionally', approveSuccess > 0 || approvedBadge > 0 ? 'PASS' : 'FAIL', `successAlert=${approveSuccess}`);
  } else {
    log('Submission already approved / no pending form', 'PASS', 'Already approved in prior run');
  }

  // Test 6: Database Data Consistency & Mapping Check
  console.log('\nTest 6: Database Person => Member => Mapping verification via PHP PDO');
  let dbCheckOutput = '';
  try {
    dbCheckOutput = execSync('php tests/helpers/check_db_mapping.php', { cwd: process.cwd() }).toString().trim();
  } catch (e) {
    dbCheckOutput = e.message;
  }

  const isDbValid = dbCheckOutput.includes('member_id') && dbCheckOutput.includes('person_id');
  log('Database relational integrity verified', isDbValid ? 'PASS' : 'FAIL', `output=${dbCheckOutput}`);

  // Test 7: Idempotency (Re-approving approved submission does not duplicate records)
  console.log('\nTest 7: Idempotency check');
  const membersBefore = parseInt(execSync('php tests/helpers/count_table.php members', { cwd: process.cwd() }).toString().trim());
  const personsBefore = parseInt(execSync('php tests/helpers/count_table.php persons', { cwd: process.cwd() }).toString().trim());

  // Trigger re-approval programmatically via helper script
  execSync('php tests/helpers/trigger_reapproval.php', { cwd: process.cwd() });

  const membersAfter = parseInt(execSync('php tests/helpers/count_table.php members', { cwd: process.cwd() }).toString().trim());
  const personsAfter = parseInt(execSync('php tests/helpers/count_table.php persons', { cwd: process.cwd() }).toString().trim());

  const isIdempotent = (membersBefore === membersAfter) && (personsBefore === personsAfter);
  log('Idempotent re-approval (no duplicate Person/Member)', isIdempotent ? 'PASS' : 'FAIL', `membersBefore=${membersBefore} after=${membersAfter}, personsBefore=${personsBefore} after=${personsAfter}`);

  await browser.close();

  console.log('\n=== PHASE 7 RESULTS ===');
  const pass = results.filter(r => r.status === 'PASS').length;
  const fail = results.filter(r => r.status === 'FAIL').length;
  const blocked = results.filter(r => r.status === 'BLOCKED').length;

  console.log(`PASS: ${pass}`);
  console.log(`FAIL: ${fail}`);
  console.log(`BLOCKED: ${blocked}`);

  if (fail > 0) {
    console.log('\n=== FAILURES ===');
    results.filter(r => r.status === 'FAIL').forEach(r => {
      console.log(`- ${r.name}: ${r.details}`);
    });
    process.exit(1);
  }
}

testPhase7().catch(e => {
  console.error('Test error:', e);
  process.exit(1);
});
