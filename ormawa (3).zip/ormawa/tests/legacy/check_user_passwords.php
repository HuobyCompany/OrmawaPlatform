<?php
declare(strict_types=1);
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';
require __DIR__ . '/../app/core/Database.php';

$pdo = Database::connection();

echo "=== CHECK TEST USER PASSWORDS ===\n\n";

// Check member@test.com
$stmt = $pdo->prepare('SELECT id, email, role FROM users WHERE email = "member@test.com"');
$stmt->execute();
$memberUser = $stmt->fetch();

if ($memberUser) {
    echo "Found member@test.com:\n";
    echo "ID: {$memberUser['id']}\n";
    echo "Email: {$memberUser['email']}\n";
    echo "Role: {$memberUser['role']}\n";
    
    // Test with common test passwords
    $testPasswords = ['password', 'admin123', 'password123', 'member123', 'test123'];
    $noneWork = true;
    
    $stmt = $pdo->prepare('SELECT password FROM users WHERE id = 12');
    $stmt->execute();
    $hash = $stmt->fetch()['password'];
    
    echo "\nTesting common passwords:\n";
    foreach ($testPasswords as $testPw) {
        if (password_verify($testPw, $hash)) {
            echo "✅ Password '{$testPw}' works!\n";
        }
    }
    
    // If none work, let's set a known password
    $noneWork = true;
    foreach ($testPasswords as $testPw) {
        if (password_verify($testPw, $hash)) {
            $noneWork = false;
            break;
        }
    }
    
    if ($noneWork) {
        echo "⚠️  None of the common test passwords work.\n";
        echo "Setting password to 'password123' for testing...\n";
        $newHash = password_hash('password123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('UPDATE users SET password = :hash WHERE id = 12');
        $stmt->execute(['hash' => $newHash]);
        echo "✅ Password updated to 'password123'\n";
    }
} else {
    echo "❌ member@test.com not found\n";
}

// Check admin@example.com
echo "\n---\n";
$stmt = $pdo->prepare('SELECT id, email, role FROM users WHERE email = "admin@example.com"');
$stmt->execute();
$adminUser = $stmt->fetch();

if ($adminUser) {
    echo "Found admin@example.com:\n";
    echo "ID: {$adminUser['id']}\n";
    echo "Email: {$adminUser['email']}\n";
    echo "Role: {$adminUser['role']}\n";
    
    $stmt = $pdo->prepare('SELECT password FROM users WHERE id = 1');
    $stmt->execute();
    $hash = $stmt->fetch()['password'];
    
    echo "\nTesting common passwords:\n";
    foreach ($testPasswords as $testPw) {
        if (password_verify($testPw, $hash)) {
            echo "✅ Password '{$testPw}' works!\n";
        }
    }
    
    if ($noneWork) {
        echo "⚠️  None of the common test passwords work.\n";
        echo "Setting password to 'admin123' for testing...\n";
        $newHash = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare('UPDATE users SET password = :hash WHERE id = 1');
        $stmt->execute(['hash' => $newHash]);
        echo "✅ Password updated to 'admin123'\n";
    }
} else {
    echo "❌ admin@example.com not found\n";
}

echo "\n=== PASSWORD CHECK COMPLETE ===\n";
