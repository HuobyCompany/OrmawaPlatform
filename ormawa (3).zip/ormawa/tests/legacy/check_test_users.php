<?php
// Check existing users for manual testing
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';

foreach(glob(BASE_PATH.'/app/helpers/*.php') as $f) require_once $f;
foreach([BASE_PATH.'/app/core/Database.php'] as $f) require_once $f;

echo "=== Existing Users for Testing ===\n\n";

try {
    $pdo = Database::connection();
    
    // Check all users
    $stmt = $pdo->query("SELECT id, name, email, role, organization_id, status FROM users ORDER BY role, id");
    $users = $stmt->fetchAll();
    
    echo "Users table:\n";
    foreach ($users as $user) {
        echo "- ID: {$user['id']}, Name: {$user['name']}, Email: {$user['email']}, Role: {$user['role']}, Org: {$user['organization_id']}, Status: {$user['status']}\n";
    }
    
    // Check organizations
    $stmt = $pdo->query("SELECT id, name, slug FROM organizations");
    $orgs = $stmt->fetchAll();
    
    echo "\nOrganizations:\n";
    foreach ($orgs as $org) {
        echo "- ID: {$org['id']}, Name: {$org['name']}, Slug: {$org['slug']}\n";
    }
    
    // Check members (for potential member account testing)
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM members");
    $memberCount = $stmt->fetch();
    echo "\nMembers count: {$memberCount['count']}\n";
    
    // Check registration_submissions (for legacy member testing)
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM registration_submissions WHERE status = 'approved'");
    $regCount = $stmt->fetch();
    echo "Approved registration_submissions count: {$regCount['count']}\n";
    
    // Check user_account_members links
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM user_account_members");
    $linkCount = $stmt->fetch();
    echo "User-account-members links count: {$linkCount['count']}\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
