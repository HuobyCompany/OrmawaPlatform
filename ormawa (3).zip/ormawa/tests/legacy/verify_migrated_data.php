<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';

$pdo = Database::connection();

echo "=== MIGRATED DATA VERIFICATION ===\n";

$maps = $pdo->query('SELECT * FROM legacy_structure_mappings')->fetchAll(PDO::FETCH_ASSOC);
echo "Mappings count: " . count($maps) . "\n";
foreach ($maps as $m) {
    echo " Legacy #{$m['legacy_position_id']} -> Term: {$m['term_id']} | Group: {$m['group_id']} | Position: {$m['position_id']} | Person: " . ($m['person_id'] ?? 'NULL (VACANT)') . " | Assignment: {$m['assignment_id']}\n";
}

$assignments = $pdo->query('SELECT pa.id, t.name as term_name, g.name as group_name, pos.title as position_title, p.full_name as person_name, pa.status FROM position_assignments pa JOIN organization_terms t ON pa.term_id = t.id JOIN positions pos ON pa.position_id = pos.id JOIN structure_groups g ON pos.group_id = g.id LEFT JOIN persons p ON pa.person_id = p.id ORDER BY pa.id ASC')->fetchAll(PDO::FETCH_ASSOC);

echo "\nPosition Assignments in DB:\n";
foreach ($assignments as $a) {
    echo " Assignment #{$a['id']} | Term: {$a['term_name']} | Group: {$a['group_name']} | Title: {$a['position_title']} | Person: " . ($a['person_name'] ?? 'VACANT') . " | Status: {$a['status']}\n";
}
