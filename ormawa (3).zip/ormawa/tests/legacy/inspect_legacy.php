<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';

$pdo = Database::connection();
$rows = $pdo->query('SELECT * FROM organization_positions')->fetchAll(PDO::FETCH_ASSOC);
echo "Total organization_positions rows: " . count($rows) . "\n\n";

foreach ($rows as $r) {
    echo "ID: {$r['id']} | Org: {$r['organization_id']} | Parent: " . ($r['parent_id'] ?? 'NULL') . " | PosName: {$r['position_name']} | Person: " . ($r['person_name'] ?? 'NULL') . " | Period: " . ($r['period'] ?? 'NULL') . " | Photo: " . ($r['photo'] ?? 'NULL') . " | Status: {$r['status']}\n";
}
