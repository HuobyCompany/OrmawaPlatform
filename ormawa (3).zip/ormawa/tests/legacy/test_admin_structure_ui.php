<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/View.php';
require_once __DIR__ . '/../app/models/OrganizationModel.php';
require_once __DIR__ . '/../app/models/TermModel.php';
require_once __DIR__ . '/../app/models/PersonModel.php';
require_once __DIR__ . '/../app/models/StructureGroupModel.php';
require_once __DIR__ . '/../app/models/StructurePositionModel.php';
require_once __DIR__ . '/../app/models/PositionAssignmentModel.php';
require_once __DIR__ . '/../app/services/PersonService.php';
require_once __DIR__ . '/../app/services/StructureService.php';
require_once __DIR__ . '/../app/controllers/OrganizationController.php';
require_once __DIR__ . '/../app/controllers/StructureController.php';

echo "=== TESTING ADMIN STRUCTURE BUILDER UI & CONTROLLER ===\n";

$_SESSION['user_id'] = 1; // Fake login session
$_SESSION['organization_id'] = 1;

try {
    $st = new StructureController();

    // 1. Fetch main index data
    echo "1. Fetching main admin structure dashboard data...\n";
    $org = OrganizationModel::findById(1);
    $terms = TermModel::all(1);
    $groups = StructureGroupModel::all(1);
    
    echo "   [OK] Found " . count($terms) . " terms and " . count($groups) . " groups.\n";

    // 2. Test group management data
    if (!empty($groups)) {
        $firstGroup = $groups[0];
        echo "2. Managing Group #{$firstGroup['id']} ('{$firstGroup['name']}')...\n";
        $positions = StructurePositionModel::all(1, (int)$firstGroup['id']);
        echo "   [OK] Group has " . count($positions) . " positions.\n";
    }

    echo "=== ALL ADMIN STRUCTURE BUILDER TESTS PASSED ===\n";

} catch (Exception $e) {
    echo "[FAIL] Error: " . $e->getMessage() . "\n";
    exit(1);
}
