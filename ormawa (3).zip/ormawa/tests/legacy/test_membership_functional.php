<?php
/**
 * Membership Functional Verification Tests
 * Tests actual CRUD operations and business logic for Person/Member/User Account separation
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/constants.php';

// Load helpers
foreach(glob(__DIR__ . '/../app/helpers/*.php') as $f) require_once $f;

// Load core Database class
require_once __DIR__ . '/../app/core/Database.php';

// Get database connection
$pdo = Database::connection();

// Load only the specific models and services we need
require_once __DIR__ . '/../app/models/MemberModel.php';
require_once __DIR__ . '/../app/models/PersonModel.php';
require_once __DIR__ . '/../app/models\UserModel.php';
require_once __DIR__ . '/../app/services/MemberService.php';

echo "=== Membership Functional Verification Tests ===\n\n";

$testResults = [
    'passed' => 0,
    'failed' => 0,
    'tests' => []
];

/**
 * Test helper function
 */
function runTest(string $name, callable $test): void {
    global $testResults;
    echo "Testing: {$name}... ";
    try {
        $result = $test();
        if ($result) {
            echo "✅ PASS\n";
            $testResults['passed']++;
            $testResults['tests'][$name] = 'pass';
        } else {
            echo "❌ FAIL\n";
            $testResults['failed']++;
            $testResults['tests'][$name] = 'fail';
        }
    } catch (Exception $e) {
        echo "❌ ERROR: " . $e->getMessage() . "\n";
        $testResults['failed']++;
        $testResults['tests'][$name] = 'error';
    }
}

$orgId = 1; // Test with organization ID 1

// Clean up any test data from previous runs
$cleanupStmt = $pdo->prepare('DELETE FROM member_audit WHERE member_id IN (SELECT id FROM members WHERE member_number LIKE "TEST%")');
$cleanupStmt->execute();
$cleanupStmt = $pdo->prepare('DELETE FROM members WHERE member_number LIKE "TEST%"');
$cleanupStmt->execute();
$cleanupStmt = $pdo->prepare('DELETE FROM persons WHERE full_name LIKE "TEST%"');
$cleanupStmt->execute();
$cleanupStmt = $pdo->prepare('DELETE FROM position_assignments WHERE person_id IN (SELECT id FROM persons WHERE full_name LIKE "TEST%")');
$cleanupStmt->execute();
$cleanupStmt = $pdo->prepare('DELETE FROM positions WHERE title LIKE "TEST%"');
$cleanupStmt->execute();
$cleanupStmt = $pdo->prepare('DELETE FROM users WHERE email LIKE "test%@example.com"');
$cleanupStmt->execute();

echo "=== Before Test Data Counts ===\n";
$beforeCounts = [
    'persons' => $pdo->query('SELECT COUNT(*) FROM persons WHERE organization_id = ' . $orgId)->fetchColumn(),
    'members' => $pdo->query('SELECT COUNT(*) FROM members WHERE organization_id = ' . $orgId)->fetchColumn(),
    'users' => $pdo->query('SELECT COUNT(*) FROM users WHERE organization_id = ' . $orgId)->fetchColumn(),
    'reg_submissions' => $pdo->query('SELECT COUNT(*) FROM registration_submissions WHERE organization_id = ' . $orgId)->fetchColumn(),
    'member_audit' => $pdo->query('SELECT COUNT(*) FROM member_audit')->fetchColumn(),
    'mapping' => $pdo->query('SELECT COUNT(*) FROM registration_member_mapping')->fetchColumn()
];
foreach ($beforeCounts as $table => $count) {
    echo "{$table}: {$count}\n";
}
echo "\n";

// Test 1: Create Person without Member
runTest('Create Person without Member', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Person No Member',
        'email' => 'testnomember@example.com',
        'phone' => '081234567890'
    ], null, $orgId);

    if (!$personId) return false;

    // Verify person exists
    $person = PersonModel::find($personId, $orgId);
    if (!$person) return false;

    // Verify no member exists for this person
    $member = MemberModel::findByPersonId($personId, $orgId);
    if ($member) return false; // Should not have member

    // Cleanup
    PersonModel::delete($personId, $orgId);
    return true;
});

// Test 2: Create Member without User Account
runTest('Create Member without User Account', function() use ($orgId, $pdo) {
    // Create person
    $personId = PersonModel::save([
        'full_name' => 'TEST Member No User',
        'email' => 'testmembernouser@example.com',
        'phone' => '081234567891'
    ], null, $orgId);

    if (!$personId) return false;

    // Create member
    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'active',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    // Verify member exists
    $member = MemberModel::find($memberId, $orgId);
    if (!$member) return false;

    // Verify no user account with this email
    $userCheck = $pdo->prepare('SELECT COUNT(*) FROM users WHERE email = :email');
    $userCheck->execute(['email' => 'testmembernouser@example.com']);
    $userCount = (int)$userCheck->fetchColumn();

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $userCount === 0;
});

// Test 3: Link Member to User Account (simulated - just verify relationship can exist)
runTest('Member can be linked to User Account', function() use ($orgId, $pdo) {
    // Create person
    $personId = PersonModel::save([
        'full_name' => 'TEST Member With User',
        'email' => 'testmemberwithuser@example.com',
        'phone' => '081234567892'
    ], null, $orgId);

    if (!$personId) return false;

    // Create member
    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'active',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    // Create user account (simulating link)
    $userId = UserModel::save([
        'organization_id' => $orgId,
        'name' => 'TEST Member With User',
        'email' => 'testmemberwithuser@example.com',
        'password' => password_hash('test123', PASSWORD_DEFAULT),
        'role' => 'editor',
        'status' => 'active'
    ]);

    if (!$userId) return false;

    // Verify both exist independently
    $member = MemberModel::find($memberId, $orgId);
    $user = UserModel::find($userId, $orgId);

    // Cleanup
    UserModel::delete($userId, $orgId);
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $member !== false && $user !== false;
});

// Test 4: Pending status works
runTest('Pending status works', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Pending Member',
        'email' => 'testpending@example.com',
        'phone' => '081234567893'
    ], null, $orgId);

    if (!$personId) return false;

    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'pending',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    $member = MemberModel::find($memberId, $orgId);
    $isPending = $member && $member['status'] === 'pending';

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $isPending;
});

// Test 5: Active status works
runTest('Active status works', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Active Member',
        'email' => 'testactive@example.com',
        'phone' => '081234567894'
    ], null, $orgId);

    if (!$personId) return false;

    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'active',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    $member = MemberModel::find($memberId, $orgId);
    $isActive = $member && $member['status'] === 'active';

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $isActive;
});

// Test 6: Rejected status works
runTest('Rejected status works', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Rejected Member',
        'email' => 'testrejected@example.com',
        'phone' => '081234567895'
    ], null, $orgId);

    if (!$personId) return false;

    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'rejected',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    $member = MemberModel::find($memberId, $orgId);
    $isRejected = $member && $member['status'] === 'rejected';

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $isRejected;
});

// Test 7: Suspended status works
runTest('Suspended status works', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Suspended Member',
        'email' => 'testsuspended@example.com',
        'phone' => '081234567896'
    ], null, $orgId);

    if (!$personId) return false;

    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'suspended',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    $member = MemberModel::find($memberId, $orgId);
    $isSuspended = $member && $member['status'] === 'suspended';

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $isSuspended;
});

// Test 8: Inactive status works
runTest('Inactive status works', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Inactive Member',
        'email' => 'testinactive@example.com',
        'phone' => '081234567897'
    ], null, $orgId);

    if (!$personId) return false;

    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'inactive',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    $member = MemberModel::find($memberId, $orgId);
    $isInactive = $member && $member['status'] === 'inactive';

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $isInactive;
});

// Test 9: Alumni status works
runTest('Alumni status works', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Alumni Member',
        'email' => 'testalumni@example.com',
        'phone' => '081234567898'
    ], null, $orgId);

    if (!$personId) return false;

    $memberNumber = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber,
        'status' => 'alumni',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    $member = MemberModel::find($memberId, $orgId);
    $isAlumni = $member && $member['status'] === 'alumni';

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $isAlumni;
});

// Test 10: Member number uniqueness
runTest('Member number uniqueness', function() use ($orgId, $pdo) {
    // Check that members table has unique constraint on member_number
    $stmt = $pdo->query("SHOW INDEX FROM members WHERE Key_name != 'PRIMARY' AND Column_name = 'member_number'");
    $index = $stmt->fetch();

    if (!$index) return false;

    // Check it's a unique index
    return $index['Non_unique'] == 0;
});

// Test 11: Repeated membership across terms
runTest('Repeated membership across terms', function() use ($orgId, $pdo) {
    // Create a test term if needed
    $termStmt = $pdo->prepare('SELECT id FROM organization_terms WHERE organization_id = :org LIMIT 1');
    $termStmt->execute(['org' => $orgId]);
    $term = $termStmt->fetch();

    if (!$term) {
        $termStmt = $pdo->prepare('INSERT INTO organization_terms (organization_id, name, slug, start_date) VALUES (:org, :name, :slug, NOW())');
        $termStmt->execute(['org' => $orgId, 'name' => 'Test Term 2026', 'slug' => 'test-term-2026']);
        $termId = (int)$pdo->lastInsertId();
    } else {
        $termId = (int)$term['id'];
    }

    // Create person
    $personId = PersonModel::save([
        'full_name' => 'TEST Repeated Member',
        'email' => 'testrepeated@example.com',
        'phone' => '081234567811'
    ], null, $orgId);

    if (!$personId) return false;

    // Create first membership
    $memberNumber1 = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId1 = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber1,
        'status' => 'active',
        'current_term_id' => $termId,
        'batch_year' => '2026'
    ]);

    // Create second membership (same person, different term/batch)
    $memberNumber2 = MemberModel::generateMemberNumber($orgId, '2027');
    $memberId2 = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => $memberNumber2,
        'status' => 'active',
        'current_term_id' => null,
        'batch_year' => '2027'
    ]);

    if (!$memberId1 || !$memberId2) return false;

    // Verify both members exist for same person
    $member1 = MemberModel::find($memberId1, $orgId);
    $member2 = MemberModel::find($memberId2, $orgId);

    $bothExist = $member1 && $member2;
    $samePerson = $member1['person_id'] === $member2['person_id'] && $member1['person_id'] == $personId;
    $differentNumbers = $member1['member_number'] !== $member2['member_number'];

    // Cleanup
    MemberModel::delete($memberId1, $orgId);
    MemberModel::delete($memberId2, $orgId);
    PersonModel::delete($personId, $orgId);

    return $bothExist && $samePerson && $differentNumbers;
});

// Test 12: Duplicate person name handling
runTest('Duplicate person name handling', function() use ($orgId, $pdo) {
    // Create two persons with same name but different emails
    $personId1 = PersonModel::save([
        'full_name' => 'TEST Duplicate Name',
        'email' => 'duplicate1@example.com',
        'phone' => '081234567812'
    ], null, $orgId);

    $personId2 = PersonModel::save([
        'full_name' => 'TEST Duplicate Name',
        'email' => 'duplicate2@example.com',
        'phone' => '081234567813'
    ], null, $orgId);

    if (!$personId1 || !$personId2) return false;
    if ($personId1 === $personId2) return false; // Should be different persons

    // Create members for both
    $memberNumber1 = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId1 = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId1,
        'member_number' => $memberNumber1,
        'status' => 'active',
        'batch_year' => '2026'
    ]);

    $memberNumber2 = MemberModel::generateMemberNumber($orgId, '2026');
    $memberId2 = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId2,
        'member_number' => $memberNumber2,
        'status' => 'active',
        'batch_year' => '2026'
    ]);

    if (!$memberId1 || !$memberId2) return false;

    // Verify both members exist with different person_ids
    $member1 = MemberModel::find($memberId1, $orgId);
    $member2 = MemberModel::find($memberId2, $orgId);

    if ($member1['person_id'] === $member2['person_id']) return false;
    if ($member1['member_number'] === $member2['member_number']) return false;

    // Cleanup
    MemberModel::delete($memberId1, $orgId);
    MemberModel::delete($memberId2, $orgId);
    PersonModel::delete($personId1, $orgId);
    PersonModel::delete($personId2, $orgId);

    return true;
});

// Test 13: Multiple structure assignments for one Person
runTest('Multiple structure assignments for one Person', function() use ($orgId, $pdo) {
    // Get/create structure entities
    $termStmt = $pdo->prepare('SELECT id FROM organization_terms WHERE organization_id = :org LIMIT 1');
    $termStmt->execute(['org' => $orgId]);
    $term = $termStmt->fetch();

    if (!$term) {
        $termStmt = $pdo->prepare('INSERT INTO organization_terms (organization_id, name, slug, start_date) VALUES (:org, :name, :slug, NOW())');
        $termStmt->execute(['org' => $orgId, 'name' => 'Test Term Multi', 'slug' => 'test-term-multi']);
        $termId = (int)$pdo->lastInsertId();
    } else {
        $termId = (int)$term['id'];
    }

    $groupStmt = $pdo->prepare('SELECT id FROM structure_groups WHERE organization_id = :org LIMIT 1');
    $groupStmt->execute(['org' => $orgId]);
    $group = $groupStmt->fetch();

    if (!$group) {
        $groupStmt = $pdo->prepare('INSERT INTO structure_groups (organization_id, name) VALUES (:org, :name)');
        $groupStmt->execute(['org' => $orgId, 'name' => 'Test Group Multi']);
        $groupId = (int)$pdo->lastInsertId();
    } else {
        $groupId = (int)$group['id'];
    }

    // Create two positions
    $posStmt1 = $pdo->prepare('INSERT INTO positions (organization_id, group_id, title) VALUES (:org, :gid, :title)');
    $posStmt1->execute(['org' => $orgId, 'gid' => $groupId, 'title' => 'Test Position Multi 1']);
    $positionId1 = (int)$pdo->lastInsertId();

    $posStmt2 = $pdo->prepare('INSERT INTO positions (organization_id, group_id, title) VALUES (:org, :gid, :title)');
    $posStmt2->execute(['org' => $orgId, 'gid' => $groupId, 'title' => 'Test Position Multi 2']);
    $positionId2 = (int)$pdo->lastInsertId();

    // Create person
    $personId = PersonModel::save([
        'full_name' => 'TEST Multi Assign Person',
        'email' => 'testmultiassign@example.com',
        'phone' => '081234567814'
    ], null, $orgId);

    if (!$personId) return false;

    // Create multiple assignments for same person
    $assignStmt1 = $pdo->prepare('INSERT INTO position_assignments (organization_id, term_id, position_id, person_id, start_date, status) VALUES (:org, :tid, :pid, :person, NOW(), "active")');
    $assignStmt1->execute(['org' => $orgId, 'tid' => $termId, 'pid' => $positionId1, 'person' => $personId]);

    $assignStmt2 = $pdo->prepare('INSERT INTO position_assignments (organization_id, term_id, position_id, person_id, start_date, status) VALUES (:org, :tid, :pid, :person, NOW(), "active")');
    $assignStmt2->execute(['org' => $orgId, 'tid' => $termId, 'pid' => $positionId2, 'person' => $personId]);

    // Verify person has multiple assignments
    $assignCheck = $pdo->prepare('SELECT COUNT(*) FROM position_assignments WHERE person_id = :pid');
    $assignCheck->execute(['pid' => $personId]);
    $assignmentCount = (int)$assignCheck->fetchColumn();

    // Cleanup
    $deleteAssign = $pdo->prepare('DELETE FROM position_assignments WHERE person_id = :pid');
    $deleteAssign->execute(['pid' => $personId]);
    $deletePos1 = $pdo->prepare('DELETE FROM positions WHERE id = :id');
    $deletePos1->execute(['id' => $positionId1]);
    $deletePos2 = $pdo->prepare('DELETE FROM positions WHERE id = :id');
    $deletePos2->execute(['id' => $positionId2]);
    PersonModel::delete($personId, $orgId);

    return $assignmentCount === 2;
});

// Test 14: One Person is not duplicated across multiple terms
runTest('One Person not duplicated across terms', function() use ($orgId, $pdo) {
    // Create person
    $personId = PersonModel::save([
        'full_name' => 'TEST No Duplication',
        'email' => 'testnodup@example.com',
        'phone' => '081234567815'
    ], null, $orgId);

    if (!$personId) return false;

    // Create multiple members for same person (different terms)
    $memberId1 = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => MemberModel::generateMemberNumber($orgId, '2026'),
        'status' => 'active',
        'batch_year' => '2026'
    ]);

    $memberId2 = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId, // Same person
        'member_number' => MemberModel::generateMemberNumber($orgId, '2027'),
        'status' => 'inactive',
        'batch_year' => '2027'
    ]);

    if (!$memberId1 || !$memberId2) return false;

    // Verify person still has only one record
    $personCheck = $pdo->prepare('SELECT COUNT(*) FROM persons WHERE id = :pid');
    $personCheck->execute(['pid' => $personId]);
    $personCount = (int)$personCheck->fetchColumn();

    // Cleanup
    MemberModel::delete($memberId1, $orgId);
    MemberModel::delete($memberId2, $orgId);
    PersonModel::delete($personId, $orgId);

    return $personCount === 1; // Person not duplicated
});

// Test 15: Membership status changes create member_audit records
runTest('Status changes create member_audit records', function() use ($orgId, $pdo) {
    $personId = PersonModel::save([
        'full_name' => 'TEST Audit Trail',
        'email' => 'testaudit@example.com',
        'phone' => '081234567816'
    ], null, $orgId);

    if (!$personId) return false;

    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => MemberModel::generateMemberNumber($orgId, '2026'),
        'status' => 'pending',
        'batch_year' => '2026'
    ]);

    if (!$memberId) return false;

    // Get initial audit count
    $initialAuditCount = $pdo->prepare('SELECT COUNT(*) FROM member_audit WHERE member_id = :mid');
    $initialAuditCount->execute(['mid' => $memberId]);
    $initialCount = (int)$initialAuditCount->fetchColumn();

    // Perform status change
    MemberModel::approve($memberId, $orgId, 1, 'Test approval');

    // Check audit count increased
    $finalAuditCount = $pdo->prepare('SELECT COUNT(*) FROM member_audit WHERE member_id = :mid');
    $finalAuditCount->execute(['mid' => $memberId]);
    $finalCount = (int)$finalAuditCount->fetchColumn();

    // Verify audit record details
    $audit = $pdo->prepare('SELECT * FROM member_audit WHERE member_id = :mid ORDER BY changed_at DESC LIMIT 1');
    $audit->execute(['mid' => $memberId]);
    $auditRecord = $audit->fetch();

    // Cleanup
    MemberModel::delete($memberId, $orgId);
    PersonModel::delete($personId, $orgId);

    return $finalCount > $initialCount && $auditRecord && $auditRecord['old_status'] === 'pending' && $auditRecord['new_status'] === 'active';
});

// Test 16: registration_member_mapping is idempotent
runTest('registration_member_mapping is idempotent', function() use ($orgId, $pdo) {
    // Create a test registration submission
    $formStmt = $pdo->prepare('SELECT id FROM registration_forms WHERE organization_id = :org LIMIT 1');
    $formStmt->execute(['org' => $orgId]);
    $form = $formStmt->fetch();

    if (!$form) {
        $formStmt = $pdo->prepare('INSERT INTO registration_forms (organization_id, title, is_active) VALUES (:org, :title, 1)');
        $formStmt->execute(['org' => $orgId, 'title' => 'Test Form']);
        $formId = (int)$pdo->lastInsertId();
    } else {
        $formId = (int)$form['id'];
    }

    $subStmt = $pdo->prepare('INSERT INTO registration_submissions (form_id, organization_id, status, created_at, updated_at) VALUES (:fid, :org, "pending", NOW(), NOW())');
    $subStmt->execute(['fid' => $formId, 'org' => $orgId]);
    $submissionId = (int)$pdo->lastInsertId();

    // Create person and member
    $personId = PersonModel::save([
        'full_name' => 'TEST Idempotent',
        'email' => 'testidempotent@example.com',
        'phone' => '081234567817'
    ], null, $orgId);

    $memberId = MemberModel::create([
        'organization_id' => $orgId,
        'person_id' => $personId,
        'member_number' => MemberModel::generateMemberNumber($orgId, '2026'),
        'status' => 'active',
        'batch_year' => '2026'
    ]);

    // Create first mapping
    $mapStmt1 = $pdo->prepare('INSERT INTO registration_member_mapping (registration_submission_id, member_id, mapping_type, mapped_at) VALUES (:sid, :mid, "direct", NOW())');
    $mapStmt1->execute(['sid' => $submissionId, 'mid' => $memberId]);

    // Try to create duplicate mapping (should fail due to unique constraint)
    try {
        $mapStmt2 = $pdo->prepare('INSERT INTO registration_member_mapping (registration_submission_id, member_id, mapping_type, mapped_at) VALUES (:sid, :mid, "direct", NOW())');
        $mapStmt2->execute(['sid' => $submissionId, 'mid' => $memberId]);
        // If we get here, idempotency failed
        $cleanupMap = $pdo->prepare('DELETE FROM registration_member_mapping WHERE registration_submission_id = :sid');
        $cleanupMap->execute(['sid' => $submissionId]);
        MemberModel::delete($memberId, $orgId);
        PersonModel::delete($personId, $orgId);
        $pdo->prepare('DELETE FROM registration_submissions WHERE id = :sid')->execute(['sid' => $submissionId]);
        return false;
    } catch (Exception $e) {
        // Expected to fail due to unique constraint
        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            // Cleanup
            $cleanupMap = $pdo->prepare('DELETE FROM registration_member_mapping WHERE registration_submission_id = :sid');
            $cleanupMap->execute(['sid' => $submissionId]);
            MemberModel::delete($memberId, $orgId);
            PersonModel::delete($personId, $orgId);
            $pdo->prepare('DELETE FROM registration_submissions WHERE id = :sid')->execute(['sid' => $submissionId]);
            return true; // Expected failure
        }
        throw $e;
    }
});

// Test 17: Existing admin login remains functional
runTest('Existing admin login remains functional', function() use ($pdo) {
    // Check admin users exist
    $adminStmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role IN ("super_admin", "organization_admin")');
    $adminStmt->execute();
    $adminCount = (int)$adminStmt->fetchColumn();

    // Check admin users have required fields
    $adminDetailStmt = $pdo->prepare('SELECT id, name, email, role, status FROM users WHERE role IN ("super_admin", "organization_admin") LIMIT 1');
    $adminDetailStmt->execute();
    $admin = $adminDetailStmt->fetch();

    return $adminCount > 0 && $admin && !empty($admin['email']);
});

// Test 18: Legacy registration_submissions remain intact
runTest('Legacy registration_submissions remain intact', function() use ($orgId, $pdo) {
    // Check table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'registration_submissions'");
    $tableExists = $stmt->fetch();

    if (!$tableExists) return false;

    // Check original columns still exist
    $stmt = $pdo->query("SHOW COLUMNS FROM registration_submissions LIKE 'status'");
    $statusColumn = $stmt->fetch();

    $stmt = $pdo->query("SHOW COLUMNS FROM registration_submissions LIKE 'member_number'");
    $memberNumberColumn = $stmt->fetch();

    // Check we still have original data
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM registration_submissions WHERE organization_id = :org');
    $stmt->execute(['org' => $orgId]);
    $hasData = (int)$stmt->fetchColumn() >= 0;

    return $tableExists && $statusColumn && $memberNumberColumn && $hasData;
});

echo "\n=== After Test Data Counts ===\n";
$afterCounts = [
    'persons' => $pdo->query('SELECT COUNT(*) FROM persons WHERE organization_id = ' . $orgId)->fetchColumn(),
    'members' => $pdo->query('SELECT COUNT(*) FROM members WHERE organization_id = ' . $orgId)->fetchColumn(),
    'users' => $pdo->query('SELECT COUNT(*) FROM users WHERE organization_id = ' . $orgId)->fetchColumn(),
    'reg_submissions' => $pdo->query('SELECT COUNT(*) FROM registration_submissions WHERE organization_id = ' . $orgId)->fetchColumn(),
    'member_audit' => $pdo->query('SELECT COUNT(*) FROM member_audit')->fetchColumn(),
    'mapping' => $pdo->query('SELECT COUNT(*) FROM registration_member_mapping')->fetchColumn()
];
foreach ($afterCounts as $table => $count) {
    echo "{$table}: {$count}\n";
}

echo "\n=== Data Changes ===\n";
foreach ($beforeCounts as $table => $before) {
    $after = isset($afterCounts[$table]) ? $afterCounts[$table] : 0;
    $change = $after - $before;
    if ($change > 0) {
        $changeStr = '+' . $change;
    } else {
        $changeStr = $change;
    }
    echo "{$table}: {$before} → {$after} ({$changeStr})\n";
}

// Print summary
echo "\n" . str_repeat('=', 50) . "\n";
echo "Test Summary:\n";
echo "Passed: {$testResults['passed']}\n";
echo "Failed: {$testResults['failed']}\n";
echo "Total: " . ($testResults['passed'] + $testResults['failed']) . "\n";

if ($testResults['failed'] > 0) {
    echo "\nFailed tests:\n";
    foreach ($testResults['tests'] as $name => $result) {
        if ($result !== 'pass') {
            echo "  ❌ {$name}\n";
        }
    }
    exit(1);
} else {
    echo "\n✅ All functional tests passed!\n";
    exit(0);
}
