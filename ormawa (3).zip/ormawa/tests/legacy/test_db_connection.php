<?php
/**
 * Simple Database Connection Test
 * Diagnoses database connection issues
 */

echo "=== Database Connection Diagnostic ===\n\n";

echo "1. Checking database configuration...\n";
echo "DB_HOST: " . (defined('DB_HOST') ? DB_HOST : 'NOT DEFINED') . "\n";
echo "DB_PORT: " . (defined('DB_PORT') ? DB_PORT : 'NOT DEFINED') . "\n";
echo "DB_NAME: " . (defined('DB_NAME') ? DB_NAME : 'NOT DEFINED') . "\n";
echo "DB_USER: " . (defined('DB_USER') ? DB_USER : 'NOT DEFINED') . "\n";
echo "DB_PASS: " . (defined('DB_PASS') ? (empty(DB_PASS) ? '(empty)' : '***') : 'NOT DEFINED') . "\n\n";

echo "2. Testing PDO connection...\n";
try {
    require_once __DIR__ . '/../config/config.php';
    require_once __DIR__ . '/../config/constants.php';
    
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    echo "DSN: $dsn\n";
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    
    echo "✅ Connection successful!\n\n";
    
    echo "3. Testing simple query...\n";
    $stmt = $pdo->query('SELECT 1 as test');
    $result = $stmt->fetch();
    echo "✅ Query successful! Result: " . print_r($result, true) . "\n\n";
    
    echo "4. Checking tables...\n";
    $stmt = $pdo->query('SHOW TABLES');
    $tables = $stmt->fetchAll();
    echo "Found " . count($tables) . " tables:\n";
    foreach ($tables as $table) {
        echo "  - " . array_values($table)[0] . "\n";
    }
    
    echo "\n✅ All database tests passed!\n";
    exit(0);
    
} catch (PDOException $e) {
    echo "❌ PDO Error: " . $e->getMessage() . "\n";
    echo "Error Code: " . $e->getCode() . "\n";
    exit(1);
} catch (Exception $e) {
    echo "❌ General Error: " . $e->getMessage() . "\n";
    exit(1);
}
