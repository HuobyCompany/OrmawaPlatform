<?php
/**
 * Safe Cleanup Script for Test Fixtures
 * 
 * This script removes ONLY test fixtures created by test_admin_structure_verification.php
 * while preserving real organization data.
 * 
 * REAL DATA (PRESERVED):
 * - Groups 6, 7, 8: "Pembina / Pembimbing", "Badan Pengurus Harian (BPH)", "Divisi / Departemen"
 * - Positions 12-19: Real positions under groups 6, 7, 8
 * - Persons 8-12: Real people names
 * 
 * TEST FIXTURES (REMOVED):
 * - Groups with names containing: "Test Group", "Empty Group", "Many Group", "Order A", "Order B", "Parent Group", "Child Group"
 * - Positions under test groups
 * - Persons with names containing: "Test MultiPos", "Second Person", "Term2 Person", "NoLogin Person"
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';

$pdo = Database::connection();
$pdo->beginTransaction();

try {
    echo "=== CLEANING UP TEST FIXTURES ===\n\n";

    // 1. Identify test persons by name patterns
    $testPersonPatterns = ['Test MultiPos', 'Second Person', 'Term2 Person', 'NoLogin Person'];
    $testPersonIds = [];
    
    foreach ($testPersonPatterns as $pattern) {
        $stmt = $pdo->prepare("SELECT id FROM persons WHERE full_name LIKE :pattern");
        $stmt->execute(['pattern' => "%$pattern%"]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $r) {
            $testPersonIds[] = (int)$r['id'];
        }
    }
    
    $testPersonIds = array_unique($testPersonIds);
    echo "Found " . count($testPersonIds) . " test persons to remove\n";

    // 2. Delete position assignments for test persons
    if (!empty($testPersonIds)) {
        $in = str_repeat('?,', count($testPersonIds) - 1) . '?';
        $stmt = $pdo->prepare("DELETE FROM position_assignments WHERE person_id IN ($in)");
        $stmt->execute($testPersonIds);
        echo "Deleted position assignments for test persons\n";
    }

    // 3. Delete test persons
    if (!empty($testPersonIds)) {
        $in = str_repeat('?,', count($testPersonIds) - 1) . '?';
        $stmt = $pdo->prepare("DELETE FROM persons WHERE id IN ($in)");
        $stmt->execute($testPersonIds);
        echo "Deleted test persons\n";
    }

    // 4. Identify test groups by name patterns
    $testGroupPatterns = ['Test Group', 'Empty Group', 'Many Group', 'Order A', 'Order B', 'Parent Group', 'Child Group'];
    $testGroupIds = [];
    
    foreach ($testGroupPatterns as $pattern) {
        $stmt = $pdo->prepare("SELECT id FROM structure_groups WHERE name LIKE :pattern");
        $stmt->execute(['pattern' => "%$pattern%"]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($results as $r) {
            $testGroupIds[] = (int)$r['id'];
        }
    }
    
    $testGroupIds = array_unique($testGroupIds);
    echo "Found " . count($testGroupIds) . " test groups to remove\n";

    // 5. Delete positions under test groups
    if (!empty($testGroupIds)) {
        $in = str_repeat('?,', count($testGroupIds) - 1) . '?';
        $stmt = $pdo->prepare("DELETE FROM position_assignments WHERE position_id IN (SELECT id FROM positions WHERE group_id IN ($in))");
        $stmt->execute($testGroupIds);
        echo "Deleted position assignments for test group positions\n";
        
        $stmt = $pdo->prepare("DELETE FROM positions WHERE group_id IN ($in)");
        $stmt->execute($testGroupIds);
        echo "Deleted positions under test groups\n";
    }

    // 6. Delete test groups
    if (!empty($testGroupIds)) {
        $in = str_repeat('?,', count($testGroupIds) - 1) . '?';
        $stmt = $pdo->prepare("DELETE FROM structure_groups WHERE id IN ($in)");
        $stmt->execute($testGroupIds);
        echo "Deleted test groups\n";
    }

    // 7. Verify remaining data
    $remainingGroups = $pdo->query("SELECT id, name FROM structure_groups ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    echo "\nRemaining structure groups (" . count($remainingGroups) . "):\n";
    foreach ($remainingGroups as $g) {
        echo "  ID: {$g['id']} | Name: {$g['name']}\n";
    }

    $remainingPersons = $pdo->query("SELECT id, full_name FROM persons ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    echo "\nRemaining persons (" . count($remainingPersons) . "):\n";
    foreach ($remainingPersons as $p) {
        echo "  ID: {$p['id']} | Name: {$p['full_name']}\n";
    }

    $pdo->commit();
    echo "\n=== TEST FIXTURE CLEANUP COMPLETED SUCCESSFULLY ===\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "[FAIL] Cleanup error: " . $e->getMessage() . "\n";
    exit(1);
}
