<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/models/TermModel.php';
require_once __DIR__ . '/../app/models/PersonModel.php';
require_once __DIR__ . '/../app/models/StructureGroupModel.php';
require_once __DIR__ . '/../app/models/StructurePositionModel.php';
require_once __DIR__ . '/../app/models/PositionAssignmentModel.php';
require_once __DIR__ . '/../app/services/PersonService.php';
require_once __DIR__ . '/../app/services/StructureService.php';

echo "=== PHASE 1B VERIFICATION TEST ===\n";

$pdo = Database::connection();
$orgId = 1; // Test on default organization ID 1

$pdo->beginTransaction();

try {
    // 1. Create Terms (Current & Historical)
    $termCurrentId = StructureService::createTerm($orgId, 'Periode 2026/2027', '2026-2027', '2026-01-01', '2026-12-31');
    $termHistoricalId = StructureService::createTerm($orgId, 'Periode 2024/2025', '2024-2025', '2024-01-01', '2024-12-31');
    echo "[PASS] Created terms (Current ID: $termCurrentId, Historical ID: $termHistoricalId)\n";

    // 2. Create Custom Structure Groups
    $groupBphId = StructureService::createGroup($orgId, 'Badan Pengurus Harian (BPH)', 'Pengurus Inti', null, 1);
    $groupDivHumasId = StructureService::createGroup($orgId, 'Divisi Humas', 'Hubungan Masyarakat', $groupBphId, 2);
    echo "[PASS] Created structure groups (BPH ID: $groupBphId, Divisi Humas ID: $groupDivHumasId)\n";

    // 3. Create Positions under Groups
    $posKetuaId = StructureService::createPosition($orgId, $groupBphId, 'Ketua Umum', 'Ketua Organisasi', 1);
    $posStaffHumasId = StructureService::createPosition($orgId, $groupDivHumasId, 'Staff Humas', 'Anggota Divisi Humas', 1);
    $posWakilId = StructureService::createPosition($orgId, $groupBphId, 'Wakil Ketua', 'Wakil Ketua Organisasi', 2);
    echo "[PASS] Created positions (Ketua ID: $posKetuaId, Staff Humas ID: $posStaffHumasId, Wakil ID: $posWakilId)\n";

    // 4. Create Persons
    $person1Id = PersonService::createPerson($orgId, 'Budi Santoso', 'budi@example.com', '08123456789');
    $person2Id = PersonService::createPerson($orgId, 'Siti Rahma', 'siti@example.com', '08987654321');
    echo "[PASS] Created persons (Person 1 ID: $person1Id, Person 2 ID: $person2Id)\n";

    // 5. Test Multiple People in One Position (Co-Staff Humas)
    $asgStaff1 = StructureService::assignPerson($orgId, $termCurrentId, $posStaffHumasId, $person1Id, '2026-01-01');
    $asgStaff2 = StructureService::assignPerson($orgId, $termCurrentId, $posStaffHumasId, $person2Id, '2026-01-01');
    echo "[PASS] Assigned multiple people to single position (Assignments: $asgStaff1, $asgStaff2)\n";

    // 6. Test One Person with Multiple Assignments (Budi is also Ketua)
    $asgKetua = StructureService::assignPerson($orgId, $termCurrentId, $posKetuaId, $person1Id, '2026-01-01');
    echo "[PASS] Assigned one person to multiple positions (Ketua Assignment: $asgKetua)\n";

    // 7. Test Vacant Position (Wakil Ketua is currently vacant)
    $asgVacant = StructureService::assignPerson($orgId, $termCurrentId, $posWakilId, null, '2026-01-01', null, 'vacant');
    echo "[PASS] Created vacant position assignment (Vacant Assignment ID: $asgVacant)\n";

    // 8. Test Historical Term Assignment (Siti was Ketua in 2024/2025)
    $asgHist = StructureService::assignPerson($orgId, $termHistoricalId, $posKetuaId, $person2Id, '2024-01-01', '2024-12-31');
    echo "[PASS] Created historical term assignment (Historical Assignment ID: $asgHist)\n";

    // 9. Verify Tree Retrieval
    $treeCurrent = StructureService::getStructureTree($orgId, $termCurrentId);
    echo "[PASS] Retrieved current term structure tree (" . count($treeCurrent) . " top-level groups)\n";

    $treeHist = StructureService::getStructureTree($orgId, $termHistoricalId);
    echo "[PASS] Retrieved historical term structure tree (" . count($treeHist) . " top-level groups)\n";

    // Rollback test changes to leave database clean
    $pdo->rollBack();
    echo "=== ALL VERIFICATION TESTS PASSED (Transactional Rollback Complete) ===\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "[FAIL] Verification test error: " . $e->getMessage() . "\n";
    exit(1);
}
