<?php
// Check actual table structure
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';

foreach(glob(BASE_PATH.'/app/helpers/*.php') as $f) require_once $f;
foreach([BASE_PATH.'/app/core/Database.php'] as $f) require_once $f;

echo "=== Table Structure Check ===\n\n";

try {
    $pdo = Database::connection();
    
    // Check user_account_members structure
    echo "user_account_members table structure:\n";
    $stmt = $pdo->query("DESCRIBE user_account_members");
    $columns = $stmt->fetchAll();
    foreach ($columns as $col) {
        echo "- {$col['Field']}: {$col['Type']} {$col['Null']} {$col['Key']}\n";
    }
    
    echo "\nuser_account_members constraints:\n";
    $stmt = $pdo->query("SHOW CREATE TABLE user_account_members");
    $tableDef = $stmt->fetch();
    echo $tableDef['Create Table'] . "\n";
    
    echo "\nusers table structure (remember_token):\n";
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'remember_token'");
    $tokenCol = $stmt->fetch();
    if ($tokenCol) {
        echo "- {$tokenCol['Field']}: {$tokenCol['Type']}\n";
    } else {
        echo "- remember_token column NOT FOUND\n";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
