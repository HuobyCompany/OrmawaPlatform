<?php
// Get test passwords for existing users (for development testing only)
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';

foreach(glob(BASE_PATH.'/app/helpers/*.php') as $f) require_once $f;
foreach([BASE_PATH.'/app/core/Database.php'] as $f) require_once $f;

echo "=== Test User Passwords ===\n\n";

try {
    $pdo = Database::connection();
    
    // Get test users with their password hashes
    $stmt = $pdo->query("SELECT id, name, email, role, organization_id, password FROM users WHERE id IN (1,2,9,10,11,12) ORDER BY id");
    $users = $stmt->fetchAll();
    
    echo "Available test users:\n";
    foreach ($users as $user) {
        echo "- ID: {$user['id']}, Name: {$user['name']}, Email: {$user['email']}, Role: {$user['role']}, Org: {$user['organization_id']}\n";
        echo "  Password hash: " . substr($user['password'], 0, 20) . "...\n";
        echo "  For testing, common dev passwords are usually: 'password', 'admin123', or the email name\n\n";
    }
    
    // Check if we can verify with common passwords
    echo "Testing common passwords:\n";
    $commonPasswords = ['password', 'admin123', '123456', 'test123'];
    
    foreach ($users as $user) {
        echo "\nTesting for {$user['email']}:\n";
        foreach ($commonPasswords as $testPwd) {
            if (password_verify($testPwd, $user['password'])) {
                echo "  ✓ Password: '$testPwd' WORKS!\n";
            }
        }
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
