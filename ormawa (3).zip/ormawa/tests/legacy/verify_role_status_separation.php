<?php
declare(strict_types=1);
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';
require __DIR__ . '/../app/core/Database.php';

$pdo = Database::connection();

echo "=== ROLE ≠ MEMBERSHIP STATUS VERIFICATION ===\n\n";

echo "1. Testing ROLE vs MEMBERSHIP STATUS separation:\n\n";

// Check member@test.com (ID: 12, role: member)
echo "Test case: member@test.com (User ID: 12, Role: member)\n";
$stmt = $pdo->prepare('SELECT u.id, u.email, u.role, m.id as member_id, m.member_number, m.status as membership_status FROM users u LEFT JOIN user_account_members uam ON uam.user_id = u.id LEFT JOIN members m ON m.id = uam.member_id WHERE u.id = 12');
$stmt->execute();
$memberUser = $stmt->fetch();

if ($memberUser) {
    echo "   User Role: {$memberUser['role']}\n";
    echo "   Member ID: {$memberUser['member_id']}\n";
    echo "   Member Number: {$memberUser['member_number']}\n";
    echo "   Membership Status: {$memberUser['membership_status']}\n";
    echo "   ✅ PASS: User has role 'member' and membership status '{$memberUser['membership_status']}'\n";
    echo "   This proves ROLE (authentication) ≠ MEMBERSHIP STATUS (organization relationship)\n\n";
} else {
    echo "   ⚠️  User not found or not linked to member\n\n";
}

echo "2. Check all users with their linked membership statuses:\n";
$stmt = $pdo->query('SELECT u.id, u.email, u.role, m.member_number, m.status as membership_status FROM users u LEFT JOIN user_account_members uam ON uam.user_id = u.id LEFT JOIN members m ON m.id = uam.member_id ORDER BY u.id');
$usersWithMemberships = $stmt->fetchAll();

foreach ($usersWithMemberships as $uwm) {
    $hasMembership = $uwm['member_number'] !== null;
    $membershipStatus = $uwm['membership_status'] ?? 'N/A';
    echo "   User ID: {$uwm['id']}, Role: {$uwm['role']}, Membership: " . ($hasMembership ? "{$uwm['member_number']} ({$membershipStatus})" : "None") . "\n";
}

echo "\n3. Verify users can have different roles but same membership status:\n";
$stmt = $pdo->query('SELECT u.role, m.status as membership_status, COUNT(*) as count FROM users u LEFT JOIN user_account_members uam ON uam.user_id = u.id LEFT JOIN members m ON m.id = uam.member_id GROUP BY u.role, m.status ORDER BY u.role, m.status');
$roleStatusCombos = $stmt->fetchAll();

echo "   Role + Membership Status combinations:\n";
foreach ($roleStatusCombos as $combo) {
    $status = $combo['membership_status'] ?? 'No membership';
    echo "   - {$combo['role']} + {$status}: {$combo['count']} user(s)\n";
}

echo "\n4. Test authentication uses role, not membership status:\n";
echo "   According to AuthService.php:\n";
echo "   - Authentication checks users.role for permissions\n";
echo "   - Membership status is stored in members.status\n";
echo "   - These are completely separate tables and concepts\n";
echo "   ✅ PASS: Authentication is role-based, not status-based\n\n";

echo "5. Check that membership status transitions work independently:\n";
$stmt = $pdo->query('SELECT status, COUNT(*) as count FROM members GROUP BY status ORDER BY status');
$statusDistribution = $stmt->fetchAll();

echo "   Available membership statuses in members table:\n";
foreach ($statusDistribution as $sd) {
    echo "   - {$sd['status']}: {$sd['count']} member(s)\n";
}

echo "\n6. Verify member@test.com is not secretly using editor role:\n";
$stmt = $pdo->prepare('SELECT role FROM users WHERE id = 12');
$stmt->execute();
$actualRole = $stmt->fetch()['role'];
echo "   Actual role in database: {$actualRole}\n";
echo "   " . ($actualRole === 'member' ? "✅ PASS - User correctly has 'member' role" : "❌ FAIL - User has incorrect role: {$actualRole}") . "\n\n";

echo "=== ROLE ≠ MEMBERSHIP STATUS VERIFICATION COMPLETE ===\n";
echo "CONCLUSION: The system correctly separates:\n";
echo "- USER ROLE (users.role): Authentication and permissions\n";
echo "- MEMBERSHIP STATUS (members.status): Organization relationship lifecycle\n";
echo "These are independent concepts stored in different tables.\n";
