<?php
// Programmatic Authentication Flow Testing
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';

// Start session for testing
if(session_status() !== PHP_SESSION_ACTIVE){
    session_start();
}

foreach(glob(BASE_PATH.'/app/helpers/*.php') as $f) require_once $f;
foreach([BASE_PATH.'/app/core/Database.php',BASE_PATH.'/app/models/UserModel.php',BASE_PATH.'/app/services/AuthService.php'] as $f) require_once $f;
foreach(glob(BASE_PATH.'/app/models/*.php') as $f) require_once $f;

echo "=== Programmatic Authentication Flow Testing ===\n\n";

$testResults = [
    'passed' => 0,
    'failed' => 0,
    'notes' => []
];

function assertTest($condition, $testName, &$results, $notes = '') {
    if ($condition) {
        echo "✓ $testName";
        if ($notes) echo " - $notes";
        echo "\n";
        $results['passed']++;
        return true;
    } else {
        echo "✗ $testName";
        if ($notes) echo " - $notes";
        echo "\n";
        $results['failed']++;
        $results['notes'][] = "$testName: $notes";
        return false;
    }
}

try {
    $pdo = Database::connection();
    
    echo "1. Authentication Flow Tests\n";
    
    // Test 1: Super admin authentication
    echo "Testing super_admin authentication...\n";
    $superAdmin = AuthService::authenticate('superadmin@example.com', 'admin123');
    assertTest($superAdmin !== null, "Super admin authentication works", $testResults);
    if ($superAdmin) {
        assertTest($superAdmin['role'] === 'super_admin', "Super admin has correct role", $testResults);
        assertTest($superAdmin['organization_id'] == 1, "Super admin has organization context", $testResults);
    }
    
    // Test 2: Organization admin authentication
    echo "\nTesting organization_admin authentication...\n";
    $orgAdmin = AuthService::authenticate('admin@example.com', 'admin123');
    assertTest($orgAdmin !== null, "Organization admin authentication works", $testResults);
    if ($orgAdmin) {
        assertTest($orgAdmin['role'] === 'organization_admin', "Organization admin has correct role", $testResults);
        assertTest($orgAdmin['organization_id'] == 1, "Organization admin has correct organization", $testResults);
    }
    
    // Test 3: Editor authentication
    echo "\nTesting editor authentication...\n";
    $editor = AuthService::authenticate('editor@test.com', 'test123');
    assertTest($editor !== null, "Editor authentication works", $testResults);
    if ($editor) {
        assertTest($editor['role'] === 'editor', "Editor has correct role", $testResults);
        assertTest($editor['organization_id'] == 4, "Editor has correct organization", $testResults);
    }
    
    // Test 4: Wrong password rejection
    echo "\nTesting wrong password rejection...\n";
    $wrongAuth = AuthService::authenticate('superadmin@example.com', 'wrongpassword');
    assertTest($wrongAuth === null, "Wrong password is rejected", $testResults);
    
    // Test 5: Non-existent user rejection
    echo "\nTesting non-existent user rejection...\n";
    $nonExistent = AuthService::authenticate('nonexistent@example.com', 'password');
    assertTest($nonExistent === null, "Non-existent user is rejected", $testResults);
    
    echo "\n2. Session Management Tests\n";
    
    // Test 6: Session creation
    echo "Testing session creation...\n";
    if ($superAdmin) {
        AuthService::createSession($superAdmin, false);
        assertTest(AuthService::isAuthenticated(), "Session created successfully", $testResults);
        
        $currentUser = AuthService::currentUser();
        assertTest($currentUser !== null, "Current user retrievable", $testResults);
        assertTest($currentUser['id'] === $superAdmin['id'], "Session contains correct user ID", $testResults);
        assertTest($currentUser['role'] === 'super_admin', "Session contains correct role", $testResults);
    }
    
    // Test 7: Session destruction
    echo "\nTesting session destruction...\n";
    AuthService::destroySession();
    assertTest(!AuthService::isAuthenticated(), "Session destroyed successfully", $testResults);
    assertTest(AuthService::currentUser() === null, "Current user null after destruction", $testResults);
    
    echo "\n3. Role and Permission Tests\n";
    
    // Test 8: Role checking
    echo "Testing role checking...\n";
    AuthService::createSession($superAdmin, false);
    assertTest(AuthService::hasRole(['super_admin']), "Super admin has super_admin role", $testResults);
    assertTest(AuthService::hasRole(['organization_admin']), "Super admin does not have organization_admin role", $testResults, "correctly rejected");
    assertTest(!AuthService::hasRole(['editor']), "Super admin does not have editor role", $testResults, "correctly rejected");
    
    // Test 9: Permission checking
    echo "\nTesting permission checking...\n";
    assertTest(AuthService::can('manage_settings'), "Super admin can manage_settings", $testResults);
    assertTest(AuthService::can('manage_users'), "Super admin can manage_users", $testResults);
    assertTest(AuthService::can('manage_content'), "Super admin can manage_content", $testResults);
    
    // Test 10: Organization admin permissions
    echo "\nTesting organization admin permissions...\n";
    AuthService::destroySession();
    AuthService::createSession($orgAdmin, false);
    assertTest(AuthService::can('manage_settings'), "Organization admin can manage_settings", $testResults);
    assertTest(AuthService::can('manage_users'), "Organization admin can manage_users", $testResults);
    assertTest(AuthService::can('manage_content'), "Organization admin can manage_content", $testResults);
    assertTest(!AuthService::can('view_analytics'), "Organization admin permission check (depends on mapping)", $testResults, "may need verification");
    
    // Test 11: Editor permissions
    echo "\nTesting editor permissions...\n";
    AuthService::destroySession();
    AuthService::createSession($editor, false);
    assertTest(!AuthService::can('manage_settings'), "Editor cannot manage_settings", $testResults, "correctly restricted");
    assertTest(!AuthService::can('manage_users'), "Editor cannot manage_users", $testResults, "correctly restricted");
    assertTest(AuthService::can('manage_content'), "Editor can manage_content", $testResults);
    
    echo "\n4. Organization Isolation Tests\n";
    
    // Test 12: Organization membership check
    echo "Testing organization membership...\n";
    assertTest(AuthService::isMemberOf(4), "Editor is member of organization 4", $testResults);
    assertTest(!AuthService::isMemberOf(1), "Editor is not member of organization 1", $testResults, "correctly isolated");
    
    echo "\n5. Member Relationship Tests\n";
    
    // Test 13: User-member linking
    echo "Testing user-member linking...\n";
    $linkResult = UserModel::linkToMember($editor['id'], 1, $superAdmin['id']);
    assertTest($linkResult === true || $linkResult === false, "User-member linking function works", $testResults, "may fail if already linked");
    
    // Test 14: Check member data
    echo "\nTesting member data retrieval...\n";
    $memberData = AuthService::getMemberData();
    if ($memberData) {
        assertTest($memberData['id'] === 1, "Member data contains correct member ID", $testResults);
    } else {
        echo "  - No member data available (user may not be linked to member)\n";
    }
    
    echo "\n6. Legacy System Tests\n";
    
    // Test 15: Legacy authentication check
    echo "Testing legacy authentication preservation...\n";
    assertTest(function_exists('is_logged_in'), "Legacy is_logged_in function exists", $testResults);
    assertTest(function_exists('is_member_logged_in'), "Legacy is_member_logged_in function exists", $testResults);
    assertTest(function_exists('current_member'), "Legacy current_member function exists", $testResults);
    
    // Test 16: Legacy member authentication
    echo "\nTesting legacy member authentication...\n";
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM registration_submissions WHERE status = 'approved'");
    $legacyMembers = $stmt->fetch();
    assertTest($legacyMembers['count'] > 0, "Legacy registration_submissions still exists with approved members", $testResults);
    
    echo "\n7. Security Feature Tests\n";
    
    // Test 17: Password verification
    echo "Testing password verification...\n";
    $testPassword = 'test123';
    $testHash = password_hash($testPassword, PASSWORD_DEFAULT);
    assertTest(password_verify($testPassword, $testHash), "Password verification works", $testResults);
    assertTest(!password_verify('wrongpassword', $testHash), "Wrong password rejected", $testResults);
    
    // Test 18: Rate limiting
    echo "\nTesting rate limiting...\n";
    assertTest(method_exists('AuthService', 'checkRateLimit'), "Rate limiting method exists", $testResults);
    assertTest(method_exists('AuthService', 'recordFailedAttempt'), "Failed attempt recording exists", $testResults);
    assertTest(method_exists('AuthService', 'clearFailedAttempts'), "Failed attempt clearing exists", $testResults);
    
    // Test 19: Session timeout
    echo "\nTesting session timeout configuration...\n";
    $reflection = new ReflectionClass('AuthService');
    assertTest($reflection->hasConstant('SESSION_TIMEOUT'), "SESSION_TIMEOUT constant exists", $testResults);
    assertTest($reflection->getConstant('SESSION_TIMEOUT') === 3600, "SESSION_TIMEOUT is 1 hour", $testResults);
    
    // Test 20: Remember-me configuration
    echo "\nTesting remember-me configuration...\n";
    assertTest($reflection->hasConstant('REMEMBER_COOKIE_DAYS'), "REMEMBER_COOKIE_DAYS constant exists", $testResults);
    assertTest($reflection->getConstant('REMEMBER_COOKIE_DAYS') === 30, "REMEMBER_COOKIE_DAYS is 30 days", $testResults);
    
    // Clean up session
    AuthService::destroySession();
    
} catch (Exception $e) {
    echo "✗ Test failed: " . $e->getMessage() . "\n";
    $testResults['failed']++;
    $testResults['notes'][] = "Exception: " . $e->getMessage();
}

echo "\n=== Programmatic Test Summary ===\n";
echo "Passed: {$testResults['passed']}\n";
echo "Failed: {$testResults['failed']}\n";
echo "Total: " . ($testResults['passed'] + $testResults['failed']) . "\n";

if (!empty($testResults['notes'])) {
    echo "\n=== Notes ===\n";
    foreach ($testResults['notes'] as $note) {
        echo "- $note\n";
    }
}

if ($testResults['failed'] === 0) {
    echo "\n✓ All programmatic authentication tests passed!\n";
    echo "Note: Browser-based tests still required for complete verification.\n";
    exit(0);
} else {
    echo "\n✗ Some programmatic tests failed. Please review the notes above.\n";
    exit(1);
}
