<?php
/**
 * Membership Verification Tests
 * Tests the Person/Member/User Account separation implementation
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/constants.php';

// Load helpers
foreach(glob(__DIR__ . '/../app/helpers/*.php') as $f) require_once $f;

// Load core Database class
require_once __DIR__ . '/../app/core/Database.php';

// Get database connection
$pdo = Database::connection();

// Load only the specific models and services we need
require_once __DIR__ . '/../app/models/MemberModel.php';
require_once __DIR__ . '/../app/models/PersonModel.php';
require_once __DIR__ . '/../app/services/MemberService.php';

echo "=== Membership Verification Tests ===\n\n";

$testResults = [
    'passed' => 0,
    'failed' => 0,
    'tests' => []
];

/**
 * Test helper function
 */
function runTest(string $name, callable $test): void {
    global $testResults;
    echo "Testing: {$name}... ";
    try {
        $result = $test();
        if ($result) {
            echo "✅ PASS\n";
            $testResults['passed']++;
            $testResults['tests'][$name] = 'pass';
        } else {
            echo "❌ FAIL\n";
            $testResults['failed']++;
            $testResults['tests'][$name] = 'fail';
        }
    } catch (Exception $e) {
        echo "❌ ERROR: " . $e->getMessage() . "\n";
        $testResults['failed']++;
        $testResults['tests'][$name] = 'error';
    }
}

$pdo = Database::connection();
$orgId = 1; // Test with organization ID 1

// Test 1: Members table exists
runTest('Members table exists', function() use ($pdo) {
    $stmt = $pdo->query("SHOW TABLES LIKE 'members'");
    return $stmt->fetch() !== false;
});

// Test 2: Member_audit table exists
runTest('Member_audit table exists', function() use ($pdo) {
    $stmt = $pdo->query("SHOW TABLES LIKE 'member_audit'");
    return $stmt->fetch() !== false;
});

// Test 3: Registration_member_mapping table exists
runTest('Registration_member_mapping table exists', function() use ($pdo) {
    $stmt = $pdo->query("SHOW TABLES LIKE 'registration_member_mapping'");
    return $stmt->fetch() !== false;
});

// Test 4: Persons table exists
runTest('Persons table exists', function() use ($pdo) {
    $stmt = $pdo->query("SHOW TABLES LIKE 'persons'");
    return $stmt->fetch() !== false;
});

// Test 5: Can create a Person without Member
runTest('Person without Member', function() use ($pdo, $orgId) {
    // Check that we can have persons without requiring members
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM persons WHERE organization_id = :org');
    $stmt->execute(['org' => $orgId]);
    $personCount = (int)$stmt->fetchColumn();

    // Check members count
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM members WHERE organization_id = :org');
    $stmt->execute(['org' => $orgId]);
    $memberCount = (int)$stmt->fetchColumn();

    // It's possible to have more persons than members (persons without membership)
    return $personCount >= $memberCount;
});

// Test 6: Can create a Member with Person
runTest('Member with Person', function() use ($pdo, $orgId) {
    // Check that members table has person_id column (foreign key relationship)
    $stmt = $pdo->query("SHOW COLUMNS FROM members LIKE 'person_id'");
    $column = $stmt->fetch();

    if (!$column) return false;

    // Check that the foreign key constraint exists
    $stmt = $pdo->query("SELECT * FROM information_schema.key_column_usage WHERE table_schema = DATABASE() AND table_name = 'members' AND column_name = 'person_id' AND referenced_table_name = 'persons'");
    $fk = $stmt->fetch();

    return $fk !== false;
});

// Test 7: Member without User Account
runTest('Member without User Account', function() use ($pdo, $orgId) {
    // Check that members exist without requiring user accounts
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM members WHERE organization_id = :org');
    $stmt->execute(['org' => $orgId]);
    $memberCount = (int)$stmt->fetchColumn();

    // Check user accounts count
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE organization_id = :org');
    $stmt->execute(['org' => $orgId]);
    $userCount = (int)$stmt->fetchColumn();

    // It's possible to have members without user accounts
    return $memberCount >= $userCount;
});

// Test 8: Person with Structure Assignment but no User
runTest('Person with Structure Assignment but no User', function() use ($pdo, $orgId) {
    // Check that position_assignments table references persons
    $stmt = $pdo->query("SHOW COLUMNS FROM position_assignments LIKE 'person_id'");
    $column = $stmt->fetch();

    if (!$column) return false;

    // Check that position_assignments can have NULL person_id (vacant positions)
    $stmt = $pdo->query("SELECT * FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'position_assignments' AND column_name = 'person_id' AND is_nullable = 'YES'");
    $nullable = $stmt->fetch();

    return $nullable !== false;
});

// Test 9: Member status transitions work correctly
runTest('Member status transitions support', function() use ($pdo) {
    // Check that members table supports all required statuses
    $stmt = $pdo->query("SHOW COLUMNS FROM members LIKE 'status'");
    $column = $stmt->fetch();

    if (!$column) return false;

    // Check if ENUM contains required statuses
    $requiredStatuses = ['pending', 'active', 'rejected', 'suspended', 'inactive', 'alumni'];
    $type = $column['Type'];

    foreach ($requiredStatuses as $status) {
        if (strpos($type, $status) === false) return false;
    }

    return true;
});

// Test 10: Duplicate names handled correctly
runTest('Duplicate names can exist', function() use ($pdo, $orgId) {
    // Check that persons table allows duplicate full_name (no unique constraint)
    $stmt = $pdo->query("SHOW INDEX FROM persons WHERE Key_name != 'PRIMARY' AND Column_name = 'full_name'");
    $index = $stmt->fetch();

    // Should not have unique index on full_name
    return $index === false;
});

// Test 11: Multiple structure assignments for same person
runTest('Multiple structure assignments supported', function() use ($pdo) {
    // Check that position_assignments table allows multiple assignments per person
    $stmt = $pdo->query("SHOW INDEX FROM position_assignments WHERE Key_name != 'PRIMARY' AND Column_name = 'person_id'");
    $index = $stmt->fetch();

    // Should have index on person_id for querying, but not unique constraint
    if (!$index) return false;

    // Check it's not a unique index
    return $index['Non_unique'] == 1;
});

// Test 12: Admin authentication still works
runTest('Admin authentication still works', function() use ($pdo) {
    // Check if admin user exists
    $adminStmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE role = "super_admin" OR role = "organization_admin"');
    $adminStmt->execute();
    $adminCount = (int)$adminStmt->fetchColumn();

    return $adminCount > 0;
});

// Test 13: Legacy registration_submissions preserved
runTest('Legacy registration_submissions preserved', function() use ($pdo, $orgId) {
    // Check if registration_submissions table still exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'registration_submissions'");
    $tableExists = $stmt->fetch();

    if (!$tableExists) return false;

    // Check if it has data
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM registration_submissions WHERE organization_id = :org');
    $stmt->execute(['org' => $orgId]);
    $submissionCount = (int)$stmt->fetchColumn();

    return $submissionCount >= 0; // Table exists with no data loss
});

// Test 14: Member number generation works
runTest('Member number generation works', function() use ($orgId) {
    // Test that the generateMemberNumber method exists and is callable
    return method_exists('MemberModel', 'generateMemberNumber');
});

// Test 15: Member statistics work
runTest('Member statistics work', function() use ($orgId) {
    // Test that the getStatistics method exists and is callable
    return method_exists('MemberService', 'getStatistics');
});

// Print summary
echo "\n" . str_repeat('=', 50) . "\n";
echo "Test Summary:\n";
echo "Passed: {$testResults['passed']}\n";
echo "Failed: {$testResults['failed']}\n";
echo "Total: " . ($testResults['passed'] + $testResults['failed']) . "\n";

if ($testResults['failed'] > 0) {
    echo "\nFailed tests:\n";
    foreach ($testResults['tests'] as $name => $result) {
        if ($result !== 'pass') {
            echo "  ❌ {$name}\n";
        }
    }
    exit(1);
} else {
    echo "\n✅ All tests passed!\n";
    exit(0);
}
