<?php
declare(strict_types=1);
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';
require __DIR__ . '/../app/core/Database.php';

$pdo = Database::connection();

echo "=== MEMBER ROLE MIGRATION VERIFICATION ===\n\n";

// Check users table role enum
$stmt = $pdo->query('SHOW COLUMNS FROM users WHERE Field = "role"');
$result = $stmt->fetch();
echo "1. Users table role enum: " . $result['Type'] . "\n";

// Check if 'member' is in the enum
$hasMemberRole = str_contains($result['Type'], 'member');
echo "   Status: " . ($hasMemberRole ? "✅ PASS - 'member' role exists in enum" : "❌ FAIL - 'member' role missing") . "\n\n";

// Check all users and their roles
echo "2. Current users in database:\n";
$stmt = $pdo->query('SELECT id, email, role, organization_id FROM users ORDER BY id');
$users = $stmt->fetchAll();

foreach ($users as $user) {
    echo "   ID: {$user['id']}, Email: {$user['email']}, Role: {$user['role']}, Org: {$user['organization_id']}\n";
}

echo "\n3. Role distribution:\n";
$stmt = $pdo->query('SELECT role, COUNT(*) as count FROM users GROUP BY role ORDER BY role');
$roleCounts = $stmt->fetchAll();

foreach ($roleCounts as $rc) {
    echo "   {$rc['role']}: {$rc['count']} user(s)\n";
}

echo "\n4. Check for users with member role:\n";
$stmt = $pdo->prepare('SELECT id, email, role FROM users WHERE role = "member"');
$stmt->execute();
$memberUsers = $stmt->fetchAll();

if (count($memberUsers) > 0) {
    echo "   ✅ Found " . count($memberUsers) . " user(s) with member role:\n";
    foreach ($memberUsers as $mu) {
        echo "   - ID: {$mu['id']}, Email: {$mu['email']}\n";
    }
} else {
    echo "   ⚠️  No users with member role found (this is expected if no member accounts created yet)\n";
}

echo "\n5. Check user_account_members table:\n";
$stmt = $pdo->query('SELECT COUNT(*) as count FROM user_account_members');
$uamCount = $stmt->fetch()['count'];
echo "   Total user-member links: {$uamCount}\n";

if ($uamCount > 0) {
    $stmt = $pdo->query('SELECT uam.*, u.email as user_email, m.member_number FROM user_account_members uam LEFT JOIN users u ON u.id = uam.user_id LEFT JOIN members m ON m.id = uam.member_id LIMIT 5');
    $links = $stmt->fetchAll();
    echo "   Sample links:\n";
    foreach ($links as $link) {
        echo "   - User ID: {$link['user_id']} ({$link['user_email']}), Member ID: {$link['member_id']} ({$link['member_number']})\n";
    }
}

echo "\n6. Check members table:\n";
$stmt = $pdo->query('SELECT COUNT(*) as count FROM members');
$memberCount = $stmt->fetch()['count'];
echo "   Total members: {$memberCount}\n";

$stmt = $pdo->query('SELECT status, COUNT(*) as count FROM members GROUP BY status ORDER BY status');
$statusCounts = $stmt->fetchAll();
echo "   Member status distribution:\n";
foreach ($statusCounts as $sc) {
    echo "   - {$sc['status']}: {$sc['count']}\n";
}

echo "\n=== VERIFICATION COMPLETE ===\n";
