<?php
// tests/test_admin_structure_verification.php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/core/View.php';
require_once __DIR__ . '/../app/models/OrganizationModel.php';
require_once __DIR__ . '/../app/models/TermModel.php';
require_once __DIR__ . '/../app/models/PersonModel.php';
require_once __DIR__ . '/../app/models/StructureGroupModel.php';
require_once __DIR__ . '/../app/models/StructurePositionModel.php';
require_once __DIR__ . '/../app/models/PositionAssignmentModel.php';
require_once __DIR__ . '/../app/models/UserModel.php';
require_once __DIR__ . '/../app/services/PersonService.php';
require_once __DIR__ . '/../app/services/StructureService.php';

$pdo = Database::connection();

// Simulate admin session
$_SESSION['user_id'] = 1;
$_SESSION['organization_id'] = 1;

function assertEqual($a, $b, $msg) {
    if ($a !== $b) {
        echo "[FAIL] $msg Expected " . var_export($b, true) . ", got " . var_export($a, true) . "\n";
        exit(1);
    } else {
        echo "[OK] $msg\n";
    }
}

$orgId = $_SESSION['organization_id'];
$pdo->beginTransaction();

try {
    // Ensure a term exists
    $terms = TermModel::all($orgId);
    if (empty($terms)) {
        $termId = StructureService::createTerm($orgId, 'Periode Test', '2026-2027', '2026-01-01', '2027-12-31');
        $term = TermModel::find($termId, $orgId);
    } else {
        $term = $terms[0];
    }
    $termId = (int)$term['id'];

// Helper to create a person (expects just a name string)
function createPerson(string $name): int {
    global $orgId;
    return PersonService::createPerson($orgId, $name);
}

// Helper to assign a person (or vacancy) to a position
function assignPerson(int $orgId, int $termId, int $positionId, ?int $personId, string $status = 'active'): void {
    StructureService::assignPerson($orgId, $termId, $positionId, $personId, date('Y-m-d'), null, $status);
}

// 1. One person assigned to multiple positions in the same term
$personId = createPerson('Test MultiPos');
$groupId = StructureGroupModel::save(['name' => 'Test Group', 'description' => '', 'parent_id' => null, 'sort_order' => 0], null, $orgId);
$pos1 = StructurePositionModel::save(['title' => 'Pos A', 'group_id' => $groupId, 'sort_order' => 1], null, $orgId);
$pos2 = StructurePositionModel::save(['title' => 'Pos B', 'group_id' => $groupId, 'sort_order' => 2], null, $orgId);
assignPerson($orgId, $termId, $pos1, $personId);
assignPerson($orgId, $termId, $pos2, $personId);
$assignments = PositionAssignmentModel::all($orgId, $termId);
$count = 0;
foreach ($assignments as $a) {
    if ((int)$a['person_id'] === $personId) $count++;
}
assertEqual($count, 2, 'Person assigned to two positions');

// 2. Multiple people assigned to the same position
$personId2 = createPerson('Second Person');
assignPerson($orgId, $termId, $pos1, $personId2);
$pos1Assigns = [];
foreach (PositionAssignmentModel::all($orgId, $termId) as $a) {
    if ((int)$a['position_id'] === $pos1) $pos1Assigns[] = $a;
}
assertEqual(count($pos1Assigns), 2, 'Two people assigned to same position');

// 3. Vacant position (person_id NULL, status = 'vacant')
assignPerson($orgId, $termId, $pos2, null, 'vacant');
$vacantFound = false;
foreach (PositionAssignmentModel::all($orgId, $termId) as $a) {
    if ((int)$a['position_id'] === $pos2 && empty($a['person_id']) && $a['status'] === 'vacant') {
        $vacantFound = true;
        break;
    }
}
assertEqual($vacantFound, true, 'Vacant position created');

// 4. Group with zero positions
$groupZero = StructureGroupModel::save(['name' => 'Empty Group', 'description' => '', 'parent_id' => null, 'sort_order' => 0], null, $orgId);
$positionsZero = StructurePositionModel::all($orgId, (int)$groupZero);
assertEqual(count($positionsZero), 0, 'Group with zero positions');

// 5. Group with many positions (20)
$groupMany = StructureGroupModel::save(['name' => 'Many Group', 'description' => '', 'parent_id' => null, 'sort_order' => 0], null, $orgId);
for ($i = 1; $i <= 20; $i++) {
    StructurePositionModel::save(['title' => "Pos $i", 'group_id' => $groupMany, 'sort_order' => $i], null, $orgId);
}
$manyPositions = StructurePositionModel::all($orgId, (int)$groupMany);
assertEqual(count($manyPositions), 20, 'Group with many positions');

// 6. Custom group ordering (swap order of two groups)
$groupA = StructureGroupModel::save(['name' => 'Order A', 'description' => '', 'parent_id' => null, 'sort_order' => 1], null, $orgId);
$groupB = StructureGroupModel::save(['name' => 'Order B', 'description' => '', 'parent_id' => null, 'sort_order' => 2], null, $orgId);
StructureGroupModel::save(['sort_order' => 2], $groupA, $orgId);
$groupAData = StructureGroupModel::find($groupA, $orgId);
assertEqual((int)$groupAData['sort_order'], 2, 'Group ordering moved down');

// 7. Custom position ordering within a group
$posA = StructurePositionModel::save(['title' => 'Pos Order A', 'group_id' => $groupA, 'sort_order' => 1], null, $orgId);
$posB = StructurePositionModel::save(['title' => 'Pos Order B', 'group_id' => $groupA, 'sort_order' => 2], null, $orgId);
StructurePositionModel::save(['sort_order' => 2], $posA, $orgId);
$posAData = StructurePositionModel::find($posA, $orgId);
assertEqual((int)$posAData['sort_order'], 2, 'Position ordering moved down');

// 8. Historical term switching
$term2Slug = '2024-2025';
$existingTerm = TermModel::findBySlug($term2Slug, $orgId);
if ($existingTerm) {
    $term2Id = (int)$existingTerm['id'];
} else {
    $term2Id = StructureService::createTerm($orgId, 'Periode 2024/2025', $term2Slug, '2024-01-01', '2025-12-31');
}
$personTerm2 = createPerson('Term2 Person');
assignPerson($orgId, $term2Id, $pos1, $personTerm2);
$assignTerm2 = PositionAssignmentModel::all($orgId, $term2Id);
assertEqual(count($assignTerm2) > 0, true, 'Assignment exists for second term');
$currentAssign = PositionAssignmentModel::all($orgId, $termId);
$found = false;
foreach ($currentAssign as $a) {
    if ((int)$a['person_id'] === $personTerm2) $found = true;
}
assertEqual($found, false, 'Term switching isolates assignments');

// 9. Group banner column existence
$groupMeta = StructureGroupModel::find($groupId, $orgId);
assertEqual(array_key_exists('banner_media_id', $groupMeta), true, 'Group banner column exists');

// 10. Person photo column existence
$personMeta = PersonModel::find($personId, $orgId);
assertEqual(array_key_exists('photo_media_id', $personMeta), true, 'Person photo column exists');

// 11. Person without login account
$usersBefore = UserModel::all();
createPerson('NoLogin Person');
$usersAfter = UserModel::all();
assertEqual(count($usersBefore), count($usersAfter), 'Creating person does not add user account');

// 12. Top-level group has null parent
$topGroup = StructureGroupModel::find($groupId, $orgId);
assertEqual($topGroup['parent_id'] ?? null, null, 'Top level group has null parent');

// 13. Child group linked to parent
$parentGroup = StructureGroupModel::save(['name' => 'Parent Group', 'description' => '', 'parent_id' => null, 'sort_order' => 0], null, $orgId);
$childGroup = StructureGroupModel::save(['name' => 'Child Group', 'description' => '', 'parent_id' => $parentGroup, 'sort_order' => 0], null, $orgId);
$childData = StructureGroupModel::find($childGroup, $orgId);
assertEqual((int)$childData['parent_id'], (int)$parentGroup, 'Child group linked to parent');

// Rollback all test changes to leave database clean
$pdo->rollBack();
echo "=== ALL VERIFICATION CASES PASSED (Transactional Rollback Complete) ===\n";

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "[FAIL] Verification test error: " . $e->getMessage() . "\n";
    exit(1);
}
?>
