<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../app/core/Database.php';

$pdo = Database::connection();
$sql = file_get_contents(__DIR__ . '/../database/migrations/20260915_create_legacy_structure_mappings.sql');
$pdo->exec($sql);
echo "legacy_structure_mappings table created!\n";
