<?php
// Security Verification Script for Phase 5 Authentication
require __DIR__ . '/../config/config.php';
require __DIR__ . '/../config/constants.php';

foreach(glob(BASE_PATH.'/app/helpers/*.php') as $f) require_once $f;
foreach([BASE_PATH.'/app/core/Database.php',BASE_PATH.'/app/models/UserModel.php',BASE_PATH.'/app/services/AuthService.php'] as $f) require_once $f;

echo "=== Phase 5 Security Verification ===\n\n";

$testResults = [
    'passed' => 0,
    'failed' => 0,
    'skipped' => 0,
    'issues' => []
];

function assertSecurity($condition, $testName, &$results, $notes = '') {
    if ($condition) {
        echo "✓ $testName";
        if ($notes) echo " - $notes";
        echo "\n";
        $results['passed']++;
        return true;
    } else {
        echo "✗ $testName";
        if ($notes) echo " - $notes";
        echo "\n";
        $results['failed']++;
        $results['issues'][] = "$testName: $notes";
        return false;
    }
}

try {
    $pdo = Database::connection();
    
    echo "1. Schema Security Verification\n";
    
    // Check that user_account_members table exists and has basic structure
    $stmt = $pdo->query("SHOW TABLES LIKE 'user_account_members'");
    $tableExists = $stmt->fetch();
    assertSecurity($tableExists, "user_account_members table exists", $testResults);
    
    // Check table has required columns
    $stmt = $pdo->query("DESCRIBE user_account_members");
    $columns = $stmt->fetchAll();
    $columnNames = array_column($columns, 'Field');
    
    assertSecurity(in_array('user_id', $columnNames), "user_account_members has user_id column", $testResults);
    assertSecurity(in_array('member_id', $columnNames), "user_account_members has member_id column", $testResults);
    assertSecurity(in_array('is_primary', $columnNames), "user_account_members has is_primary column", $testResults);
    
    echo "\n2. Authentication Logic Verification\n";
    
    // Check that AuthService methods exist and work correctly
    assertSecurity(class_exists('AuthService'), "AuthService class exists", $testResults);
    assertSecurity(method_exists('AuthService', 'authenticate'), "AuthService::authenticate method exists", $testResults);
    assertSecurity(method_exists('AuthService', 'createSession'), "AuthService::createSession method exists", $testResults);
    assertSecurity(method_exists('AuthService', 'destroySession'), "AuthService::destroySession method exists", $testResults);
    
    echo "\n3. Security Features Verification\n";
    
    // Check password verification functions
    $testPassword = 'test123';
    $testHash = password_hash($testPassword, PASSWORD_DEFAULT);
    $verifyResult = password_verify($testPassword, $testHash);
    assertSecurity($verifyResult, "Password verification works correctly", $testResults);
    
    // Check that wrong password is rejected
    $wrongVerify = password_verify('wrongpassword', $testHash);
    assertSecurity(!$wrongVerify, "Wrong password is correctly rejected", $testResults);
    
    echo "\n4. Session Security Verification\n";
    
    // Check session timeout constant
    $reflection = new ReflectionClass('AuthService');
    assertSecurity($reflection->hasConstant('SESSION_TIMEOUT'), "AuthService has SESSION_TIMEOUT constant", $testResults);
    assertSecurity($reflection->hasConstant('REMEMBER_COOKIE_DAYS'), "AuthService has REMEMBER_COOKIE_DAYS constant", $testResults);
    
    echo "\n5. Role and Permission Verification\n";
    
    assertSecurity(method_exists('AuthService', 'hasRole'), "AuthService::hasRole method exists", $testResults);
    assertSecurity(method_exists('AuthService', 'can'), "AuthService::can method exists", $testResults);
    assertSecurity(method_exists('AuthService', 'isMemberOf'), "AuthService::isMemberOf method exists", $testResults);
    
    echo "\n6. Relationship Management Verification\n";
    
    assertSecurity(method_exists('AuthService', 'linkUserToMember'), "AuthService::linkUserToMember method exists", $testResults);
    assertSecurity(method_exists('AuthService', 'linkUserToPerson'), "AuthService::linkUserToPerson method exists", $testResults);
    assertSecurity(method_exists('UserModel', 'linkToMember'), "UserModel::linkToMember method exists", $testResults);
    assertSecurity(method_exists('UserModel', 'linkToPerson'), "UserModel::linkToPerson method exists", $testResults);
    
    echo "\n7. Backward Compatibility Verification\n";
    
    assertSecurity(function_exists('is_logged_in'), "is_logged_in() function exists", $testResults);
    assertSecurity(function_exists('current_user'), "current_user() function exists", $testResults);
    assertSecurity(function_exists('is_member_logged_in'), "is_member_logged_in() function exists", $testResults);
    assertSecurity(function_exists('current_member'), "current_member() function exists", $testResults);
    
    echo "\n8. Data Integrity Verification\n";
    
    // Check that no duplicate user-member links can be created
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM user_account_members GROUP BY user_id, member_id HAVING COUNT(*) > 1");
    $duplicates = $stmt->fetch();
    assertSecurity(!$duplicates, "No duplicate user-member links exist", $testResults);
    
    // Check that users table has remember_token column
    $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'remember_token'");
    $hasRememberToken = $stmt->fetch();
    assertSecurity($hasRememberToken, "users table has remember_token column", $testResults);
    
    echo "\n9. Organization Isolation Verification\n";
    
    // Check that users have organization_id when appropriate
    $stmt = $pdo->query("SELECT id, role, organization_id FROM users WHERE role IN ('organization_admin', 'editor')");
    $orgUsers = $stmt->fetchAll();
    $allHaveOrg = true;
    foreach ($orgUsers as $user) {
        if ($user['role'] !== 'super_admin' && empty($user['organization_id'])) {
            $allHaveOrg = false;
            break;
        }
    }
    assertSecurity($allHaveOrg, "Organization-scoped users have organization_id", $testResults);
    
    echo "\n10. File Structure Verification\n";
    
    assertSecurity(file_exists(BASE_PATH . '/app/services/AuthService.php'), "AuthService.php exists", $testResults);
    assertSecurity(file_exists(BASE_PATH . '/docs/AUTHENTICATION_MODEL.md'), "AUTHENTICATION_MODEL.md exists", $testResults);
    assertSecurity(file_exists(BASE_PATH . '/docs/PHASE5_IMPLEMENTATION_REPORT.md'), "PHASE5_IMPLEMENTATION_REPORT.md exists", $testResults);
    
    echo "\n11. Member-Without-Account Security\n";
    
    // Check that members can exist without user accounts
    $stmt = $pdo->query("SELECT COUNT(*) as total_members FROM members");
    $totalMembers = $stmt->fetch()['total_members'];
    
    $stmt = $pdo->query("SELECT COUNT(DISTINCT user_id) as linked_members FROM user_account_members WHERE member_id IS NOT NULL");
    $linkedMembers = $stmt->fetch()['linked_members'];
    
    $unlinkedMembers = $totalMembers - $linkedMembers;
    assertSecurity($unlinkedMembers >= 0, "Members can exist without user accounts ($unlinkedMembers unlinked)", $testResults);
    
    echo "\n12. Person Duplication Prevention\n";
    
    // Check that user_account_members structure prevents user-member duplication
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM user_account_members GROUP BY user_id, member_id HAVING COUNT(*) > 1");
    $memberDuplicates = $stmt->fetch();
    assertSecurity(!$memberDuplicates, "No duplicate user-member links exist", $testResults);
    
    echo "\n13. Legacy System Preservation\n";
    
    // Check that legacy tables still exist
    $stmt = $pdo->query("SHOW TABLES LIKE 'registration_submissions'");
    $hasRegSubmissions = $stmt->fetch();
    assertSecurity($hasRegSubmissions, "registration_submissions table still exists", $testResults);
    
    // Check that member_auth session handling is still present
    assertSecurity(function_exists('is_member_logged_in'), "Legacy member_auth session handling exists", $testResults);
    
} catch (Exception $e) {
    echo "✗ Security verification failed: " . $e->getMessage() . "\n";
    $testResults['failed']++;
    $testResults['issues'][] = "Security verification exception: " . $e->getMessage();
}

echo "\n=== Security Verification Summary ===\n";
echo "Passed: {$testResults['passed']}\n";
echo "Failed: {$testResults['failed']}\n";
echo "Skipped: {$testResults['skipped']}\n";
echo "Total: " . ($testResults['passed'] + $testResults['failed'] + $testResults['skipped']) . "\n";

if (!empty($testResults['issues'])) {
    echo "\n=== Issues Found ===\n";
    foreach ($testResults['issues'] as $issue) {
        echo "- $issue\n";
    }
}

if ($testResults['failed'] === 0) {
    echo "\n✓ All security verifications passed!\n";
    echo "Note: Some security tests require manual browser testing:\n";
    echo "- Session ID regeneration\n";
    echo "- Session expiry\n";
    echo "- Remember-me token invalidation\n";
    echo "- Actual login/logout flows\n";
    echo "- Route-based access control\n";
    exit(0);
} else {
    echo "\n✗ Some security verifications failed. Please review the issues above.\n";
    exit(1);
}
