# Manual Authentication Testing Guide

## Test Environment
- **URL**: http://localhost:8080
- **Status**: PHP development server running
- **Database**: ormawa_platform (migrated with Phase 5 schema)

## Test Credentials
Based on the database scan, the following users exist:
- **super_admin**: superadmin@example.com
- **organization_admin**: (check your database for specific org admin)
- **editor**: (check your database for specific editor)

## Manual Test Scenarios

### 1. Super Admin Login Test
**Steps:**
1. Navigate to http://localhost:8080/login
2. Enter super_admin email and password
3. Click login
4. Verify redirect to /admin/dashboard
5. Verify session is created
6. Verify user data in session

**Expected Results:**
- ✅ Authentication successful
- ✅ Redirect to admin dashboard
- ✅ Session contains user data with role 'super_admin'
- ✅ Organization context set if applicable

### 2. Organization Admin Login Test
**Steps:**
1. Navigate to http://localhost:8080/login
2. Enter organization_admin email and password
3. Click login
4. Verify redirect to /admin/dashboard
5. Verify organization context is set

**Expected Results:**
- ✅ Authentication successful
- ✅ Redirect to admin dashboard
- ✅ Session contains organization_id
- ✅ Organization-scoped access enforced

### 3. Editor/Pengurus Login Test
**Steps:**
1. Navigate to http://localhost:8080/login
2. Enter editor email and password
3. Click login
4. Verify redirect to /admin/dashboard
5. Verify limited permissions

**Expected Results:**
- ✅ Authentication successful
- ✅ Redirect to admin dashboard
- ✅ Limited access to content management only
- ✅ Cannot access user management

### 4. Wrong Password Test
**Steps:**
1. Navigate to http://localhost:8080/login
2. Enter valid email with wrong password
3. Click login
4. Verify error message
5. Try 5 more times to test rate limiting

**Expected Results:**
- ✅ Authentication fails
- ✅ Error message displayed
- ✅ Rate limiting after 5 attempts
- ✅ Lockout message after threshold

### 5. Logout Test
**Steps:**
1. Login as any admin user
2. Navigate to /admin/logout
3. Verify session destroyed
4. Verify redirect to /login
5. Try to access admin routes

**Expected Results:**
- ✅ Session destroyed
- ✅ Redirect to login
- ✅ Cannot access admin routes
- ✅ Remember-me cookie cleared

### 6. Unauthorized Admin Access Test
**Steps:**
1. Do not login
2. Try to access http://localhost:8080/admin/dashboard
3. Verify redirect to login

**Expected Results:**
- ✅ Redirect to login page
- ✅ AuthMiddleware blocks access
- ✅ Error message if applicable

### 7. Member Accessing Admin Route Test
**Steps:**
1. Login as member (if member account exists)
2. Try to access /admin/dashboard
3. Verify access denied

**Expected Results:**
- ✅ Access denied
- ✅ Redirect to member area
- ✅ Appropriate error message

### 8. Admin Accessing Member Area Test
**Steps:**
1. Login as admin with member relationship
2. Access /{org_slug}/kartu-anggota
3. Verify access granted

**Expected Results:**
- ✅ Access granted if admin has member relationship
- ✅ Can view member card
- ✅ Full admin privileges maintained

### 9. Legacy Admin Login Test (Backward Compatibility)
**Steps:**
1. Navigate to http://localhost:8080/admin/login
2. Enter existing admin credentials
3. Verify login works

**Expected Results:**
- ✅ Legacy authentication still works
- ✅ Existing admin accounts functional
- ✅ No breaking changes

### 10. Legacy Member Authentication Test
**Steps:**
1. Navigate to http://localhost:8080/kartu-anggota
2. Enter member number and name
3. Verify legacy authentication works

**Expected Results:**
- ✅ Legacy member_auth still functional
- ✅ Member card displayed
- ✅ No breaking changes

### 11. Session Regeneration Test
**Steps:**
1. Login as any user
2. Check session ID before and after login
3. Verify session ID changed

**Expected Results:**
- ✅ Session ID regenerated on login
- ✅ Security best practice followed
- ✅ Session fixation prevented

### 12. Session Expiry Test
**Steps:**
1. Login as any user
2. Wait for session timeout (1 hour)
3. Try to access protected route
4. Verify redirect to login

**Expected Results:**
- ✅ Session expires after timeout
- ✅ Redirect to login
- ✅ Security enforced

### 13. Organization Isolation Test
**Steps:**
1. Login as organization_admin for Org A
2. Try to access Org B data
3. Verify access denied

**Expected Results:**
- ✅ Organization isolation enforced
- ✅ Cannot access other organizations
- ✅ Data security maintained

## Test Results Template

Use this template to record your test results:

```
### Test Results - [Date]

1. Super Admin Login: [✅/❌] - [Notes]
2. Organization Admin Login: [✅/❌] - [Notes]
3. Editor Login: [✅/❌] - [Notes]
4. Wrong Password: [✅/❌] - [Notes]
5. Logout: [✅/❌] - [Notes]
6. Unauthorized Access: [✅/❌] - [Notes]
7. Member → Admin: [✅/❌] - [Notes]
8. Admin → Member: [✅/❌] - [Notes]
9. Legacy Admin: [✅/❌] - [Notes]
10. Legacy Member: [✅/❌] - [Notes]
11. Session Regeneration: [✅/❌] - [Notes]
12. Session Expiry: [✅/❌] - [Notes]
13. Organization Isolation: [✅/❌] - [Notes]

### Overall Status: [✅ PASSED / ❌ FAILED]

### Issues Found:
- [List any issues found during testing]

### Recommendations:
- [Any recommendations for improvements]
```

## Notes
- The web server is running on http://localhost:8080
- Use browser DevTools to inspect session storage and cookies
- Check storage/logs/app.log for any errors
- Test both unified authentication and legacy fallback paths
