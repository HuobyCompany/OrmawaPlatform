<?php
// Helper script for Test 6 in phase7_registration_member_test.js
require_once 'config/config.php';
require_once 'app/core/Database.php';

$pdo = Database::connection();
$sub = $pdo->query(
    'SELECT s.id, s.status, s.member_number, rmm.member_id, m.person_id
     FROM registration_submissions s
     JOIN registration_member_mapping rmm ON rmm.registration_submission_id = s.id
     JOIN members m ON m.id = rmm.member_id
     WHERE s.status = "approved"
     ORDER BY s.id DESC
     LIMIT 1'
)->fetch();
echo json_encode($sub);
