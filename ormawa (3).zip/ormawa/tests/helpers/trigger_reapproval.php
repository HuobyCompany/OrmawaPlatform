<?php
// Helper script for Test 7 re-approval idempotency in phase7_registration_member_test.js
require_once 'config/config.php';
require_once 'app/core/Database.php';
require_once 'app/models/RegistrationSubmissionModel.php';
require_once 'app/models/MemberModel.php';
require_once 'app/models/PersonModel.php';
require_once 'app/models/ActivityLogModel.php';

$pdo = Database::connection();
$s = $pdo->query('SELECT id, organization_id FROM registration_submissions WHERE status = "approved" LIMIT 1')->fetch();
if ($s) {
    RegistrationSubmissionModel::approve((int)$s['id'], (int)$s['organization_id'], 1, 'Re-approval Idempotency Test');
    echo 'done';
} else {
    echo 'no_approved_submission';
}
