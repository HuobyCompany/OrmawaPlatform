<?php
// Helper script for Test 7 idempotency check in phase7_registration_member_test.js
// Usage: php tests/helpers/count_table.php members
require_once 'config/config.php';
require_once 'app/core/Database.php';

$table = $argv[1] ?? 'members';
$allowedTables = ['members', 'persons', 'registration_submissions', 'users'];
if (!in_array($table, $allowedTables, true)) {
    echo '0';
    exit(1);
}
echo (int)Database::connection()->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn();
