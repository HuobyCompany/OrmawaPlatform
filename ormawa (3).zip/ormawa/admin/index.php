<?php
require dirname(__DIR__).'/config/config.php';
require dirname(__DIR__).'/app/helpers/functions.php';
header('Location: '.url('admin/dashboard'));
exit;
