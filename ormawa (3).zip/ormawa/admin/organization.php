<?php
require dirname(__DIR__).'/config/config.php';
header('Location: '.rtrim(APP_URL,'/').'/admin/organization');
exit;
