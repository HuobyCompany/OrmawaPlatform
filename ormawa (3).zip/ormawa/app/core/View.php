<?php
final class View {
 public static function render(string $view, array $data = [], ?string $layout = 'frontend'): void {
  $vf = BASE_PATH . '/views/' . $view . '.php';
  if (!is_file($vf)) throw new RuntimeException('View file not found: ' . $vf);
  extract($data, EXTR_SKIP);
  if ($layout === null || $layout === '' || $layout === 'none' || $layout === 'standalone') {
      require $vf;
      return;
  }
  $lf = BASE_PATH . '/views/layouts/' . $layout . '.php';
  if (!is_file($lf)) {
      require $vf;
      return;
  }
  ob_start(); require $vf; $content = ob_get_clean(); require $lf;
 }
}

