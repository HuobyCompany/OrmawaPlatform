<?php
// You can configure your database connection here for deployment.
// If using config/config.php, these will be ignored.
if (!defined('DB_HOST')) define('DB_HOST', '127.0.0.1');
if (!defined('DB_PORT')) define('DB_PORT', '3306');
if (!defined('DB_NAME')) define('DB_NAME', 'ormawa_platform');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');

final class Database {
 private static ?PDO $pdo=null;
 public static function connection():PDO {
  if(self::$pdo instanceof PDO) return self::$pdo;
  self::$pdo=new PDO(
   'mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4',
   DB_USER,DB_PASS,
   [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]
  );
  return self::$pdo;
 }
}

