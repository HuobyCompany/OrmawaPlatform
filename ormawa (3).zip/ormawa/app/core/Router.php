<?php
final class Router {
 private array $routes=[];
 public function get(string $p,callable $h):void{$this->add('GET',$p,$h);}
 public function post(string $p,callable $h):void{$this->add('POST',$p,$h);}
 private function add(string $m,string $p,callable $h):void{$this->routes[]=[$m,$p,$h];}
  public function dispatch(string $method, string $uri): void{
   $path = function_exists('request_path') ? request_path() : (parse_url($uri, PHP_URL_PATH) ?: '/');
   $path = '/' . trim($path, '/'); if ($path !== '/') $path = rtrim($path, '/');
   foreach($this->routes as [$rm,$pat,$handler]){
    if($rm!==$method)continue;
    $rx=preg_replace('#\{([a-zA-Z_][a-zA-Z0-9_]*)\}#','(?P<$1>[^/]+)',$pat);
    if(preg_match('#^'.$rx.'$#',$path,$m)){ $args=[];foreach($m as $k=>$v)if(!is_int($k))$args[]=urldecode($v); call_user_func_array($handler,$args);return; }
   }
   http_response_code(404); View::render('errors/404',[],'error');
  }
}

