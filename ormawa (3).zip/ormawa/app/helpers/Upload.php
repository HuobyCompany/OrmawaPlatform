<?php
final class Upload{
  public const ALLOWED=[
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/webp' => 'webp',
    'image/x-icon' => 'ico',
    'image/svg+xml' => 'svg',
  ];
  private static function isOptimizable(string $mime):bool{
    return in_array($mime,['image/jpeg','image/png','image/webp'],true);
  }
  public static function handle(array $f,string $folder,?string $old=null):array{
    if(($f['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)throw new RuntimeException('File tidak dipilih.');
    if(($f['error']??0)!==UPLOAD_ERR_OK){
      $msg='Upload gagal.';
      if(($f['error']??0)===UPLOAD_ERR_INI_SIZE)$msg='Ukuran file melebihi batas maksimum server ('.ini_get('upload_max_filesize').').';
      if(($f['error']??0)===UPLOAD_ERR_FORM_SIZE)$msg='Ukuran file melebihi batas formulir.';
      throw new RuntimeException($msg);
    }
    if(($f['size']??0)>UPLOAD_MAX_BYTES)throw new RuntimeException('Ukuran file melebihi '.round(UPLOAD_MAX_BYTES/1024/1024,1).' MB.');
    if(!is_uploaded_file($f['tmp_name']))throw new RuntimeException('File upload tidak valid. Pastikan folder upload writable.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if(!isset(self::ALLOWED[$mime]))throw new RuntimeException('Format harus JPG, PNG, WebP, ICO, atau SVG.');
    $name=bin2hex(random_bytes(16)).'.'.self::ALLOWED[$mime];
    $dir=UPLOAD_PATH.'/'.trim($folder,'/');
    if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Folder upload tidak dapat dibuat.');
    $dest=$dir.'/'.$name;
    if(!move_uploaded_file($f['tmp_name'],$dest))throw new RuntimeException('File tidak dapat disimpan. Cek permission folder upload.');
    if(self::isOptimizable($mime)){
      self::optimize($dest,$mime);
      self::makeThumbnail($dest,$folder,$name,$mime);
    }
    if($old)self::delete($old);
    return ['path'=>trim($folder,'/').'/'.$name,'mime'=>$mime,'size'=>(int)filesize($dest),'name'=>$name];
  }
  public static function handleDocument(array $f,string $folder,?string $old=null):array{
    if(($f['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)throw new RuntimeException('File tidak dipilih.');
    if(($f['error']??0)!==UPLOAD_ERR_OK)throw new RuntimeException('Upload gagal.');
    if(($f['size']??0)>(15 * 1024 * 1024))throw new RuntimeException('Ukuran file melebihi 15 MB.');
    if(!is_uploaded_file($f['tmp_name']))throw new RuntimeException('File upload tidak valid.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $allowedDocs = [
      'application/pdf' => 'pdf',
      'application/msword' => 'doc',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
      'image/jpeg' => 'jpg',
      'image/png' => 'png',
      'image/webp' => 'webp',
      'image/x-icon' => 'ico',
      'image/svg+xml' => 'svg',
    ];
    if(!isset($allowedDocs[$mime])) throw new RuntimeException('Format file harus PDF, DOC, DOCX, JPG, PNG, WebP, ICO, atau SVG.');
    $ext = $allowedDocs[$mime];
    $name=bin2hex(random_bytes(16)).'.'.$ext;
    $dir=UPLOAD_PATH.'/'.trim($folder,'/');
    if(!is_dir($dir)&&!mkdir($dir,0755,true))throw new RuntimeException('Folder upload tidak dapat dibuat.');
    $dest=$dir.'/'.$name;
    if(!move_uploaded_file($f['tmp_name'],$dest))throw new RuntimeException('File tidak dapat disimpan.');
    if(self::isOptimizable($mime)){
      self::optimize($dest, $mime);
      self::makeThumbnail($dest, $folder, $name, $mime);
    }
    if($old)self::delete($old);
    return ['path'=>trim($folder,'/').'/'.$name,'mime'=>$mime,'size'=>(int)filesize($dest),'name'=>$name];
  }
  public static function delete(?string $rel):void{if(!$rel)return;$root=realpath(UPLOAD_PATH);$rel=ltrim($rel,'/');$full=realpath(UPLOAD_PATH.'/'.$rel);if($full&&$root&&str_starts_with($full,$root.DIRECTORY_SEPARATOR)&&is_file($full))@unlink($full);$dir=dirname($rel);$base=basename($rel);$thumb=UPLOAD_PATH.'/'.$dir.'/thumb_'.$base;$tf=realpath($thumb);if($tf&&$root&&str_starts_with($tf,$root.DIRECTORY_SEPARATOR)&&is_file($tf))@unlink($tf);}
  public static function optimize(string $p,string $mime):void{if(!function_exists('imagecreatefromjpeg'))return;[$w,$h]=@getimagesize($p)?:[0,0];if(!$w||!$h||max($w,$h)<=2200)return;$r=min(2200/$w,2200/$h);$nw=max(1,(int)($w*$r));$nh=max(1,(int)($h*$r));$src=match($mime){'image/jpeg'=>@imagecreatefromjpeg($p),'image/png'=>@imagecreatefrompng($p),'image/webp'=>@imagecreatefromwebp($p),default=>null};if(!$src)return;$dst=imagecreatetruecolor($nw,$nh);if($mime!=='image/jpeg'){imagealphablending($dst,false);imagesavealpha($dst,true);$tr=imagecolorallocatealpha($dst,0,0,0,127);imagefilledrectangle($dst,0,0,$nw,$nh,$tr);}imagecopyresampled($dst,$src,0,0,0,0,$nw,$nh,$w,$h);match($mime){'image/jpeg'=>imagejpeg($dst,$p,84),'image/png'=>imagepng($dst,$p,6),'image/webp'=>imagewebp($dst,$p,82),default=>null};imagedestroy($src);imagedestroy($dst);}
  public static function makeThumbnail(string $p,string $folder,string $name,string $mime):void{if(!function_exists('imagecreatefromjpeg'))return;[$w,$h]=@getimagesize($p)?:[0,0];if(!$w||!$h)return;$tw=640;$th=max(1,(int)($h*($tw/$w)));$src=match($mime){'image/jpeg'=>@imagecreatefromjpeg($p),'image/png'=>@imagecreatefrompng($p),'image/webp'=>@imagecreatefromwebp($p),default=>null};if(!$src)return;$dst=imagecreatetruecolor($tw,$th);if($mime!=='image/jpeg'){imagealphablending($dst,false);imagesavealpha($dst,true);$tr=imagecolorallocatealpha($dst,0,0,0,127);imagefilledrectangle($dst,0,0,$tw,$th,$tr);}imagecopyresampled($dst,$src,0,0,0,0,$tw,$th,$w,$h);$thumb=UPLOAD_PATH.'/'.trim($folder,'/').'/thumb_'.$name;match($mime){'image/jpeg'=>imagejpeg($dst,$thumb,80),'image/png'=>imagepng($dst,$thumb,6),'image/webp'=>imagewebp($dst,$thumb,80),default=>null};imagedestroy($src);imagedestroy($dst);}
}