<?php
final class Csrf{
  public static function token():string{if(empty($_SESSION['_csrf']))$_SESSION['_csrf']=bin2hex(random_bytes(32));return $_SESSION['_csrf'];}
  public static function field():string{return '<input type="hidden" name="_csrf" value="'.e(self::token()).'">';}
  public static function check():void{$t=$_POST['_csrf']??'';if(!$t||!hash_equals($_SESSION['_csrf']??'',$t)){http_response_code(419);exit('Sesi form kedaluwarsa.');}self::rotate();}
  private static function rotate():void{$_SESSION['_csrf']=bin2hex(random_bytes(32));}
}

