<?php
declare(strict_types=1);

final class DriveUrlParser
{
    /**
     * Extracts an individual Google Drive file ID from common Google Drive file URLs.
     * Strictly rejects folder URLs.
     */
    public static function extractFileId(string $url): ?string
    {
        $url = trim($url);

        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return null;
        }

        $parsed = parse_url($url);
        if (!isset($parsed['host'])) {
            return null;
        }

        $host = strtolower($parsed['host']);
        if (!str_contains($host, 'drive.google.com') && !str_contains($host, 'docs.google.com')) {
            return null;
        }

        $path = $parsed['path'] ?? '';

        // STRICT REJECTION: Reject folder URLs explicitly
        if (
            preg_match('#/folders/#i', $path) ||
            preg_match('#/drive/u/\d+/folders/#i', $path) ||
            preg_match('#/drive/folders/#i', $path)
        ) {
            return null;
        }

        if (isset($parsed['query'])) {
            parse_str($parsed['query'], $queryParams);
            if (isset($queryParams['isFolder']) && ($queryParams['isFolder'] === 'true' || $queryParams['isFolder'] === '1')) {
                return null;
            }
            if (isset($queryParams['folderId'])) {
                return null;
            }
        }

        $fileId = null;

        // Pattern 1: /file/d/FILE_ID/...
        if (preg_match('#/file/d/([A-Za-z0-9_-]{20,})#i', $path, $matches)) {
            $fileId = $matches[1];
        }

        // Pattern 2: /document/d/FILE_ID/..., /spreadsheets/d/FILE_ID/..., etc.
        if (!$fileId && preg_match('#/(?:document|spreadsheets|presentation|drawings)/d/([A-Za-z0-9_-]{20,})#i', $path, $matches)) {
            $fileId = $matches[1];
        }

        // Pattern 3: Query string parameters: id=FILE_ID (for open?id=..., uc?id=..., thumbnail?id=...)
        if (!$fileId && isset($parsed['query'])) {
            parse_str($parsed['query'], $queryParams);
            if (isset($queryParams['id']) && is_string($queryParams['id'])) {
                $idCandidate = trim($queryParams['id']);
                if (preg_match('/^[A-Za-z0-9_-]{20,}$/', $idCandidate)) {
                    $fileId = $idCandidate;
                }
            }
        }

        // Validate final file ID format
        if (!$fileId || !preg_match('/^[A-Za-z0-9_-]{20,}$/', $fileId)) {
            return null;
        }

        return $fileId;
    }

    /**
     * Legacy helper to check if a URL is a folder.
     */
    public static function isFolderUrl(string $url): bool
    {
        $url = trim($url);
        if ($url === '') return false;
        $parsed = parse_url($url);
        $path = $parsed['path'] ?? '';
        return (bool)(
            preg_match('#/folders/#i', $path) ||
            preg_match('#/drive/u/\d+/folders/#i', $path) ||
            preg_match('#/drive/folders/#i', $path)
        );
    }
}
