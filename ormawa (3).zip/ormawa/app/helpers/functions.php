<?php
function e(?string $v):string{return htmlspecialchars($v??'',ENT_QUOTES,'UTF-8');}
function url(string $p=''):string{return rtrim(APP_URL,'/').'/'.ltrim($p,'/');}
function org_url(?array $org = null, string $p = ''): string {
    if (!$org) {
        return url($p);
    }
    $slug = trim((string)($org['slug'] ?? DEFAULT_ORGANIZATION_SLUG), '/');
    $p = ltrim($p, '/');
    $requestPath = request_path();
    $parts = array_values(array_filter(explode('/', trim($requestPath, '/'))));
    $firstSeg = $parts[0] ?? '';
    if ($firstSeg === $slug) {
        return url($slug . ($p ? '/' . $p : ''));
    }
    return url($p);
}
function asset(string $p):string{return url('public/assets/'.ltrim($p,'/'));}
function asset_url(string $p):string{return asset($p);}
function media_url(string $p):string{return url('public/uploads/'.ltrim($p,'/'));}
function upload_url(string $p):string{return media_url($p);}
function thumbnail_url(string $p):string{$p=ltrim($p,'/');$candidate=UPLOAD_PATH.'/'.$p;$thumb=UPLOAD_PATH.'/'.dirname($p).'/thumb_'.basename($p);return is_file($thumb)?media_url(dirname($p).'/thumb_'.basename($p)):media_url($p);}
function absolute_url(string $p):string{return preg_match('#^https?://#i',$p)?$p:url($p);}
function redirect(string $p,int $status=302):never{header('Location: '.(preg_match('#^https?://#i',$p)?$p:url($p)),true,$status);exit;}
function flash(string $k,?string $m=null):?string{if($m!==null){$_SESSION['_flash'][$k]=$m;return null;}$v=$_SESSION['_flash'][$k]??null;unset($_SESSION['_flash'][$k]);return $v;}
function current_user():?array{
    // Check unified authentication first
    if (class_exists('AuthService') && AuthService::isAuthenticated()) {
        return AuthService::currentUser();
    }
    // Fallback to legacy authentication
    return $_SESSION['user']??null;
}
function auth_user():?array{return current_user();}
function is_logged_in():bool{return current_user()!==null;}
function is_member_logged_in():bool{
    if(!empty($_SESSION['member_auth']['id'])){
        return true;
    }
    if(!empty($_COOKIE['ormawa_member_token'])){
        $token=$_COOKIE['ormawa_member_token'];
        $hash=hash('sha256',$token);
        $pdo=Database::connection();
        $s=$pdo->prepare('SELECT s.*, o.slug AS org_slug FROM registration_submissions s JOIN organizations o ON o.id = s.organization_id WHERE s.public_token_hash = :hash AND s.status = "approved"');
        $s->execute(['hash'=>$hash]);
        $sub=$s->fetch();
        if($sub){
            $_SESSION['member_auth']=[
                'id'=>(int)$sub['id'],
                'member_number'=>$sub['member_number'],
                'name'=>$sub['full_name'],
                'organization_id'=>(int)$sub['organization_id'],
                'org_slug'=>$sub['org_slug'],
            ];
            setcookie('ormawa_member_token',$token,time()+(365*86400),'/', '', false, true);
            return true;
        }
    }
    return false;
}
function current_member():?array{
    if(is_member_logged_in()){
        $id=(int)($_SESSION['member_auth']['id']??0);
        if($id>0){
            $pdo=Database::connection();
            $s=$pdo->prepare('SELECT s.*, o.name AS organization_name, o.short_name AS organization_short_name, o.slug AS organization_slug, o.logo AS organization_logo, o.website_name FROM registration_submissions s JOIN organizations o ON o.id = s.organization_id WHERE s.id = :id AND s.status = "approved"');
            $s->execute(['id'=>$id]);
            return $s->fetch()?:null;
        }
    }
    return null;
}
function selected_organization_id():?int{return isset($_SESSION['organization_id'])?(int)$_SESSION['organization_id']:null;}
function set_selected_organization(int $id):void{$_SESSION['organization_id']=$id;}
function request_path():string{
    $p=parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)?:'/';
    $appPath=defined('APP_URL')?rtrim((string)parse_url(APP_URL,PHP_URL_PATH),'/'):'';
    if($appPath && $appPath !== '' && str_starts_with($p, $appPath)){
        $p=substr($p,strlen($appPath))?:'/';
    } else {
        $base=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME']??'')),'/');
        // Do not strip base if it equals an app top-level directory like /admin
        if($base&&$base!=='/'&&!in_array($base,['/admin','/member','/public'],true)&&str_starts_with($p,$base)){
            $p=substr($p,strlen($base))?:'/';
        }
    }
    return '/'.trim($p,'/');
}
function old(string $k,mixed $d=''):mixed{return $_SESSION['_old'][$k]??$d;}
function slugify(string $s):string{$s=trim(function_exists('mb_strtolower')?mb_strtolower($s):strtolower($s));$s=function_exists('iconv')?(iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s)?:$s):$s;$s=preg_replace('/[^a-z0-9]+/i','-',$s);return trim($s,'-')?:'item';}
function format_date_id(?string $d):string{if(!$d)return '-';$m=[1=>'Januari',2=>'Februari',3=>'Maret',4=>'April',5=>'Mei',6=>'Juni',7=>'Juli',8=>'Agustus',9=>'September',10=>'Oktober',11=>'November',12=>'Desember'];$dt=new DateTime($d,new DateTimeZone(APP_TIMEZONE));return $dt->format('j').' '.$m[(int)$dt->format('n')].' '.$dt->format('Y');}
function format_time(?string $t):string{return $t?(new DateTime($t))->format('H:i'):'-';}
function excerpt(?string $t,int $n=150):string{$t=trim(strip_tags((string)$t));$len=function_exists('mb_strlen')?mb_strlen($t):strlen($t);return $len<=$n?$t:(function_exists('mb_substr')?mb_substr($t,0,$n-1):substr($t,0,$n-1)).'…';}
function clean_rich(?string $html):string{return Sanitizer::richText($html??'');}
function theme_vars(?array $org):string{if(!$org)return '';return '--primary-color:'.e($org['primary_color']??'#0a84ff').';--secondary-color:'.e($org['secondary_color']??'#5e5ce6').';--accent-color:'.e($org['accent_color']??'#30d158').';--background-color:'.e($org['background_color']??'#f7f8fa').';--text-color:'.e($org['text_color']??'#111827').';--font-family:\''.e($org['font_family']??'Inter').'\',system-ui,sans-serif;';}
function require_role(array $roles):void{
    $u=current_user();
    if(!$u||!in_array($u['role'],$roles,true)){
        http_response_code(403);
        View::render('errors/403',[],'error');
        exit;
    }
}
function can(string $permission):bool{
    // Check unified authentication first
    if (class_exists('AuthService') && AuthService::isAuthenticated()) {
        return AuthService::can($permission);
    }
    // Fallback to legacy authentication
    $u=current_user();
    if(!$u)return false;
    if($u['role']==='super_admin')return true;
    $map=['manage_settings'=>['organization_admin'],'manage_users'=>['organization_admin'],'manage_content'=>['organization_admin','editor']];
    return in_array($u['role'],$map[$permission]??[],true);
}
function safe_external_url(?string $u):string{
 $u=trim((string)$u);
 if(!preg_match('#^https?://#i',$u))return '';
 $host=parse_url($u,PHP_URL_HOST);
 if(!$host)return '';
 $blocked=['localhost','127.0.0.1','0.0.0.0','::1','[::1]'];
 $lowerHost=strtolower($host);
 if(in_array($lowerHost,$blocked,true))return '';
 if(preg_match('/^10\./',$lowerHost)||preg_match('/^100\.64\./',$lowerHost)||preg_match('/^172\.(1[6-9]|2\d|3[01])\./',$lowerHost)||preg_match('/^192\.168\./',$lowerHost)||preg_match('/^169\.254\./',$lowerHost))return '';
 return $u;
}
function validate_remote_image_url(?string $url):array{
 $url=trim((string)$url);
 if($url==='')return ['ok'=>false,'error'=>'URL gambar kosong.'];
 if(!preg_match('#^https?://#i',$url))return ['ok'=>false,'error'=>'URL harus diawali http:// atau https://.'];
 $safe=safe_external_url($url);
 if($url!==$safe)return ['ok'=>false,'error'=>'URL gambar tidak diizinkan karena menuju host internal/private.'];
 $ch=curl_init($url);
 curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_NOBODY=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_TIMEOUT=>10,CURLOPT_USERAGENT=>'ORMAWA-Platform-Gallery/1.0']);
 curl_exec($ch);
 $httpCode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
 $contentType=curl_getinfo($ch,CURLINFO_CONTENT_TYPE);
 curl_close($ch);
 if($httpCode<200||$httpCode>=400)return ['ok'=>false,'error'=>'Gambar tidak dapat diakses (HTTP '.$httpCode.').'];
 if(!$contentType||!preg_match('#^image/(jpeg|png|webp|gif)#i',$contentType))return ['ok'=>false,'error'=>'URL tersebut bukan resource gambar yang valid.'];
 return ['ok'=>true,'url'=>$url,'mime_type'=>$contentType];
}
function dummy_image_url(string $seed, int $width = 800, int $height = 600): string {
    static $counter = 0;
    $counter++;
    return 'https://picsum.photos/seed/' . urlencode($seed . '-' . $counter) . '/' . (int)$width . '/' . (int)$height;
}
function check_login_rate_limit(string $email): void {
    $key = 'login_attempts_' . md5($email);
    $now = time();
    $attempts = $_SESSION[$key] ?? [];
    $attempts = array_filter($attempts, fn($t) => $now - (int)$t < 900);
    if (count($attempts) >= 5) {
        throw new RuntimeException('Terlalu banyak percobaan login. Coba lagi dalam 15 menit.');
    }
}
function record_login_attempt(string $email): void {
    $key = 'login_attempts_' . md5($email);
    $now = time();
    $attempts = $_SESSION[$key] ?? [];
    $attempts[] = $now;
    $_SESSION[$key] = array_slice($attempts, -10);
}
function clear_login_attempts(string $email): void {
    unset($_SESSION['login_attempts_' . md5($email)]);
}
