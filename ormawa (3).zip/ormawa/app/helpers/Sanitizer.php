<?php
final class Sanitizer {
    /**
     * Sanitize rich text HTML — allows safe formatting tags only.
     * Strips scripts, event handlers, style attrs, and dangerous href values.
     */
    public static function richText(?string $html): string {
        $html = trim((string)$html);
        if ($html === '') return '';

        // 1. Strip all tags except allowed formatting/structure tags
        $allowed = '<p><br><strong><b><em><i><u><ul><ol><li><a><h2><h3><h4><blockquote><span><hr><s><sub><sup>';
        $html = strip_tags($html, $allowed);

        // 1b. Replace non-breaking spaces (&nbsp; and UTF-8 \xC2\xA0) with normal spaces so line-wrapping works
        $html = str_replace(['&nbsp;', "\xc2\xa0"], ' ', $html);

        // 2. Remove ALL event handlers (onclick, onmouseover, onerror, etc.)
        $html = preg_replace('/\s+on[a-z]{1,20}\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);

        // 3. Remove style attributes (prevents CSS injection)
        $html = preg_replace('/\s+style\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);

        // 4. Remove potentially dangerous attributes
        foreach (['target', 'rel', 'class', 'id'] as $attr) {
            $html = preg_replace('/\s+' . $attr . '\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);
        }

        // 5. Sanitize <a> tags: block javascript:/data:/vbscript: hrefs, add safe rel
        $html = preg_replace_callback('/<a\b([^>]*)>/i', function ($m) {
            $attrs = $m[1];
            if (preg_match('/href\s*=\s*(["\'])(.*?)\1/i', $attrs, $x)) {
                if (preg_match('/^\s*(javascript|data|vbscript)\s*:/i', $x[2])) {
                    $attrs = preg_replace('/\s*href\s*=\s*(["\']).*?\1/i', '', $attrs);
                }
            }
            return '<a' . $attrs . ' rel="noopener noreferrer">';
        }, $html);

        // 6. Belt-and-suspenders: remove remaining dangerous tag fragments
        $html = preg_replace('/<\s*(script|iframe|object|embed|form|input|svg|math)\b[^>]*>.*?<\/\s*\1\s*>/is', '', $html);
        $html = preg_replace('/<\s*(script|iframe|object|embed|form|input|svg|math)\b[^>]*\/?>/i', '', $html);

        return $html;
    }
}
