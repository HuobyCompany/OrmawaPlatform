<?php
declare(strict_types=1);

final class FrontendController {
    private function base(string $uri): array {
        $o = OrganizationResolver::resolve($uri);
        if (!$o) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            exit;
        }
        $settings = SettingModel::all($o['id']);
        $sections = HomeSectionModel::all($o['id']);
        $pages = [];
        foreach (PageModel::all($o['id']) as $p) {
            $pages[$p['page_key']] = $p;
        }

        // Determine registration availability for navbar
        $registrationAvailable = false;
        if (!empty($o['id'])) {
            if (($settings['registration_enabled'] ?? '0') === '1') {
                $registrationAvailable = RegistrationFormModel::active($o['id']) !== null;
            }
        }

        return [$o, $settings, $sections, $pages, $registrationAvailable];
    }

    private function tree(array $ps): array {
        $map = [];
        $ch = [];
        foreach ($ps as $p) {
            $map[$p['id']] = $p;
            $pid = (int)($p['parent_id'] ?? 0);
            $ch[$pid][] = $p['id'];
        }
        $build = function ($id) use (&$build, &$map, &$ch) {
            $p = $map[$id];
            $p['children'] = array_map($build, $ch[$id] ?? []);
            return $p;
        };
        return array_map($build, $ch[0] ?? []);
    }

    private function homeCalendar(int $org): array {
        $now = new DateTime('now', new DateTimeZone(APP_TIMEZONE));
        $from = $now->format('Y-m-01');
        $to = $now->format('Y-m-t');
        return EventModel::calendar($org, $from, $to);
    }

    public function home(): void {
    [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');

    $events = EventModel::upcoming($o['id'], 4);
    $albums = GalleryModel::albums($o['id'], '', null, null, 1, 6)['items'];
    $ps = array_values(array_filter(PositionModel::all($o['id']), fn($p) => $p['status'] === 'active'));

        View::render('frontend/home', [
            'title' => $o['website_name'] ?: $o['name'],
            'organization' => $o,
            'settings' => $s,
            'sections' => $sec,
            'pages' => $pages,
            'events' => $events,
            'albums' => $albums,
            'positions' => $ps,
            'tree' => $this->tree($ps),
            'month_events' => $this->homeCalendar($o['id']),
            'meta_description' => $o['description'],
            'registration_available' => $registrationAvailable
        ]);
    }

    public function about(): void {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');
        $p = ['title' => 'Tentang Organisasi', 'content' => $o['about']];
        View::render('frontend/about', [
            'title' => $p['title'],
            'organization' => $o,
            'settings' => $s,
            'page' => $p,
            'registration_available' => $registrationAvailable
        ]);
    }

    public function events(): void {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');

        $filter = isset($_GET['filter']) && is_string($_GET['filter']) ? $_GET['filter'] : 'all';
        if (!in_array($filter, ['all', 'upcoming', 'past', 'month', 'year'], true)) {
            $filter = 'all';
        }

        $q = isset($_GET['q']) && is_string($_GET['q']) ? trim($_GET['q']) : '';
        $page = max(1, (int)($_GET['page'] ?? 1));

        $l = EventModel::all($o['id'], $q, $filter, $page, 9);

        View::render('frontend/events', [
            'title' => 'Kegiatan',
            'organization' => $o,
            'settings' => $s,
            'events' => $l['items'],
            'pagination' => [
                'total_pages' => (int)ceil($l['total'] / max(1, $l['per_page'])),
                'page' => $l['page']
            ],
            'filters' => [
                'q' => $q,
                'filter' => $filter
            ],
            'registration_available' => $registrationAvailable
        ]);
    }

    public function event(string ...$args): void {
        $slug = $args[0] ?? '';
        if (count($args) === 2) {
            $slug = $args[1];
        }
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');
        $e = EventModel::bySlug($slug, $o['id']);
        if (!$e) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            return;
        }
        View::render('frontend/event_detail', [
            'title' => $e['title'],
            'organization' => $o,
            'settings' => $s,
            'event' => $e,
            'canonical' => org_url($o, 'kegiatan/' . $e['slug']),
            'meta_description' => excerpt($e['description'], 160),
            'registration_available' => $registrationAvailable
        ]);
    }

    public function calendar(): void {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');
        
        $m = isset($_GET['month']) ? max(1, min(12, (int)$_GET['month'])) : (int)date('n');
        $y = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
        
        $from = sprintf('%04d-%02d-01', $y, $m);
        $to = date('Y-m-t', strtotime($from));
        
        $calendarEvents = EventModel::calendar($o['id'], $from, $to);
        foreach ($calendarEvents as &$ce) {
            $ce['poster_url'] = $ce['poster'] ? media_url($ce['poster']) : '';
        }
        unset($ce);

        View::render('frontend/calendar', [
            'title' => 'Kalender',
            'organization' => $o,
            'settings' => $s,
            'events' => $calendarEvents,
            'month' => $m,
            'year' => $y,
            'registration_available' => $registrationAvailable
        ]);
    }

    public function gallery(): void {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');

        $year = isset($_GET['year']) && $_GET['year'] !== '' ? (int)$_GET['year'] : null;
        $q = isset($_GET['q']) && is_string($_GET['q']) ? trim($_GET['q']) : '';
        $category = isset($_GET['category']) && is_string($_GET['category']) ? trim($_GET['category']) : '';
        $page = max(1, (int)($_GET['page'] ?? 1));

        $list = GalleryModel::albums($o['id'], $q, $category ?: null, $year, $page, 9);

        $yearsQuery = Database::connection()->prepare('SELECT DISTINCT YEAR(event_date) year FROM gallery_albums WHERE organization_id = :o AND event_date IS NOT NULL ORDER BY year DESC');
        $yearsQuery->execute(['o' => $o['id']]);
        $categoriesQuery = Database::connection()->prepare('SELECT DISTINCT category FROM gallery_albums WHERE organization_id = :o AND category IS NOT NULL AND category <> :empty ORDER BY category');
        $categoriesQuery->execute(['o' => $o['id'], 'empty' => '']);

        View::render('frontend/gallery', [
            'title' => 'Gallery',
            'organization' => $o,
            'settings' => $s,
            'albums' => $list['items'],
            'pagination' => [
                'total_pages' => (int)ceil($list['total'] / max(1, $list['per_page'])),
                'page' => $list['page']
            ],
            'filters' => [
                'q' => $q,
                'category' => $category,
                'year' => $year
            ],
            'years' => $yearsQuery ? $yearsQuery->fetchAll() : [],
            'categories' => $categoriesQuery ? $categoriesQuery->fetchAll() : [],
            'registration_available' => $registrationAvailable
        ]);
    }

    public function galleryAlbum(string ...$args): void {
        $slug = $args[0] ?? '';
        if (count($args) === 2) {
            $slug = $args[1];
        }
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');
        $a = GalleryModel::bySlug($slug, $o['id']);
        if (!$a) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            return;
        }
        View::render('frontend/gallery_album', [
            'title' => $a['title'],
            'organization' => $o,
            'settings' => $s,
            'album' => $a,
            'items' => GalleryModel::items($a['id'], $o['id']),
            'registration_available' => $registrationAvailable
        ]);
    }

    public function structure(): void {
        // Resolve organization and basic data
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');

        // Load organization terms for selector (may be empty)
        $terms = TermModel::all($o['id']) ?: [];

        $selectedTermId = null;
        if (isset($_GET['term']) && is_numeric($_GET['term'])) {
            $selectedTermId = (int)$_GET['term'];
        } else {
            // Fallback to the most recent term (by start_date)
            $latest = null;
            foreach ($terms as $t) {
                if ($latest === null || $t['start_date'] > $latest['start_date']) {
                    $latest = $t;
                }
            }
            $selectedTermId = $latest['id'] ?? null;
        }

        // Get hierarchical structure for the selected term (handles null term gracefully)
        // Use publicOnly=true to filter out private/draft structure data
        $structureTree = StructureService::getStructureTree($o['id'], $selectedTermId, true);

        View::render('frontend/structure', [
            'title' => 'Struktur Organisasi',
            'organization' => $o,
            'settings' => $s,
            'terms' => $terms,
            'selectedTermId' => $selectedTermId,
            'structureTree' => $structureTree,
            'registration_available' => $registrationAvailable
        ]);
    }

    public function contact(): void {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->base($_SERVER['REQUEST_URI'] ?? '/');
        View::render('frontend/contact', [
            'title' => 'Kontak',
            'organization' => $o,
            'settings' => $s,
            'registration_available' => $registrationAvailable
        ]);
    }
}
