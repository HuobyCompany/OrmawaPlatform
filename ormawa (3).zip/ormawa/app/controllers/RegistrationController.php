<?php
declare(strict_types=1);

final class RegistrationController
{
    private const FIELD_TYPE_LABELS = [
        'text' => 'Teks',
        'textarea' => 'Teks Panjang',
        'number' => 'Angka',
        'phone' => 'Nomor Telepon',
        'date' => 'Tanggal',
        'email' => 'Email',
        'select' => 'Pilihan Ganda (Select)',
        'radio' => 'Pilihan Ganda (Radio)',
        'checkbox' => 'Kotak Centang',
        'file_image' => 'Upload Foto',
        'file' => 'Upload File',
        'social_media' => 'Media Sosial',
        'faculty_selector' => 'Pemilih Fakultas',
        'program_study_selector' => 'Pemilih Program Studi',
    ];

    public static function fieldTypes(): array
    {
        $types = [];
        foreach (self::FIELD_TYPE_LABELS as $type => $label) {
            $types[] = ['value' => $type, 'label' => $label];
        }
        return $types;
    }

    // === ADMIN: Form Builder ===

    public function builder(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        $o = OrganizationController::current();
        $form = RegistrationFormModel::active($o['id']);
        $fields = $form ? RegistrationFieldModel::byForm((int)$form['id']) : [];
        $allForms = RegistrationFormModel::findByOrg($o['id']);

        View::render('admin/registration_builder', [
            'title' => 'Formulir Pendaftaran',
            'organization' => $o,
            'form' => $form,
            'fields' => $fields,
            'allForms' => $allForms,
            'fieldTypes' => self::fieldTypes(),
            'faculties' => FacultyModel::all(),
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
        ], 'admin');
    }

    public function createForm(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $title = trim($_POST['title'] ?? 'Formulir Pendaftaran');
        $desc = trim($_POST['description'] ?? '') ?: null;
        $formId = RegistrationFormModel::create($o['id'], $title, $desc);
        // Activate the newly created form so it appears in the builder view
        RegistrationFormModel::activate($formId, $o['id']);
        flash('success', 'Formulir baru dibuat. Sekarang tambahkan field.');
        redirect('admin/registration');
    }

    public function saveForm(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['form_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $desc = trim($_POST['description'] ?? '') ?: null;
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if ($id) {
            $form = RegistrationFormModel::find($id, $o['id']);
            if (!$form) { flash('error', 'Formulir tidak ditemukan.'); redirect('admin/registration'); }
            RegistrationFormModel::update($id, $o['id'], $title, $desc, $isActive);
        } else {
            $id = RegistrationFormModel::create($o['id'], $title, $desc);
            if ($isActive) RegistrationFormModel::activate($id, $o['id']);
        }
        ActivityLogModel::add($o['id'], current_user()['id'], $isActive ? 'activate' : 'update', 'registration_form', 'Form pendaftaran "' . $title . '" disimpan');
        flash('success', 'Formulir tersimpan.');
        redirect('admin/registration');
    }

    public function addField(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $formId = (int)($_POST['form_id'] ?? 0);
        $form = RegistrationFormModel::find($formId, $o['id']);
        if (!$form) { flash('error', 'Formulir tidak ditemukan.'); redirect('admin/registration'); }

        $type = $_POST['field_type'] ?? '';
        $label = trim($_POST['label'] ?? '');
        if ($label === '') { flash('error', 'Label field wajib diisi.'); redirect('admin/registration'); }

        $options = $this->buildOptions($_POST);
        $config = $this->buildConfig($_POST);
        $validation = $this->buildValidation($_POST);

        $name = $this->generateNameFromLabel($label);

        RegistrationFieldModel::create($formId, [
            'field_type' => $type,
            'name' => $name,
            'label' => $label,
            'placeholder' => trim($_POST['placeholder'] ?? '') ?: null,
            'help_text' => trim($_POST['help_text'] ?? '') ?: null,
            'is_required' => isset($_POST['is_required']) ? 1 : 0,
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
            'sort_order' => RegistrationFieldModel::nextSortOrder($formId),
            'options_json' => $options,
            'validation_rules' => $validation,
            'config_json' => $config,
            'file_accept' => $type === 'file_image' || $type === 'file' ? ($_POST['file_accept'] ?? null) : null,
            'file_max_bytes' => $type === 'file_image' || $type === 'file' ? ((int)($_POST['file_max_bytes'] ?? 5242880)) : null,
        ]);

        ActivityLogModel::add($o['id'], current_user()['id'], 'create', 'registration_field', 'Field "' . $label . '" (tipe: ' . $type . ') ditambahkan');
        flash('success', 'Field berhasil ditambahkan.');
        redirect('admin/registration');
    }

    public function editField(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['field_id'] ?? 0);
        $form = RegistrationFormModel::find((int)($_POST['form_id'] ?? 0), $o['id']);
        if (!$form) { flash('error', 'Formulir tidak ditemukan.'); redirect('admin/registration'); }

        $field = RegistrationFieldModel::find($id, $form['id']);
        if (!$field) { flash('error', 'Field tidak ditemukan.'); redirect('admin/registration'); }

        $options = $this->buildOptions($_POST);
        $config = $this->buildConfig($_POST);
        $validation = $this->buildValidation($_POST);

        RegistrationFieldModel::update($id, $form['id'], [
            'field_type' => $_POST['field_type'] ?? $field['field_type'],
            'label' => trim($_POST['label'] ?? $field['label']),
            'placeholder' => trim($_POST['placeholder'] ?? '') ?: null,
            'help_text' => trim($_POST['help_text'] ?? '') ?: null,
            'is_required' => isset($_POST['is_required']) ? 1 : 0,
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
            'sort_order' => (int)($_POST['sort_order'] ?? $field['sort_order']),
            'options_json' => $options,
            'validation_rules' => $validation,
            'config_json' => $config,
            'file_accept' => in_array($_POST['field_type'], ['file_image', 'file']) ? ($_POST['file_accept'] ?? null) : null,
            'file_max_bytes' => in_array($_POST['field_type'], ['file_image', 'file']) ? ((int)($_POST['file_max_bytes'] ?? 5242880)) : null,
        ]);

        ActivityLogModel::add($o['id'], current_user()['id'], 'update', 'registration_field', 'Field "' . $field['label'] . '" diperbarui');
        flash('success', 'Field berhasil diperbarui.');
        redirect('admin/registration');
    }

    public function deleteField(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['field_id'] ?? 0);
        $formId = (int)($_POST['form_id'] ?? 0);
        $form = RegistrationFormModel::find($formId, $o['id']);
        if (!$form) { flash('error', 'Formulir tidak ditemukan.'); redirect('admin/registration'); }

        $field = RegistrationFieldModel::find($id, $form['id']);
        if (!$field) { flash('error', 'Field tidak ditemukan.'); redirect('admin/registration'); }

        if (RegistrationFieldModel::hasSubmissions($id)) {
            RegistrationFieldModel::softDelete($id, $form['id']);
            ActivityLogModel::add($o['id'], current_user()['id'], 'deactivate', 'registration_field', 'Field "' . $field['label'] . '" dinonaktifkan (soft-delete, masih ada submission)');
            flash('success', 'Field dinonaktifkan (data submission tetap tersimpan).');
        } else {
            $pdo = Database::connection();
            $s = $pdo->prepare('DELETE FROM registration_fields WHERE id = :id AND form_id = :f');
            $s->execute(['id' => $id, 'f' => $form['id']]);
            ActivityLogModel::add($o['id'], current_user()['id'], 'delete', 'registration_field', 'Field "' . $field['label'] . '" dihapus');
            flash('success', 'Field berhasil dihapus.');
        }
        redirect('admin/registration');
    }

    public function toggleField(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['field_id'] ?? 0);
        $form = RegistrationFormModel::find((int)($_POST['form_id'] ?? 0), $o['id']);
        if (!$form) { flash('error', 'Formulir tidak ditemukan.'); redirect('admin/registration'); }

        $current = RegistrationFieldModel::find($id, (int)$_POST['form_id'] ?? 0);
        $active = $current ? !$current['is_active'] : 1;
        RegistrationFieldModel::updateActive($id, $form['id'], (int)$active);
        ActivityLogModel::add($o['id'], current_user()['id'], $active ? 'activate' : 'deactivate', 'registration_field', 'Field di-' . ($active ? 'aktifkan' : 'nonaktifkan'));
        redirect('admin/registration');
    }

    public function reorderFields(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $formId = (int)($_POST['form_id'] ?? 0);
        $form = RegistrationFormModel::find($formId, $o['id']);
        if (!$form) { flash('error', 'Formulir tidak ditemukan.'); redirect('admin/registration'); }

        $order = $_POST['order'] ?? [];
        if (is_array($order) && count($order) > 0) {
            RegistrationFieldModel::reorder($form['id'], $order);
        }
        ActivityLogModel::add($o['id'], current_user()['id'], 'update', 'registration_field', 'Field di-reorder');
        redirect('admin/registration');
    }

    // === ADMIN: Members Directory (Approved Members) ===

    public function members(): void
    {
        AuthMiddleware::handle();
        $o = OrganizationController::current();
        $batch = $_GET['batch'] ?? null;
        $q = trim((string)($_GET['q'] ?? ''));

        $members = RegistrationSubmissionModel::members($o['id'], $batch ?: null, $q ?: null);
        $batches = RegistrationSubmissionModel::getDistinctBatches($o['id']);

        View::render('admin/members', [
            'title' => 'Data Anggota Resmi',
            'organization' => $o,
            'members' => $members,
            'batches' => $batches,
            'currentBatch' => $batch,
            'searchQuery' => $q,
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
        ], 'admin');
    }

    public function memberDetailAjax(): void
    {
        AuthMiddleware::handle();
        header('Content-Type: application/json');
        $o = OrganizationController::current();
        $id = (int)($_GET['id'] ?? 0);
        $sub = RegistrationSubmissionModel::find($id, $o['id']);
        if (!$sub) {
            echo json_encode(['ok' => false, 'message' => 'Member not found.']);
            return;
        }
        $values = RegistrationSubmissionModel::values($id);
        echo json_encode(['ok' => true, 'submission' => $sub, 'values' => $values]);
    }

    // === ADMIN: Members CRUD ===

    public function memberCreate(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        $o = OrganizationController::current();
        $faculties = FacultyModel::active();
        
        View::render('admin/member_form', [
            'title' => 'Tambah Anggota Baru',
            'organization' => $o,
            'member' => null,
            'faculties' => $faculties,
            'studyPrograms' => [],
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
        ], 'admin');
    }

    public function memberStore(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();

        $data = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'faculty_name' => trim($_POST['faculty_name'] ?? ''),
            'prodi_name' => trim($_POST['prodi_name'] ?? ''),
            'whatsapp' => trim($_POST['whatsapp'] ?? ''),
            'batch_year' => trim($_POST['batch_year'] ?? ''),
            'member_number' => trim($_POST['member_number'] ?? ''),
        ];

        if ($data['member_number'] === '' || $data['member_number'] === '-') {
            $data['member_number'] = RegistrationSubmissionModel::generateMemberNumber($o['id'], $data['batch_year'] ?: null);
        }

        $errors = [];
        if ($data['full_name'] === '') $errors[] = 'Nama lengkap wajib diisi.';

        if ($errors) {
            flash('error', implode(' ', $errors));
            redirect('admin/members/create');
            return;
        }

        $pdo = Database::connection();
        $form = RegistrationFormModel::active($o['id']);
        $formId = $form ? (int)$form['id'] : 1;
        $stmt = $pdo->prepare('INSERT INTO registration_submissions (form_id, organization_id, status, full_name, faculty_name, prodi_name, whatsapp, batch_year, member_number, public_reference, public_token_hash, submitted_at, reviewed_at, created_at, updated_at) VALUES (:fid, :o, "approved", :fn, :fac, :pro, :wa, :by, :mn, :ref, :hash, NOW(), NOW(), NOW(), NOW())');
        $ref = 'REG-MAN-' . strtoupper(bin2hex(random_bytes(4)));
        $hash = hash('sha256', bin2hex(random_bytes(32)));
        $stmt->execute([
            'fid' => $formId,
            'o' => $o['id'],
            'fn' => $data['full_name'],
            'fac' => $data['faculty_name'] ?: null,
            'pro' => $data['prodi_name'] ?: null,
            'wa' => $data['whatsapp'] ?: null,
            'by' => $data['batch_year'] ?: null,
            'mn' => $data['member_number'],
            'ref' => $ref,
            'hash' => $hash,
        ]);

        ActivityLogModel::add($o['id'], current_user()['id'], 'create', 'member', 'Anggota baru ditambahkan: ' . $data['full_name']);
        flash('success', 'Anggota berhasil ditambahkan.');
        redirect('admin/members');
    }

    public function memberEdit(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        $o = OrganizationController::current();
        $id = (int)($_GET['id'] ?? 0);
        $member = RegistrationSubmissionModel::find($id, $o['id']);
        if (!$member || $member['status'] !== 'approved') {
            flash('error', 'Anggota tidak ditemukan.');
            redirect('admin/members');
        }
        $faculties = FacultyModel::active();
        
        View::render('admin/member_form', [
            'title' => 'Edit Anggota',
            'organization' => $o,
            'member' => $member,
            'faculties' => $faculties,
            'studyPrograms' => [],
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
        ], 'admin');
    }

    public function memberUpdate(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['id'] ?? 0);
        $member = RegistrationSubmissionModel::find($id, $o['id']);
        if (!$member || $member['status'] !== 'approved') {
            flash('error', 'Anggota tidak ditemukan.');
            redirect('admin/members');
        }

        $data = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'faculty_name' => trim($_POST['faculty_name'] ?? ''),
            'prodi_name' => trim($_POST['prodi_name'] ?? ''),
            'whatsapp' => trim($_POST['whatsapp'] ?? ''),
            'batch_year' => trim($_POST['batch_year'] ?? ''),
            'member_number' => trim($_POST['member_number'] ?? ''),
        ];

        if ($data['member_number'] === '' || $data['member_number'] === '-') {
            $data['member_number'] = RegistrationSubmissionModel::generateMemberNumber($o['id'], $data['batch_year'] ?: null);
        }

        $errors = [];
        if ($data['full_name'] === '') $errors[] = 'Nama lengkap wajib diisi.';

        if ($errors) {
            flash('error', implode(' ', $errors));
            redirect('admin/members/edit?id=' . $id);
            return;
        }

        $pdo = Database::connection();
        $stmt = $pdo->prepare('UPDATE registration_submissions SET full_name = :fn, faculty_name = :fac, prodi_name = :pro, whatsapp = :wa, batch_year = :by, member_number = :mn, updated_at = NOW() WHERE id = :id AND organization_id = :o AND status = "approved"');
        $stmt->execute([
            'id' => $id,
            'o' => $o['id'],
            'fn' => $data['full_name'],
            'fac' => $data['faculty_name'] ?: null,
            'pro' => $data['prodi_name'] ?: null,
            'wa' => $data['whatsapp'] ?: null,
            'by' => $data['batch_year'] ?: null,
            'mn' => $data['member_number'],
        ]);

        ActivityLogModel::add($o['id'], current_user()['id'], 'update', 'member', 'Anggota diperbarui: ' . $data['full_name']);
        flash('success', 'Anggota berhasil diperbarui.');
        redirect('admin/members');
    }

    public function memberDelete(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['id'] ?? 0);
        $member = RegistrationSubmissionModel::find($id, $o['id']);
        if (!$member || $member['status'] !== 'approved') {
            flash('error', 'Anggota tidak ditemukan.');
            redirect('admin/members');
        }

        $name = $member['full_name'];
        RegistrationSubmissionModel::delete($id, $o['id']);

        ActivityLogModel::add($o['id'], current_user()['id'], 'delete', 'member', 'Anggota dihapus: ' . $name);
        flash('success', 'Anggota berhasil dihapus.');
        redirect('admin/members');
    }

    // === ADMIN: Submissions ===

    public function submissions(): void
    {
        AuthMiddleware::handle();
        $o = OrganizationController::current();
        $status = $_GET['status'] ?? null;
        $subs = RegistrationSubmissionModel::all($o['id'], $status);
        View::render('admin/registration_submissions', [
            'title' => 'Pendaftar Masuk',
            'organization' => $o,
            'submissions' => $subs,
            'currentStatus' => $status ?: 'all',
            'counts' => [
                'pending' => RegistrationSubmissionModel::countPending($o['id']),
                'approved' => RegistrationSubmissionModel::countByStatus($o['id'], 'approved'),
                'rejected' => RegistrationSubmissionModel::countByStatus($o['id'], 'rejected'),
            ],
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
        ], 'admin');
    }

    public function submissionView(): void
    {
        AuthMiddleware::handle();
        $o = OrganizationController::current();
        $id = (int)($this->routeParam('id') ?? $_GET['id'] ?? 0);
        $sub = RegistrationSubmissionModel::find($id, $o['id']);
        if (!$sub) { flash('error', 'Submission tidak ditemukan.'); redirect('admin/registration/submissions'); }
        $values = RegistrationSubmissionModel::values($id);
        $lifecycle = RegistrationSubmissionModel::getLifecycleTrace($id, $o['id']);

        View::render('admin/registration_submission_detail', [
            'title' => 'Detail Pendaftar',
            'organization' => $o,
            'submission' => $sub,
            'values' => $values,
            'lifecycle' => $lifecycle,
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
        ], 'admin');
    }

    public function approve(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['id'] ?? 0);
        $notes = trim($_POST['reviewer_notes'] ?? '') ?: null;
        $sub = RegistrationSubmissionModel::find($id, $o['id']);
        if (!$sub) { flash('error', 'Submission tidak ditemukan.'); redirect('admin/registration/submissions'); }

        try {
            RegistrationSubmissionModel::approve($id, $o['id'], (int)current_user()['id'], $notes);
            flash('success', 'Pendaftar berhasil disetujui dan dihubungkan ke data Anggota & Person.');
        } catch (Throwable $e) {
            flash('error', 'Gagal menyetujui pendaftar: ' . $e->getMessage());
        }
        redirect('admin/registration/submissions');
    }

    public function reject(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['id'] ?? 0);
        $notes = trim($_POST['reviewer_notes'] ?? '') ?: null;
        $sub = RegistrationSubmissionModel::find($id, $o['id']);
        if (!$sub) { flash('error', 'Submission tidak ditemukan.'); redirect('admin/registration/submissions'); }

        try {
            RegistrationSubmissionModel::reject($id, $o['id'], (int)current_user()['id'], $notes);
            flash('success', 'Pendaftar telah ditolak.');
        } catch (Throwable $e) {
            flash('error', 'Gagal menolak pendaftar: ' . $e->getMessage());
        }
        redirect('admin/registration/submissions');
    }

    public function deleteSubmission(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['id'] ?? 0);
        RegistrationSubmissionModel::delete($id, $o['id']);
        ActivityLogModel::add($o['id'], current_user()['id'], 'delete', 'registration_submission', 'Submission #' . $id . ' dihapus');
        flash('success', 'Submission dihapus.');
        redirect('admin/registration/submissions');
    }

    // === PUBLIC: Registration Form ===

    public function publicForm(): void
    {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->frontendBase($_SERVER['REQUEST_URI'] ?? '/');

        if (is_member_logged_in()) {
            redirect(org_url($o, 'kartu-anggota'));
            return;
        }

        $enabled = ($s['registration_enabled'] ?? '') === '1';
        $form = RegistrationFormModel::active($o['id']);
        $fields = $form ? RegistrationFieldModel::activeByForm((int)$form['id']) : [];

        $faculties = FacultyModel::active();
        $studyPrograms = [];
        foreach ($faculties as $f) {
            $studyPrograms[(int)$f['id']] = StudyProgramModel::byFaculty((int)$f['id']);
        }

        if (!$enabled || !$form) {
            View::render('frontend/registration_closed', [
                'title' => 'Pendaftaran',
                'organization' => $o,
                'settings' => $s,
                'sections' => $sec,
                'pages' => $pages,
                'registrationEnabled' => $enabled,
                'registration_available' => $registrationAvailable
            ]);
            return;
        }

        View::render('frontend/registration', [
            'title' => $form['title'] ?: 'Pendaftaran Anggota',
            'organization' => $o,
            'settings' => $s,
            'sections' => $sec,
            'pages' => $pages,
            'form' => $form,
            'fields' => $fields,
            'faculties' => $faculties,
            'studyPrograms' => $studyPrograms,
            'registration_available' => $registrationAvailable
        ]);
    }

    public function publicSubmit(): void
    {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->frontendBase($_SERVER['REQUEST_URI'] ?? '/');
        $enabled = ($s['registration_enabled'] ?? '') === '1';
        $form = RegistrationFormModel::active($o['id']);
        $fields = $form ? RegistrationFieldModel::activeByForm((int)$form['id']) : [];

        if (!$enabled || !$form) {
            flash('error', 'Pendaftaran tidak sedang dibuka.');
            redirect(org_url($o, 'kontak'));
            return;
        }

        Csrf::check();

        $errors = [];
        $values = [];
        $uploadedFiles = [];

        foreach ($fields as $field) {
            $fn = $field['name'];
            $ft = $field['field_type'];
            $lv = $field['is_required'] ? 'required' : 'optional';

            if (in_array($ft, ['file_image', 'file'])) {
                $v = $this->handleFileUpload($_FILES[$fn] ?? null, $o['id'], $field, $errors);
                if ($v !== null) $uploadedFiles[] = $v;
            } elseif ($ft === 'faculty_selector') {
                $v = (int)($_POST[$fn] ?? 0);
                if ($field['is_required'] && $v === 0) $errors[$fn] = 'Wajib pilih.';
                elseif ($v > 0 && !FacultyModel::find($v)) $errors[$fn] = 'Fakultas tidak valid.';
            } elseif ($ft === 'program_study_selector') {
                $v = (int)($_POST[$fn] ?? 0);
                $dependsOn = $field['config_json'] ? (json_decode($field['config_json'], true)['depends_on'] ?? null) : null;
                if ($field['is_required'] && $v === 0) $errors[$fn] = 'Wajib pilih.';
                elseif ($v > 0) {
                    $sp = StudyProgramModel::find($v);
                    if (!$sp) $errors[$fn] = 'Program studi tidak valid.';
                    else {
                        if ($dependsOn) {
                            $facultyField = $this->findFieldByName($fields, $dependsOn);
                            if ($facultyField) {
                                $selFaculty = (int)($_POST[$facultyField['name']] ?? 0);
                                if ($sp['faculty_id'] !== $selFaculty) $errors[$fn] = 'Program studi tidak cocok dengan fakultas yang dipilih.';
                            }
                        }
                    }
                }
            } elseif ($ft === 'social_media') {
                $v = $_POST[$fn] ?? [];
                $v = is_array($v) ? array_filter($v, fn($o) => trim((string)$o) !== '') : [];
                $jsonVal = $v ? json_encode(array_map('trim', $v)) : null;
                $storedVal = $jsonVal;
            } elseif ($ft === 'checkbox') {
                $v = $_POST[$fn] ?? [];
                $v = is_array($v) ? array_map('trim', array_filter($v, fn($o) => trim((string)$o) !== '')) : [];
                $jsonVal = $v ? json_encode(array_values($v)) : null;
            } else {
                $v = trim((string)($_POST[$fn] ?? ''));
                $v = $this->validateScalar($v, $ft, $field);
            }

            $values[$fn] = [
                'field_name' => $fn,
                'field_label' => $field['label'],
                'field_type' => $ft,
                'value' => in_array($ft, ['file_image', 'file']) ? null : (in_array($ft, ['checkbox', 'social_media']) ? $jsonVal : (is_array($v) ? null : $v)),
                'file_path' => in_array($ft, ['file_image', 'file']) ? $v : null,
            ];
        }

        // Extract 5 Mandatory Core Member Attributes from Section 1
        $coreFullName = trim((string)($_POST['core_full_name'] ?? ''));
        $coreFacId = (int)($_POST['core_faculty_id'] ?? 0);
        $coreProdiId = (int)($_POST['core_program_id'] ?? 0);
        $coreWa = trim((string)($_POST['core_whatsapp'] ?? ''));
        $coreBatch = trim((string)($_POST['core_batch_year'] ?? ''));

        if ($coreFullName === '') $errors['core_full_name'] = 'Nama lengkap wajib diisi.';
        if ($coreFacId <= 0) $errors['core_faculty_id'] = 'Fakultas wajib dipilih.';
        if ($coreProdiId <= 0) $errors['core_program_id'] = 'Program studi wajib dipilih.';
        if ($coreWa === '') $errors['core_whatsapp'] = 'Kontak WhatsApp wajib diisi.';
        if ($coreBatch === '') $errors['core_batch_year'] = 'Angkatan kuliah wajib dipilih.';

        $coreFacName = null;
        if ($coreFacId > 0) {
            $fObj = FacultyModel::find($coreFacId);
            if ($fObj) $coreFacName = $fObj['name'];
        }

        $coreProdiName = null;
        if ($coreProdiId > 0) {
            $spObj = StudyProgramModel::find($coreProdiId);
            if ($spObj) $coreProdiName = $spObj['name'];
        }

        if ($errors) {
            $_SESSION['_old'] = $_POST;
            $_SESSION['_errors'] = $errors;
            $_SESSION['_form_data'] = $values;
            redirect($o ? org_url($o, 'join') : 'join');
            return;
        }

        $coreData = [
            'full_name' => $coreFullName ?: null,
            'faculty_name' => $coreFacName ?: null,
            'prodi_name' => $coreProdiName ?: null,
            'whatsapp' => $coreWa ?: null,
            'batch_year' => $coreBatch ?: null,
        ];

        // Also check if fallback fields in dynamic list contain any remaining core attributes
        foreach ($fields as $field) {
            $fn = $field['name'];
            $ft = $field['field_type'];
            $fl = strtolower($field['label']);

            if (!$coreData['full_name'] && preg_match('/(nama|name)/i', $fl)) {
                $coreData['full_name'] = trim((string)($_POST[$fn] ?? ''));
            }
            if (!$coreData['faculty_name']) {
                if ($ft === 'faculty_selector') {
                    $facId = (int)($_POST[$fn] ?? 0);
                    if ($facId > 0) { $facObj = FacultyModel::find($facId); if ($facObj) $coreData['faculty_name'] = $facObj['name']; }
                } elseif (preg_match('/(fakultas|faculty)/i', $fl)) {
                    $coreData['faculty_name'] = trim((string)($_POST[$fn] ?? ''));
                }
            }
            if (!$coreData['prodi_name']) {
                if ($ft === 'program_study_selector') {
                    $prodiId = (int)($_POST[$fn] ?? 0);
                    if ($prodiId > 0) { $spObj = StudyProgramModel::find($prodiId); if ($spObj) $coreData['prodi_name'] = $spObj['name']; }
                } elseif (preg_match('/(prodi|program_studi|study_program)/i', $fl)) {
                    $coreData['prodi_name'] = trim((string)($_POST[$fn] ?? ''));
                }
            }
            if (!$coreData['whatsapp'] && preg_match('/(phone|telepon|hp|wa|whatsapp)/i', $fl)) {
                $coreData['whatsapp'] = trim((string)($_POST[$fn] ?? ''));
            }
            if (!$coreData['batch_year'] && preg_match('/(angkatan|batch|tahun)/i', $fl)) {
                $coreData['batch_year'] = trim((string)($_POST[$fn] ?? ''));
            }
        }

        $subId = RegistrationSubmissionModel::create((int)$form['id'], $o['id'], $coreData);
        foreach ($values as $val) {
            RegistrationSubmissionModel::saveValue($subId, null, [
                'field_name' => $val['field_name'],
                'field_label' => $val['field_label'],
                'field_type' => $val['field_type'],
                'value' => $val['value'],
                'file_path' => $val['file_path'],
            ]);
        }
        RegistrationSubmissionModel::setSubmitted($subId);

        // Generate public reference and token for status tracking
        $publicReference = 'REG-' . strtoupper(bin2hex(random_bytes(3)));
        $publicToken = bin2hex(random_bytes(32));
        $publicTokenHash = hash('sha256', $publicToken);
        $pdo = Database::connection();
        $pdo->prepare('UPDATE registration_submissions SET public_reference = :ref, public_token_hash = :hash WHERE id = :id AND organization_id = :o')
            ->execute(['ref' => $publicReference, 'hash' => $publicTokenHash, 'id' => $subId, 'o' => $o['id']]);

        ActivityLogModel::add($o['id'], null, 'create', 'registration_submission', 'Submission #' . $subId . ' dikirim');
        $_SESSION['flash_submission_id'] = $subId;
        $_SESSION['flash_public_reference'] = $publicReference;
        $_SESSION['flash_public_token'] = $publicToken;

        // Check if created submission has status approved and member_number assigned
        $createdSub = RegistrationSubmissionModel::find($subId, $o['id']);
        if ($createdSub && $createdSub['status'] === 'approved' && !empty($createdSub['member_number']) && !empty($createdSub['full_name'])) {
            $cardCtrl = new MemberCardController();
            $cardCtrl->setMemberSession($createdSub);
            flash('success', 'Selamat! Pendaftaran Anda berhasil dan Kartu Anggota Digital Anda telah diterbitkan.');
            redirect(org_url($o, 'kartu-anggota'));
            return;
        }

        // If system doesn't have member number yet (pending approval), redirect to Kartu Anggota login page with notice
        flash('success', 'Pendaftaran Anda berhasil dikirim! Setelah disetujui oleh pengurus, Anda dapat login menggunakan Nama Lengkap & Nomor Anggota Anda.');
        redirect(org_url($o, 'kartu-anggota'));
    }

    public function publicThanks(): void
    {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->frontendBase($_SERVER['REQUEST_URI'] ?? '/');
        $publicReference = $_SESSION['flash_public_reference'] ?? null;
        $publicToken = $_SESSION['flash_public_token'] ?? null;
        View::render('frontend/registration_thanks', [
            'title' => 'Pendaftaran Berhasil',
            'organization' => $o,
            'settings' => $s,
            'sections' => $sec,
            'pages' => $pages,
            'submissionId' => (int)($_SESSION['flash_submission_id'] ?? 0),
            'publicReference' => $publicReference,
            'publicToken' => $publicToken,
            'registration_available' => $registrationAvailable
        ]);
    }

    public function publicStatus(): void
    {
        header('Content-Type: application/json');
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->frontendBase($_SERVER['REQUEST_URI'] ?? '/');
        $reference = trim((string)($_POST['reference'] ?? $_GET['reference'] ?? ''));
        $token = trim((string)($_POST['token'] ?? $_GET['token'] ?? ''));
        if ($reference === '' || $token === '') {
            echo json_encode(['ok' => false]);
            return;
        }
        $tokenHash = hash('sha256', $token);
        $pdo = Database::connection();
        $stmt = $pdo->prepare('SELECT s.*, o.slug AS org_slug FROM registration_submissions s JOIN organizations o ON o.id = s.organization_id WHERE s.organization_id = :o AND s.public_reference = :ref AND s.public_token_hash = :hash');
        $stmt->execute(['o' => $o['id'], 'ref' => $reference, 'hash' => $tokenHash]);
        $row = $stmt->fetch();
        if (!$row) {
            echo json_encode(['ok' => false]);
            return;
        }

        // Persistent auto-login if approved member details exist
        if ($row['status'] === 'approved' && !empty($row['member_number']) && !empty($row['full_name'])) {
            $cardCtrl = new MemberCardController();
            $cardCtrl->setMemberSession($row);
        }

        echo json_encode(['ok' => true, 'reference' => $reference, 'status' => $row['status']]);
    }

    // === PUBLIC: Study Programs AJAX (for dependent select) ===

    public function studyProgramsAjax(): void
    {
        header('Content-Type: application/json');
        $orgSlug = $_GET['organization'] ?? DEFAULT_ORGANIZATION_SLUG;
        $facultyId = (int)($_GET['faculty_id'] ?? 0);
        if ($facultyId <= 0) {
            echo json_encode(['programs' => []]);
            return;
        }
        $programs = StudyProgramModel::byFaculty($facultyId);
        echo json_encode(['programs' => $programs]);
    }

    // === Helpers ===

    private function frontendBase(string $uri): array
    {
        $o = OrganizationResolver::resolve($uri);
        if (!$o) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            exit;
        }
        $settings = SettingModel::all($o['id']);
        $sections = HomeSectionModel::all($o['id']);
        $pages = [];
        foreach (PageModel::all($o['id']) as $p) {
            $pages[$p['page_key']] = $p;
        }

        // Determine registration availability for navbar
        $registrationAvailable = false;
        if (!empty($o['id'])) {
            if (($settings['registration_enabled'] ?? '0') === '1') {
                $registrationAvailable = RegistrationFormModel::active($o['id']) !== null;
            }
        }

        return [$o, $settings, $sections, $pages, $registrationAvailable];
    }

    private function buildOptions(array $post): ?string
    {
        $opts = $post['options'] ?? null;
        if (!is_array($opts) || empty(array_filter($opts, fn($o) => trim((string)$o) !== ''))) return null;
        $clean = array_values(array_filter($opts, fn($o) => trim((string)$o) !== ''));
        return json_encode(array_map('trim', $clean));
    }

    private function buildConfig(array $post): ?string
    {
        $cfg = [];
        if (isset($post['program_study_depends_on'])) {
            $cfg['depends_on'] = trim($post['program_study_depends_on']);
        }
        return $cfg ? json_encode($cfg, JSON_UNESCAPED_SLASHES) : null;
    }

    private function buildValidation(array $post): ?string
    {
        $rules = [];
        $ft = $post['field_type'] ?? '';
        if ($ft === 'email') $rules[] = 'email';
        if ($ft === 'phone') $rules[] = 'phone';
        if ($ft === 'number') $rules[] = 'number';
        if ($ft === 'date') $rules[] = 'date';
        if ($ft === 'url') $rules[] = 'url';

        if (!empty($post['max_length'])) $rules[] = 'max_length:' . (int)$post['max_length'];
        if (!empty($post['min_length'])) $rules[] = 'min_length:' . (int)$post['min_length'];

        $pattern = trim($post['custom_pattern'] ?? '');
        if ($pattern) $rules[] = 'regex:' . $pattern;

        return $rules ? json_encode($rules) : null;
    }

    private function generateNameFromLabel(string $label): string
    {
        $n = preg_replace('/[^a-zA-Z0-9_\s-]/', '', strtolower(trim($label)));
        $n = preg_replace('/[\s-]+/', '_', $n);
        $n = trim($n, '_');
        return ($n !== '' ? $n : 'field') . '_' . time();
    }

    private function findFieldByName(array $fields, string $name): ?array
    {
        foreach ($fields as $f) {
            if ($f['name'] === $name) return $f;
        }
        return null;
    }

    private function handleFileUpload(?array $file, int $orgId, array $field, array &$errors): ?string
    {
        if (!isset($file['name']) || $file['error'] === UPLOAD_ERR_NO_FILE) {
            if ($field['is_required']) $errors[$field['name']] = 'File wajib diunggah.';
            return null;
        }

        $allowedMimes = [
            'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp',
            'image/gif' => 'gif', 'image/svg+xml' => 'svg',
            'application/pdf' => 'pdf',
        ];

        if (!is_uploaded_file($file['tmp_name'])) {
            $errors[$field['name']] = 'Upload tidak valid.';
            return null;
        }

        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
        if (!isset($allowedMimes[$mime])) {
            $errors[$field['name']] = 'Format file tidak didukung.';
            return null;
        }

        $maxBytes = (int)($field['file_max_bytes'] ?? 5242880);
        if ($file['size'] > $maxBytes) {
            $errors[$field['name']] = 'Ukuran file melebihi batas maksimum ' . round($maxBytes / 1048576, 1) . ' MB.';
            return null;
        }

        $folder = 'registration/' . $orgId;
        try {
            $r = Upload::handle($file, $folder);
            return $r['path'];
        } catch (Throwable $e) {
            $errors[$field['name']] = $e->getMessage();
            return null;
        }
    }

    private function validateScalar(string $value, string $type, array $field): string|false
    {
        if ($field['is_required'] && $value === '') {
            return false;
        }
        if ($value === '') return '';

        $rules = [];
        if ($type === 'email') $rules['email'] = filter_var($value, FILTER_VALIDATE_EMAIL) !== false;
        if ($type === 'phone') $rules['phone'] = preg_match('/^[0-9+\-\s()]{7,20}$/', $value) === 1;
        if ($type === 'number') $rules['number'] = is_numeric($value);
        if ($type === 'date') $rules['date'] = strtotime($value) !== false;
        if ($type === 'url') $rules['url'] = preg_match('#^https?://#i', $value) === 1;

        foreach ($rules as $k => $valid) {
            if (!$valid) return false;
        }
        return $value;
    }

    private function routeParam(string $key): ?string
    {
        static $params = null;
        if ($params === null) {
            $params = [];
            $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
            $script = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
            if ($script && $script !== '/' && str_starts_with($path, $script)) {
                $path = substr($path, strlen($script)) ?: '/';
            }
            $path = trim($path, '/');
            $segments = $path ? explode('/', $path) : [];
            // Try to find numeric param from common patterns
            foreach ($segments as $i => $seg) {
                if (is_numeric($seg)) $params['id'] = $seg;
            }
        }
        return $params[$key] ?? null;
    }
}
