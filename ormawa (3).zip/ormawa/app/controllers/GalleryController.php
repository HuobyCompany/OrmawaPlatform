<?php
declare(strict_types=1);

final class GalleryController
{
    private function o(): array
    {
        return OrganizationController::current();
    }

    public function index(): void
    {
        AuthMiddleware::handle();
        $o = $this->o();
        $list = GalleryModel::albums($o['id'], '', null, null, 1, 1000);
        View::render('admin/gallery', ['title' => 'Gallery', 'organization' => $o, 'albums' => $list['items']], 'admin');
    }

    public function form(?string $id = null): void
    {
        AuthMiddleware::handle();
        $o = $this->o();
        $a = $id ? GalleryModel::album((int) $id, $o['id']) : null;
        $items = $a ? GalleryModel::items($a['id'], $o['id']) : [];
        View::render('admin/gallery_form', ['title' => $a ? 'Edit Album' : 'Tambah Album', 'organization' => $o, 'album' => $a, 'items' => $items], 'admin');
    }

    public function save(): void
    {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();
        $id = (int) ($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        if ($title === '') {
            flash('error', 'Judul album wajib diisi.');
            redirect($id ? 'admin/gallery/edit/' . $id : 'admin/gallery/create');
        }
        $slug = slugify($_POST['slug'] ?: $title);
        $ex = GalleryModel::bySlug($slug, $o['id']);
        if ($ex && (int) $ex['id'] !== $id) $slug .= '-' . time();
        $old = $id ? GalleryModel::album($id, $o['id']) : null;
        $oldCover = $old['cover_image'] ?? null;
        $cover = $oldCover;
        $newFiles = [];
        $pdo = Database::connection();

        $sourceType = $_POST['source_type'] ?? 'local';
        if (!in_array($sourceType, ['local', 'google_drive', 'remote_url'], true)) {
            $sourceType = 'local';
        }

        try {
            if (!empty($_FILES['cover_image']['name'])) {
                $r = Upload::handle($_FILES['cover_image'], 'gallery', null);
                $cover = $r['path'];
                $newFiles[] = $r['path'];
            }

            $pdo->beginTransaction();
            $albumId = GalleryModel::saveAlbum([
                'title' => $title,
                'slug' => $slug,
                'description' => Sanitizer::richText($_POST['description'] ?? ''),
                'event_date' => $_POST['event_date'] ?: null,
                'category' => trim($_POST['category'] ?? ''),
                'cover_image' => $cover,
                'source_type' => $sourceType,
                'drive_folder_id' => null,
                'drive_folder_name' => null,
                'sync_status' => 'idle'
            ], $id ?: null, $o['id']);

            if ($sourceType === 'local' && !empty($_FILES['photos']['name'][0])) {
                foreach ($_FILES['photos']['name'] as $i => $name) {
                    if (!$name) continue;
                    $f = [
                        'name' => $name,
                        'type' => $_FILES['photos']['type'][$i],
                        'tmp_name' => $_FILES['photos']['tmp_name'][$i],
                        'error' => $_FILES['photos']['error'][$i],
                        'size' => $_FILES['photos']['size'][$i]
                    ];
                    $r = Upload::handle($f, 'gallery', null);
                    $newFiles[] = $r['path'];
                    GalleryModel::saveItem([
                        'album_id' => $albumId,
                        'title' => $name,
                        'description' => '',
                        'file_path' => $r['path'],
                        'mime_type' => $r['mime'],
                        'file_size' => $r['size'],
                        'sort_order' => GalleryModel::getNextSortOrder((int) $albumId),
                        'alt_text' => $name,
                        'caption' => trim($_POST['caption'] ?? ''),
                        'source_type' => 'local',
                        'drive_file_id' => null,
                        'drive_url' => null,
                        'remote_url' => null,
                        'thumbnail_url' => null,
                        'sync_status' => 'active',
                        'last_synced_at' => date('Y-m-d H:i:s')
                    ]);
                    MediaModel::add([
                        'organization_id' => $o['id'],
                        'uploaded_by' => current_user()['id'],
                        'category' => 'gallery',
                        'file_name' => $name,
                        'file_path' => $r['path'],
                        'mime_type' => $r['mime'],
                        'file_size' => $r['size']
                    ]);
                }
            }

            if ($cover !== $oldCover && $cover) {
                MediaModel::add([
                    'organization_id' => $o['id'],
                    'uploaded_by' => current_user()['id'],
                    'category' => 'gallery-cover',
                    'file_name' => 'cover',
                    'file_path' => $cover,
                    'mime_type' => 'image/*',
                    'file_size' => 0
                ]);
            }
            $pdo->commit();
            if ($oldCover && $oldCover !== $cover) Upload::delete($oldCover);
            ActivityLogModel::add($o['id'], current_user()['id'], $id ? 'update' : 'create', 'gallery', 'Album ' . $title . ' disimpan');
            flash('success', 'Album berhasil disimpan.');
            redirect('admin/gallery/edit/' . $albumId);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            foreach ($newFiles as $path) Upload::delete($path);
            flash('error', $e->getMessage());
            redirect($id ? 'admin/gallery/edit/' . $id : 'admin/gallery/create');
        }
    }

    /**
     * Adds an individual Google Drive photo to an album using a Google Drive file link.
     */
    public function addDriveFile(string $id): void
    {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();
        $a = GalleryModel::album((int) $id, $o['id']);
        if (!$a) {
            flash('error', 'Album tidak ditemukan.');
            redirect('admin/gallery');
        }

        $url = trim((string) ($_POST['drive_file_url'] ?? ''));
        if ($url === '') {
            flash('error', 'Link file Google Drive wajib diisi.');
            redirect('admin/gallery/edit/' . $id);
        }

        $fileId = DriveUrlParser::extractFileId($url);
        if (!$fileId) {
            flash('error', 'Link Google Drive tidak valid. Harap masukkan link file foto individual (contoh: https://drive.google.com/file/d/FILE_ID/view), bukan link folder.');
            redirect('admin/gallery/edit/' . $id);
        }

        try {
            $service = new GoogleDriveService();
            $meta = $service->getFileMetadata($fileId);

            $sortOrder = GalleryModel::getNextSortOrder((int) $id);
            GalleryModel::saveItem([
                'album_id' => (int) $id,
                'title' => $meta['name'],
                'description' => '',
                'file_path' => $meta['id'],
                'mime_type' => $meta['mimeType'],
                'file_size' => $meta['size'],
                'sort_order' => $sortOrder,
                'alt_text' => $meta['name'],
                'caption' => trim($_POST['caption'] ?? ''),
                'source_type' => 'google_drive',
                'drive_file_id' => $meta['id'],
                'drive_url' => $meta['webContentLink'],
                'remote_url' => null,
                'thumbnail_url' => $meta['thumbnailLink'],
                'sync_status' => 'active',
                'last_synced_at' => date('Y-m-d H:i:s')
            ]);

            ActivityLogModel::add($o['id'], current_user()['id'], 'create', 'gallery_item', 'Foto Google Drive ditambahkan ke album ' . $a['title']);
            flash('success', 'Foto Google Drive "' . $meta['name'] . '" berhasil ditambahkan ke album.');
        } catch (Throwable $e) {
            flash('error', 'Gagal menambahkan foto Google Drive: ' . $e->getMessage());
        }

        redirect('admin/gallery/edit/' . $id);
    }

    /**
     * AJAX endpoint to verify a Google Drive file link and return metadata + preview.
     */
    public function verifyDriveFile(): void
    {
        AuthMiddleware::handle();
        header('Content-Type: application/json');

        $url = trim((string) ($_POST['drive_file_url'] ?? ''));
        if ($url === '') {
            echo json_encode(['ok' => false, 'error' => 'Link file Google Drive kosong.']);
            exit;
        }

        $fileId = DriveUrlParser::extractFileId($url);
        if (!$fileId) {
            echo json_encode(['ok' => false, 'error' => 'Link Google Drive tidak valid atau berupa folder. Masukkan link file foto individual.']);
            exit;
        }

        try {
            $service = new GoogleDriveService();
            $meta = $service->getFileMetadata($fileId);
            echo json_encode(['ok' => true, 'data' => $meta]);
        } catch (Throwable $e) {
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function addRemoteUrl(string $id): void
    {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();
        $a = GalleryModel::album((int) $id, $o['id']);
        if (!$a) {
            flash('error', 'Album tidak ditemukan.');
            redirect('admin/gallery');
        }

        $url = trim((string) ($_POST['remote_url'] ?? ''));
        if ($url === '') {
            flash('error', 'URL gambar wajib diisi.');
            redirect('admin/gallery/edit/' . $id);
        }

        $validation = validate_remote_image_url($url);
        if (!$validation['ok']) {
            flash('error', $validation['error']);
            redirect('admin/gallery/edit/' . $id);
        }

        try {
            $sortOrder = GalleryModel::getNextSortOrder((int) $id);
            GalleryModel::saveItem([
                'album_id' => (int) $id,
                'title' => basename(parse_url($validation['url'], PHP_URL_PATH) ?: 'Remote Image'),
                'description' => '',
                'file_path' => '',
                'mime_type' => $validation['mime_type'],
                'file_size' => 0,
                'sort_order' => $sortOrder,
                'alt_text' => '',
                'caption' => trim($_POST['caption'] ?? ''),
                'source_type' => 'remote_url',
                'drive_file_id' => null,
                'drive_url' => null,
                'remote_url' => $validation['url'],
                'thumbnail_url' => $validation['url'],
                'sync_status' => 'active',
                'last_synced_at' => date('Y-m-d H:i:s')
            ]);

            ActivityLogModel::add($o['id'], current_user()['id'], 'create', 'gallery_item', 'Foto remote URL ditambahkan ke album ' . $a['title']);
            flash('success', 'Gambar remote URL berhasil ditambahkan.');
        } catch (Throwable $e) {
            flash('error', 'Gagal menambahkan gambar: ' . $e->getMessage());
        }

        redirect('admin/gallery/edit/' . $id);
    }

    public function updateItem(string $albumId, string $id): void
    {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();
        $a = GalleryModel::album((int) $albumId, $o['id']);
        if (!$a) redirect('admin/gallery');
        $item = GalleryModel::item((int) $id, (int) $albumId, $o['id']);
        if (!$item) redirect('admin/gallery/edit/' . $albumId);
        GalleryModel::updateItem((int) $id, (int) $albumId, ['title' => trim($_POST['title'] ?? $item['title']), 'description' => Sanitizer::richText($_POST['description'] ?? $item['description']), 'alt_text' => trim($_POST['alt_text'] ?? $item['alt_text']), 'caption' => trim($_POST['caption'] ?? $item['caption'])], $o['id']);
        ActivityLogModel::add($o['id'], current_user()['id'], 'update', 'gallery_item', 'Foto gallery diperbarui');
        flash('success', 'Informasi foto diperbarui.');
        redirect('admin/gallery/edit/' . $albumId);
    }

    public function deleteAlbum(string $id): void
    {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();
        $a = GalleryModel::album((int) $id, $o['id']);
        if ($a) {
            foreach (GalleryModel::items($a['id'], $o['id']) as $i) {
                if ($i['source_type'] === 'local') {
                    Upload::delete($i['file_path']);
                }
            }
            Upload::delete($a['cover_image']);
            GalleryModel::deleteAlbum((int) $id, $o['id']);
        }
        flash('success', 'Album dihapus.');
        redirect('admin/gallery');
    }

    public function deleteItem(string $albumId, string $id): void
    {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();
        $a = GalleryModel::album((int) $albumId, $o['id']);
        if (!$a) redirect('admin/gallery');
        $item = GalleryModel::item((int) $id, (int) $albumId, $o['id']);
        if ($item && $item['source_type'] === 'local') {
            Upload::delete($item['file_path']);
        }
        GalleryModel::deleteItem((int) $id, (int) $albumId, $o['id']);
        flash('success', 'Foto dihapus dari album.');
        redirect('admin/gallery/edit/' . $albumId);
    }
}
