<?php
declare(strict_types=1);

final class OrganizationController
{
    public static function current(): array
    {
        $u = current_user();
        $id = selected_organization_id() ?? ($u['organization_id'] ?? null);
        if (!$id) {
            $o = OrganizationModel::findBySlug(DEFAULT_ORGANIZATION_SLUG);
            if (!$o) throw new RuntimeException('Default organization not found.');
            return $o;
        }
        $o = OrganizationModel::findById((int)$id);
        if (!$o) throw new RuntimeException('Organization not found.');
        if ($u && $u['role'] !== 'super_admin' && (int)$u['organization_id'] !== (int)$o['id']) {
            throw new RuntimeException('Unauthorized tenant context.');
        }
        return $o;
    }

    public function switch(): void
    {
        AuthMiddleware::handle();
        if (current_user()['role'] !== 'super_admin') redirect('admin');
        Csrf::check();
        $id = (int)($_POST['organization_id'] ?? 0);
        if (!OrganizationModel::findById($id)) redirect('admin');
        set_selected_organization($id);
        $redirect = trim((string)($_POST['redirect'] ?? 'admin'));
        if (preg_match('#^[a-zA-Z0-9_/]+$#', $redirect) && !str_starts_with($redirect, '//') && !str_contains($redirect, ':')) {
            $redirect = url($redirect);
        } else {
            $redirect = url('admin');
        }
        flash('success', 'Organisasi aktif diganti.');
        redirect($redirect);
    }

    public function list(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin']);
        View::render('admin/organizations', ['title' => 'Organizations', 'organization' => self::current(), 'organizations' => OrganizationModel::all()], 'admin');
    }

    public function edit(?string $id = null): void
    {
        AuthMiddleware::handle();
        $u = current_user();
        if ($id) {
            require_role(['super_admin']);
            $o = OrganizationModel::findById((int)$id);
        } elseif ($u['role'] === 'super_admin') {
            $o = null;
        } else {
            $o = self::current();
        }
        View::render('admin/organization_form', ['title' => $o ? 'Edit Organisasi' : 'Tambah Organisasi', 'organization' => $o], 'admin');
    }

    public function save(): void
    {
        AuthMiddleware::handle();
        Csrf::check();
        $u = current_user();
        $id = (int)($_POST['id'] ?? 0);
        if ($u['role'] !== 'super_admin') {
            $id = (int)($u['organization_id'] ?? 0);
        } elseif ($id === 0) {
            $id = null;
        }

        $name = trim($_POST['name'] ?? '');
        if ($name === '') {
            flash('error', 'Nama organisasi wajib diisi.');
            redirect($id ? 'admin/organization/edit/' . $id : 'admin/organization/create');
        }

        $slug = slugify($_POST['slug'] ?: $name);
        $exist = OrganizationModel::findBySlug($slug);
        if ($exist && (!$id || (int)$exist['id'] !== $id)) {
            flash('error', 'Slug organisasi sudah digunakan.');
            redirect($id ? 'admin/organization/edit/' . $id : 'admin/organization/create');
        }

        $color = fn($v, $d) => preg_match('/^#[0-9A-Fa-f]{6}$/', (string)$v) ? $v : $d;

        $d = [
            'name' => $name,
            'short_name' => trim($_POST['short_name'] ?? ''),
            'slug' => $slug,
            'website_name' => trim($_POST['website_name'] ?? $name),
            'description' => trim($_POST['description'] ?? ''),
            'about' => Sanitizer::richText($_POST['about'] ?? ''),
            'vision' => Sanitizer::richText($_POST['vision'] ?? ''),
            'mission' => Sanitizer::richText($_POST['mission'] ?? ''),
            'values_text' => Sanitizer::richText($_POST['values_text'] ?? ''),
            'primary_color' => $color($_POST['primary_color'] ?? '', '#0a84ff'),
            'secondary_color' => $color($_POST['secondary_color'] ?? '', '#5e5ce6'),
            'accent_color' => $color($_POST['accent_color'] ?? '', '#30d158'),
            'background_color' => $color($_POST['background_color'] ?? '', '#f7f8fa'),
            'text_color' => $color($_POST['text_color'] ?? '', '#111827'),
            'font_family' => in_array($_POST['font_family'] ?? 'Inter', ['Inter', 'Poppins', 'Plus Jakarta Sans', 'DM Sans', 'System UI'], true) ? $_POST['font_family'] : 'Inter',
            'email' => trim($_POST['email'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'whatsapp' => trim($_POST['whatsapp'] ?? ''),
            'instagram' => safe_external_url($_POST['instagram'] ?? ''),
            'facebook' => safe_external_url($_POST['facebook'] ?? ''),
            'youtube' => safe_external_url($_POST['youtube'] ?? ''),
            'tiktok' => safe_external_url($_POST['tiktok'] ?? ''),
            'linkedin' => safe_external_url($_POST['linkedin'] ?? ''),
            'website' => safe_external_url($_POST['website'] ?? ''),
            'map_embed_url' => safe_external_url($_POST['map_embed_url'] ?? ''),
            'status' => in_array($_POST['status'] ?? 'active', ['active', 'inactive'], true) ? $_POST['status'] : 'active'
        ];

        $newId = OrganizationModel::save($d, $id);
        $o = OrganizationModel::findById($newId);

        $uploadErrors = [];
        foreach (['logo' => 'logos', 'favicon' => 'favicon', 'hero_image' => 'banners'] as $field => $folder) {
            if (!empty($_FILES[$field]['name'])) {
                try {
                    $oldPath = $o[$field] ?? null;
                    $r = Upload::handle($_FILES[$field], $folder, $oldPath);
                    $s = Database::connection()->prepare('UPDATE organizations SET ' . $field . '=:v, updated_at=NOW() WHERE id=:id');
                    $s->execute(['v' => $r['path'], 'id' => $newId]);
                    MediaModel::add([
                        'organization_id' => $newId,
                        'uploaded_by' => $u['id'],
                        'category' => $field,
                        'file_name' => $_FILES[$field]['name'],
                        'file_path' => $r['path'],
                        'mime_type' => $r['mime'],
                        'file_size' => $r['size']
                    ]);
                } catch (Throwable $e) {
                    $uploadErrors[] = "Upload " . ucfirst($field) . " gagal: " . $e->getMessage();
                }
            }
        }

        set_selected_organization($newId);
        ActivityLogModel::add($newId, $u['id'], $id ? 'update' : 'create', 'organization', 'Organisasi ' . $name . ' disimpan');

        if ($uploadErrors) {
            flash('error', implode(' | ', $uploadErrors));
        } else {
            flash('success', 'Profil dan media organisasi berhasil disimpan.');
        }

        redirect('admin/organization');
    }

    public function delete(string $id): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin']);
        Csrf::check();
        OrganizationModel::delete((int)$id);
        flash('success', 'Organisasi dihapus.');
        redirect('admin/organizations');
    }
}
