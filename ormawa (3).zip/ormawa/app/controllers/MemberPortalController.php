<?php
declare(strict_types=1);

final class MemberPortalController
{
    public function index(?string $organization = null): void
    {
        // Check authentication
        if (!AuthService::isAuthenticated()) {
            redirect('login');
            return;
        }

        $user = AuthService::currentUser();
        
        // Check if user has member role or member relationship
        if ($user['role'] !== 'member' && !$user['member_id']) {
            flash('error', 'Anda tidak memiliki akses ke area anggota.');
            redirect('admin/dashboard');
            return;
        }

        // Get organization - use provided org slug or fall back to user's org
        $orgSlug = $organization ?: ($user['organization_slug'] ?? '');
        if (!$orgSlug) {
            flash('error', 'Organisasi tidak ditemukan.');
            redirect('admin/dashboard');
            return;
        }

        $org = OrganizationResolver::resolve('/' . $orgSlug);
        if (!$org) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            return;
        }

        // Organization isolation: Ensure user belongs to this organization
        if ($user['organization_id'] && $user['organization_id'] != $org['id']) {
            flash('error', 'Anda tidak memiliki akses ke organisasi ini.');
            redirect(org_url(['slug' => $user['organization_slug']], 'member'));
            return;
        }

        // Get member data
        $memberData = null;
        if ($user['member_id']) {
            $memberData = MemberModel::find((int)$user['member_id'], $org['id']);
        }

        // Get person data
        $personData = null;
        if ($user['person_id']) {
            $personData = PersonModel::find((int)$user['person_id'], $org['id']);
        }

        // Get member's structure assignments
        $assignments = [];
        if ($personData) {
            $assignStmt = Database::connection()->prepare('
                SELECT pa.*, p.title as position_title, g.name as group_name, t.name as term_name
                FROM position_assignments pa
                JOIN positions p ON p.id = pa.position_id
                JOIN structure_groups g ON g.id = p.group_id
                LEFT JOIN organization_terms t ON t.id = pa.term_id
                WHERE pa.person_id = :pid AND pa.organization_id = :org
                ORDER BY pa.created_at DESC
            ');
            $assignStmt->execute(['pid' => $personData['id'], 'org' => $org['id']]);
            $assignments = $assignStmt->fetchAll();
        }

        // Get settings
        $settings = SettingModel::all($org['id']);

        View::render('member/portal', [
            'title' => 'Portal Anggota',
            'organization' => $org,
            'settings' => $settings,
            'user' => $user,
            'member' => $memberData,
            'person' => $personData,
            'assignments' => $assignments
        ], 'member');
    }

    public function card(?string $organization = null): void
    {
        // Check authentication
        if (!AuthService::isAuthenticated()) {
            redirect('login');
            return;
        }

        $user = AuthService::currentUser();
        
        // Check if user has member role or member relationship
        if ($user['role'] !== 'member' && !$user['member_id']) {
            flash('error', 'Anda tidak memiliki akses ke kartu anggota.');
            redirect('admin/dashboard');
            return;
        }

        // Get organization - use provided org slug or fall back to user's org
        $orgSlug = $organization ?: ($user['organization_slug'] ?? '');
        if (!$orgSlug) {
            flash('error', 'Organisasi tidak ditemukan.');
            redirect('admin/dashboard');
            return;
        }

        $org = OrganizationResolver::resolve('/' . $orgSlug);
        if (!$org) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            return;
        }

        // Organization isolation: Ensure user belongs to this organization
        if ($user['organization_id'] && $user['organization_id'] != $org['id']) {
            flash('error', 'Anda tidak memiliki akses ke organisasi ini.');
            redirect(org_url(['slug' => $user['organization_slug']], 'member'));
            return;
        }

        // Get member data
        $memberData = null;
        if ($user['member_id']) {
            $memberData = MemberModel::find((int)$user['member_id'], $org['id']);
        }

        // Get person data
        $personData = null;
        if ($user['person_id']) {
            $personData = PersonModel::find((int)$user['person_id'], $org['id']);
        }

        // Get settings
        $settings = SettingModel::all($org['id']);

        View::render('member/card', [
            'title' => 'Kartu Anggota Digital',
            'organization' => $org,
            'settings' => $settings,
            'user' => $user,
            'member' => $memberData,
            'person' => $personData
        ], 'member');
    }

    public function profile(?string $organization = null): void
    {
        // Check authentication
        if (!AuthService::isAuthenticated()) {
            redirect('login');
            return;
        }

        $user = AuthService::currentUser();
        
        // Check if user has member role or member relationship
        if ($user['role'] !== 'member' && !$user['member_id']) {
            flash('error', 'Anda tidak memiliki akses ke profil anggota.');
            redirect('admin/dashboard');
            return;
        }

        // Get organization - use provided org slug or fall back to user's org
        $orgSlug = $organization ?: ($user['organization_slug'] ?? '');
        if (!$orgSlug) {
            flash('error', 'Organisasi tidak ditemukan.');
            redirect('admin/dashboard');
            return;
        }

        $org = OrganizationResolver::resolve('/' . $orgSlug);
        if (!$org) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            return;
        }

        // Organization isolation: Ensure user belongs to this organization
        if ($user['organization_id'] && $user['organization_id'] != $org['id']) {
            flash('error', 'Anda tidak memiliki akses ke organisasi ini.');
            redirect(org_url(['slug' => $user['organization_slug']], 'member'));
            return;
        }

        // Get member data
        $memberData = null;
        if ($user['member_id']) {
            $memberData = MemberModel::find((int)$user['member_id'], $org['id']);
        }

        // Get person data
        $personData = null;
        if ($user['person_id']) {
            $personData = PersonModel::find((int)$user['person_id'], $org['id']);
        }

        // Get settings
        $settings = SettingModel::all($org['id']);

        View::render('member/profile', [
            'title' => 'Profil Anggota',
            'organization' => $org,
            'settings' => $settings,
            'user' => $user,
            'member' => $memberData,
            'person' => $personData
        ], 'member');
    }

    public function updateProfile(?string $organization = null): void
    {
        // Check authentication
        if (!AuthService::isAuthenticated()) {
            redirect('login');
            return;
        }

        $user = AuthService::currentUser();
        
        // Check if user has member role or member relationship
        if ($user['role'] !== 'member' && !$user['member_id']) {
            flash('error', 'Anda tidak memiliki akses ke profil anggota.');
            redirect('admin/dashboard');
            return;
        }

        // Get organization - use provided org slug or fall back to user's org
        $orgSlug = $organization ?: ($user['organization_slug'] ?? '');
        if (!$orgSlug) {
            flash('error', 'Organisasi tidak ditemukan.');
            redirect('admin/dashboard');
            return;
        }

        $org = OrganizationResolver::resolve('/' . $orgSlug);
        if (!$org) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            return;
        }

        // Organization isolation: Ensure user belongs to this organization
        if ($user['organization_id'] && $user['organization_id'] != $org['id']) {
            flash('error', 'Anda tidak memiliki akses ke organisasi ini.');
            redirect(org_url(['slug' => $user['organization_slug']], 'member'));
            return;
        }

        // Check CSRF token
        try {
            Csrf::check();
        } catch (Throwable $e) {
            flash('error', 'Token Keamanan tidak valid. Silakan coba lagi.');
            redirect(org_url($org, 'member/profile'));
            return;
        }

        // Strict Ownership Verification: Resolve person_id strictly from session user
        $personId = null;
        if (!empty($user['person_id'])) {
            $personId = (int)$user['person_id'];
        } else {
            // Look up primary person_id in user_account_members for logged in user ID
            $pdo = Database::connection();
            $stmt = $pdo->prepare('SELECT person_id FROM user_account_members WHERE user_id = :uid AND is_primary = TRUE LIMIT 1');
            $stmt->execute(['uid' => $user['id']]);
            $row = $stmt->fetch();
            if ($row && !empty($row['person_id'])) {
                $personId = (int)$row['person_id'];
            }
        }

        if (!$personId) {
            flash('error', 'Data profil person tidak ditemukan untuk akun Anda.');
            redirect(org_url($org, 'member/profile'));
            return;
        }

        // Ensure person exists and belongs to organization
        $existingPerson = PersonModel::find($personId, (int)$org['id']);
        if (!$existingPerson) {
            flash('error', 'Data profil tidak ditemukan di organisasi ini.');
            redirect(org_url($org, 'member/profile'));
            return;
        }

        // Input Validation
        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $phone = trim((string)($_POST['phone'] ?? ''));

        if ($fullName === '') {
            flash('error', 'Nama lengkap tidak boleh kosong.');
            redirect(org_url($org, 'member/profile'));
            return;
        }

        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            flash('error', 'Format email tidak valid.');
            redirect(org_url($org, 'member/profile'));
            return;
        }

        $photoMediaId = !empty($existingPerson['photo_media_id']) ? (int)$existingPerson['photo_media_id'] : null;

        // Handle profile photo upload if file uploaded
        if (isset($_FILES['photo']) && ($_FILES['photo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            try {
                $uploadResult = Upload::handle($_FILES['photo'], 'members');
                // Create media database record
                $photoMediaId = MediaModel::add([
                    'organization_id' => (int)$org['id'],
                    'uploaded_by' => (int)$user['id'],
                    'category' => 'image',
                    'file_name' => $uploadResult['name'],
                    'file_path' => $uploadResult['path'],
                    'mime_type' => $uploadResult['mime'],
                    'file_size' => $uploadResult['size']
                ]);
            } catch (Throwable $e) {
                flash('error', 'Gagal mengunggah foto: ' . $e->getMessage());
                redirect(org_url($org, 'member/profile'));
                return;
            }
        }

        // Update Person record (strictly mutable attributes only)
        PersonModel::save([
            'full_name' => $fullName,
            'email' => $email,
            'phone' => $phone,
            'photo_media_id' => $photoMediaId
        ], $personId, (int)$org['id']);

        // Update linked user record if needed
        $pdo = Database::connection();
        $userStmt = $pdo->prepare('UPDATE users SET name = :name, email = :email, updated_at = NOW() WHERE id = :id');
        $userStmt->execute(['name' => $fullName, 'email' => $email, 'id' => (int)$user['id']]);

        // Update active session user array
        if (isset($_SESSION['auth_user'])) {
            $_SESSION['auth_user']['name'] = $fullName;
            $_SESSION['auth_user']['email'] = $email;
        }

        // Activity log
        ActivityLogModel::add(
            (int)$org['id'],
            (int)$user['id'],
            'member_profile_update',
            'member',
            'Memperbarui profil anggota ' . $fullName
        );

        flash('success', 'Profil berhasil diperbarui.');
        redirect(org_url($org, 'member/profile'));
    }
}