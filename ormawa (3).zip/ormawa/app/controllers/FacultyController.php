<?php
declare(strict_types=1);

final class FacultyController
{
    public function index(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        $o = OrganizationController::current();

        $faculties = FacultyModel::all();
        $studyPrograms = StudyProgramModel::all();

        View::render('admin/faculties', [
            'title' => 'Fakultas & Program Studi',
            'organization' => $o,
            'faculties' => $faculties,
            'studyPrograms' => $studyPrograms,
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
        ], 'admin');
    }

    public function saveFaculty(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();

        $id = (int)($_POST['id'] ?? 0);
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $name = trim($_POST['name'] ?? '');
        $sortOrder = (int)($_POST['sort_order'] ?? 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if ($code === '' || $name === '') {
            flash('error', 'Kode dan Nama Fakultas wajib diisi.');
            redirect('admin/faculties');
            return;
        }

        FacultyModel::save([
            'id' => $id ?: null,
            'code' => $code,
            'name' => $name,
            'sort_order' => $sortOrder,
            'is_active' => $isActive,
        ]);

        flash('success', 'Data Fakultas "' . $name . '" berhasil disimpan.');
        redirect('admin/faculties');
    }

    public function deleteFaculty(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            FacultyModel::delete($id);
            flash('success', 'Fakultas berhasil dihapus.');
        }
        redirect('admin/faculties');
    }

    public function saveProgram(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();

        $id = (int)($_POST['id'] ?? 0);
        $facultyId = (int)($_POST['faculty_id'] ?? 0);
        $code = strtoupper(trim($_POST['code'] ?? ''));
        $name = trim($_POST['name'] ?? '');
        $sortOrder = (int)($_POST['sort_order'] ?? 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if ($facultyId <= 0 || $code === '' || $name === '') {
            flash('error', 'Fakultas, Kode, dan Nama Program Studi wajib diisi.');
            redirect('admin/faculties');
            return;
        }

        StudyProgramModel::save([
            'id' => $id ?: null,
            'faculty_id' => $facultyId,
            'code' => $code,
            'name' => $name,
            'sort_order' => $sortOrder,
            'is_active' => $isActive,
        ]);

        flash('success', 'Data Program Studi "' . $name . '" berhasil disimpan.');
        redirect('admin/faculties');
    }

    public function deleteProgram(): void
    {
        AuthMiddleware::handle();
        require_role(['super_admin', 'organization_admin']);
        Csrf::check();

        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            StudyProgramModel::delete($id);
            flash('success', 'Program Studi berhasil dihapus.');
        }
        redirect('admin/faculties');
    }
}
