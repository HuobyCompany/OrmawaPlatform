<?php
final class MediaController{
 public function index():void{AuthMiddleware::handle();$o=OrganizationController::current();View::render('admin/media',['title'=>'Media Manager','organization'=>$o,'media'=>MediaModel::all($o['id'])],'admin');}
 public function upload():void{AuthMiddleware::handle();Csrf::check();$o=OrganizationController::current();try{$r=Upload::handle($_FILES['file']??[],'organization');MediaModel::add(['organization_id'=>$o['id'],'uploaded_by'=>current_user()['id'],'category'=>trim($_POST['category']??'general'),'file_name'=>$_FILES['file']['name'],'file_path'=>$r['path'],'mime_type'=>$r['mime'],'file_size'=>$r['size']]);ActivityLogModel::add($o['id'],current_user()['id'],'upload','media','Media diunggah');flash('success','Media berhasil diunggah.');}catch(Throwable $e){flash('error',$e->getMessage());}redirect('admin/media');}
 public function delete(string $id):void{AuthMiddleware::handle();Csrf::check();$o=OrganizationController::current();$s=Database::connection()->prepare('SELECT * FROM media WHERE id=:id AND organization_id=:o');$s->execute(['id'=>$id,'o'=>$o['id']]);$m=$s->fetch();if($m){Upload::delete($m['file_path']);MediaModel::delete((int)$id,$o['id']);}flash('success','Media dihapus.');redirect('admin/media');}
}

