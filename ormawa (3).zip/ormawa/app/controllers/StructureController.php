<?php
declare(strict_types=1);

final class StructureController {

    /**
     * Main Admin Structure Dashboard
     * Level 1: Term Selector
     * Level 2: Structure Group Cards Grid
     */
    public function index(): void {
        AuthMiddleware::handle();
        $o = OrganizationController::current();

        // 1. Fetch Terms
        $terms = TermModel::all($o['id']);
        if (!$terms) {
            // Auto-create default term if none exists
            $defaultTermId = StructureService::createTerm($o['id'], 'Periode 2026/2027', '2026-2027', '2026-01-01', '2027-12-31');
            $terms = TermModel::all($o['id']);
        }

        // Determine active selected term
        $selectedTermId = !empty($_GET['term']) ? (int)$_GET['term'] : (int)$terms[0]['id'];
        $selectedTerm = TermModel::find($selectedTermId, $o['id']) ?: $terms[0];

        // 2. Fetch Groups & calculate statistics
        $groups = StructureGroupModel::all($o['id']);
        $positions = StructurePositionModel::all($o['id']);
        $assignments = PositionAssignmentModel::all($o['id'], (int)$selectedTerm['id']);

        // Count assignments & positions per group
        $assignmentsByPos = [];
        foreach ($assignments as $as) {
            $assignmentsByPos[$as['position_id']][] = $as;
        }

        $groupStats = [];
        foreach ($groups as &$g) {
            $gId = (int)$g['id'];
            $gPositions = array_filter($positions, fn($p) => (int)$p['group_id'] === $gId);
            
            $personCount = 0;
            $vacantCount = 0;
            foreach ($gPositions as $pos) {
                $posAssigns = $assignmentsByPos[$pos['id']] ?? [];
                foreach ($posAssigns as $pa) {
                    if (!empty($pa['person_id']) && $pa['status'] === 'active') {
                        $personCount++;
                    } elseif ($pa['status'] === 'vacant' || empty($pa['person_id'])) {
                        $vacantCount++;
                    }
                }
            }

            $g['position_count'] = count($gPositions);
            $g['person_count'] = $personCount;
            $g['vacant_count'] = $vacantCount;
        }
        unset($g);

        // Fetch persons list for quick assignment modal
        $persons = PersonModel::all($o['id']);

        View::render('admin/structure', [
            'title' => 'Struktur Organisasi',
            'organization' => $o,
            'terms' => $terms,
            'selectedTerm' => $selectedTerm,
            'groups' => $groups,
            'persons' => $persons
        ], 'admin');
    }

    /**
     * Level 3: Manage Positions & People inside a Group
     */
    public function manageGroup(string $id): void {
        AuthMiddleware::handle();
        $o = OrganizationController::current();
        $groupId = (int)$id;

        $group = StructureGroupModel::find($groupId, $o['id']);
        if (!$group) {
            flash('error', 'Kelompok struktur tidak ditemukan.');
            redirect('admin/structure');
        }

        $terms = TermModel::all($o['id']);
        $selectedTermId = !empty($_GET['term']) ? (int)$_GET['term'] : (int)$terms[0]['id'];
        $selectedTerm = TermModel::find($selectedTermId, $o['id']) ?: $terms[0];

        $positions = StructurePositionModel::all($o['id'], $groupId);
        $assignments = PositionAssignmentModel::all($o['id'], (int)$selectedTerm['id']);

        // Group assignments by position_id
        $assignmentsByPos = [];
        foreach ($assignments as $as) {
            if ((int)$as['group_id'] === $groupId) {
                $assignmentsByPos[$as['position_id']][] = $as;
            }
        }

        foreach ($positions as &$pos) {
            $pos['assignments'] = $assignmentsByPos[$pos['id']] ?? [];
        }
        unset($pos);

        $persons = PersonModel::all($o['id']);

        View::render('admin/structure_group_manage', [
            'title' => 'Kelola Group: ' . $group['name'],
            'organization' => $o,
            'group' => $group,
            'terms' => $terms,
            'selectedTerm' => $selectedTerm,
            'positions' => $positions,
            'persons' => $persons
        ], 'admin');
    }

    /**
     * Save/Create Term
     */
    public function saveTerm(): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();

        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $name = trim($_POST['name'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $startDate = trim($_POST['start_date'] ?? date('Y-01-01'));
        $endDate = !empty($_POST['end_date']) ? trim($_POST['end_date']) : null;

        if (!$name) {
            flash('error', 'Nama periode/term wajib diisi.');
            redirect('admin/structure');
        }

        if (!$slug) {
            $slug = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $name));
        }

        $termId = TermModel::save([
            'name' => $name,
            'slug' => $slug,
            'start_date' => $startDate,
            'end_date' => $endDate
        ], $id, $o['id']);

        ActivityLogModel::add($o['id'], current_user()['id'], $id ? 'update' : 'create', 'structure_term', 'Periode ' . $name . ' disimpan');
        flash('success', 'Periode kepengurusan berhasil disimpan.');
        redirect('admin/structure?term=' . $termId);
    }

    /**
     * Save/Create Structure Group
     */
    public function saveGroup(): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();

        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $name = trim($_POST['name'] ?? '');
        $description = Sanitizer::richText($_POST['description'] ?? '');
        $sortOrder = (int)($_POST['sort_order'] ?? 0);
        $termId = !empty($_POST['term_id']) ? (int)$_POST['term_id'] : null;

        if (!$name) {
            flash('error', 'Nama kelompok struktur wajib diisi.');
            redirect('admin/structure');
        }

        $groupId = StructureGroupModel::save([
            'name' => $name,
            'description' => $description,
            'parent_id' => null,
            'sort_order' => $sortOrder
        ], $id, $o['id']);

        ActivityLogModel::add($o['id'], current_user()['id'], $id ? 'update' : 'create', 'structure_group', 'Kelompok ' . $name . ' disimpan');
        flash('success', 'Kelompok struktur berhasil disimpan.');
        
        $redirectUrl = 'admin/structure';
        if ($termId) {
            $redirectUrl .= '?term=' . $termId;
        }
        redirect($redirectUrl);
    }

    /**
     * Move Group order
     */
    public function moveGroup(string $id, string $direction): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();
        $groupId = (int)$id;

        $group = StructureGroupModel::find($groupId, $o['id']);
        if ($group) {
            $newOrder = $direction === 'up' ? max(0, (int)$group['sort_order'] - 1) : (int)$group['sort_order'] + 1;
            StructureGroupModel::save([
                'name' => $group['name'],
                'description' => $group['description'],
                'parent_id' => $group['parent_id'],
                'sort_order' => $newOrder
            ], $groupId, $o['id']);
            flash('success', 'Urutan kelompok diperbarui.');
        }
        redirect('admin/structure');
    }

    /**
     * Delete Group
     */
    public function deleteGroup(string $id): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();

        $group = StructureGroupModel::find((int)$id, $o['id']);
        if ($group) {
            StructureGroupModel::delete((int)$id, $o['id']);
            ActivityLogModel::add($o['id'], current_user()['id'], 'delete', 'structure_group', 'Kelompok ' . $group['name'] . ' dihapus');
            flash('success', 'Kelompok struktur berhasil dihapus.');
        }
        redirect('admin/structure');
    }

    /**
     * Save/Create Position inside a Group
     */
    public function savePosition(): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();

        $id = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $groupId = (int)($_POST['group_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $description = Sanitizer::richText($_POST['description'] ?? '');
        $sortOrder = (int)($_POST['sort_order'] ?? 0);
        $termId = !empty($_POST['term_id']) ? (int)$_POST['term_id'] : null;

        if (!$groupId || !$title) {
            flash('error', 'Nama posisi/jabatan dan kelompok wajib diisi.');
            redirect('admin/structure');
        }

        $posId = StructurePositionModel::save([
            'group_id' => $groupId,
            'title' => $title,
            'description' => $description,
            'sort_order' => $sortOrder
        ], $id, $o['id']);

        ActivityLogModel::add($o['id'], current_user()['id'], $id ? 'update' : 'create', 'structure_position', 'Jabatan ' . $title . ' disimpan');
        flash('success', 'Jabatan berhasil disimpan.');

        $redirectUrl = 'admin/structure/group/' . $groupId;
        if ($termId) {
            $redirectUrl .= '?term=' . $termId;
        }
        redirect($redirectUrl);
    }

    /**
     * Move Position order
     */
    public function movePosition(string $id, string $direction): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();
        $posId = (int)$id;

        $pos = StructurePositionModel::find($posId, $o['id']);
        if ($pos) {
            $newOrder = $direction === 'up' ? max(0, (int)$pos['sort_order'] - 1) : (int)$pos['sort_order'] + 1;
            StructurePositionModel::save([
                'group_id' => $pos['group_id'],
                'title' => $pos['title'],
                'description' => $pos['description'],
                'sort_order' => $newOrder
            ], $posId, $o['id']);
            flash('success', 'Urutan jabatan diperbarui.');
            redirect('admin/structure/group/' . $pos['group_id']);
        }
        redirect('admin/structure');
    }

    /**
     * Delete Position
     */
    public function deletePosition(string $id): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();

        $pos = StructurePositionModel::find((int)$id, $o['id']);
        if ($pos) {
            $groupId = $pos['group_id'];
            StructurePositionModel::delete((int)$id, $o['id']);
            ActivityLogModel::add($o['id'], current_user()['id'], 'delete', 'structure_position', 'Jabatan ' . $pos['title'] . ' dihapus');
            flash('success', 'Jabatan berhasil dihapus.');
            redirect('admin/structure/group/' . $groupId);
        }
        redirect('admin/structure');
    }

    /**
     * Save/Create Assignment (Assign Person to Position)
     */
    public function saveAssignment(): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();

        $assignmentId = !empty($_POST['id']) ? (int)$_POST['id'] : null;
        $termId = (int)($_POST['term_id'] ?? 0);
        $positionId = (int)($_POST['position_id'] ?? 0);
        $groupId = (int)($_POST['group_id'] ?? 0);
        $isVacant = !empty($_POST['is_vacant']);

        if (!$termId || !$positionId) {
            flash('error', 'Periode dan jabatan wajib ditentukan.');
            redirect('admin/structure');
        }

        $personId = null;

        if (!$isVacant) {
            // Check if existing person selected or new person created
            if (!empty($_POST['person_id'])) {
                $personId = (int)$_POST['person_id'];
            } elseif (!empty($_POST['new_person_name'])) {
                // Handle new person creation & photo upload
                $fullName = trim($_POST['new_person_name']);
                $email = !empty($_POST['email']) ? trim($_POST['email']) : null;
                $phone = !empty($_POST['phone']) ? trim($_POST['phone']) : null;
                $photoMediaId = null;

                if (!empty($_FILES['photo']['name'])) {
                    try {
                        $r = Upload::handle($_FILES['photo'], 'members');
                        MediaModel::add([
                            'organization_id' => $o['id'],
                            'uploaded_by' => current_user()['id'],
                            'category' => 'person_photo',
                            'file_name' => $_FILES['photo']['name'],
                            'file_path' => $r['path'],
                            'mime_type' => $r['mime'],
                            'file_size' => $r['size']
                        ]);
                        $photoMediaId = (int)Database::connection()->lastInsertId();
                    } catch (Throwable $e) {
                        flash('error', 'Gagal upload foto: ' . $e->getMessage());
                    }
                }

                $personId = PersonService::createPerson($o['id'], $fullName, $email, $phone, $photoMediaId);
            }
        }

        $startDate = !empty($_POST['start_date']) ? trim($_POST['start_date']) : date('Y-01-01');
        $endDate = !empty($_POST['end_date']) ? trim($_POST['end_date']) : null;
        $status = $isVacant ? 'vacant' : (!empty($_POST['status']) ? $_POST['status'] : 'active');

        PositionAssignmentModel::save([
            'term_id' => $termId,
            'position_id' => $positionId,
            'person_id' => $personId,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'status' => $status
        ], $assignmentId, $o['id']);

        ActivityLogModel::add($o['id'], current_user()['id'], $assignmentId ? 'update' : 'create', 'structure_assignment', 'Penugasan jabatan disimpan');
        flash('success', 'Penugasan pengurus berhasil disimpan.');

        if ($groupId) {
            redirect('admin/structure/group/' . $groupId . '?term=' . $termId);
        }
        redirect('admin/structure?term=' . $termId);
    }

    /**
     * Delete Assignment
     */
    public function deleteAssignment(string $id): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();
        $groupId = (int)($_GET['group_id'] ?? 0);
        $termId = (int)($_GET['term_id'] ?? 0);

        PositionAssignmentModel::delete((int)$id, $o['id']);
        ActivityLogModel::add($o['id'], current_user()['id'], 'delete', 'structure_assignment', 'Penugasan dihapus');
        flash('success', 'Penugasan berhasil dihapus.');

        if ($groupId) {
            redirect('admin/structure/group/' . $groupId . '?term=' . $termId);
        }
        redirect('admin/structure?term=' . $termId);
    }

    // --- Legacy Fallbacks ---
    public function legacyForm(?string $id = null): void {
        AuthMiddleware::handle();
        $o = OrganizationController::current();
        $p = $id ? PositionModel::find((int)$id, $o['id']) : null;
        View::render('admin/structure_form', [
            'title' => $p ? 'Edit Posisi Legacy' : 'Tambah Posisi Legacy',
            'organization' => $o,
            'position' => $p,
            'positions' => PositionModel::all($o['id'])
        ], 'admin');
    }

    public function legacySave(): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['id'] ?? 0);
        $old = $id ? PositionModel::find($id, $o['id']) : null;
        $photo = $old['photo'] ?? null;

        if (!empty($_FILES['photo']['name'])) {
            try {
                $r = Upload::handle($_FILES['photo'], 'members', $photo);
                $photo = $r['path'];
                MediaModel::add([
                    'organization_id' => $o['id'],
                    'uploaded_by' => current_user()['id'],
                    'category' => 'structure',
                    'file_name' => $_FILES['photo']['name'],
                    'file_path' => $r['path'],
                    'mime_type' => $r['mime'],
                    'file_size' => $r['size']
                ]);
            } catch (Throwable $e) {
                flash('error', $e->getMessage());
            }
        }

        $name = trim($_POST['position_name'] ?? '');
        if (!$name) {
            flash('error', 'Nama jabatan wajib diisi.');
            redirect('admin/structure');
        }

        $d = [
            'parent_id' => (int)($_POST['parent_id'] ?? 0) ?: null,
            'position_name' => $name,
            'description' => Sanitizer::richText($_POST['description'] ?? ''),
            'sort_order' => max(0, (int)($_POST['sort_order'] ?? 0)),
            'photo' => $photo,
            'person_name' => trim($_POST['person_name'] ?? ''),
            'period' => trim($_POST['period'] ?? ''),
            'status' => isset($_POST['status']) ? 'active' : 'inactive'
        ];
        PositionModel::save($d, $id ?: null, $o['id']);
        flash('success', 'Struktur legacy tersimpan.');
        redirect('admin/structure');
    }

    public function legacyMove(string $id, string $direction): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();
        PositionModel::move((int)$id, $o['id'], $direction === 'up' ? 'up' : 'down');
        flash('success', 'Urutan struktur diperbarui.');
        redirect('admin/structure');
    }

    public function legacySetParent(): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();
        $id = (int)($_POST['id'] ?? 0);
        $parentId = (int)($_POST['parent_id'] ?? 0);
        $p = PositionModel::find($id, $o['id']);
        if ($p) {
            $d = [
                'parent_id' => $parentId > 0 ? $parentId : null,
                'position_name' => $p['position_name'],
                'description' => $p['description'],
                'sort_order' => (int)$p['sort_order'],
                'photo' => $p['photo'],
                'person_name' => $p['person_name'],
                'period' => $p['period'],
                'status' => $p['status']
            ];
            PositionModel::save($d, $id, $o['id']);
            flash('success', 'Garis relasi atasan diperbarui.');
        }
        redirect('admin/structure');
    }

    public function legacyDelete(string $id): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = OrganizationController::current();
        $p = PositionModel::find((int)$id, $o['id']);
        if ($p) Upload::delete($p['photo']);
        PositionModel::delete((int)$id, $o['id']);
        flash('success', 'Posisi legacy dihapus.');
        redirect('admin/structure');
    }
}
