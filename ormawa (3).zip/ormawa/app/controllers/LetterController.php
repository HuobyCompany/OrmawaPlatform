<?php
declare(strict_types=1);

final class LetterController {
    private function o(): array {
        return OrganizationController::current();
    }

    public function index(): void {
        AuthMiddleware::handle();
        $o = $this->o();

        $type = $_GET['type'] ?? 'all';
        if (!in_array($type, ['all', 'incoming', 'outgoing'], true)) {
            $type = 'all';
        }

        $q = trim($_GET['q'] ?? '');
        $category = trim($_GET['category'] ?? '');
        $page = max(1, (int)($_GET['page'] ?? 1));

        $list = LetterModel::all($o['id'], $type, $q, $category, $page, 15);
        $counts = LetterModel::counts($o['id']);
        $categories = LetterModel::categories($o['id']);

        View::render('admin/letters', [
            'title' => 'Arsip Surat',
            'organization' => $o,
            'list' => $list,
            'counts' => $counts,
            'categories' => $categories,
            'type' => $type,
            'search' => $q,
            'category' => $category
        ], 'admin');
    }

    public function form(?string $id = null): void {
        AuthMiddleware::handle();
        $o = $this->o();
        $letter = $id ? LetterModel::find((int)$id, $o['id']) : null;
        $categories = LetterModel::categories($o['id']);

        View::render('admin/letter_form', [
            'title' => $letter ? 'Edit Surat' : 'Tambah Surat',
            'organization' => $o,
            'letter' => $letter,
            'categories' => $categories,
            'defaultType' => $_GET['type'] ?? 'incoming'
        ], 'admin');
    }

    public function save(): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();

        $id = (int)($_POST['id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $letter_number = trim($_POST['letter_number'] ?? '');
        $sender = trim($_POST['sender'] ?? '');
        $recipient = trim($_POST['recipient'] ?? '');

        if ($title === '' || $letter_number === '') {
            flash('error', 'Nomor surat dan Judul/Perihal surat wajib diisi.');
            redirect($id ? 'admin/letters/edit/' . $id : 'admin/letters/create');
        }

        $type = in_array($_POST['type'] ?? 'incoming', ['incoming', 'outgoing'], true) ? $_POST['type'] : 'incoming';
        $old = $id ? LetterModel::find($id, $o['id']) : null;
        $filePath = $old['file_path'] ?? null;
        $fileSize = (int)($old['file_size'] ?? 0);

        if (!empty($_FILES['file']['name'])) {
            try {
                $uploadResult = Upload::handleDocument($_FILES['file'], 'letters', $filePath);
                $filePath = $uploadResult['path'];
                $fileSize = $uploadResult['size'];

                MediaModel::add([
                    'organization_id' => $o['id'],
                    'uploaded_by' => current_user()['id'],
                    'category' => 'document',
                    'file_name' => $_FILES['file']['name'],
                    'file_path' => $filePath,
                    'mime_type' => $uploadResult['mime'],
                    'file_size' => $fileSize
                ]);
            } catch (Throwable $e) {
                flash('error', $e->getMessage());
                redirect($id ? 'admin/letters/edit/' . $id : 'admin/letters/create');
            }
        }

        $d = [
            'type' => $type,
            'letter_number' => $letter_number,
            'title' => $title,
            'sender' => $sender,
            'recipient' => $recipient,
            'letter_date' => $_POST['letter_date'] ?? date('Y-m-d'),
            'received_or_sent_date' => !empty($_POST['received_or_sent_date']) ? $_POST['received_or_sent_date'] : null,
            'category' => trim($_POST['category'] ?? 'Umum'),
            'file_path' => $filePath,
            'file_size' => $fileSize,
            'description' => trim($_POST['description'] ?? ''),
            'status' => in_array($_POST['status'] ?? 'active', ['active', 'archived'], true) ? $_POST['status'] : 'active'
        ];

        LetterModel::save($d, $id ?: null, $o['id']);
        ActivityLogModel::add($o['id'], current_user()['id'], $id ? 'update' : 'create', 'letter', 'Surat (' . $letter_number . ') ' . $title . ' disimpan.');

        flash('success', 'Data surat berhasil disimpan.');
        redirect('admin/letters?type=' . $type);
    }

    public function download(string $id): void {
        AuthMiddleware::handle();
        $o = $this->o();
        $letter = LetterModel::find((int)$id, $o['id']);

        if (!$letter || empty($letter['file_path'])) {
            flash('error', 'File lampiran tidak ditemukan.');
            redirect('admin/letters');
        }

        $fullPath = UPLOAD_PATH . '/' . ltrim($letter['file_path'], '/');
        if (!file_exists($fullPath)) {
            flash('error', 'File tidak ditemukan di server.');
            redirect('admin/letters');
        }

        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($fullPath) ?: 'application/octet-stream';
        $filename = basename($fullPath);

        header('Content-Description: File Transfer');
        header('Content-Type: ' . $mime);
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $letter['title'] . '-' . $letter['letter_number']) . '.' . pathinfo($filename, PATHINFO_EXTENSION) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($fullPath));
        readfile($fullPath);
        exit;
    }

    public function delete(string $id): void {
        AuthMiddleware::handle();
        Csrf::check();
        $o = $this->o();
        $letter = LetterModel::find((int)$id, $o['id']);

        if ($letter) {
            if (!empty($letter['file_path'])) {
                Upload::delete($letter['file_path']);
            }
            LetterModel::delete((int)$id, $o['id']);
            ActivityLogModel::add($o['id'], current_user()['id'], 'delete', 'letter', 'Surat (' . $letter['letter_number'] . ') dihapus.');
            flash('success', 'Surat berhasil dihapus.');
        }

        redirect('admin/letters');
    }
}
