<?php
declare(strict_types=1);

final class MemberCardController
{
    public function show(): void
    {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->frontendBase($_SERVER['REQUEST_URI'] ?? '/');

        // Refresh 1-year member session/cookie if logged in
        if (!is_member_logged_in()) {
            // Check if member_number is passed in GET to look up
            $lookupNum = trim((string)($_GET['number'] ?? ''));
            if ($lookupNum !== '') {
                $sub = $this->findMemberByNumber($lookupNum, $o['id']);
                if ($sub) {
                    $this->setMemberSession($sub);
                } else {
                    flash('error', 'Nomor Anggota (' . e($lookupNum) . ') tidak ditemukan.');
                }
            }
        }

        $member = current_member();

        if (!$member) {
            View::render('frontend/member_card_login', [
                'title' => 'Kartu Anggota Digital',
                'organization' => $o,
                'settings' => $s,
                'sections' => $sec,
                'pages' => $pages,
                'flash_error' => flash('error'),
                'flash_success' => flash('success'),
                'registration_available' => $registrationAvailable
            ]);
            return;
        }

        // Get additional field values (photo, etc.)
        $values = RegistrationSubmissionModel::values((int)$member['id']);
        $photoPath = null;
        foreach ($values as $v) {
            if ($v['field_type'] === 'file_image' && !empty($v['file_path'])) {
                $photoPath = $v['file_path'];
                break;
            }
        }

        View::render('frontend/member_card', [
            'title' => 'Kartu Tanda Anggota Digital',
            'organization' => $o,
            'settings' => $s,
            'sections' => $sec,
            'pages' => $pages,
            'member' => $member,
            'values' => $values,
            'photoPath' => $photoPath,
            'flash_success' => flash('success'),
            'flash_error' => flash('error'),
            'registration_available' => $registrationAvailable
        ]);
    }

    public function loginByNumber(): void
    {
        $auth = new AuthController();
        $auth->authenticate();
    }

    public function logout(): void
    {
        [$o, $s, $sec, $pages, $registrationAvailable] = $this->frontendBase($_SERVER['REQUEST_URI'] ?? '/');
        unset($_SESSION['member_auth']);
        setcookie('ormawa_member_token', '', time() - 3600, '/');
        flash('success', 'Anda telah keluar dari sesi Kartu Anggota.');
        redirect(org_url($o, 'kartu-anggota'));
    }

    public function findMemberByNameAndNumber(string $fullName, string $num, int $orgId): ?array
    {
        $cleanNum = preg_replace('/[^0-9]/', '', $num);
        $pdo = Database::connection();
        $s = $pdo->prepare('SELECT s.*, o.slug AS org_slug FROM registration_submissions s JOIN organizations o ON o.id = s.organization_id WHERE LOWER(TRIM(s.full_name)) = LOWER(TRIM(:fn)) AND (s.member_number = :num OR s.member_number = :clean) AND s.status = "approved" AND s.organization_id = :o');
        $s->execute(['fn' => $fullName, 'num' => $num, 'clean' => $cleanNum, 'o' => $orgId]);
        return $s->fetch() ?: null;
    }

    public function setMemberSession(array $sub): void
    {
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $pdo = Database::connection();
        $pdo->prepare('UPDATE registration_submissions SET public_token_hash = :hash WHERE id = :id')
            ->execute(['hash' => $tokenHash, 'id' => $sub['id']]);

        $_SESSION['member_auth'] = [
            'id' => (int)$sub['id'],
            'member_number' => $sub['member_number'],
            'name' => $sub['full_name'],
            'organization_id' => (int)$sub['organization_id'],
            'org_slug' => $sub['org_slug'] ?? '',
        ];

        // 1 Year persistent cookie (365 days)
        setcookie('ormawa_member_token', $token, time() + (365 * 86400), '/', '', isset($_SERVER['HTTPS']), true);
    }

    private function frontendBase(string $uri): array
    {
        $o = OrganizationResolver::resolve($uri);
        if (!$o) {
            http_response_code(404);
            View::render('errors/404', [], 'error');
            exit;
        }
        $settings = SettingModel::all($o['id']);
        $sections = HomeSectionModel::all($o['id']);
        $pages = [];
        foreach (PageModel::all($o['id']) as $p) {
            $pages[$p['page_key']] = $p;
        }

        // Determine registration availability for navbar
        $registrationAvailable = false;
        if (!empty($o['id'])) {
            if (($settings['registration_enabled'] ?? '0') === '1') {
                $registrationAvailable = RegistrationFormModel::active($o['id']) !== null;
            }
        }

        return [$o, $settings, $sections, $pages, $registrationAvailable];
    }
}
