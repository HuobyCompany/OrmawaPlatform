<?php
declare(strict_types=1);

final class AuthController
{
    public function login(): void
    {
        // Check unified authentication first
        if (AuthService::isAuthenticated()) {
            $user = AuthService::currentUser();
            if ($user && in_array($user['role'], ['super_admin', 'organization_admin', 'editor'], true)) {
                redirect('admin/dashboard');
                return;
            }
        }
        
        // Fallback to legacy authentication
        if (is_logged_in()) {
            redirect('admin/dashboard');
            return;
        }
        
        View::render('admin/login', ['title' => 'Login Admin'], 'admin');
    }

    public function authenticate(): void
    {
        Csrf::check();
        $input = trim((string)($_POST['email'] ?? $_POST['login_input'] ?? $_POST['full_name'] ?? ''));
        $pw = trim((string)($_POST['password'] ?? $_POST['member_number'] ?? ''));
        $remember = isset($_POST['remember']);

        if ($input === '' && $pw === '') {
            flash('error', 'Masukkan Email dan Password.');
            redirect('login');
            return;
        }

        // 1. Try Unified Authentication (User Account)
        if ($input !== '' && $pw !== '') {
            try {
                $user = AuthService::authenticate($input, $pw);
                if ($user) {
                    AuthService::createSession($user, $remember);
                    
                    // Redirect based on role
                    if (in_array($user['role'], ['super_admin', 'organization_admin', 'editor'], true)) {
                        redirect('admin/dashboard');
                    } elseif ($user['role'] === 'member' || $user['member_id']) {
                        // Member with user account - redirect to member portal
                        $orgSlug = $user['organization_slug'] ?? '';
                        redirect(org_url(['slug' => $orgSlug], 'member'));
                    } else {
                        redirect('admin/dashboard');
                    }
                    return;
                }
            } catch (RuntimeException $e) {
                flash('error', $e->getMessage());
                redirect('login');
                return;
            }
        }

        // 2. Fallback to Legacy Admin Authentication (for backward compatibility)
        if ($input !== '' && $pw !== '') {
            $u = UserModel::byEmail($input);
            if ($u && $u['status'] === 'active') {
                $isPasswordValid = password_verify($pw, $u['password']);
                if ($isPasswordValid) {
                    clear_login_attempts($input);
                    session_regenerate_id(true);
                    $_SESSION['user'] = [
                        'id' => (int)$u['id'],
                        'name' => $u['name'],
                        'email' => $u['email'],
                        'role' => $u['role'],
                        'organization_id' => $u['organization_id'] ? (int)$u['organization_id'] : null,
                        'organization_name' => $u['organization_name']
                    ];
                    if ($u['organization_id']) set_selected_organization((int)$u['organization_id']);

                    UserModel::touchLogin((int)$u['id']);
                    ActivityLogModel::add($u['organization_id'] ? (int)$u['organization_id'] : null, (int)$u['id'], 'login', 'auth', 'Login user ' . $u['name'] . ' (legacy fallback)');

                    redirect('admin/dashboard');
                    return;
                }
            }
        }

        // 3. Fallback to Legacy Member Authentication (member_auth)
        $cleanInput = preg_replace('/[^0-9]/', '', $input);
        $cleanPw = preg_replace('/[^0-9]/', '', $pw);
        $pdo = Database::connection();
        $sub = null;

        // Candidate 3a: Input itself is 8-digit Member Number
        if (strlen($cleanInput) === 8 || preg_match('/^\d{8}$/', $input)) {
            $stmt = $pdo->prepare('SELECT s.*, o.slug AS org_slug FROM registration_submissions s JOIN organizations o ON o.id = s.organization_id WHERE (s.member_number = :mn OR s.member_number = :clean) AND s.status = "approved"');
            $stmt->execute(['mn' => $input, 'clean' => $cleanInput]);
            $sub = $stmt->fetch() ?: null;
        }

        // Candidate 3b: Password/Secondary input is 8-digit Member Number
        if (!$sub && (strlen($cleanPw) === 8 || preg_match('/^\d{8}$/', $pw))) {
            if ($input !== '') {
                $stmt = $pdo->prepare('SELECT s.*, o.slug AS org_slug FROM registration_submissions s JOIN organizations o ON o.id = s.organization_id WHERE LOWER(TRIM(s.full_name)) = LOWER(TRIM(:fn)) AND (s.member_number = :mn OR s.member_number = :clean) AND s.status = "approved"');
                $stmt->execute(['fn' => $input, 'mn' => $pw, 'clean' => $cleanPw]);
                $sub = $stmt->fetch() ?: null;
            }
            if (!$sub) {
                $stmt = $pdo->prepare('SELECT s.*, o.slug AS org_slug FROM registration_submissions s JOIN organizations o ON o.id = s.organization_id WHERE (s.member_number = :mn OR s.member_number = :clean) AND s.status = "approved"');
                $stmt->execute(['mn' => $pw, 'clean' => $cleanPw]);
                $sub = $stmt->fetch() ?: null;
            }
        }

        if ($sub) {
            // Legacy member authentication success! Set 1-year token cookie & session
            $token = bin2hex(random_bytes(32));
            $tokenHash = hash('sha256', $token);
            $pdo->prepare('UPDATE registration_submissions SET public_token_hash = :hash WHERE id = :id')
                ->execute(['hash' => $tokenHash, 'id' => $sub['id']]);

            $_SESSION['member_auth'] = [
                'id' => (int)$sub['id'],
                'member_number' => $sub['member_number'],
                'name' => $sub['full_name'],
                'organization_id' => (int)$sub['organization_id'],
                'org_slug' => $sub['org_slug'],
            ];

            // Set 1-year persistent cookie (365 days)
            setcookie('ormawa_member_token', $token, time() + (365 * 86400), '/', '', isset($_SERVER['HTTPS']), true);

            ActivityLogModel::add((int)$sub['organization_id'], null, 'member_login', 'auth', 'Login Anggota ' . $sub['full_name'] . ' (#' . $sub['member_number'] . ') (legacy fallback)');
            flash('success', 'Selamat datang, ' . $sub['full_name'] . '! Sesi Kartu Anggota Digital Anda aktif.');
            redirect(org_url(['slug' => $sub['org_slug']], 'kartu-anggota'));
            return;
        }

        // 4. Failed Authentication Response
        if ($input !== '') record_login_attempt($input);
        flash('error', 'Kredensial tidak ditemukan atau belum disetujui pengurus.');
        redirect('login');
    }

    public function logout(): void
    {
        // Use unified authentication logout
        if (AuthService::isAuthenticated()) {
            AuthService::destroySession();
            redirect('login');
            return;
        }
        
        // Fallback to legacy logout
        $u = current_user();
        if ($u) ActivityLogModel::add($u['organization_id'], $u['id'], 'logout', 'auth', 'Logout user ' . $u['name']);
        $_SESSION = [];
        setcookie('ormawa_member_token', '', time() - 3600, '/');
        session_regenerate_id(true);
        redirect('login');
    }
}
