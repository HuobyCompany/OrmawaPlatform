<?php
declare(strict_types=1);

final class AuthMiddleware
{
    public static function handle(): void
    {
        // Check unified authentication first
        if (AuthService::isAuthenticated()) {
            $user = AuthService::currentUser();
            
            // Check if user has admin role
            if ($user && in_array($user['role'], ['super_admin', 'organization_admin', 'editor'], true)) {
                // Organization isolation: Check if user belongs to requested organization
                if ($user['role'] !== 'super_admin') {
                    $reqPath = function_exists('request_path') ? request_path() : ($_SERVER['REQUEST_URI'] ?? '/');
                    $parts = array_values(array_filter(explode('/', trim($reqPath, '/'))));
                    $firstSeg = $parts[0] ?? '';
                    
                    $requestedOrg = null;
                    if ($firstSeg !== '' && $firstSeg !== 'admin') {
                        $requestedOrg = OrganizationModel::findBySlug($firstSeg);
                    }
                    if (!$requestedOrg) {
                        $requestedOrg = OrganizationController::current();
                    }
                    
                    if ($requestedOrg && $user['organization_id'] && (int)$user['organization_id'] !== (int)$requestedOrg['id']) {
                        flash('error', 'Anda tidak memiliki akses ke organisasi ini.');
                        $orgSlug = $user['organization_slug'] ?? DEFAULT_ORGANIZATION_SLUG;
                        redirect(org_url(['slug' => $orgSlug], 'admin/dashboard'));
                        return;
                    }
                }
                return; // User is authenticated and has admin role + belongs to org (or is super_admin)
            }
            
            // User is authenticated but doesn't have admin role
            if ($user && ($user['role'] === 'member' || $user['member_id'])) {
                flash('error', 'Anggota biasa tidak memiliki akses ke Halaman Admin Pengurus.');
                $orgSlug = $user['organization_slug'] ?? '';
                redirect(org_url(['slug' => $orgSlug], 'member'));
                return;
            }
        }
        
        // Fallback to legacy authentication
        if (!is_logged_in()) {
            if (is_member_logged_in()) {
                flash('error', 'Anggota biasa tidak memiliki akses ke Halaman Admin Pengurus.');
                redirect('kartu-anggota');
                return;
            }
            redirect('login');
        }
    }
    
    public static function requireRole(array $roles): void
    {
        // Check unified authentication first
        if (AuthService::isAuthenticated()) {
            if (AuthService::hasRole($roles)) {
                return;
            }
            
            $user = AuthService::currentUser();
            if ($user) {
                http_response_code(403);
                View::render('errors/403', [], 'error');
                exit;
            }
        }
        
        // Fallback to legacy authentication
        require_role($roles);
    }
    
    public static function requirePermission(string $permission): void
    {
        // Check unified authentication first
        if (AuthService::isAuthenticated()) {
            if (AuthService::can($permission)) {
                return;
            }
            
            $user = AuthService::currentUser();
            if ($user) {
                http_response_code(403);
                View::render('errors/403', [], 'error');
                exit;
            }
        }
        
        // Fallback to legacy authentication
        if (!can($permission)) {
            http_response_code(403);
            View::render('errors/403', [], 'error');
            exit;
        }
    }
}
