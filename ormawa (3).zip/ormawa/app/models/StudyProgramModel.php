<?php
declare(strict_types=1);

final class StudyProgramModel
{
    public static function all(): array
    {
        $s = Database::connection()->query('SELECT sp.*, f.name AS faculty_name FROM study_programs sp JOIN faculties f ON f.id = sp.faculty_id ORDER BY f.sort_order, sp.sort_order, sp.name');
        return $s->fetchAll();
    }

    public static function byFaculty(int $facultyId): array
    {
        $s = Database::connection()->prepare('SELECT id, code, name FROM study_programs WHERE faculty_id = :f AND is_active = 1 ORDER BY sort_order, name');
        $s->execute(['f' => $facultyId]);
        return $s->fetchAll();
    }

    public static function active(): array
    {
        $s = Database::connection()->prepare('SELECT sp.id, sp.code, sp.name, sp.faculty_id, f.name AS faculty_name FROM study_programs sp JOIN faculties f ON f.id = sp.faculty_id WHERE sp.is_active = 1 ORDER BY f.sort_order, sp.sort_order');
        $s->execute();
        return $s->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $s = Database::connection()->prepare('SELECT sp.*, f.name AS faculty_name FROM study_programs sp JOIN faculties f ON f.id = sp.faculty_id WHERE sp.id = :id');
        $s->execute(['id' => $id]);
        $r = $s->fetch();
        return $r ?: null;
    }

    public static function save(array $d): int
    {
        $id = (int)($d['id'] ?? 0);
        if ($id) {
            $s = Database::connection()->prepare('UPDATE study_programs SET faculty_id = :f, code = :c, name = :n, sort_order = :o, is_active = :a, updated_at = NOW() WHERE id = :id');
            $s->execute(['f' => (int)$d['faculty_id'], 'c' => $d['code'], 'n' => $d['name'], 'o' => (int)($d['sort_order'] ?? 0), 'a' => (int)($d['is_active'] ?? 1), 'id' => $id]);
            return $id;
        }
        $s = Database::connection()->prepare('INSERT INTO study_programs (faculty_id, code, name, sort_order, is_active, created_at, updated_at) VALUES (:f, :c, :n, :o, :a, NOW(), NOW())');
        $s->execute(['f' => (int)$d['faculty_id'], 'c' => $d['code'], 'n' => $d['name'], 'o' => (int)($d['sort_order'] ?? 0), 'a' => (int)($d['is_active'] ?? 1)]);
        return (int)Database::connection()->lastInsertId();
    }

    public static function delete(int $id): void
    {
        $s = Database::connection()->prepare('DELETE FROM study_programs WHERE id = :id');
        $s->execute(['id' => $id]);
    }
}
