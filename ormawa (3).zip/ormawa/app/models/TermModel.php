<?php
declare(strict_types=1);

final class TermModel {
    public static function all(int $orgId): array {
        $s = Database::connection()->prepare('SELECT * FROM organization_terms WHERE organization_id = :org ORDER BY start_date DESC');
        $s->execute(['org' => $orgId]);
        return $s->fetchAll();
    }

    public static function find(int $id, int $orgId): ?array {
        $s = Database::connection()->prepare('SELECT * FROM organization_terms WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function findBySlug(string $slug, int $orgId): ?array {
        $s = Database::connection()->prepare('SELECT * FROM organization_terms WHERE slug = :slug AND organization_id = :org');
        $s->execute(['slug' => $slug, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function save(array $d, ?int $id, int $orgId): int {
        $pdo = Database::connection();
        $d['organization_id'] = $orgId;
        if ($id) {
            $d['id'] = $id;
            $sql = 'UPDATE organization_terms SET name = :name, slug = :slug, start_date = :start_date, end_date = :end_date, updated_at = NOW() WHERE id = :id AND organization_id = :organization_id';
        } else {
            $sql = 'INSERT INTO organization_terms (organization_id, name, slug, start_date, end_date, created_at, updated_at) VALUES (:organization_id, :name, :slug, :start_date, :end_date, NOW(), NOW())';
        }
        $s = $pdo->prepare($sql);
        $s->execute($d);
        return $id ?: (int)$pdo->lastInsertId();
    }

    public static function delete(int $id, int $orgId): void {
        $s = Database::connection()->prepare('DELETE FROM organization_terms WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
    }
}
