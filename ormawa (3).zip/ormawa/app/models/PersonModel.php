<?php
declare(strict_types=1);

final class PersonModel {
    public static function all(int $orgId): array {
        $sql = 'SELECT p.*, m.file_path as photo_path FROM persons p LEFT JOIN media m ON p.photo_media_id = m.id WHERE p.organization_id = :org ORDER BY p.full_name ASC';
        $s = Database::connection()->prepare($sql);
        $s->execute(['org' => $orgId]);
        return $s->fetchAll();
    }

    public static function find(int $id, int $orgId): ?array {
        $sql = 'SELECT p.*, m.file_path as photo_path FROM persons p LEFT JOIN media m ON p.photo_media_id = m.id WHERE p.id = :id AND p.organization_id = :org';
        $s = Database::connection()->prepare($sql);
        $s->execute(['id' => $id, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function save(array $d, ?int $id, int $orgId): int {
        $pdo = Database::connection();
        $d['organization_id'] = $orgId;
        $d['email'] = $d['email'] ?? null;
        $d['phone'] = $d['phone'] ?? null;
        $d['photo_media_id'] = !empty($d['photo_media_id']) ? (int)$d['photo_media_id'] : null;

        if ($id) {
            $d['id'] = $id;
            $sql = 'UPDATE persons SET full_name = :full_name, email = :email, phone = :phone, photo_media_id = :photo_media_id, updated_at = NOW() WHERE id = :id AND organization_id = :organization_id';
        } else {
            $sql = 'INSERT INTO persons (organization_id, full_name, email, phone, photo_media_id, created_at, updated_at) VALUES (:organization_id, :full_name, :email, :phone, :photo_media_id, NOW(), NOW())';
        }
        $s = $pdo->prepare($sql);
        $s->execute($d);
        return $id ?: (int)$pdo->lastInsertId();
    }

    public static function delete(int $id, int $orgId): void {
        $s = Database::connection()->prepare('DELETE FROM persons WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
    }
}
