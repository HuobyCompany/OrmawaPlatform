<?php
final class ActivityLogModel{
 public static function add(?int $org,?int $user,string $action,string $entity,string $desc):void{$s=Database::connection()->prepare('INSERT INTO activity_logs(organization_id,user_id,action,entity,description,ip_address,user_agent,created_at) VALUES(:o,:u,:a,:e,:d,:ip,:ua,NOW())');$s->execute(['o'=>$org,'u'=>$user,'a'=>$action,'e'=>$entity,'d'=>$desc,'ip'=>$_SERVER['REMOTE_ADDR']??null,'ua'=>substr($_SERVER['HTTP_USER_AGENT']??'',0,255)]);}
 public static function recent(int $org,int $limit=12):array{$s=Database::connection()->prepare('SELECT l.*,u.name FROM activity_logs l LEFT JOIN users u ON u.id=l.user_id WHERE l.organization_id=:o ORDER BY l.created_at DESC LIMIT :l');$s->bindValue(':o',$org,PDO::PARAM_INT);$s->bindValue(':l',$limit,PDO::PARAM_INT);$s->execute();return $s->fetchAll();}
}

