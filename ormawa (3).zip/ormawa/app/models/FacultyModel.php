<?php
declare(strict_types=1);

final class FacultyModel
{
    public static function all(): array
    {
        $s = Database::connection()->query('SELECT * FROM faculties ORDER BY sort_order, name');
        return $s->fetchAll();
    }

    public static function active(): array
    {
        $s = Database::connection()->prepare('SELECT id, code, name FROM faculties WHERE is_active = 1 ORDER BY sort_order, name');
        $s->execute();
        return $s->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $s = Database::connection()->prepare('SELECT * FROM faculties WHERE id = :id');
        $s->execute(['id' => $id]);
        $r = $s->fetch();
        return $r ?: null;
    }

    public static function save(array $d): int
    {
        $id = (int)($d['id'] ?? 0);
        $s = Database::connection()->prepare('INSERT INTO faculties (code, name, sort_order, is_active, created_at, updated_at) VALUES (:c, :n, :o, :a, NOW(), NOW()) ON DUPLICATE KEY UPDATE name = VALUES(name), sort_order = VALUES(sort_order), is_active = VALUES(is_active), updated_at = NOW()');
        $s->execute([
            'c' => $d['code'], 'n' => $d['name'],
            'o' => (int)($d['sort_order'] ?? 0),
            'a' => (int)($d['is_active'] ?? 1),
        ]);
        if (!$id && !isset($d['id'])) $id = (int) Database::connection()->lastInsertId();
        if ($d['id']) {
            Database::connection()->prepare('UPDATE faculties SET name = :n, sort_order = :o, is_active = :a, updated_at = NOW() WHERE id = :id')->execute([
                'n' => $d['name'], 'o' => (int)($d['sort_order'] ?? 0), 'a' => (int)($d['is_active'] ?? 1), 'id' => $d['id'],
            ]);
            $id = (int)$d['id'];
        }
        return $id;
    }

    public static function delete(int $id): void
    {
        $s = Database::connection()->prepare('DELETE FROM faculties WHERE id = :id');
        $s->execute(['id' => $id]);
    }
}
