<?php
declare(strict_types=1);

final class RegistrationFieldModel
{
    private const ALLOWED_TYPES = [
        'text', 'textarea', 'number', 'phone', 'date', 'email',
        'select', 'radio', 'checkbox', 'file_image', 'file',
        'social_media', 'faculty_selector', 'program_study_selector',
    ];

    public static function byForm(int $formId): array
    {
        $s = Database::connection()->prepare('SELECT * FROM registration_fields WHERE form_id = :f AND deleted_at IS NULL ORDER BY sort_order ASC, id ASC');
        $s->execute(['f' => $formId]);
        return $s->fetchAll() ?: [];
    }

    public static function activeByForm(int $formId): array
    {
        $s = Database::connection()->prepare('SELECT * FROM registration_fields WHERE form_id = :f AND is_active = 1 AND deleted_at IS NULL ORDER BY sort_order ASC, id ASC');
        $s->execute(['f' => $formId]);
        return $s->fetchAll() ?: [];
    }

    public static function find(int $id, int $formId): ?array
    {
        $s = Database::connection()->prepare('SELECT * FROM registration_fields WHERE id = :id AND form_id = :f AND deleted_at IS NULL');
        $s->execute(['id' => $id, 'f' => $formId]);
        $r = $s->fetch();
        return $r ?: null;
    }

    public static function nextSortOrder(int $formId): int
    {
        $s = Database::connection()->prepare('SELECT MAX(sort_order) AS m FROM registration_fields WHERE form_id = :f AND deleted_at IS NULL');
        $s->execute(['f' => $formId]);
        $r = $s->fetch();
        return $r && $r['m'] !== null ? (int)$r['m'] + 1 : 1;
    }

    public static function create(int $formId, array $d): int
    {
        $name = self::sanitizeName($d['name']);
        $s = Database::connection()->prepare('INSERT INTO registration_fields (form_id, field_type, name, label, placeholder, help_text, is_required, is_active, sort_order, options_json, validation_rules, config_json, file_accept, file_max_bytes, created_at, updated_at) VALUES (:f, :t, :n, :l, :p, :h, :r, :a, :o, :opt, :vr, :cfg, :fa, :fm, NOW(), NOW())');
        $s->execute([
            'f' => $formId,
            't' => $d['field_type'],
            'n' => $name,
            'l' => $d['label'],
            'p' => $d['placeholder'] ?? null,
            'h' => $d['help_text'] ?? null,
            'r' => (int)($d['is_required'] ?? 0),
            'a' => (int)($d['is_active'] ?? 1),
            'o' => (int)($d['sort_order'] ?? 0),
            'opt' => $d['options_json'] ?? null,
            'vr' => $d['validation_rules'] ?? null,
            'cfg' => $d['config_json'] ?? null,
            'fa' => $d['file_accept'] ?? null,
            'fm' => $d['file_max_bytes'] ?? null,
        ]);
        return (int)Database::connection()->lastInsertId();
    }

    public static function update(int $id, int $formId, array $d): void
    {
        $s = Database::connection()->prepare('UPDATE registration_fields SET field_type = :t, label = :l, placeholder = :p, help_text = :h, is_required = :r, is_active = :a, sort_order = :o, options_json = :opt, validation_rules = :vr, config_json = :cfg, file_accept = :fa, file_max_bytes = :fm, updated_at = NOW() WHERE id = :id AND form_id = :f AND deleted_at IS NULL');
        $s->execute([
            't' => $d['field_type'], 'l' => $d['label'], 'p' => $d['placeholder'] ?? null,
            'h' => $d['help_text'] ?? null, 'r' => (int)($d['is_required'] ?? 0),
            'a' => (int)($d['is_active'] ?? 1), 'o' => (int)($d['sort_order'] ?? 0),
            'opt' => $d['options_json'] ?? null, 'vr' => $d['validation_rules'] ?? null,
            'cfg' => $d['config_json'] ?? null, 'fa' => $d['file_accept'] ?? null,
            'fm' => $d['file_max_bytes'] ?? null, 'id' => $id, 'f' => $formId,
        ]);
    }

    public static function softDelete(int $id, int $formId): void
    {
        $s = Database::connection()->prepare('UPDATE registration_fields SET deleted_at = NOW() WHERE id = :id AND form_id = :f AND deleted_at IS NULL');
        $s->execute(['id' => $id, 'f' => $formId]);
    }

    public static function updateActive(int $id, int $formId, int $active): void
    {
        $s = Database::connection()->prepare('UPDATE registration_fields SET is_active = :a, updated_at = NOW() WHERE id = :id AND form_id = :f AND deleted_at IS NULL');
        $s->execute(['a' => $active, 'id' => $id, 'f' => $formId]);
    }

    public static function reorder(int $formId, array $order): void
    {
        $pdo = Database::connection();
        $pdo->beginTransaction();
        foreach ($order as $idx => $fieldId) {
            $s = $pdo->prepare('UPDATE registration_fields SET sort_order = :o, updated_at = NOW() WHERE id = :id AND form_id = :f');
            $s->execute(['o' => (int)$idx, 'id' => (int)$fieldId, 'f' => $formId]);
        }
        $pdo->commit();
    }

    public static function hasSubmissions(int $id): bool
    {
        $s = Database::connection()->prepare('SELECT 1 FROM registration_values WHERE field_id = :id LIMIT 1');
        $s->execute(['id' => $id]);
        return (bool)$s->fetch();
    }

    public static function parseOptions(?string $json): array
    {
        if (!$json) return [];
        $d = json_decode($json, true);
        return is_array($d) ? $d : [];
    }

    private static function sanitizeName(string $n): string
    {
        $n = trim($n);
        $n = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $n);
        $n = trim($n, '_-');
        return $n !== '' ? $n : 'field';
    }
}
