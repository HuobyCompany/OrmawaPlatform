<?php
declare(strict_types=1);

final class StructurePositionModel {
    public static function all(int $orgId, ?int $groupId = null, bool $publicOnly = false): array {
        $sql = 'SELECT pos.*, g.name as group_name FROM positions pos JOIN structure_groups g ON pos.group_id = g.id WHERE pos.organization_id = :org';
        $params = ['org' => $orgId];
        if ($groupId !== null) {
            $sql .= ' AND pos.group_id = :group';
            $params['group'] = $groupId;
        }
        if ($publicOnly) {
            $sql .= ' AND pos.is_public = 1';
        }
        $sql .= ' ORDER BY pos.sort_order, pos.title';
        $s = Database::connection()->prepare($sql);
        $s->execute($params);
        return $s->fetchAll();
    }

    public static function find(int $id, int $orgId): ?array {
        $sql = 'SELECT pos.*, g.name as group_name FROM positions pos JOIN structure_groups g ON pos.group_id = g.id WHERE pos.id = :id AND pos.organization_id = :org';
        $s = Database::connection()->prepare($sql);
        $s->execute(['id' => $id, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function save(array $d, ?int $id, int $orgId): int {
        $pdo = Database::connection();
        $d['organization_id'] = $orgId;
        $d['description'] = $d['description'] ?? null;
        $d['sort_order'] = isset($d['sort_order']) ? (int)$d['sort_order'] : 0;
        $d['is_public'] = isset($d['is_public']) ? (int)$d['is_public'] : 1;

        if ($id) {
            // Fetch existing record to fill missing fields for partial updates
            $existing = self::find($id, $orgId);
            // Ensure required fields are present
            $d['group_id'] = $d['group_id'] ?? $existing['group_id'];
            $d['title'] = $d['title'] ?? $existing['title'];
            $d['description'] = $d['description'] ?? $existing['description'];
            $d['is_public'] = $d['is_public'] ?? $existing['is_public'];
            $d['id'] = $id;
            $sql = 'UPDATE positions SET group_id = :group_id, title = :title, description = :description, sort_order = :sort_order, is_public = :is_public, updated_at = NOW() WHERE id = :id AND organization_id = :organization_id';
        } else {
            $sql = 'INSERT INTO positions (organization_id, group_id, title, description, sort_order, is_public, created_at, updated_at) VALUES (:organization_id, :group_id, :title, :description, :sort_order, :is_public, NOW(), NOW())';
        }
        $s = $pdo->prepare($sql);
        $s->execute($d);
        return $id ?: (int)$pdo->lastInsertId();
    }

    public static function delete(int $id, int $orgId): void {
        $s = Database::connection()->prepare('DELETE FROM positions WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
    }
}
