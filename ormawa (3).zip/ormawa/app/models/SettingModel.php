<?php
final class SettingModel{
 public static function all(int $org):array{$s=Database::connection()->prepare('SELECT setting_key,setting_value FROM organization_settings WHERE organization_id=:o');$s->execute(['o'=>$org]);$a=[];foreach($s->fetchAll() as $r)$a[$r['setting_key']]=$r['setting_value'];return $a;}
 public static function set(int $org,string $k,string $v):void{$s=Database::connection()->prepare('INSERT INTO organization_settings(organization_id,setting_key,setting_value,created_at,updated_at) VALUES(:o,:k,:v,NOW(),NOW()) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value),updated_at=NOW()');$s->execute(['o'=>$org,'k'=>$k,'v'=>$v]);}
}

