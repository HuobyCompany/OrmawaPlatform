<?php
declare(strict_types=1);

final class LetterModel {
    public static function find(int $id, int $org): ?array {
        $s = Database::connection()->prepare('SELECT * FROM letters WHERE id = :id AND organization_id = :o');
        $s->execute(['id' => $id, 'o' => $org]);
        return $s->fetch() ?: null;
    }

    public static function all(int $org, string $type = 'all', string $q = '', string $category = '', int $page = 1, int $per = 15): array {
        $w = ['organization_id = :o'];
        $p = ['o' => $org];

        if ($type === 'incoming' || $type === 'outgoing') {
            $w[] = 'type = :type';
            $p['type'] = $type;
        }

        if ($category !== '') {
            $w[] = 'category = :category';
            $p['category'] = $category;
        }

        if ($q !== '') {
            $w[] = '(letter_number LIKE :q OR title LIKE :q OR sender LIKE :q OR recipient LIKE :q OR description LIKE :q)';
            $p['q'] = '%' . $q . '%';
        }

        $where = implode(' AND ', $w);
        $off = max(0, ($page - 1) * $per);

        $sql = 'SELECT * FROM letters WHERE ' . $where . ' ORDER BY letter_date DESC, id DESC LIMIT :l OFFSET :off';
        $s = Database::connection()->prepare($sql);
        foreach ($p as $k => $v) {
            $s->bindValue(':' . $k, $v);
        }
        $s->bindValue(':l', $per, PDO::PARAM_INT);
        $s->bindValue(':off', $off, PDO::PARAM_INT);
        $s->execute();

        $c = Database::connection()->prepare('SELECT COUNT(*) FROM letters WHERE ' . $where);
        $c->execute($p);

        return [
            'items' => $s->fetchAll(),
            'total' => (int)$c->fetchColumn(),
            'page' => $page,
            'per_page' => $per
        ];
    }

    public static function counts(int $org): array {
        $s = Database::connection()->prepare('
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN type = "incoming" THEN 1 ELSE 0 END) as incoming,
                SUM(CASE WHEN type = "outgoing" THEN 1 ELSE 0 END) as outgoing
            FROM letters 
            WHERE organization_id = :o
        ');
        $s->execute(['o' => $org]);
        $row = $s->fetch();
        return [
            'total' => (int)($row['total'] ?? 0),
            'incoming' => (int)($row['incoming'] ?? 0),
            'outgoing' => (int)($row['outgoing'] ?? 0)
        ];
    }

    public static function categories(int $org): array {
        $s = Database::connection()->prepare('SELECT DISTINCT category FROM letters WHERE organization_id = :o AND category != "" ORDER BY category ASC');
        $s->execute(['o' => $org]);
        return array_column($s->fetchAll(), 'category');
    }

    public static function save(array $d, ?int $id, int $org): int {
        $pdo = Database::connection();
        $d['organization_id'] = $org;

        if ($id) {
            $d['id'] = $id;
            $sql = 'UPDATE letters SET 
                    type = :type,
                    letter_number = :letter_number,
                    title = :title,
                    sender = :sender,
                    recipient = :recipient,
                    letter_date = :letter_date,
                    received_or_sent_date = :received_or_sent_date,
                    category = :category,
                    file_path = :file_path,
                    file_size = :file_size,
                    description = :description,
                    status = :status,
                    updated_at = NOW() 
                    WHERE id = :id AND organization_id = :organization_id';
        } else {
            $sql = 'INSERT INTO letters (
                    organization_id, type, letter_number, title, sender, recipient, 
                    letter_date, received_or_sent_date, category, file_path, file_size, 
                    description, status, created_at, updated_at
                ) VALUES (
                    :organization_id, :type, :letter_number, :title, :sender, :recipient, 
                    :letter_date, :received_or_sent_date, :category, :file_path, :file_size, 
                    :description, :status, NOW(), NOW()
                )';
        }

        $s = $pdo->prepare($sql);
        $s->execute($d);
        return $id ?: (int)$pdo->lastInsertId();
    }

    public static function delete(int $id, int $org): void {
        $s = Database::connection()->prepare('DELETE FROM letters WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $org]);
    }
}
