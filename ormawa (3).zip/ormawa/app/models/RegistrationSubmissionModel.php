<?php
declare(strict_types=1);

final class RegistrationSubmissionModel
{
    public static function create(int $formId, int $orgId, array $coreData = []): int
    {
        $s = Database::connection()->prepare('INSERT INTO registration_submissions (form_id, organization_id, full_name, faculty_name, prodi_name, whatsapp, batch_year, status, ip_address, user_agent, created_at, updated_at) VALUES (:f, :o, :fn, :fac, :prodi, :wa, :batch, "pending", :ip, :ua, NOW(), NOW())');
        $s->execute([
            'f' => $formId,
            'o' => $orgId,
            'fn' => $coreData['full_name'] ?? null,
            'fac' => $coreData['faculty_name'] ?? null,
            'prodi' => $coreData['prodi_name'] ?? null,
            'wa' => $coreData['whatsapp'] ?? null,
            'batch' => $coreData['batch_year'] ?? null,
            'ip' => $_SERVER['REMOTE_ADDR'] ?? null,
            'ua' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
        ]);
        return (int)Database::connection()->lastInsertId();
    }

    public static function setSubmitted(int $id): void
    {
        $s = Database::connection()->prepare('UPDATE registration_submissions SET status = "pending", submitted_at = NOW(), updated_at = NOW() WHERE id = :id');
        $s->execute(['id' => $id]);
    }

    public static function find(int $id, int $orgId): ?array
    {
        $s = Database::connection()->prepare('SELECT s.*, f.title AS form_title FROM registration_submissions s JOIN registration_forms f ON f.id = s.form_id WHERE s.id = :id AND s.organization_id = :o');
        $s->execute(['id' => $id, 'o' => $orgId]);
        $r = $s->fetch();
        return $r ?: null;
    }

    public static function all(int $orgId, ?string $status = null, int $limit = 100): array
    {
        $where = '';
        $params = ['o' => $orgId];
        if ($status) {
            $where = ' AND s.status = :st';
            $params['st'] = $status;
        }
        $s = Database::connection()->prepare('SELECT s.*, f.title AS form_title FROM registration_submissions s JOIN registration_forms f ON f.id = s.form_id WHERE s.organization_id = :o' . $where . ' ORDER BY s.created_at DESC LIMIT ' . (int)$limit);
        $s->execute($params);
        return $s->fetchAll() ?: [];
    }

    public static function members(int $orgId, ?string $batch = null, ?string $q = null): array
    {
        $where = ' WHERE s.organization_id = :o AND s.status = "approved"';
        $params = ['o' => $orgId];

        if ($batch) {
            $where .= ' AND s.batch_year = :b';
            $params['b'] = $batch;
        }

        if ($q) {
            $where .= ' AND (s.full_name LIKE :q OR s.faculty_name LIKE :q OR s.prodi_name LIKE :q OR s.whatsapp LIKE :q OR s.public_reference LIKE :q)';
            $params['q'] = '%' . $q . '%';
        }

        $s = Database::connection()->prepare('SELECT s.*, f.title AS form_title FROM registration_submissions s JOIN registration_forms f ON f.id = s.form_id' . $where . ' ORDER BY s.reviewed_at DESC, s.id DESC');
        $s->execute($params);
        return $s->fetchAll() ?: [];
    }

    public static function getDistinctBatches(int $orgId): array
    {
        $s = Database::connection()->prepare('SELECT DISTINCT batch_year FROM registration_submissions WHERE organization_id = :o AND status = "approved" AND batch_year IS NOT NULL ORDER BY batch_year DESC');
        $s->execute(['o' => $orgId]);
        return $s->fetchAll(PDO::FETCH_COLUMN) ?: [];
    }

    public static function generateMemberNumber(int $orgId, ?string $batchYear = null): string
    {
        $pdo = Database::connection();
        $batchDigits = (!empty($batchYear) && preg_match('/\d{2,4}/', $batchYear)) ? substr(trim($batchYear), -2) : date('y');
        $yearDigits = date('y');
        $prefix = $batchDigits . $yearDigits;

        $stmt = $pdo->prepare('SELECT member_number FROM registration_submissions WHERE organization_id = :o AND member_number LIKE :p AND status = "approved" ORDER BY member_number DESC LIMIT 1');
        $stmt->execute(['o' => $orgId, 'p' => $prefix . '%']);
        $lastNum = $stmt->fetchColumn();

        if ($lastNum && strlen((string)$lastNum) >= 8) {
            $seq = (int)substr((string)$lastNum, 4) + 1;
        } else {
            $seq = 1;
        }

        do {
            $candidate = $prefix . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
            $chk = $pdo->prepare('SELECT COUNT(*) FROM registration_submissions WHERE organization_id = :o AND member_number = :c');
            $chk->execute(['o' => $orgId, 'c' => $candidate]);
            if ((int)$chk->fetchColumn() === 0) {
                return $candidate;
            }
            $seq++;
        } while ($seq < 9999);

        return $prefix . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
    }

    public static function approve(int $id, int $orgId, int $userId, ?string $notes = null): void
    {
        $pdo = Database::connection();
        $sub = self::find($id, $orgId);
        if (!$sub) {
            throw new RuntimeException('Submission tidak ditemukan.');
        }

        $vals = self::values($id);
        $fullName = trim((string)($sub['full_name'] ?? ''));
        $facName = trim((string)($sub['faculty_name'] ?? '')) ?: null;
        $prodiName = trim((string)($sub['prodi_name'] ?? '')) ?: null;
        $wa = trim((string)($sub['whatsapp'] ?? '')) ?: null;
        $batchYear = trim((string)($sub['batch_year'] ?? '')) ?: null;

        $email = null;
        $photoPath = null;

        foreach ($vals as $v) {
            if ($v['field_type'] === 'email' && !empty($v['value'])) {
                $email = trim((string)$v['value']);
            } elseif (empty($email) && preg_match('/email/i', (string)$v['field_name']) && !empty($v['value'])) {
                $email = trim((string)$v['value']);
            }

            if (in_array($v['field_type'], ['file_image', 'file']) && !empty($v['file_path'])) {
                $photoPath = trim((string)$v['file_path']);
            }
        }

        $pdo->beginTransaction();
        try {
            // 1. Person Resolution
            $personId = null;

            // Check existing mapping first
            $mapStmt = $pdo->prepare('SELECT m.person_id FROM registration_member_mapping rmm JOIN members m ON m.id = rmm.member_id WHERE rmm.registration_submission_id = :sid LIMIT 1');
            $mapStmt->execute(['sid' => $id]);
            $mappedPersonId = $mapStmt->fetchColumn();
            if ($mappedPersonId) {
                $personId = (int)$mappedPersonId;
            }

            // Check by email in persons table
            if (!$personId && !empty($email)) {
                $pStmt = $pdo->prepare('SELECT id FROM persons WHERE organization_id = :org AND email = :email LIMIT 1');
                $pStmt->execute(['org' => $orgId, 'email' => $email]);
                $foundId = $pStmt->fetchColumn();
                if ($foundId) {
                    $personId = (int)$foundId;
                }
            }

            // Check by full_name + phone in persons table
            if (!$personId && !empty($fullName) && !empty($wa)) {
                $pStmt = $pdo->prepare('SELECT id FROM persons WHERE organization_id = :org AND full_name = :fn AND phone = :phone LIMIT 1');
                $pStmt->execute(['org' => $orgId, 'fn' => $fullName, 'phone' => $wa]);
                $foundId = $pStmt->fetchColumn();
                if ($foundId) {
                    $personId = (int)$foundId;
                }
            }

            // Check by full_name only
            if (!$personId && !empty($fullName)) {
                $pStmt = $pdo->prepare('SELECT id FROM persons WHERE organization_id = :org AND full_name = :fn LIMIT 1');
                $pStmt->execute(['org' => $orgId, 'fn' => $fullName]);
                $foundId = $pStmt->fetchColumn();
                if ($foundId) {
                    $personId = (int)$foundId;
                }
            }

            // Create Person if not found
            if (!$personId) {
                $personData = [
                    'organization_id' => $orgId,
                    'full_name' => $fullName ?: ('Pendaftar #' . $id),
                    'email' => $email,
                    'phone' => $wa,
                    'photo_media_id' => null
                ];
                $personId = PersonModel::save($personData, null, $orgId);
                ActivityLogModel::add($orgId, $userId, 'person_created', 'person', 'Person baru dibuat: ' . $fullName);
            }

            // 2. Photo Handling
            if ($photoPath) {
                $pObj = PersonModel::find($personId, $orgId);
                if ($pObj && empty($pObj['photo_media_id'])) {
                    $mStmt = $pdo->prepare('SELECT id FROM media WHERE organization_id = :org AND file_path = :path LIMIT 1');
                    $mStmt->execute(['org' => $orgId, 'path' => $photoPath]);
                    $mediaId = $mStmt->fetchColumn();

                    if (!$mediaId) {
                        $fileName = basename($photoPath);
                        $mediaId = MediaModel::add([
                            'organization_id' => $orgId,
                            'uploaded_by' => $userId,
                            'category' => 'image',
                            'file_name' => $fileName,
                            'file_path' => $photoPath,
                            'mime_type' => 'image/jpeg',
                            'file_size' => 0
                        ]);
                    }

                    if ($mediaId) {
                        $upStmt = $pdo->prepare('UPDATE persons SET photo_media_id = :mid, updated_at = NOW() WHERE id = :pid AND organization_id = :org');
                        $upStmt->execute(['mid' => $mediaId, 'pid' => $personId, 'org' => $orgId]);
                    }
                }
            }

            // 3. Active Term Resolution
            $termStmt = $pdo->prepare('SELECT id FROM organization_terms WHERE organization_id = :org ORDER BY start_date DESC LIMIT 1');
            $termStmt->execute(['org' => $orgId]);
            $termRow = $termStmt->fetch();
            $currentTermId = $termRow ? (int)$termRow['id'] : null;

            // 4. Member Resolution
            $memberId = null;
            $existingMember = null;

            $mapCheck = $pdo->prepare('SELECT member_id FROM registration_member_mapping WHERE registration_submission_id = :sid LIMIT 1');
            $mapCheck->execute(['sid' => $id]);
            $mappedMemberId = $mapCheck->fetchColumn();
            if ($mappedMemberId) {
                $existingMember = MemberModel::find((int)$mappedMemberId, $orgId);
            }

            if (!$existingMember && $personId) {
                $existingMember = MemberModel::findByPersonId($personId, $orgId);
            }

            if ($existingMember) {
                $memberNumber = $existingMember['member_number'];
            } else {
                $subNumber = trim((string)($sub['member_number'] ?? ''));
                if ($subNumber !== '' && $subNumber !== '-') {
                    $chk = $pdo->prepare('SELECT COUNT(*) FROM members WHERE organization_id = :org AND member_number = :mn');
                    $chk->execute(['org' => $orgId, 'mn' => $subNumber]);
                    if ((int)$chk->fetchColumn() === 0) {
                        $memberNumber = $subNumber;
                    } else {
                        $memberNumber = MemberModel::generateMemberNumber($orgId, $batchYear);
                    }
                } else {
                    $memberNumber = MemberModel::generateMemberNumber($orgId, $batchYear);
                }
            }

            if ($existingMember) {
                $memberId = (int)$existingMember['id'];
                MemberModel::addAudit($memberId, $existingMember['status'], 'active', $userId, $notes);
                MemberModel::update($memberId, $orgId, [
                    'status' => 'active',
                    'reviewed_at' => date('Y-m-d H:i:s'),
                    'reviewed_by' => $userId,
                    'reviewer_notes' => $notes,
                    'current_term_id' => $currentTermId ?: ($existingMember['current_term_id'] ?? null),
                    'batch_year' => $batchYear ?: ($existingMember['batch_year'] ?? null),
                    'faculty_name' => $facName ?: ($existingMember['faculty_name'] ?? null),
                    'prodi_name' => $prodiName ?: ($existingMember['prodi_name'] ?? null),
                    'whatsapp' => $wa ?: ($existingMember['whatsapp'] ?? null),
                ]);
            } else {
                $memberId = MemberModel::create([
                    'organization_id' => $orgId,
                    'person_id' => $personId,
                    'member_number' => $memberNumber,
                    'status' => 'active',
                    'joined_at' => date('Y-m-d H:i:s'),
                    'current_term_id' => $currentTermId,
                    'batch_year' => $batchYear,
                    'faculty_name' => $facName,
                    'prodi_name' => $prodiName,
                    'whatsapp' => $wa,
                ]);
                MemberModel::addAudit($memberId, 'pending', 'active', $userId, $notes);
                ActivityLogModel::add($orgId, $userId, 'member_created', 'member', 'Anggota resmi baru dibuat: ' . $fullName . ' (#' . $memberNumber . ')');
            }

            // 5. Mapping record
            $mapCheck = $pdo->prepare('SELECT id FROM registration_member_mapping WHERE registration_submission_id = :sid LIMIT 1');
            $mapCheck->execute(['sid' => $id]);
            $existingMapId = $mapCheck->fetchColumn();

            if ($existingMapId) {
                $upMap = $pdo->prepare('UPDATE registration_member_mapping SET member_id = :mid, mapped_by = :mb, mapped_at = NOW(), notes = :notes WHERE registration_submission_id = :sid');
                $upMap->execute(['mid' => $memberId, 'mb' => $userId, 'notes' => $notes, 'sid' => $id]);
            } else {
                $inMap = $pdo->prepare('INSERT INTO registration_member_mapping (registration_submission_id, member_id, mapping_type, confidence_score, mapped_by, mapped_at, notes) VALUES (:sid, :mid, "direct", 100, :mb, NOW(), :notes)');
                $inMap->execute(['sid' => $id, 'mid' => $memberId, 'mb' => $userId, 'notes' => $notes]);
            }

            // 6. Update registration submission status & member_number
            $subStmt = $pdo->prepare('UPDATE registration_submissions SET status = "approved", member_number = :mn, reviewed_at = NOW(), reviewed_by = :u, reviewer_notes = :n, updated_at = NOW() WHERE id = :id AND organization_id = :o');
            $subStmt->execute(['mn' => $memberNumber, 'u' => $userId, 'n' => $notes, 'id' => $id, 'o' => $orgId]);

            ActivityLogModel::add($orgId, $userId, 'registration_approved', 'registration_submission', 'Submission #' . $id . ' disetujui (Member #' . $memberNumber . ')');

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function reject(int $id, int $orgId, int $userId, ?string $notes = null): void
    {
        $pdo = Database::connection();
        $sub = self::find($id, $orgId);
        if (!$sub) {
            throw new RuntimeException('Submission tidak ditemukan.');
        }

        $pdo->beginTransaction();
        try {
            $s = $pdo->prepare('UPDATE registration_submissions SET status = "rejected", reviewed_at = NOW(), reviewed_by = :u, reviewer_notes = :n, updated_at = NOW() WHERE id = :id AND organization_id = :o');
            $s->execute(['u' => $userId, 'n' => $notes, 'id' => $id, 'o' => $orgId]);

            $mapCheck = $pdo->prepare('SELECT member_id FROM registration_member_mapping WHERE registration_submission_id = :sid LIMIT 1');
            $mapCheck->execute(['sid' => $id]);
            $mappedMemberId = $mapCheck->fetchColumn();

            if ($mappedMemberId) {
                $member = MemberModel::find((int)$mappedMemberId, $orgId);
                if ($member) {
                    MemberModel::reject((int)$member['id'], $orgId, $userId, $notes);
                }
            }

            ActivityLogModel::add($orgId, $userId, 'registration_rejected', 'registration_submission', 'Submission #' . $id . ' ditolak');

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function getLifecycleTrace(int $submissionId, int $orgId): array
    {
        $pdo = Database::connection();

        $stmt = $pdo->prepare('SELECT rmm.*, u.name as mapped_by_name FROM registration_member_mapping rmm LEFT JOIN users u ON u.id = rmm.mapped_by WHERE rmm.registration_submission_id = :sid');
        $stmt->execute(['sid' => $submissionId]);
        $mapping = $stmt->fetch() ?: null;

        $member = null;
        if ($mapping && !empty($mapping['member_id'])) {
            $member = MemberModel::find((int)$mapping['member_id'], $orgId);
        }

        $person = null;
        if ($member && !empty($member['person_id'])) {
            $person = PersonModel::find((int)$member['person_id'], $orgId);
        } else {
            $sub = self::find($submissionId, $orgId);
            if ($sub && !empty($sub['full_name'])) {
                $stmtP = $pdo->prepare('SELECT * FROM persons WHERE organization_id = :org AND full_name = :fn LIMIT 1');
                $stmtP->execute(['org' => $orgId, 'fn' => $sub['full_name']]);
                $person = $stmtP->fetch() ?: null;
            }
        }

        $user = null;
        if ($member) {
            $stmtU = $pdo->prepare('SELECT u.id, u.name, u.email, u.role, u.status, uam.is_primary, uam.linked_at FROM users u JOIN user_account_members uam ON uam.user_id = u.id WHERE uam.member_id = :mid LIMIT 1');
            $stmtU->execute(['mid' => $member['id']]);
            $user = $stmtU->fetch() ?: null;
        }
        if (!$user && $person) {
            $stmtU = $pdo->prepare('SELECT u.id, u.name, u.email, u.role, u.status, uam.is_primary, uam.linked_at FROM users u JOIN user_account_members uam ON uam.user_id = u.id WHERE uam.person_id = :pid LIMIT 1');
            $stmtU->execute(['pid' => $person['id']]);
            $user = $stmtU->fetch() ?: null;
        }

        return [
            'mapping' => $mapping,
            'member' => $member,
            'person' => $person,
            'user' => $user,
        ];
    }

    public static function countByStatus(int $orgId, string $status = 'approved'): int
    {
        $s = Database::connection()->prepare('SELECT COUNT(*) FROM registration_submissions WHERE organization_id = :o AND status = :st');
        $s->execute(['o' => $orgId, 'st' => $status]);
        return (int)$s->fetchColumn();
    }

    public static function countPending(int $orgId): int
    {
        $s = Database::connection()->prepare('SELECT COUNT(*) FROM registration_submissions WHERE organization_id = :o AND status = "pending"');
        $s->execute(['o' => $orgId]);
        return (int)$s->fetchColumn();
    }

    public static function saveValue(int $submissionId, ?int $fieldId, array $v): void
    {
        $s = Database::connection()->prepare('INSERT INTO registration_values (submission_id, field_id, field_name, field_label, field_type, value, file_path, created_at) VALUES (:s, :f, :n, :l, :t, :v, :p, NOW())');
        $s->execute([
            's' => $submissionId,
            'f' => $fieldId,
            'n' => $v['field_name'],
            'l' => $v['field_label'],
            't' => $v['field_type'],
            'v' => $v['value'] ?? null,
            'p' => $v['file_path'] ?? null,
        ]);
    }

    public static function values(int $submissionId): array
    {
        $s = Database::connection()->prepare('SELECT * FROM registration_values WHERE submission_id = :s ORDER BY id ASC');
        $s->execute(['s' => $submissionId]);
        return $s->fetchAll() ?: [];
    }

    public static function delete(int $id, int $orgId): void
    {
        $s = Database::connection()->prepare('DELETE FROM registration_submissions WHERE id = :id AND organization_id = :o');
        $s->execute(['id' => $id, 'o' => $orgId]);
    }
}
