<?php
declare(strict_types=1);

final class MemberModel
{
    public static function all(int $orgId, ?string $status = null): array
    {
        $sql = 'SELECT m.*, p.full_name, p.email, p.phone, t.name as term_name FROM members m LEFT JOIN persons p ON p.id = m.person_id LEFT JOIN organization_terms t ON t.id = m.current_term_id WHERE m.organization_id = :org';
        $params = ['org' => $orgId];

        if ($status) {
            $sql .= ' AND m.status = :st';
            $params['st'] = $status;
        }

        $sql .= ' ORDER BY m.created_at DESC';
        $s = Database::connection()->prepare($sql);
        $s->execute($params);
        return $s->fetchAll() ?: [];
    }

    public static function find(int $id, int $orgId): ?array
    {
        $sql = 'SELECT m.*, p.full_name, p.email, p.phone, t.name as term_name FROM members m LEFT JOIN persons p ON p.id = m.person_id LEFT JOIN organization_terms t ON t.id = m.current_term_id WHERE m.id = :id AND m.organization_id = :org';
        $s = Database::connection()->prepare($sql);
        $s->execute(['id' => $id, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function findByMemberNumber(string $memberNumber, int $orgId): ?array
    {
        $sql = 'SELECT m.*, p.full_name, p.email, p.phone, t.name as term_name FROM members m LEFT JOIN persons p ON p.id = m.person_id LEFT JOIN organization_terms t ON t.id = m.current_term_id WHERE m.member_number = :mn AND m.organization_id = :org';
        $s = Database::connection()->prepare($sql);
        $s->execute(['mn' => $memberNumber, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function findByPersonId(int $personId, int $orgId): ?array
    {
        $sql = 'SELECT m.*, p.full_name, p.email, p.phone, t.name as term_name FROM members m LEFT JOIN persons p ON p.id = m.person_id LEFT JOIN organization_terms t ON t.id = m.current_term_id WHERE m.person_id = :pid AND m.organization_id = :org';
        $s = Database::connection()->prepare($sql);
        $s->execute(['pid' => $personId, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function create(array $data): int
    {
        $pdo = Database::connection();
        $sql = 'INSERT INTO members (organization_id, person_id, member_number, status, joined_at, current_term_id, batch_year, faculty_name, prodi_name, whatsapp, created_at, updated_at) VALUES (:org, :pid, :mn, :st, :ja, :tid, :by, :fac, :pro, :wa, NOW(), NOW())';
        $s = $pdo->prepare($sql);
        $s->execute([
            'org' => $data['organization_id'],
            'pid' => $data['person_id'] ?? null,
            'mn' => $data['member_number'],
            'st' => $data['status'] ?? 'pending',
            'ja' => $data['joined_at'] ?? null,
            'tid' => $data['current_term_id'] ?? null,
            'by' => $data['batch_year'] ?? null,
            'fac' => $data['faculty_name'] ?? null,
            'pro' => $data['prodi_name'] ?? null,
            'wa' => $data['whatsapp'] ?? null,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, int $orgId, array $data): void
    {
        $pdo = Database::connection();
        $fields = [];
        $params = ['id' => $id, 'org' => $orgId];

        if (isset($data['person_id'])) {
            $fields[] = 'person_id = :pid';
            $params['pid'] = $data['person_id'];
        }
        if (isset($data['status'])) {
            $fields[] = 'status = :st';
            $params['st'] = $data['status'];
        }
        if (isset($data['current_term_id'])) {
            $fields[] = 'current_term_id = :tid';
            $params['tid'] = $data['current_term_id'];
        }
        if (isset($data['batch_year'])) {
            $fields[] = 'batch_year = :by';
            $params['by'] = $data['batch_year'];
        }
        if (isset($data['faculty_name'])) {
            $fields[] = 'faculty_name = :fac';
            $params['fac'] = $data['faculty_name'];
        }
        if (isset($data['prodi_name'])) {
            $fields[] = 'prodi_name = :pro';
            $params['pro'] = $data['prodi_name'];
        }
        if (isset($data['whatsapp'])) {
            $fields[] = 'whatsapp = :wa';
            $params['wa'] = $data['whatsapp'];
        }
        if (isset($data['reviewed_at'])) {
            $fields[] = 'reviewed_at = :ra';
            $params['ra'] = $data['reviewed_at'];
        }
        if (isset($data['reviewed_by'])) {
            $fields[] = 'reviewed_by = :rb';
            $params['rb'] = $data['reviewed_by'];
        }
        if (isset($data['reviewer_notes'])) {
            $fields[] = 'reviewer_notes = :rn';
            $params['rn'] = $data['reviewer_notes'];
        }

        $fields[] = 'updated_at = NOW()';

        $sql = 'UPDATE members SET ' . implode(', ', $fields) . ' WHERE id = :id AND organization_id = :org';
        $s = $pdo->prepare($sql);
        $s->execute($params);
    }

    public static function delete(int $id, int $orgId): void
    {
        $s = Database::connection()->prepare('DELETE FROM members WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
    }

    public static function countByStatus(int $orgId, string $status): int
    {
        $s = Database::connection()->prepare('SELECT COUNT(*) FROM members WHERE organization_id = :org AND status = :st');
        $s->execute(['org' => $orgId, 'st' => $status]);
        return (int)$s->fetchColumn();
    }

    public static function getDistinctBatches(int $orgId): array
    {
        $s = Database::connection()->prepare('SELECT DISTINCT batch_year FROM members WHERE organization_id = :org AND batch_year IS NOT NULL ORDER BY batch_year DESC');
        $s->execute(['org' => $orgId]);
        $result = $s->fetchAll();
        return array_column($result, 'batch_year');
    }

    public static function generateMemberNumber(int $orgId, ?string $batchYear = null): string
    {
        $pdo = Database::connection();
        $batchDigits = (!empty($batchYear) && preg_match('/\d{2,4}/', $batchYear)) ? substr(trim($batchYear), -2) : date('y');
        $yearDigits = date('y');
        $prefix = $batchDigits . $yearDigits;

        $stmt = $pdo->prepare('SELECT member_number FROM members WHERE organization_id = :o AND member_number LIKE :p ORDER BY member_number DESC LIMIT 1');
        $stmt->execute(['o' => $orgId, 'p' => $prefix . '%']);
        $lastNum = $stmt->fetchColumn();

        if ($lastNum && strlen((string)$lastNum) >= 8) {
            $seq = (int)substr((string)$lastNum, 4) + 1;
        } else {
            $seq = 1;
        }

        do {
            $candidate = $prefix . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
            $chk = $pdo->prepare('SELECT COUNT(*) FROM members WHERE organization_id = :o AND member_number = :c');
            $chk->execute(['o' => $orgId, 'c' => $candidate]);
            if ((int)$chk->fetchColumn() === 0) {
                return $candidate;
            }
            $seq++;
        } while ($seq < 9999);

        return $prefix . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
    }

    public static function approve(int $id, int $orgId, int $userId, ?string $notes = null): void
    {
        $pdo = Database::connection();
        $member = self::find($id, $orgId);
        if (!$member) {
            return;
        }

        $mn = trim((string)($member['member_number'] ?? ''));
        if ($mn === '' || $mn === '-') {
            $mn = self::generateMemberNumber($orgId, $member['batch_year'] ?? null);
        }

        // Record status change in audit
        self::addAudit($id, $member['status'], 'active', $userId, $notes);

        $s = $pdo->prepare('UPDATE members SET status = "active", member_number = :mn, reviewed_at = NOW(), reviewed_by = :u, reviewer_notes = :n, updated_at = NOW() WHERE id = :id AND organization_id = :o');
        $s->execute(['mn' => $mn, 'u' => $userId, 'n' => $notes, 'id' => $id, 'o' => $orgId]);
    }

    public static function reject(int $id, int $orgId, int $userId, ?string $notes = null): void
    {
        $pdo = Database::connection();
        $member = self::find($id, $orgId);
        if (!$member) {
            return;
        }

        // Record status change in audit
        self::addAudit($id, $member['status'], 'rejected', $userId, $notes);

        $s = $pdo->prepare('UPDATE members SET status = "rejected", reviewed_at = NOW(), reviewed_by = :u, reviewer_notes = :n, updated_at = NOW() WHERE id = :id AND organization_id = :o');
        $s->execute(['u' => $userId, 'n' => $notes, 'id' => $id, 'o' => $orgId]);
    }

    public static function suspend(int $id, int $orgId, int $userId, ?string $notes = null): void
    {
        $pdo = Database::connection();
        $member = self::find($id, $orgId);
        if (!$member) {
            return;
        }

        // Record status change in audit
        self::addAudit($id, $member['status'], 'suspended', $userId, $notes);

        $s = $pdo->prepare('UPDATE members SET status = "suspended", reviewed_at = NOW(), reviewed_by = :u, reviewer_notes = :n, updated_at = NOW() WHERE id = :id AND organization_id = :o');
        $s->execute(['u' => $userId, 'n' => $notes, 'id' => $id, 'o' => $orgId]);
    }

    public static function addAudit(int $memberId, ?string $oldStatus, string $newStatus, ?int $changedBy, ?string $notes = null): void
    {
        $s = Database::connection()->prepare('INSERT INTO member_audit (member_id, old_status, new_status, changed_by, notes, changed_at) VALUES (:mid, :old, :new, :cb, :notes, NOW())');
        $s->execute([
            'mid' => $memberId,
            'old' => $oldStatus,
            'new' => $newStatus,
            'cb' => $changedBy,
            'notes' => $notes,
        ]);
    }

    public static function getAuditHistory(int $memberId): array
    {
        $s = Database::connection()->prepare('SELECT ma.*, u.name as changed_by_name FROM member_audit ma LEFT JOIN users u ON u.id = ma.changed_by WHERE ma.member_id = :mid ORDER BY ma.changed_at DESC');
        $s->execute(['mid' => $memberId]);
        return $s->fetchAll() ?: [];
    }
}
