<?php
final class MediaModel{
 public static function all(int $org):array{$s=Database::connection()->prepare('SELECT * FROM media WHERE organization_id=:o ORDER BY created_at DESC');$s->execute(['o'=>$org]);return $s->fetchAll();}
 public static function find(int $id):?array{$s=Database::connection()->prepare('SELECT * FROM media WHERE id=:id LIMIT 1');$s->execute(['id'=>$id]);return $s->fetch()?:null;}
 public static function add(array $d):int{$s=Database::connection()->prepare('INSERT INTO media(organization_id,uploaded_by,category,file_name,file_path,mime_type,file_size,created_at) VALUES(:organization_id,:uploaded_by,:category,:file_name,:file_path,:mime_type,:file_size,NOW())');$s->execute($d);return (int)Database::connection()->lastInsertId();}
 public static function delete(int $id,int $org):void{$s=Database::connection()->prepare('DELETE FROM media WHERE id=:id AND organization_id=:o');$s->execute(['id'=>$id,'o'=>$org]);}
}

