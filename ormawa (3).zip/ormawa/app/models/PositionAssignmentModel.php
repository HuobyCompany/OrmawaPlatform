<?php
declare(strict_types=1);

final class PositionAssignmentModel {
    public static function all(int $orgId, ?int $termId = null, bool $publicOnly = false): array {
        $sql = 'SELECT pa.*, pos.title as position_title, g.name as group_name, p.full_name as person_name, t.name as term_name, m.file_path as photo, p.photo_media_id
                FROM position_assignments pa
                JOIN positions pos ON pa.position_id = pos.id
                JOIN structure_groups g ON pos.group_id = g.id
                JOIN organization_terms t ON pa.term_id = t.id
                LEFT JOIN persons p ON pa.person_id = p.id
                LEFT JOIN media m ON p.photo_media_id = m.id
                WHERE pa.organization_id = :org';
        $params = ['org' => $orgId];
        if ($termId !== null) {
            $sql .= ' AND pa.term_id = :term';
            $params['term'] = $termId;
        }
        if ($publicOnly) {
            $sql .= ' AND pa.is_public = 1 AND pos.is_public = 1 AND g.is_public = 1';
        }
        $sql .= ' ORDER BY g.sort_order, pos.sort_order';
        $s = Database::connection()->prepare($sql);
        $s->execute($params);
        return $s->fetchAll();
    }

    public static function find(int $id, int $orgId): ?array {
        $sql = 'SELECT pa.*, pos.title as position_title, g.name as group_name, p.full_name as person_name, t.name as term_name 
                FROM position_assignments pa
                JOIN positions pos ON pa.position_id = pos.id
                JOIN structure_groups g ON pos.group_id = g.id
                JOIN organization_terms t ON pa.term_id = t.id
                LEFT JOIN persons p ON pa.person_id = p.id
                WHERE pa.id = :id AND pa.organization_id = :org';
        $s = Database::connection()->prepare($sql);
        $s->execute(['id' => $id, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function findByPerson(int $personId, int $orgId): array {
        $sql = 'SELECT pa.*, pos.title as position_title, g.name as group_name, t.name as term_name 
                FROM position_assignments pa
                JOIN positions pos ON pa.position_id = pos.id
                JOIN structure_groups g ON pos.group_id = g.id
                JOIN organization_terms t ON pa.term_id = t.id
                WHERE pa.person_id = :person AND pa.organization_id = :org
                ORDER BY pa.start_date DESC';
        $s = Database::connection()->prepare($sql);
        $s->execute(['person' => $personId, 'org' => $orgId]);
        return $s->fetchAll();
    }

    public static function save(array $d, ?int $id, int $orgId): int {
        $pdo = Database::connection();
        $d['organization_id'] = $orgId;
        $d['person_id'] = !empty($d['person_id']) ? (int)$d['person_id'] : null;
        $d['end_date'] = !empty($d['end_date']) ? $d['end_date'] : null;
        $d['status'] = $d['status'] ?? ($d['person_id'] === null ? 'vacant' : 'active');
        $d['is_public'] = isset($d['is_public']) ? (int)$d['is_public'] : 1;

        if ($id) {
            $d['id'] = $id;
            $sql = 'UPDATE position_assignments SET term_id = :term_id, position_id = :position_id, person_id = :person_id, start_date = :start_date, end_date = :end_date, status = :status, is_public = :is_public, updated_at = NOW() WHERE id = :id AND organization_id = :organization_id';
        } else {
            $sql = 'INSERT INTO position_assignments (organization_id, term_id, position_id, person_id, start_date, end_date, status, is_public, created_at, updated_at) VALUES (:organization_id, :term_id, :position_id, :person_id, :start_date, :end_date, :status, :is_public, NOW(), NOW())';
        }
        $s = $pdo->prepare($sql);
        $s->execute($d);
        return $id ?: (int)$pdo->lastInsertId();
    }

    public static function delete(int $id, int $orgId): void {
        $s = Database::connection()->prepare('DELETE FROM position_assignments WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
    }
}
