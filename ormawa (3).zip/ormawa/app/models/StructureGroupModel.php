<?php
declare(strict_types=1);

final class StructureGroupModel {
    public static function all(int $orgId, bool $publicOnly = false): array {
        $sql = 'SELECT * FROM structure_groups WHERE organization_id = :org';
        if ($publicOnly) {
            $sql .= ' AND is_public = 1';
        }
        $sql .= ' ORDER BY parent_id IS NULL DESC, parent_id, sort_order, name';
        $s = Database::connection()->prepare($sql);
        $s->execute(['org' => $orgId]);
        return $s->fetchAll();
    }

    public static function find(int $id, int $orgId): ?array {
        $s = Database::connection()->prepare('SELECT * FROM structure_groups WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
        return $s->fetch() ?: null;
    }

    public static function save(array $d, ?int $id, int $orgId): int {
        $pdo = Database::connection();
        $d['organization_id'] = $orgId;
        $d['parent_id'] = !empty($d['parent_id']) ? (int)$d['parent_id'] : null;
        $d['description'] = $d['description'] ?? null;
        $d['sort_order'] = isset($d['sort_order']) ? (int)$d['sort_order'] : 0;
        $d['is_public'] = isset($d['is_public']) ? (int)$d['is_public'] : 1;

        if ($id) {
            // Fetch existing record to fill missing fields for partial updates
            $existing = self::find($id, $orgId);
            $d['name'] = $d['name'] ?? $existing['name'];
            $d['description'] = $d['description'] ?? $existing['description'];
            $d['parent_id'] = $d['parent_id'] ?? $existing['parent_id'];
            $d['sort_order'] = $d['sort_order'] ?? $existing['sort_order'];
            $d['is_public'] = $d['is_public'] ?? $existing['is_public'];
            $d['id'] = $id;
            $sql = 'UPDATE structure_groups SET name = :name, description = :description, parent_id = :parent_id, sort_order = :sort_order, is_public = :is_public, updated_at = NOW() WHERE id = :id AND organization_id = :organization_id';
        } else {
            $sql = 'INSERT INTO structure_groups (organization_id, name, description, parent_id, sort_order, is_public, created_at, updated_at) VALUES (:organization_id, :name, :description, :parent_id, :sort_order, :is_public, NOW(), NOW())';
        }
        $s = $pdo->prepare($sql);
        $s->execute($d);
        return $id ?: (int)$pdo->lastInsertId();
    }

    public static function delete(int $id, int $orgId): void {
        $s = Database::connection()->prepare('DELETE FROM structure_groups WHERE id = :id AND organization_id = :org');
        $s->execute(['id' => $id, 'org' => $orgId]);
    }
}
