<?php
final class HomeSectionModel{
 public static function all(int $org):array{$s=Database::connection()->prepare('SELECT * FROM home_sections WHERE organization_id=:o ORDER BY sort_order');$s->execute(['o'=>$org]);return $s->fetchAll();}
 public static function save(int $org,string $k,bool $status,int $order):void{$s=Database::connection()->prepare('INSERT INTO home_sections(organization_id,section_key,status,sort_order,updated_at) VALUES(:o,:k,:s,:ord,NOW()) ON DUPLICATE KEY UPDATE status=VALUES(status),sort_order=VALUES(sort_order),updated_at=NOW()');$s->execute(['o'=>$org,'k'=>$k,'s'=>$status?1:0,'ord'=>max(0,$order)]);}
}
