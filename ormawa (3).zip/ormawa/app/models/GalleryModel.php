<?php
declare(strict_types=1);

final class GalleryModel
{
  public static function all(int $org): array
  {
      $s = Database::connection()->prepare('SELECT * FROM gallery_albums WHERE organization_id=:o ORDER BY event_date DESC, title');
      $s->execute(['o' => $org]);
      return $s->fetchAll();
  }

  public static function album(int $id, int $org): ?array
  {
      return self::find($id, $org);
  }

  public static function find(int $id, int $org): ?array
  {
      $s = Database::connection()->prepare('SELECT * FROM gallery_albums WHERE id=:id AND organization_id=:o');
      $s->execute(['id' => $id, 'o' => $org]);
      return $s->fetch() ?: null;
  }

  public static function bySlug(string $slug, int $org): ?array
  {
      $s = Database::connection()->prepare('SELECT * FROM gallery_albums WHERE slug=:s AND organization_id=:o LIMIT 1');
      $s->execute(['s' => $slug, 'o' => $org]);
      return $s->fetch() ?: null;
  }

  public static function albums(int $org, string $q = '', ?string $category = null, ?int $year = null, int $page = 1, int $per = 9): array
  {
      $w = ['a.organization_id=:o'];
      $p = ['o' => $org];
      if ($q !== '') {
          $w[] = '(a.title LIKE :q OR a.description LIKE :q)';
          $p['q'] = '%' . $q . '%';
      }
      if ($category !== null) {
          $w[] = 'a.category=:cat';
          $p['cat'] = $category;
      }
      if ($year !== null) {
          $w[] = 'YEAR(a.event_date)=:yr';
          $p['yr'] = $year;
      }
      $where = implode(' AND ', $w);
      $off = ($page - 1) * $per;
      $sql = 'SELECT a.*,COUNT(i.id) photo_count FROM gallery_albums a LEFT JOIN gallery_items i ON i.album_id=a.id AND i.sync_status != "removed" WHERE ' . $where . ' GROUP BY a.id ORDER BY a.event_date DESC,a.title LIMIT :l OFFSET :off';
      $s = Database::connection()->prepare($sql);
      foreach ($p as $k => $v) $s->bindValue(':' . $k, $v);
      $s->bindValue(':l', $per, PDO::PARAM_INT);
      $s->bindValue(':off', $off, PDO::PARAM_INT);
      $s->execute();
      $c = Database::connection()->prepare('SELECT COUNT(*) FROM gallery_albums a WHERE ' . $where);
      $c->execute($p);
      return ['items' => $s->fetchAll(), 'total' => (int) $c->fetchColumn(), 'page' => $page, 'per_page' => $per];
  }

  public static function items(int $album, int $org = null): array
  {
      if ($org !== null) {
          $sql = 'SELECT * FROM gallery_items WHERE album_id=:a AND sync_status != "removed" AND (SELECT organization_id FROM gallery_albums WHERE id=:a2)=:o';
          $s = Database::connection()->prepare($sql);
          $s->execute(['a' => $album, 'a2' => $album, 'o' => $org]);
      } else {
          $sql = 'SELECT * FROM gallery_items WHERE album_id=:a AND sync_status != "removed"';
          $s = Database::connection()->prepare($sql);
          $s->execute(['a' => $album]);
      }
      return $s->fetchAll();
  }

  public static function item(int $id, int $album, int $org = null): ?array
  {
      if ($org !== null) {
          $sql = 'SELECT * FROM gallery_items WHERE id=:id AND album_id=:a AND sync_status != "removed" AND (SELECT organization_id FROM gallery_albums WHERE id=:a2)=:o';
          $s = Database::connection()->prepare($sql);
          $s->execute(['id' => $id, 'a' => $album, 'a2' => $album, 'o' => $org]);
      } else {
          $sql = 'SELECT * FROM gallery_items WHERE id=:id AND album_id=:a AND sync_status != "removed"';
          $s = Database::connection()->prepare($sql);
          $s->execute(['id' => $id, 'a' => $album]);
      }
      return $s->fetch() ?: null;
  }

  public static function saveAlbum(array $d, ?int $id, int $org): int
  {
      $pdo = Database::connection();
      $d['organization_id'] = $org;
      if ($id) {
          $d['id'] = $id;
          $sql = 'UPDATE gallery_albums SET title=:title,slug=:slug,description=:description,event_date=:event_date,category=:category,cover_image=:cover_image,source_type=:source_type,drive_folder_id=:drive_folder_id,drive_folder_name=:drive_folder_name,sync_status=:sync_status,updated_at=NOW() WHERE id=:id AND organization_id=:organization_id';
      } else {
          $sql = 'INSERT INTO gallery_albums(organization_id,title,slug,description,event_date,category,cover_image,source_type,drive_folder_id,drive_folder_name,sync_status,created_at,updated_at) VALUES(:organization_id,:title,:slug,:description,:event_date,:category,:cover_image,:source_type,:drive_folder_id,:drive_folder_name,:sync_status,NOW(),NOW())';
      }
      $s = $pdo->prepare($sql);
      $s->execute($d);
      return $id ?: (int) $pdo->lastInsertId();
  }

  public static function saveItem(array $d): int
  {
      $s = Database::connection()->prepare('INSERT INTO gallery_items(album_id,title,description,file_path,mime_type,file_size,sort_order,alt_text,caption,source_type,drive_file_id,drive_url,remote_url,thumbnail_url,sync_status,last_synced_at,created_at,updated_at) VALUES(:album_id,:title,:description,:file_path,:mime_type,:file_size,:sort_order,:alt_text,:caption,:source_type,:drive_file_id,:drive_url,:remote_url,:thumbnail_url,:sync_status,:last_synced_at,NOW(),NOW())');
      $s->execute($d);
      return (int) Database::connection()->lastInsertId();
  }

  public static function updateItem(int $id, int $album, array $d, int $org = null): void
  {
      $d['id'] = $id;
      $d['album'] = $album;
      if ($org !== null) {
          $sql = 'UPDATE gallery_items SET title=:title,description=:description,alt_text=:alt_text,caption=:caption,updated_at=NOW() WHERE id=:id AND album_id=:album AND (SELECT organization_id FROM gallery_albums WHERE id=:album2)=:o';
          $d['album2'] = $album;
          $d['o'] = $org;
      } else {
          $sql = 'UPDATE gallery_items SET title=:title,description=:description,alt_text=:alt_text,caption=:caption,updated_at=NOW() WHERE id=:id AND album_id=:album';
      }
      $s = Database::connection()->prepare($sql);
      $s->execute($d);
  }

  public static function deleteAlbum(int $id, int $org): void
  {
      $s = Database::connection()->prepare('DELETE FROM gallery_albums WHERE id=:id AND organization_id=:o');
      $s->execute(['id' => $id, 'o' => $org]);
  }

  public static function deleteItem(int $id, int $album, int $org = null): void
  {
      if ($org !== null) {
          $sql = 'DELETE FROM gallery_items WHERE id=:id AND album_id=:a AND (SELECT organization_id FROM gallery_albums WHERE id=:a2)=:o';
          $params = ['id' => $id, 'a' => $album, 'a2' => $album, 'o' => $org];
      } else {
          $sql = 'DELETE FROM gallery_items WHERE id=:id AND album_id=:a';
          $params = ['id' => $id, 'a' => $album];
      }
      $s = Database::connection()->prepare($sql);
      $s->execute($params);
  }

  public static function updateAlbumDriveMeta(int $id, int $org, array $meta): bool
  {
      $allowed = ['source_type', 'drive_folder_id', 'drive_folder_name', 'sync_status', 'sync_error', 'last_synced_at'];
      $sets = [];
      $params = ['id' => $id, 'o' => $org];
      foreach ($allowed as $key) {
          if (array_key_exists($key, $meta)) {
              $sets[] = $key . '=:' . $key;
              $params[$key] = $meta[$key];
          }
      }
      if (!$sets) return false;
      $sql = 'UPDATE gallery_albums SET ' . implode(', ', $sets) . ', updated_at=NOW() WHERE id=:id AND organization_id=:o';
      $s = Database::connection()->prepare($sql);
      return $s->execute($params);
  }

  public static function markAlbumItemsRemoved(int $albumId, array $keepDriveFileIds): int
  {
      if (empty($keepDriveFileIds)) {
          $s = Database::connection()->prepare('UPDATE gallery_items SET sync_status="removed", updated_at=NOW() WHERE album_id=:a AND source_type="google_drive" AND sync_status != "removed"');
          $s->execute(['a' => $albumId]);
          return (int) $s->rowCount();
      }

      $placeholders = implode(',', array_fill(0, count($keepDriveFileIds), '?'));
      $s = Database::connection()->prepare('UPDATE gallery_items SET sync_status="removed", updated_at=NOW() WHERE album_id=:a AND source_type="google_drive" AND sync_status != "removed" AND drive_file_id NOT IN (' . $placeholders . ')');
      $params = array_merge(['a' => $albumId], $keepDriveFileIds);
      $s->execute($params);
      return (int) $s->rowCount();
  }

  public static function updateDriveItemMeta(int $albumId, string $driveFileId, array $meta): bool
  {
      $allowed = ['title', 'description', 'alt_text', 'caption', 'drive_url', 'thumbnail_url', 'mime_type', 'file_size', 'sync_status', 'last_synced_at'];
      $sets = [];
      $params = ['album_id' => $albumId, 'drive_file_id' => $driveFileId];
      foreach ($allowed as $key) {
          if (array_key_exists($key, $meta)) {
              $sets[] = $key . '=:' . $key;
              $params[$key] = $meta[$key];
          }
      }
      if (!$sets) return false;
      $sql = 'UPDATE gallery_items SET ' . implode(', ', $sets) . ', updated_at=NOW() WHERE album_id=:album_id AND drive_file_id=:drive_file_id';
      $s = Database::connection()->prepare($sql);
      return $s->execute($params);
  }

  public static function syncDriveAlbum(int $albumId, int $org, array $driveFiles): array
  {
      $existing = Database::connection()->prepare('SELECT * FROM gallery_items WHERE album_id=:a AND source_type="google_drive" AND sync_status != "removed"');
      $existing->execute(['a' => $albumId]);
      $existingItems = $existing->fetchAll();

      $existingByDriveId = [];
      foreach ($existingItems as $item) {
          $existingByDriveId[$item['drive_file_id']] = $item;
      }

      $keepDriveIds = [];
      $stats = [
          'total' => count($driveFiles),
          'new' => 0,
          'updated' => 0,
          'removed' => 0,
          'errors' => 0
      ];

      foreach ($driveFiles as $file) {
          $driveFileId = $file['id'];
          $keepDriveIds[] = $driveFileId;

          if (isset($existingByDriveId[$driveFileId])) {
              $current = $existingByDriveId[$driveFileId];
              $needsUpdate = false;
              $updateMeta = [];

              if ($current['title'] !== $file['name']) {
                  $needsUpdate = true;
                  $updateMeta['title'] = $file['name'];
              }
              if ($current['drive_url'] !== ($file['webContentLink'] ?? null)) {
                  $needsUpdate = true;
                  $updateMeta['drive_url'] = $file['webContentLink'] ?? null;
              }
              if ($current['thumbnail_url'] !== ($file['thumbnailLink'] ?? null)) {
                  $needsUpdate = true;
                  $updateMeta['thumbnail_url'] = $file['thumbnailLink'] ?? null;
              }
              if ($current['mime_type'] !== $file['mimeType']) {
                  $needsUpdate = true;
                  $updateMeta['mime_type'] = $file['mimeType'];
              }
              if ($current['file_size'] !== ($file['size'] ?? 0)) {
                  $needsUpdate = true;
                  $updateMeta['file_size'] = $file['size'] ?? 0;
              }

              if ($needsUpdate) {
                  $updateMeta['sync_status'] = 'active';
                  $updateMeta['last_synced_at'] = date('Y-m-d H:i:s');
                  self::updateDriveItemMeta($albumId, $driveFileId, $updateMeta);
                  $stats['updated']++;
              }
          } else {
              $itemData = [
                  'album_id' => $albumId,
                  'title' => $file['name'],
                  'description' => '',
                  'file_path' => '',
                  'mime_type' => $file['mimeType'],
                  'file_size' => $file['size'] ?? 0,
                  'sort_order' => self::getNextSortOrder($albumId),
                  'alt_text' => $file['name'],
                  'caption' => '',
                  'source_type' => 'google_drive',
                  'drive_file_id' => $driveFileId,
                  'drive_url' => $file['webContentLink'] ?? null,
                  'thumbnail_url' => $file['thumbnailLink'] ?? null,
                  'sync_status' => 'active',
                  'last_synced_at' => date('Y-m-d H:i:s')
              ];
              self::saveItem($itemData);
              $stats['new']++;
          }
      }

      $removed = self::markAlbumItemsRemoved($albumId, $keepDriveIds);
      $stats['removed'] = $removed;

      self::updateAlbumDriveMeta($albumId, $org, [
          'sync_status' => 'synced',
          'last_synced_at' => date('Y-m-d H:i:s'),
          'sync_error' => null
      ]);

      return $stats;
  }

  public static function getNextSortOrder(int $albumId): int
  {
      $s = Database::connection()->prepare('SELECT MAX(sort_order) FROM gallery_items WHERE album_id=:a');
      $s->execute(['a' => $albumId]);
      $max = (int) $s->fetchColumn();
      return $max + 1;
  }
}
