<?php
final class PageModel{
 public static function all(int $org):array{$s=Database::connection()->prepare('SELECT * FROM pages WHERE organization_id=:o ORDER BY title');$s->execute(['o'=>$org]);return $s->fetchAll();}
 public static function byKey(string $k,int $org):?array{$s=Database::connection()->prepare('SELECT * FROM pages WHERE organization_id=:o AND page_key=:k LIMIT 1');$s->execute(['o'=>$org,'k'=>$k]);return $s->fetch()?:null;}
}

