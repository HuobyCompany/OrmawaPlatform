<?php
declare(strict_types=1);

final class RegistrationFormModel
{
    public static function active(int $orgId): ?array
    {
        $s = Database::connection()->prepare('SELECT * FROM registration_forms WHERE organization_id = :o AND is_active = 1 LIMIT 1');
        $s->execute(['o' => $orgId]);
        $r = $s->fetch();
        return $r ?: null;
    }

    public static function activeId(int $orgId): ?int
    {
        $s = Database::connection()->prepare('SELECT id FROM registration_forms WHERE organization_id = :o AND is_active = 1 LIMIT 1');
        $s->execute(['o' => $orgId]);
        $r = $s->fetch();
        return $r ? (int)$r['id'] : null;
    }

    public static function find(int $id, int $orgId): ?array
    {
        $s = Database::connection()->prepare('SELECT * FROM registration_forms WHERE id = :id AND organization_id = :o');
        $s->execute(['id' => $id, 'o' => $orgId]);
        $r = $s->fetch();
        return $r ?: null;
    }

    public static function findByOrg(int $orgId): array
    {
        $s = Database::connection()->prepare('SELECT * FROM registration_forms WHERE organization_id = :o ORDER BY is_active DESC, id DESC');
        $s->execute(['o' => $orgId]);
        return $s->fetchAll() ?: [];
    }

    public static function create(int $orgId, string $title = 'Formulir Pendaftaran', ?string $desc = null): int
    {
        $s = Database::connection()->prepare('INSERT INTO registration_forms (organization_id, title, description, is_active, created_at, updated_at) VALUES (:o, :t, :d, 0, NOW(), NOW())');
        $s->execute(['o' => $orgId, 't' => $title, 'd' => $desc]);
        return (int)Database::connection()->lastInsertId();
    }

    public static function activate(int $id, int $orgId): void
    {
        $pdo = Database::connection();
        $pdo->prepare('UPDATE registration_forms SET is_active = 0 WHERE organization_id = :o')->execute(['o' => $orgId]);
        $pdo->prepare('UPDATE registration_forms SET is_active = 1 WHERE id = :id AND organization_id = :o')->execute(['id' => $id, 'o' => $orgId]);
    }

    public static function update(int $id, int $orgId, string $title, ?string $desc, int $isActive): void
    {
        if ($isActive) self::activate($id, $orgId);
        else {
            $s = Database::connection()->prepare('UPDATE registration_forms SET title = :t, description = :d, is_active = 0, updated_at = NOW() WHERE id = :id AND organization_id = :o');
            $s->execute(['t' => $title, 'd' => $desc, 'id' => $id, 'o' => $orgId]);
        }
    }

    public static function delete(int $id, int $orgId): void
    {
        $s = Database::connection()->prepare('DELETE FROM registration_forms WHERE id = :id AND organization_id = :o');
        $s->execute(['id' => $id, 'o' => $orgId]);
    }
}
