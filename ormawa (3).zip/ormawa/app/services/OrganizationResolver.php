<?php
declare(strict_types=1);

final class OrganizationResolver {
    public static function resolve(string $uri): ?array {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $script = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '')), '/');
        if ($script && $script !== '/' && str_starts_with($path, $script)) {
            $path = substr($path, strlen($script)) ?: '/';
        }
        
        $path = trim($path, '/');
        $seg = $path ? explode('/', $path) : [];
        $candidate = $seg[0] ?? DEFAULT_ORGANIZATION_SLUG;

        $pdo = Database::connection();
        if ($candidate && !in_array($candidate, ['admin', 'public', 'assets', 'uploads'], true)) {
            $s = $pdo->prepare('SELECT * FROM organizations WHERE slug = :s AND status = "active" LIMIT 1');
            $s->execute(['s' => $candidate]);
            if ($o = $s->fetch()) {
                return $o;
            }
        }

        $s = $pdo->prepare('SELECT * FROM organizations WHERE slug = :s AND status = "active" LIMIT 1');
        $s->execute(['s' => DEFAULT_ORGANIZATION_SLUG]);
        if ($o = $s->fetch()) {
            return $o;
        }

        // A renamed or removed default slug must not take the public site offline.
        $fallback = $pdo->query('SELECT * FROM organizations WHERE status = "active" ORDER BY id ASC LIMIT 1');
        return $fallback ? ($fallback->fetch() ?: null) : null;
    }
}
