<?php
declare(strict_types=1);

final class PersonService {
    public static function createPerson(int $orgId, string $fullName, ?string $email = null, ?string $phone = null, ?int $photoMediaId = null): int {
        return PersonModel::save([
            'full_name' => $fullName,
            'email' => $email,
            'phone' => $phone,
            'photo_media_id' => $photoMediaId
        ], null, $orgId);
    }

    public static function getPerson(int $personId, int $orgId): ?array {
        return PersonModel::find($personId, $orgId);
    }

    public static function getPersonAssignments(int $personId, int $orgId): array {
        return PositionAssignmentModel::findByPerson($personId, $orgId);
    }

    public static function listPersons(int $orgId): array {
        return PersonModel::all($orgId);
    }

    public static function updatePerson(int $personId, int $orgId, array $data): void {
        PersonModel::save($data, $personId, $orgId);
    }
}
