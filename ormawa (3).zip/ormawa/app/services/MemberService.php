<?php
declare(strict_types=1);

final class MemberService
{
    /**
     * Migrate registration submissions to members table
     * This preserves legacy data while creating the new membership structure
     */
    public static function migrateRegistrationSubmissions(int $orgId, ?int $mappedBy = null): array
    {
        $pdo = Database::connection();
        $results = [
            'migrated' => 0,
            'skipped' => 0,
            'ambiguous' => 0,
            'errors' => 0,
            'details' => []
        ];

        // Get all registration submissions for the organization
        $submissions = $pdo->prepare('SELECT * FROM registration_submissions WHERE organization_id = :org ORDER BY created_at ASC');
        $submissions->execute(['org' => $orgId]);
        $submissions = $submissions->fetchAll();

        foreach ($submissions as $submission) {
            try {
                // Check if already mapped
                $checkMap = $pdo->prepare('SELECT id FROM registration_member_mapping WHERE registration_submission_id = :sid');
                $checkMap->execute(['sid' => $submission['id']]);
                if ($checkMap->fetch()) {
                    $results['skipped']++;
                    $results['details'][] = [
                        'submission_id' => $submission['id'],
                        'status' => 'already_mapped',
                        'message' => 'Submission already mapped to member'
                    ];
                    continue;
                }

                // Try to find or create person
                $personId = self::findOrCreatePerson($submission, $orgId);

                // Generate member number if not exists or if duplicate
                $memberNumber = $submission['member_number'] ?? '';
                if (empty($memberNumber)) {
                    $memberNumber = MemberModel::generateMemberNumber($orgId, $submission['batch_year'] ?? null);
                } else {
                    // Check if member_number already exists
                    $checkStmt = $pdo->prepare('SELECT COUNT(*) FROM members WHERE member_number = :mn');
                    $checkStmt->execute(['mn' => $memberNumber]);
                    if ((int)$checkStmt->fetchColumn() > 0) {
                        // Generate new member number if duplicate exists
                        $memberNumber = MemberModel::generateMemberNumber($orgId, $submission['batch_year'] ?? null);
                    }
                }

                // Determine status
                $status = $submission['status'] ?? 'pending';
                if (!in_array($status, ['pending', 'active', 'rejected', 'suspended', 'inactive', 'alumni'])) {
                    $status = 'pending';
                }

                // Create member record
                $memberData = [
                    'organization_id' => $orgId,
                    'person_id' => $personId,
                    'member_number' => $memberNumber,
                    'status' => $status,
                    'joined_at' => $submission['submitted_at'] ?? $submission['created_at'],
                    'current_term_id' => null, // Will be set by admin if needed
                    'batch_year' => $submission['batch_year'] ?? null,
                    'faculty_name' => $submission['faculty_name'] ?? null,
                    'prodi_name' => $submission['prodi_name'] ?? null,
                    'whatsapp' => $submission['whatsapp'] ?? null,
                ];

                if ($status === 'active' || $status === 'rejected') {
                    $memberData['reviewed_at'] = $submission['reviewed_at'] ?? null;
                    $memberData['reviewed_by'] = $submission['reviewed_by'] ?? null;
                    $memberData['reviewer_notes'] = $submission['reviewer_notes'] ?? null;
                }

                $memberId = MemberModel::create($memberData);

                // Create mapping record
                $mappingType = 'direct';
                $confidenceScore = 100;

                $mapSql = 'INSERT INTO registration_member_mapping (registration_submission_id, member_id, mapping_type, confidence_score, mapped_by, mapped_at) VALUES (:sid, :mid, :mt, :cs, :mb, NOW())';
                $mapStmt = $pdo->prepare($mapSql);
                $mapStmt->execute([
                    'sid' => $submission['id'],
                    'mid' => $memberId,
                    'mt' => $mappingType,
                    'cs' => $confidenceScore,
                    'mb' => $mappedBy
                ]);

                $results['migrated']++;
                $results['details'][] = [
                    'submission_id' => $submission['id'],
                    'member_id' => $memberId,
                    'person_id' => $personId,
                    'member_number' => $memberNumber,
                    'status' => 'migrated',
                    'message' => 'Successfully migrated'
                ];

            } catch (Exception $e) {
                $results['errors']++;
                $results['details'][] = [
                    'submission_id' => $submission['id'],
                    'status' => 'error',
                    'message' => $e->getMessage()
                ];
            }
        }

        return $results;
    }

    /**
     * Find existing person or create new one based on submission data
     */
    private static function findOrCreatePerson(array $submission, int $orgId): int
    {
        $pdo = Database::connection();
        $fullName = $submission['full_name'] ?? '';
        $email = null;
        $phone = $submission['whatsapp'] ?? null;

        // Try to get email from registration values
        $valueStmt = $pdo->prepare('SELECT value FROM registration_values WHERE submission_id = :sid AND field_type = "email" LIMIT 1');
        $valueStmt->execute(['sid' => $submission['id']]);
        $emailValue = $valueStmt->fetchColumn();
        if ($emailValue) {
            $email = $emailValue;
        }

        // Try to find existing person by email (most reliable)
        if ($email) {
            $personStmt = $pdo->prepare('SELECT id FROM persons WHERE organization_id = :org AND email = :email LIMIT 1');
            $personStmt->execute(['org' => $orgId, 'email' => $email]);
            $existingPerson = $personStmt->fetch();
            if ($existingPerson) {
                return (int)$existingPerson['id'];
            }
        }

        // Try to find existing person by full_name + phone (less reliable but better than name alone)
        if ($phone && $fullName) {
            $personStmt = $pdo->prepare('SELECT id FROM persons WHERE organization_id = :org AND full_name = :fn AND phone = :phone LIMIT 1');
            $personStmt->execute(['org' => $orgId, 'fn' => $fullName, 'phone' => $phone]);
            $existingPerson = $personStmt->fetch();
            if ($existingPerson) {
                return (int)$existingPerson['id'];
            }
        }

        // Create new person
        $personData = [
            'organization_id' => $orgId,
            'full_name' => $fullName ?: 'Unknown',
            'email' => $email,
            'phone' => $phone,
            'photo_media_id' => null
        ];

        // Try to get photo from registration values
        $photoStmt = $pdo->prepare('SELECT file_path FROM registration_values WHERE submission_id = :sid AND field_type = "file_image" LIMIT 1');
        $photoStmt->execute(['sid' => $submission['id']]);
        $photoPath = $photoStmt->fetchColumn();
        if ($photoPath) {
            // For now, just store the path - could be migrated to media table later
            $personData['photo_media_id'] = null;
        }

        return PersonModel::save($personData, null, $orgId);
    }

    /**
     * Get member statistics for an organization
     */
    public static function getStatistics(int $orgId): array
    {
        $pdo = Database::connection();

        $stats = [
            'total' => 0,
            'pending' => 0,
            'active' => 0,
            'rejected' => 0,
            'suspended' => 0,
            'inactive' => 0,
            'alumni' => 0,
            'by_batch' => []
        ];

        // Count by status
        $statusStmt = $pdo->prepare('SELECT status, COUNT(*) as count FROM members WHERE organization_id = :org GROUP BY status');
        $statusStmt->execute(['org' => $orgId]);
        $statusResults = $statusStmt->fetchAll();

        foreach ($statusResults as $row) {
            $stats[$row['status']] = (int)$row['count'];
            $stats['total'] += (int)$row['count'];
        }

        // Count by batch
        $batchStmt = $pdo->prepare('SELECT batch_year, COUNT(*) as count FROM members WHERE organization_id = :org AND batch_year IS NOT NULL GROUP BY batch_year ORDER BY batch_year DESC');
        $batchStmt->execute(['org' => $orgId]);
        $batchResults = $batchStmt->fetchAll();

        foreach ($batchResults as $row) {
            $stats['by_batch'][$row['batch_year']] = (int)$row['count'];
        }

        return $stats;
    }

    /**
     * Get member with related data (person, assignments, etc.)
     */
    public static function getMemberWithDetails(int $memberId, int $orgId): ?array
    {
        $member = MemberModel::find($memberId, $orgId);
        if (!$member) {
            return null;
        }

        // Get person details
        $person = null;
        if ($member['person_id']) {
            $person = PersonModel::find((int)$member['person_id'], $orgId);
        }

        // Get position assignments if person exists
        $assignments = [];
        if ($person) {
            $assignStmt = Database::connection()->prepare('
                SELECT pa.*, p.title as position_title, g.name as group_name, t.name as term_name
                FROM position_assignments pa
                JOIN positions p ON p.id = pa.position_id
                JOIN structure_groups g ON g.id = p.group_id
                LEFT JOIN organization_terms t ON t.id = pa.term_id
                WHERE pa.person_id = :pid AND pa.organization_id = :org
                ORDER BY pa.created_at DESC
            ');
            $assignStmt->execute(['pid' => $person['id'], 'org' => $orgId]);
            $assignments = $assignStmt->fetchAll();
        }

        // Get audit history
        $auditHistory = MemberModel::getAuditHistory($memberId);

        return [
            'member' => $member,
            'person' => $person,
            'assignments' => $assignments,
            'audit_history' => $auditHistory
        ];
    }

    /**
     * Update member status with audit trail
     */
    public static function updateStatus(int $memberId, int $orgId, string $newStatus, int $userId, ?string $notes = null): void
    {
        $member = MemberModel::find($memberId, $orgId);
        if (!$member) {
            throw new Exception('Member not found');
        }

        $oldStatus = $member['status'];

        switch ($newStatus) {
            case 'active':
                MemberModel::approve($memberId, $orgId, $userId, $notes);
                break;
            case 'rejected':
                MemberModel::reject($memberId, $orgId, $userId, $notes);
                break;
            case 'suspended':
                MemberModel::suspend($memberId, $orgId, $userId, $notes);
                break;
            default:
                // For other status changes, directly update
                MemberModel::addAudit($memberId, $oldStatus, $newStatus, $userId, $notes);
                MemberModel::update($memberId, $orgId, ['status' => $newStatus]);
                break;
        }
    }

    /**
     * Search members across organizations
     */
    public static function search(int $orgId, string $query, ?string $status = null, ?string $batch = null): array
    {
        $sql = 'SELECT m.*, p.full_name, p.email, p.phone FROM members m LEFT JOIN persons p ON p.id = m.person_id WHERE m.organization_id = :org';
        $params = ['org' => $orgId];

        if ($query) {
            $sql .= ' AND (m.member_number LIKE :q OR p.full_name LIKE :q OR p.email LIKE :q OR m.faculty_name LIKE :q OR m.prodi_name LIKE :q)';
            $params['q'] = '%' . $query . '%';
        }

        if ($status) {
            $sql .= ' AND m.status = :st';
            $params['st'] = $status;
        }

        if ($batch) {
            $sql .= ' AND m.batch_year = :by';
            $params['by'] = $batch;
        }

        $sql .= ' ORDER BY m.created_at DESC';

        $s = Database::connection()->prepare($sql);
        $s->execute($params);
        return $s->fetchAll() ?: [];
    }
}
