<?php
declare(strict_types=1);

final class LegacyStructureMigrationService {

    /**
     * Run legacy structure data migration.
     * 
     * @param bool $dryRun If true, rollback all changes after generating report.
     * @param int|null $targetOrgId Optional org filter.
     * @return array Migration report data.
     */
    public static function runMigration(bool $dryRun = true, ?int $targetOrgId = null): array {
        $pdo = Database::connection();

        $report = [
            'dry_run' => $dryRun,
            'total_legacy_records' => 0,
            'already_migrated_records' => 0,
            'to_create' => [
                'terms' => 0,
                'groups' => 0,
                'positions' => 0,
                'persons' => 0,
                'assignments' => 0,
            ],
            'created_entities' => [
                'terms' => [],
                'groups' => [],
                'positions' => [],
                'persons' => [],
                'assignments' => [],
            ],
            'ambiguous_persons' => [],
            'unmapped_terms' => [],
            'missing_media' => [],
            'errors' => [],
            'mapped_records' => []
        ];

        $pdo->beginTransaction();

        try {
            // 1. Fetch legacy positions
            $sql = 'SELECT * FROM organization_positions';
            $params = [];
            if ($targetOrgId !== null) {
                $sql .= ' WHERE organization_id = :org';
                $params['org'] = $targetOrgId;
            }
            $sql .= ' ORDER BY parent_id IS NULL DESC, parent_id, sort_order, id';
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $legacyPositions = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $report['total_legacy_records'] = count($legacyPositions);

            // Caches to track created/found IDs during run
            $termCache = [];       // [orgId_slug => termId]
            $groupCache = [];      // [orgId_name => groupId]
            $positionCache = [];   // [orgId_groupId_title => positionId]
            $personCache = [];     // [orgId_name => personId]

            foreach ($legacyPositions as $legacy) {
                $legacyId = (int)$legacy['id'];
                $orgId = (int)$legacy['organization_id'];

                // Check if already mapped in legacy_structure_mappings
                $mapCheck = $pdo->prepare('SELECT * FROM legacy_structure_mappings WHERE legacy_position_id = :lid');
                $mapCheck->execute(['lid' => $legacyId]);
                $existingMap = $mapCheck->fetch(PDO::FETCH_ASSOC);

                if ($existingMap) {
                    $report['already_migrated_records']++;
                    $report['mapped_records'][] = [
                        'legacy_id' => $legacyId,
                        'status' => 'already_migrated',
                        'mapping_id' => $existingMap['id']
                    ];
                    continue;
                }

                // --- 2. Handle Term ---
                $rawPeriod = trim((string)($legacy['period'] ?? ''));
                $termId = null;

                if (empty($rawPeriod)) {
                    $report['unmapped_terms'][] = [
                        'legacy_id' => $legacyId,
                        'position_name' => $legacy['position_name'],
                        'reason' => 'Period column is NULL or empty'
                    ];
                    // Create/Find Unmapped Legacy Period
                    $termSlug = 'unmapped-legacy-term';
                    $termKey = $orgId . '_' . $termSlug;
                    if (!isset($termCache[$termKey])) {
                        $existingTerm = TermModel::findBySlug($termSlug, $orgId);
                        if ($existingTerm) {
                            $termCache[$termKey] = (int)$existingTerm['id'];
                        } else {
                            $termIdNew = TermModel::save([
                                'name' => 'Unmapped Legacy Term',
                                'slug' => $termSlug,
                                'start_date' => '2000-01-01',
                                'end_date' => null
                            ], null, $orgId);
                            $termCache[$termKey] = $termIdNew;
                            $report['to_create']['terms']++;
                            $report['created_entities']['terms'][] = "Unmapped Legacy Term (ID: {$termIdNew})";
                        }
                    }
                    $termId = $termCache[$termKey];
                } else {
                    // Parse period e.g., "2026/2027" or "2026-2027" or "2026"
                    $normalizedPeriod = str_replace('/', '-', $rawPeriod);
                    if (preg_match('/^(\d{4})[-\/]?(\d{4})?$/', $rawPeriod, $matches)) {
                        $startYear = $matches[1];
                        $endYear = !empty($matches[2]) ? $matches[2] : $startYear;
                        $termSlug = "{$startYear}-{$endYear}";
                        $termName = "Periode {$startYear}/{$endYear}";
                        $startDate = "{$startYear}-01-01";
                        $endDate = "{$endYear}-12-31";

                        $termKey = $orgId . '_' . $termSlug;
                        if (!isset($termCache[$termKey])) {
                            $existingTerm = TermModel::findBySlug($termSlug, $orgId);
                            if ($existingTerm) {
                                $termCache[$termKey] = (int)$existingTerm['id'];
                            } else {
                                $termIdNew = TermModel::save([
                                    'name' => $termName,
                                    'slug' => $termSlug,
                                    'start_date' => $startDate,
                                    'end_date' => $endDate
                                ], null, $orgId);
                                $termCache[$termKey] = $termIdNew;
                                $report['to_create']['terms']++;
                                $report['created_entities']['terms'][] = "{$termName} (ID: {$termIdNew})";
                            }
                        }
                        $termId = $termCache[$termKey];
                    } else {
                        // Unparseable period format
                        $report['unmapped_terms'][] = [
                            'legacy_id' => $legacyId,
                            'position_name' => $legacy['position_name'],
                            'reason' => "Unparseable period format: '{$rawPeriod}'"
                        ];
                        $termSlug = 'unmapped-period-' . preg_replace('/[^a-z0-9]/i', '-', strtolower($rawPeriod));
                        $termKey = $orgId . '_' . $termSlug;
                        if (!isset($termCache[$termKey])) {
                            $existingTerm = TermModel::findBySlug($termSlug, $orgId);
                            if ($existingTerm) {
                                $termCache[$termKey] = (int)$existingTerm['id'];
                            } else {
                                $termIdNew = TermModel::save([
                                    'name' => "Periode Legacy ({$rawPeriod})",
                                    'slug' => $termSlug,
                                    'start_date' => '2000-01-01',
                                    'end_date' => null
                                ], null, $orgId);
                                $termCache[$termKey] = $termIdNew;
                                $report['to_create']['terms']++;
                                $report['created_entities']['terms'][] = "Periode Legacy ({$rawPeriod}) (ID: {$termIdNew})";
                            }
                        }
                        $termId = $termCache[$termKey];
                    }
                }

                // --- 3. Handle Group & Position ---
                $posName = trim($legacy['position_name']);
                $parentId = $legacy['parent_id'] !== null ? (int)$legacy['parent_id'] : null;

                // Determine appropriate group name based on position name and parent
                if (mb_stripos($posName, 'Pembina') !== false || mb_stripos($posName, 'Pembimbing') !== false) {
                    $groupName = 'Pembina / Pembimbing';
                } elseif (in_array(mb_strtolower($posName), ['ketua', 'ketua umum', 'wakil ketua', 'sekretaris', 'bendahara', 'bendahara umum', 'sekretaris umum'])) {
                    $groupName = 'Badan Pengurus Harian (BPH)';
                } else {
                    $groupName = 'Divisi / Departemen';
                }

                $groupKey = $orgId . '_' . mb_strtolower($groupName);
                if (!isset($groupCache[$groupKey])) {
                    // Check if group already exists
                    $existingGroupStmt = $pdo->prepare('SELECT * FROM structure_groups WHERE organization_id = :org AND LOWER(name) = :name');
                    $existingGroupStmt->execute(['org' => $orgId, 'name' => mb_strtolower($groupName)]);
                    $existingGroup = $existingGroupStmt->fetch(PDO::FETCH_ASSOC);

                    if ($existingGroup) {
                        $groupCache[$groupKey] = (int)$existingGroup['id'];
                    } else {
                        $groupIdNew = StructureGroupModel::save([
                            'name' => $groupName,
                            'description' => 'Migrated from legacy organization_positions',
                            'parent_id' => null,
                            'sort_order' => count($groupCache) + 1
                        ], null, $orgId);
                        $groupCache[$groupKey] = $groupIdNew;
                        $report['to_create']['groups']++;
                        $report['created_entities']['groups'][] = "{$groupName} (ID: {$groupIdNew})";
                    }
                }
                $groupId = $groupCache[$groupKey];

                // Position within Group
                $posTitle = $posName;
                $posKey = $orgId . '_' . $groupId . '_' . mb_strtolower($posTitle);
                if (!isset($positionCache[$posKey])) {
                    $existingPosStmt = $pdo->prepare('SELECT * FROM positions WHERE organization_id = :org AND group_id = :group AND LOWER(title) = :title');
                    $existingPosStmt->execute(['org' => $orgId, 'group' => $groupId, 'title' => mb_strtolower($posTitle)]);
                    $existingPos = $existingPosStmt->fetch(PDO::FETCH_ASSOC);

                    if ($existingPos) {
                        $positionCache[$posKey] = (int)$existingPos['id'];
                    } else {
                        $posIdNew = StructurePositionModel::save([
                            'group_id' => $groupId,
                            'title' => $posTitle,
                            'description' => $legacy['description'] ?? null,
                            'sort_order' => (int)($legacy['sort_order'] ?? 0)
                        ], null, $orgId);
                        $positionCache[$posKey] = $posIdNew;
                        $report['to_create']['positions']++;
                        $report['created_entities']['positions'][] = "{$posTitle} (ID: {$posIdNew})";
                    }
                }
                $positionId = $positionCache[$posKey];

                // --- 4. Handle Person & Photo ---
                $personName = trim((string)($legacy['person_name'] ?? ''));
                $personId = null;

                if (!empty($personName)) {
                    // Check duplicate / ambiguous names
                    $personStmt = $pdo->prepare('SELECT * FROM persons WHERE organization_id = :org AND LOWER(full_name) = :name');
                    $personStmt->execute(['org' => $orgId, 'name' => mb_strtolower($personName)]);
                    $matchingPersons = $personStmt->fetchAll(PDO::FETCH_ASSOC);

                    if (count($matchingPersons) > 1) {
                        $report['ambiguous_persons'][] = [
                            'legacy_id' => $legacyId,
                            'person_name' => $personName,
                            'matches_count' => count($matchingPersons),
                            'matched_ids' => array_column($matchingPersons, 'id')
                        ];
                    }

                    // Photo check & media linking
                    $photoPath = trim((string)($legacy['photo'] ?? ''));
                    $photoMediaId = null;

                    if (!empty($photoPath)) {
                        $absolutePhotoPath = BASE_PATH . '/' . ltrim($photoPath, '/');
                        $publicPhotoPath = BASE_PATH . '/public/' . ltrim($photoPath, '/');

                        if (file_exists($absolutePhotoPath) || file_exists($publicPhotoPath)) {
                            // Find or create media record
                            $mediaStmt = $pdo->prepare('SELECT id FROM media WHERE organization_id = :org AND file_path = :path');
                            $mediaStmt->execute(['org' => $orgId, 'path' => $photoPath]);
                            $existingMedia = $mediaStmt->fetch(PDO::FETCH_ASSOC);

                            if ($existingMedia) {
                                $photoMediaId = (int)$existingMedia['id'];
                            } else {
                                $insertMedia = $pdo->prepare('INSERT INTO media (organization_id, category, file_name, file_path, file_size, mime_type, created_at) VALUES (:org, "person_photo", :fname, :fpath, 0, "image/jpeg", NOW())');
                                $insertMedia->execute([
                                    'org' => $orgId,
                                    'fname' => basename($photoPath),
                                    'fpath' => $photoPath
                                ]);
                                $photoMediaId = (int)$pdo->lastInsertId();
                            }
                        } else {
                            $report['missing_media'][] = [
                                'legacy_id' => $legacyId,
                                'person_name' => $personName,
                                'photo_path' => $photoPath
                            ];
                        }
                    }

                    $personKey = $orgId . '_' . mb_strtolower($personName);
                    if (!isset($personCache[$personKey])) {
                        if (!empty($matchingPersons)) {
                            $personId = (int)$matchingPersons[0]['id'];
                        } else {
                            $personIdNew = PersonModel::save([
                                'full_name' => $personName,
                                'email' => null,
                                'phone' => null,
                                'photo_media_id' => $photoMediaId
                            ], null, $orgId);
                            $personCache[$personKey] = $personIdNew;
                            $report['to_create']['persons']++;
                            $report['created_entities']['persons'][] = "{$personName} (ID: {$personIdNew})";
                            $personId = $personIdNew;
                        }
                    } else {
                        $personId = $personCache[$personKey];
                    }
                }

                // --- 5. Handle Assignment ---
                $status = !empty($legacy['status']) ? strtolower($legacy['status']) : 'active';
                if ($personId === null) {
                    $status = 'vacant';
                }

                $assignmentId = PositionAssignmentModel::save([
                    'term_id' => $termId,
                    'position_id' => $positionId,
                    'person_id' => $personId,
                    'start_date' => '2026-01-01',
                    'end_date' => null,
                    'status' => $status
                ], null, $orgId);

                $report['to_create']['assignments']++;
                $report['created_entities']['assignments'][] = "Legacy #{$legacyId} -> Assignment ID: {$assignmentId} (Position: {$posTitle}, Person: " . ($personName ?: 'VACANT') . ")";

                // --- 6. Record Mapping Metadata ---
                $mapStmt = $pdo->prepare('INSERT INTO legacy_structure_mappings (organization_id, legacy_position_id, term_id, group_id, position_id, person_id, assignment_id, status, notes, created_at, updated_at) VALUES (:org, :lid, :tid, :gid, :pid, :perid, :aid, "migrated", :notes, NOW(), NOW())');
                $mapStmt->execute([
                    'org' => $orgId,
                    'lid' => $legacyId,
                    'tid' => $termId,
                    'gid' => $groupId,
                    'pid' => $positionId,
                    'perid' => $personId,
                    'aid' => $assignmentId,
                    'notes' => 'Migrated automatically via LegacyStructureMigrationService'
                ]);

                $report['mapped_records'][] = [
                    'legacy_id' => $legacyId,
                    'term_id' => $termId,
                    'group_id' => $groupId,
                    'position_id' => $positionId,
                    'person_id' => $personId,
                    'assignment_id' => $assignmentId,
                    'status' => 'migrated'
                ];
            }

            if ($dryRun) {
                $pdo->rollBack();
            } else {
                $pdo->commit();
            }

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $report['errors'][] = $e->getMessage();
        }

        return $report;
    }

    /**
     * Format migration report array as clean CLI/Markdown text.
     */
    public static function formatReportText(array $report): string {
        $out = [];
        $mode = $report['dry_run'] ? 'DRY RUN (No changes committed)' : 'REAL EXECUTION (Changes committed)';
        $out[] = "=================================================";
        $out[] = " LEGACY STRUCTURE DATA MIGRATION REPORT";
        $out[] = " Mode: {$mode}";
        $out[] = "=================================================";
        $out[] = "Total Legacy Records Evaluated : {$report['total_legacy_records']}";
        $out[] = "Already Migrated Records       : {$report['already_migrated_records']}";
        $out[] = "";
        $out[] = "--- Summary of Entities to Create ---";
        $out[] = " Terms       : {$report['to_create']['terms']}";
        $out[] = " Groups      : {$report['to_create']['groups']}";
        $out[] = " Positions   : {$report['to_create']['positions']}";
        $out[] = " Persons     : {$report['to_create']['persons']}";
        $out[] = " Assignments : {$report['to_create']['assignments']}";
        $out[] = "";

        if (!empty($report['created_entities']['terms'])) {
            $out[] = "--- Terms Created ---";
            foreach ($report['created_entities']['terms'] as $item) {
                $out[] = " + {$item}";
            }
            $out[] = "";
        }

        if (!empty($report['created_entities']['groups'])) {
            $out[] = "--- Groups Created ---";
            foreach ($report['created_entities']['groups'] as $item) {
                $out[] = " + {$item}";
            }
            $out[] = "";
        }

        if (!empty($report['created_entities']['positions'])) {
            $out[] = "--- Positions Created ---";
            foreach ($report['created_entities']['positions'] as $item) {
                $out[] = " + {$item}";
            }
            $out[] = "";
        }

        if (!empty($report['created_entities']['persons'])) {
            $out[] = "--- Persons Created ---";
            foreach ($report['created_entities']['persons'] as $item) {
                $out[] = " + {$item}";
            }
            $out[] = "";
        }

        if (!empty($report['ambiguous_persons'])) {
            $out[] = "--- Ambiguous Persons (Warnings) ---";
            foreach ($report['ambiguous_persons'] as $item) {
                $out[] = " ! Legacy #{$item['legacy_id']}: Name '{$item['person_name']}' matches {$item['matches_count']} existing person rows.";
            }
            $out[] = "";
        }

        if (!empty($report['unmapped_terms'])) {
            $out[] = "--- Unmapped Terms ---";
            foreach ($report['unmapped_terms'] as $item) {
                $out[] = " ! Legacy #{$item['legacy_id']} ('{$item['position_name']}'): {$item['reason']}";
            }
            $out[] = "";
        }

        if (!empty($report['missing_media'])) {
            $out[] = "--- Missing / Invalid Media ---";
            foreach ($report['missing_media'] as $item) {
                $out[] = " ! Legacy #{$item['legacy_id']} ('{$item['person_name']}'): Photo file '{$item['photo_path']}' not found on disk.";
            }
            $out[] = "";
        }

        if (!empty($report['errors'])) {
            $out[] = "--- Errors ---";
            foreach ($report['errors'] as $err) {
                $out[] = " ERROR: {$err}";
            }
            $out[] = "";
        }

        return implode("\n", $out);
    }
}
