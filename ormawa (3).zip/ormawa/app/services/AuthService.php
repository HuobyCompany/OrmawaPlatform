<?php
declare(strict_types=1);

/**
 * AuthService - Unified Authentication Foundation
 * 
 * Provides a single authentication architecture that supports:
 * - super_admin
 * - organization_admin
 * - editor/pengurus
 * - member
 * 
 * Handles session management, role resolution, and user↔person/member relationships.
 */
final class AuthService
{
    private const SESSION_KEY = 'auth_user';
    private const SESSION_TIMEOUT = 3600; // 1 hour
    private const REMEMBER_COOKIE_NAME = 'ormawa_auth_token';
    private const REMEMBER_COOKIE_DAYS = 30;

    /**
     * Authenticate a user with email/username and password
     * 
     * @param string $identifier Email or username
     * @param string $password Plain text password
     * @return array|null User data if authenticated, null otherwise
     */
    public static function authenticate(string $identifier, string $password): ?array
    {
        // Rate limiting check
        self::checkRateLimit($identifier);

        $pdo = Database::connection();
        
        // Try to find user by email
        $stmt = $pdo->prepare('SELECT u.*, o.name organization_name, o.slug organization_slug 
                              FROM users u 
                              LEFT JOIN organizations o ON o.id = u.organization_id 
                              WHERE u.email = :email AND u.status = "active" 
                              LIMIT 1');
        $stmt->execute(['email' => $identifier]);
        $user = $stmt->fetch();

        if (!$user) {
            self::recordFailedAttempt($identifier);
            return null;
        }

        // Verify password
        if (!password_verify($password, $user['password'])) {
            self::recordFailedAttempt($identifier);
            return null;
        }

        // Clear failed attempts
        self::clearFailedAttempts($identifier);

        // Update last login
        UserModel::touchLogin((int)$user['id']);

        // Load user relationships (person/member)
        $user['person'] = self::loadUserPerson((int)$user['id']);
        $user['member'] = self::loadUserMember((int)$user['id'], $user['organization_id']);

        return $user;
    }

    /**
     * Create session for authenticated user
     * 
     * @param array $user User data
     * @param bool $remember Whether to set remember-me cookie
     */
    public static function createSession(array $user, bool $remember = false): void
    {
        // Regenerate session ID for security
        session_regenerate_id(true);

        // Set session data
        $_SESSION[self::SESSION_KEY] = [
            'id' => (int)$user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
            'organization_id' => $user['organization_id'] ? (int)$user['organization_id'] : null,
            'organization_name' => $user['organization_name'] ?? null,
            'organization_slug' => $user['organization_slug'] ?? null,
            'person_id' => $user['person']['id'] ?? null,
            'member_id' => $user['member']['id'] ?? null,
            'member_number' => $user['member']['member_number'] ?? null,
            'authenticated_at' => time(),
            'last_activity' => time()
        ];

        // Set organization context
        if ($user['organization_id']) {
            set_selected_organization((int)$user['organization_id']);
        }

        // Set remember-me cookie if requested
        if ($remember) {
            self::setRememberCookie((int)$user['id']);
        }

        // Log activity
        ActivityLogModel::add(
            $user['organization_id'] ? (int)$user['organization_id'] : null,
            (int)$user['id'],
            'login',
            'auth',
            'Login user ' . $user['name']
        );
    }

    /**
     * Get current authenticated user from session
     * 
     * @return array|null User data or null if not authenticated
     */
    public static function currentUser(): ?array
    {
        if (!isset($_SESSION[self::SESSION_KEY])) {
            return null;
        }

        $session = $_SESSION[self::SESSION_KEY];

        // Check session timeout
        if (time() - $session['last_activity'] > self::SESSION_TIMEOUT) {
            self::destroySession();
            return null;
        }

        // Update last activity
        $session['last_activity'] = time();
        $_SESSION[self::SESSION_KEY] = $session;

        return $session;
    }

    /**
     * Check if user is authenticated
     * 
     * @return bool True if authenticated
     */
    public static function isAuthenticated(): bool
    {
        return self::currentUser() !== null;
    }

    /**
     * Check if user has specific role
     * 
     * @param array $roles Array of allowed roles
     * @return bool True if user has one of the roles
     */
    public static function hasRole(array $roles): bool
    {
        $user = self::currentUser();
        if (!$user) {
            return false;
        }

        return in_array($user['role'], $roles, true);
    }

    /**
     * Check if user has specific permission
     * 
     * @param string $permission Permission name
     * @return bool True if user has permission
     */
    public static function can(string $permission): bool
    {
        $user = self::currentUser();
        if (!$user) {
            return false;
        }

        // Super admin has all permissions
        if ($user['role'] === 'super_admin') {
            return true;
        }

        // Permission mapping
        $permissionMap = [
            'manage_settings' => ['organization_admin'],
            'manage_users' => ['organization_admin'],
            'manage_content' => ['organization_admin', 'editor'],
            'manage_members' => ['organization_admin', 'editor'],
            'manage_structure' => ['organization_admin', 'editor'],
            'approve_members' => ['organization_admin'],
            'view_analytics' => ['organization_admin', 'editor'],
            'view_member_area' => ['member']
        ];

        $allowedRoles = $permissionMap[$permission] ?? [];
        return in_array($user['role'], $allowedRoles, true);
    }

    /**
     * Check if user is member of specific organization
     * 
     * @param int $organizationId Organization ID
     * @return bool True if user is member
     */
    public static function isMemberOf(int $organizationId): bool
    {
        $user = self::currentUser();
        if (!$user) {
            return false;
        }

        return $user['organization_id'] === $organizationId;
    }

    /**
     * Get user's member data
     * 
     * @return array|null Member data or null if not a member
     */
    public static function getMemberData(): ?array
    {
        $user = self::currentUser();
        if (!$user || !$user['member_id']) {
            return null;
        }

        $pdo = Database::connection();
        $stmt = $pdo->prepare('SELECT m.*, p.full_name, p.email, p.phone 
                              FROM members m 
                              LEFT JOIN persons p ON p.id = m.person_id 
                              WHERE m.id = :id AND m.status = "active"');
        $stmt->execute(['id' => $user['member_id']]);
        return $stmt->fetch() ?: null;
    }

    /**
     * Destroy current session
     */
    public static function destroySession(): void
    {
        $user = self::currentUser();
        
        // Log logout if user was authenticated
        if ($user) {
            ActivityLogModel::add(
                $user['organization_id'] ?? null,
                $user['id'],
                'logout',
                'auth',
                'Logout user ' . $user['name']
            );
        }

        // Clear session
        unset($_SESSION[self::SESSION_KEY]);
        
        // Clear remember-me cookie
        self::clearRememberCookie();

        // Regenerate session ID for security
        session_regenerate_id(true);
        
        // Clear organization context
        $_SESSION['selected_organization_id'] = null;
    }

    /**
     * Link user to a member
     * 
     * @param int $userId User ID
     * @param int $memberId Member ID
     * @param int|null $linkedBy User ID who created the link
     * @return bool True if successful
     */
    public static function linkUserToMember(int $userId, int $memberId, ?int $linkedBy = null): bool
    {
        $pdo = Database::connection();
        
        try {
            $stmt = $pdo->prepare('INSERT INTO user_account_members 
                                  (user_id, member_id, is_primary, linked_by, created_at, updated_at) 
                                  VALUES (:user_id, :member_id, TRUE, :linked_by, NOW(), NOW())');
            $stmt->execute([
                'user_id' => $userId,
                'member_id' => $memberId,
                'linked_by' => $linkedBy
            ]);
            return true;
        } catch (PDOException $e) {
            // Duplicate entry or other error
            return false;
        }
    }

    /**
     * Link user to a person
     * 
     * @param int $userId User ID
     * @param int $personId Person ID
     * @param int|null $linkedBy User ID who created the link
     * @return bool True if successful
     */
    public static function linkUserToPerson(int $userId, int $personId, ?int $linkedBy = null): bool
    {
        $pdo = Database::connection();
        
        try {
            $stmt = $pdo->prepare('INSERT INTO user_account_members 
                                  (user_id, person_id, is_primary, linked_by, created_at, updated_at) 
                                  VALUES (:user_id, :person_id, TRUE, :linked_by, NOW(), NOW())');
            $stmt->execute([
                'user_id' => $userId,
                'person_id' => $personId,
                'linked_by' => $linkedBy
            ]);
            return true;
        } catch (PDOException $e) {
            // Duplicate entry or other error
            return false;
        }
    }

    /**
     * Load user's person relationship
     * 
     * @param int $userId User ID
     * @return array|null Person data or null
     */
    private static function loadUserPerson(int $userId): ?array
    {
        $pdo = Database::connection();
        
        // First check direct link via user_account_members
        $stmt = $pdo->prepare('SELECT p.* FROM persons p 
                              INNER JOIN user_account_members uam ON uam.person_id = p.id 
                              WHERE uam.user_id = :user_id AND uam.is_primary = TRUE 
                              LIMIT 1');
        $stmt->execute(['user_id' => $userId]);
        $person = $stmt->fetch();
        
        if ($person) {
            return $person;
        }

        // Fallback: check if user has member relationship
        $stmt = $pdo->prepare('SELECT p.* FROM persons p 
                              INNER JOIN members m ON m.person_id = p.id 
                              INNER JOIN user_account_members uam ON uam.member_id = m.id 
                              WHERE uam.user_id = :user_id AND uam.is_primary = TRUE 
                              LIMIT 1');
        $stmt->execute(['user_id' => $userId]);
        return $stmt->fetch() ?: null;
    }

    /**
     * Load user's member relationship
     * 
     * @param int $userId User ID
     * @param int|null $organizationId Organization ID
     * @return array|null Member data or null
     */
    private static function loadUserMember(int $userId, ?int $organizationId): ?array
    {
        $pdo = Database::connection();
        
        $sql = 'SELECT m.* FROM members m 
                INNER JOIN user_account_members uam ON uam.member_id = m.id 
                WHERE uam.user_id = :user_id AND uam.is_primary = TRUE';
        
        $params = ['user_id' => $userId];
        
        // If organization is specified, filter by it
        if ($organizationId) {
            $sql .= ' AND m.organization_id = :org_id';
            $params['org_id'] = $organizationId;
        }
        
        $sql .= ' LIMIT 1';
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch() ?: null;
    }

    /**
     * Set remember-me cookie
     * 
     * @param int $userId User ID
     */
    private static function setRememberCookie(int $userId): void
    {
        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $expiry = time() + (self::REMEMBER_COOKIE_DAYS * 86400);
        
        $pdo = Database::connection();
        $stmt = $pdo->prepare('UPDATE users SET remember_token = :token WHERE id = :id');
        $stmt->execute(['token' => $tokenHash, 'id' => $userId]);
        
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
                   (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
        
        setcookie(
            self::REMEMBER_COOKIE_NAME,
            $token,
            $expiry,
            '/',
            '',
            $isHttps,
            true
        );
    }

    /**
     * Clear remember-me cookie
     */
    private static function clearRememberCookie(): void
    {
        setcookie(
            self::REMEMBER_COOKIE_NAME,
            '',
            time() - 3600,
            '/',
            '',
            false,
            true
        );
    }

    /**
     * Check rate limit for login attempts
     * 
     * @param string $identifier Email or username
     * @throws RuntimeException If rate limit exceeded
     */
    private static function checkRateLimit(string $identifier): void
    {
        $key = 'auth_attempts_' . md5($identifier);
        $now = time();
        $attempts = $_SESSION[$key] ?? [];
        
        // Filter attempts older than 15 minutes
        $attempts = array_filter($attempts, fn($t) => $now - (int)$t < 900);
        
        if (count($attempts) >= 5) {
            throw new RuntimeException('Terlalu banyak percobaan login. Coba lagi dalam 15 menit.');
        }
    }

    /**
     * Record failed login attempt
     * 
     * @param string $identifier Email or username
     */
    private static function recordFailedAttempt(string $identifier): void
    {
        $key = 'auth_attempts_' . md5($identifier);
        $now = time();
        $attempts = $_SESSION[$key] ?? [];
        
        // Filter attempts older than 15 minutes
        $attempts = array_filter($attempts, fn($t) => $now - (int)$t < 900);
        
        // Add new attempt
        $attempts[] = $now;
        
        // Keep only last 10 attempts
        $_SESSION[$key] = array_slice($attempts, -10);
    }

    /**
     * Clear failed login attempts
     * 
     * @param string $identifier Email or username
     */
    private static function clearFailedAttempts(string $identifier): void
    {
        unset($_SESSION['auth_attempts_' . md5($identifier)]);
    }

    /**
     * Try to authenticate user from remember-me cookie
     * 
     * @return array|null User data if successful, null otherwise
     */
    public static function authenticateFromCookie(): ?array
    {
        if (!isset($_COOKIE[self::REMEMBER_COOKIE_NAME])) {
            return null;
        }

        $token = $_COOKIE[self::REMEMBER_COOKIE_NAME];
        $tokenHash = hash('sha256', $token);
        
        $pdo = Database::connection();
        $stmt = $pdo->prepare('SELECT u.*, o.name organization_name, o.slug organization_slug 
                              FROM users u 
                              LEFT JOIN organizations o ON o.id = u.organization_id 
                              WHERE u.remember_token = :token AND u.status = "active" 
                              LIMIT 1');
        $stmt->execute(['token' => $tokenHash]);
        $user = $stmt->fetch();

        if (!$user) {
            // Invalid token, clear cookie
            self::clearRememberCookie();
            return null;
        }

        // Load relationships
        $user['person'] = self::loadUserPerson((int)$user['id']);
        $user['member'] = self::loadUserMember((int)$user['id'], $user['organization_id']);

        // Create session
        self::createSession($user, true);

        return $user;
    }
}
