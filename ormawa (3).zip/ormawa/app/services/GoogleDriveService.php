<?php
declare(strict_types=1);

final class GoogleDriveService
{
    private string $clientId;
    private string $clientSecret;
    private string $refreshToken;
    private string $accessToken = '';

    public function __construct()
    {
        $this->clientId = (string) (defined('GOOGLE_DRIVE_CLIENT_ID') ? GOOGLE_DRIVE_CLIENT_ID : '');
        $this->clientSecret = (string) (defined('GOOGLE_DRIVE_CLIENT_SECRET') ? GOOGLE_DRIVE_CLIENT_SECRET : '');
        $this->refreshToken = (string) (defined('GOOGLE_DRIVE_REFRESH_TOKEN') ? GOOGLE_DRIVE_REFRESH_TOKEN : '');

        if ($this->clientId === '' || $this->clientSecret === '' || $this->refreshToken === '') {
            throw new RuntimeException('Konfigurasi Google Drive API belum lengkap pada server. Pastikan Client ID, Client Secret, dan Refresh Token terkonfigurasi.');
        }
    }

    private function getAccessToken(): string
    {
        if (!empty($this->accessToken)) {
            return $this->accessToken;
        }

        $ch = curl_init('https://oauth2.googleapis.com/token');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
            CURLOPT_POSTFIELDS => http_build_query([
                'client_id' => $this->clientId,
                'client_secret' => $this->clientSecret,
                'refresh_token' => $this->refreshToken,
                'grant_type' => 'refresh_token'
            ]),
            CURLOPT_TIMEOUT => 30
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200 || !$response) {
            $msg = 'Gagal melakukan autentikasi ke Google Drive (OAuth Token Error).';
            if ($response) {
                $decoded = json_decode($response, true);
                if (isset($decoded['error_description'])) {
                    $msg .= ' Detail: ' . $decoded['error_description'];
                }
            }
            throw new RuntimeException($msg);
        }

        $data = json_decode($response, true);
        if (!isset($data['access_token'])) {
            throw new RuntimeException('Respons token Google Drive tidak valid.');
        }

        $this->accessToken = (string) $data['access_token'];
        return $this->accessToken;
    }

    private function request(string $endpoint, array $params = []): array
    {
        $url = 'https://www.googleapis.com/drive/v3/' . ltrim($endpoint, '/');
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }

        $token = $this->getAccessToken();
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $token,
                'Accept: application/json'
            ],
            CURLOPT_TIMEOUT => 30
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 401) {
            $this->accessToken = '';
            $token = $this->getAccessToken();

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HTTPHEADER => [
                    'Authorization: Bearer ' . $token,
                    'Accept: application/json'
                ],
                CURLOPT_TIMEOUT => 30
            ]);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
        }

        if ($httpCode >= 400 || !$response) {
            $message = 'Gagal mengakses Google Drive API (HTTP ' . $httpCode . ').';
            if ($response) {
                $error = json_decode($response, true);
                if (isset($error['error']['message'])) {
                    $message = $error['error']['message'];
                }
            }
            if ($httpCode === 404) {
                $message = 'File Google Drive tidak ditemukan. Pastikan file belum dihapus.';
            } elseif ($httpCode === 403) {
                $message = 'Akses ke file Google Drive ditolak. Pastikan hak akses file diset "Siapa saja yang memiliki link dapat melihat".';
            }
            throw new RuntimeException($message);
        }

        return json_decode($response, true) ?: [];
    }

    /**
     * Retrieves metadata for an individual Google Drive file.
     * Verifies that the file exists, is accessible, is not trashed, and is a valid image.
     */
    public function getFileMetadata(string $fileId): array
    {
        $fileId = trim($fileId);
        if ($fileId === '' || !preg_match('/^[A-Za-z0-9_-]{20,}$/', $fileId)) {
            throw new InvalidArgumentException('ID File Google Drive tidak valid.');
        }

        $result = $this->request('files/' . $fileId, [
            'fields' => 'id,name,mimeType,size,thumbnailLink,webContentLink,trashed'
        ]);

        if (empty($result) || !isset($result['id'])) {
            throw new RuntimeException('Metadata file tidak ditemukan pada Google Drive.');
        }

        if (!empty($result['trashed'])) {
            throw new RuntimeException('File Google Drive yang dimasukkan berada di tempat sampah (trashed).');
        }

        $mimeType = (string) ($result['mimeType'] ?? '');

        if ($mimeType === 'application/vnd.google-apps.folder') {
            throw new RuntimeException('Link yang dimasukkan adalah folder. Harap masukkan link file foto Google Drive individual.');
        }

        $allowedImageMimes = [
            'image/jpeg',
            'image/jpg',
            'image/png',
            'image/webp',
            'image/gif',
            'image/heif',
            'image/heic',
            'image/svg+xml',
            'image/bmp',
            'image/tiff'
        ];

        $isImage = str_starts_with(strtolower($mimeType), 'image/') || in_array(strtolower($mimeType), $allowedImageMimes, true);

        if (!$isImage) {
            throw new RuntimeException('File Google Drive tersebut bukan merupakan file foto/gambar (MIME: ' . $mimeType . ').');
        }

        $name = (string) ($result['name'] ?? 'Google Drive Photo');
        $size = (int) ($result['size'] ?? 0);
        $thumbnailLink = "https://drive.google.com/thumbnail?id={$fileId}&sz=w1600";
        $previewUrl = "https://lh3.googleusercontent.com/d/{$fileId}=s1600";
        $webContentLink = "https://drive.google.com/file/d/{$fileId}/view";

        return [
            'id' => $fileId,
            'name' => $name,
            'mimeType' => $mimeType,
            'size' => $size,
            'thumbnailLink' => $thumbnailLink,
            'previewUrl' => $previewUrl,
            'webContentLink' => $webContentLink,
        ];
    }
}
