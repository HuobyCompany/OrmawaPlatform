<?php
declare(strict_types=1);

final class StructureService {
    public static function createTerm(int $orgId, string $name, string $slug, string $startDate, ?string $endDate = null): int {
        return TermModel::save([
            'name' => $name,
            'slug' => $slug,
            'start_date' => $startDate,
            'end_date' => $endDate
        ], null, $orgId);
    }

    public static function createGroup(int $orgId, string $name, ?string $description = null, ?int $parentId = null, int $sortOrder = 0): int {
        return StructureGroupModel::save([
            'name' => $name,
            'description' => $description,
            'parent_id' => $parentId,
            'sort_order' => $sortOrder
        ], null, $orgId);
    }

    public static function createPosition(int $orgId, int $groupId, string $title, ?string $description = null, int $sortOrder = 0): int {
        return StructurePositionModel::save([
            'group_id' => $groupId,
            'title' => $title,
            'description' => $description,
            'sort_order' => $sortOrder
        ], null, $orgId);
    }

    public static function assignPerson(int $orgId, int $termId, int $positionId, ?int $personId, string $startDate, ?string $endDate = null, string $status = 'active'): int {
        return PositionAssignmentModel::save([
            'term_id' => $termId,
            'position_id' => $positionId,
            'person_id' => $personId,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'status' => $status
        ], null, $orgId);
    }

    public static function getStructureTree(int $orgId, ?int $termId = null, bool $publicOnly = false): array {
        $groups = StructureGroupModel::all($orgId, $publicOnly);
        $positions = StructurePositionModel::all($orgId, null, $publicOnly);
        $assignments = PositionAssignmentModel::all($orgId, $termId, $publicOnly);

        // Map assignments by position_id
        $assignmentsByPos = [];
        foreach ($assignments as $as) {
            $assignmentsByPos[$as['position_id']][] = $as;
        }

        // Map positions by group_id
        $positionsByGroup = [];
        foreach ($positions as $pos) {
            $pos['assignments'] = $assignmentsByPos[$pos['id']] ?? [];
            $positionsByGroup[$pos['group_id']][] = $pos;
        }

        // Build group tree
        $groupTree = [];
        $groupMap = [];
        foreach ($groups as &$group) {
            $group['positions'] = $positionsByGroup[$group['id']] ?? [];
            $group['children'] = [];
            $groupMap[$group['id']] = &$group;
        }
        unset($group);

        foreach ($groups as &$group) {
            if ($group['parent_id'] !== null && isset($groupMap[$group['parent_id']])) {
                $groupMap[$group['parent_id']]['children'][] = &$group;
            } else {
                $groupTree[] = &$group;
            }
        }

        return $groupTree;
    }
    /**
     * Determine presentation mode for a group based on its characteristics.
     * Returns one of: 'featured_person', 'banner_grid', 'people_grid', 'compact_list', 'hierarchy', 'mixed'.
     */
    public static function determinePresentationMode(array $group): string
    {
        if (!empty($group['banner_media_id'])) {
            return 'banner_grid';
        }
        $positionCount = count($group['positions'] ?? []);
        if ($positionCount === 1) {
            $pos = $group['positions'][0];
            $assignCount = count($pos['assignments'] ?? []);
            if ($assignCount === 1) {
                return 'featured_person';
            }
        }
        if ($positionCount > 4) {
            return 'people_grid';
        }
        return 'people_grid';
    }
}
