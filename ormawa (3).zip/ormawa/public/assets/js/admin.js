document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.classList.remove('no-js');
  const shell = document.querySelector('.admin-shell'), sidebar = document.querySelector('.admin-sidebar');
  document.querySelector('.js-sidebar-toggle')?.addEventListener('click', () => {
    sidebar?.classList.add('open');
    shell?.classList.add('sidebar-open');
  });
  document.querySelector('.js-sidebar-close')?.addEventListener('click', () => {
    sidebar?.classList.remove('open');
    shell?.classList.remove('sidebar-open');
  });
  shell?.addEventListener('click', (e) => {
    if (e.target === shell) {
      sidebar?.classList.remove('open');
      shell.classList.remove('sidebar-open');
    }
  });

  document.querySelectorAll('[data-confirm-url]').forEach(btn => btn.addEventListener('click', () => {
    const url = btn.dataset.confirmUrl;
    const msg = btn.dataset.confirmMessage || 'Apakah Anda yakin?';
    const m = document.getElementById('confirmModal');
    const f = document.getElementById('confirmForm');
    if (m && f) {
      document.getElementById('confirmMessage').textContent = msg;
      f.action = url;
      new bootstrap.Modal(m).show();
    }
  }));

  document.querySelectorAll('input[type=file][data-preview]').forEach(input => input.addEventListener('change', () => {
    const target = document.querySelector(input.dataset.preview);
    if (!target) return;
    const file = input.files?.[0];
    if (file) {
      target.src = URL.createObjectURL(file);
      target.classList.remove('d-none');
    }
  }));

  document.querySelectorAll('[data-live-theme]').forEach(input => input.addEventListener('input', () => {
    const p = document.querySelector('[data-theme-preview]');
    if (!p) return;
    p.style.setProperty('--preview-primary', document.querySelector('[name="primary_color"]')?.value || '#111827');
    p.style.setProperty('--preview-secondary', document.querySelector('[name="secondary_color"]')?.value || '#334155');
    p.style.setProperty('--preview-accent', document.querySelector('[name="accent_color"]')?.value || '#0ea5e9');
  }));

  // Stagger Indices for Admin Containers
  const gridContainers = document.querySelectorAll('.admin-content .row, .admin-content .grid, .admin-content tbody');
  gridContainers.forEach(container => {
    Array.from(container.children).forEach((child, idx) => {
      child.style.setProperty('--reveal-index', idx % 8);
    });
  });

  // Admin Scroll Reveal Observer
  const adminRevealTargets = document.querySelectorAll(
    '.admin-content .reveal-on-scroll, .admin-content .card, .admin-content .stat-card, .admin-content .admin-card, .admin-content .table-responsive, .admin-content .ios-grouped-list, .admin-content .grid > div, .admin-content .row > div'
  );

  const observerOptions = {
    root: null,
    rootMargin: '0px 0px -30px 0px',
    threshold: 0.08
  };

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  adminRevealTargets.forEach(el => {
    if (!el.classList.contains('reveal-on-scroll')) {
      el.classList.add('reveal-on-scroll');
    }
    revealObserver.observe(el);
  });
});
