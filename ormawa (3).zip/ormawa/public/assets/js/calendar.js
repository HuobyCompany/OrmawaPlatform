document.addEventListener('DOMContentLoaded', () => {
    const root = document.querySelector('[data-calendar]');
    if (!root) return;

    const events = JSON.parse(root.dataset.events || '[]');
    const byDate = {};
    events.forEach(e => {
        (byDate[e.event_date] ??= []).push(e);
    });

    let y = Number(root.dataset.year) || new Date().getFullYear();
    let m = (Number(root.dataset.month) || (new Date().getMonth() + 1)) - 1;
    const title = root.querySelector('[data-cal-title]');
    const grid = root.querySelector('[data-cal-grid]');
    const modal = document.getElementById('calendarEventModal');
    const body = modal?.querySelector('[data-cal-modal-body]');
    const empty = root.querySelector('[data-cal-empty]');
    const names = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

    function render() {
        if (title) title.textContent = names[m] + ' ' + y;
        if (!grid) return;
        grid.innerHTML = '';
        const hasEvents = events.some(e => {
            const date = new Date(`${e.event_date}T00:00:00`);
            return date.getFullYear() === y && date.getMonth() === m;
        });
        empty?.classList.toggle('d-none', hasEvents);

        const first = new Date(y, m, 1);
        const last = new Date(y, m + 1, 0);
        const start = (first.getDay() + 6) % 7;
        const prevDays = new Date(y, m, 0).getDate();

        for (let i = 0; i < start; i++) {
            grid.insertAdjacentHTML('beforeend', `<div class="calendar-day muted"><span>${prevDays - start + i + 1}</span></div>`);
        }

        for (let d = 1; d <= last.getDate(); d++) {
            const key = `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
            const list = byDate[key] || [];
            const today = new Date();
            const isToday = today.getFullYear() === y && today.getMonth() === m && today.getDate() === d;
            const html = `
                <button type="button" class="calendar-day ${list.length ? 'has-event' : ''} ${isToday ? 'today' : ''}" ${list.length ? '' : 'disabled'} aria-label="${d} ${names[m]} ${y}${list.length ? ' - ' + list.length + ' kegiatan' : ''}">
                    <span class="calendar-day-number">${d}${list.length ? '<span class="calendar-dot"></span>' : ''}</span>
                    ${list.slice(0, 2).map(e => `
                        <span class="calendar-event-list">
                            <span class="calendar-event-chip">${escapeHtml(e.title)}</span>
                        </span>
                    `).join('')}
                </button>
            `;
            grid.insertAdjacentHTML('beforeend', html);
            const b = grid.lastElementChild;
            b.addEventListener('click', () => openDay(key, list, d, names[m], y));
        }

        const cells = grid.children.length;
        for (let i = cells; i < 42; i++) {
            grid.insertAdjacentHTML('beforeend', '<div class="calendar-day muted"></div>');
        }
    }

    function openDay(key, list, dayNum, monthName, yearNum) {
        if (!list || !list.length) return;

        body.innerHTML = `
            <div class="p-4 p-lg-5">
                <div class="d-flex align-items-center justify-content-between mb-4">
                    <div>
                        <div class="eyebrow mb-1"><i class="bi bi-calendar-event me-1"></i> Agenda Tanggal</div>
                        <h2 class="h3 fw-bold mb-0">${dayNum} ${monthName} ${yearNum}</h2>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="d-flex flex-column gap-4">
                    ${list.map(e => `
                        <article class="surface-card p-3 p-md-4 rounded-4 border shadow-sm">
                            <div class="row g-4 align-items-center">
                                ${e.poster_url ? `
                                    <div class="col-md-5">
                                        <div class="position-relative rounded-4 overflow-hidden shadow-sm" style="max-height: 280px;">
                                            <img class="w-100 h-100 object-cover" src="${e.poster_url}" alt="Poster ${escapeHtml(e.title)}" loading="lazy">
                                            <a href="${e.poster_url}" target="_blank" class="btn btn-sm btn-light rounded-circle position-absolute bottom-0 end-0 m-2 shadow" title="Buka Flyer/Poster">
                                                <i class="bi bi-arrows-angle-expand"></i>
                                            </a>
                                        </div>
                                    </div>
                                ` : ''}
                                <div class="${e.poster_url ? 'col-md-7' : 'col-12'}">
                                    <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-3 py-1.5 rounded-pill mb-2 fw-semibold">
                                        Event Terjadwal
                                    </span>
                                    <h3 class="h4 fw-bold text-dark mb-2">${escapeHtml(e.title)}</h3>
                                    
                                    <div class="d-flex flex-wrap gap-3 small text-secondary mb-3">
                                        ${(e.start_time || e.end_time) ? `
                                            <div class="d-flex align-items-center gap-1.5">
                                                <i class="bi bi-clock text-primary"></i>
                                                <span>${escapeHtml(e.start_time || '')} ${e.end_time ? '– ' + escapeHtml(e.end_time) : ''}</span>
                                            </div>
                                        ` : ''}
                                        ${e.location ? `
                                            <div class="d-flex align-items-center gap-1.5">
                                                <i class="bi bi-geo-alt text-danger"></i>
                                                <span>${escapeHtml(e.location)}</span>
                                            </div>
                                        ` : ''}
                                    </div>

                                    ${e.description ? `
                                        <p class="text-secondary small mb-3 line-clamp-3">${escapeHtml(strip(e.description))}</p>
                                    ` : ''}

                                    <a href="${window.location.pathname.replace(/\/calendar\/?$/, '')}/events/edit/${e.id}" class="btn btn-dark btn-sm rounded-3 px-3">
                                        <span>Kelola Kegiatan</span>
                                        <i class="bi bi-pencil-square ms-1"></i>
                                    </a>
                                </div>
                            </div>
                        </article>
                    `).join('')}
                </div>
            </div>
        `;

        if (modal) {
            bootstrap.Modal.getOrCreateInstance(modal).show();
        }
    }

    function escapeHtml(s) {
        return String(s).replace(/[&<>'"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]));
    }

    function strip(s) {
        const d = document.createElement('div');
        d.innerHTML = s;
        return d.textContent || d.innerText || '';
    }

    function navigateToMonth() {
        const params = new URLSearchParams(window.location.search);
        params.set('month', String(m + 1));
        params.set('year', String(y));
        window.location.search = params.toString();
    }

    root.querySelector('[data-cal-prev]')?.addEventListener('click', () => {
        m--;
        if (m < 0) {
            m = 11;
            y--;
        }
        navigateToMonth();
    });

    root.querySelector('[data-cal-next]')?.addEventListener('click', () => {
        m++;
        if (m > 11) {
            m = 0;
            y++;
        }
        navigateToMonth();
    });

    root.querySelector('[data-cal-today]')?.addEventListener('click', () => {
        const today = new Date();
        y = today.getFullYear();
        m = today.getMonth();
        navigateToMonth();
    });

    render();
});
