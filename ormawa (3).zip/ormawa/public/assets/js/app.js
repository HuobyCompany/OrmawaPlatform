document.addEventListener('DOMContentLoaded', () => {
  // Remove no-js fallback class
  document.documentElement.classList.remove('no-js');

  // Mobile Navigation Toggle
  const toggle = document.querySelector('[data-nav-toggle]');
  const menu = document.querySelector('[data-nav-menu]');
  let navLastFocus = null;

  const closeNav = () => {
    if (!menu?.classList.contains('open')) return;
    menu.classList.remove('open');
    toggle?.setAttribute('aria-expanded', 'false');
    document.body.classList.remove('body-no-scroll');
    if (navLastFocus) {
      navLastFocus.focus();
      navLastFocus = null;
    }
  };

  const openNav = () => {
    if (menu?.classList.contains('open')) return;
    navLastFocus = document.activeElement;
    menu.classList.add('open');
    toggle?.setAttribute('aria-expanded', 'true');
    document.body.classList.add('body-no-scroll');
    const firstLink = menu?.querySelector('a');
    if (firstLink) firstLink.focus();
  };

  toggle?.addEventListener('click', () => {
    menu?.classList.contains('open') ? closeNav() : openNav();
  });

  document.addEventListener('click', (e) => {
    if (menu?.classList.contains('open') && !toggle.contains(e.target) && !menu.contains(e.target)) {
      closeNav();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && menu?.classList.contains('open')) {
      closeNav();
    }
  });

  menu?.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab' || !menu.classList.contains('open')) return;
    const focusable = menu.querySelectorAll('a, button, [tabindex]:not([tabindex="-1"])');
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (e.shiftKey) {
      if (document.activeElement === first) {
        e.preventDefault();
        last.focus();
      }
    } else {
      if (document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  });

  // Copy Link Button
  document.querySelectorAll('[data-copy-link]').forEach(btn => btn.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(btn.dataset.copyLink || location.href);
      const old = btn.innerHTML;
      btn.innerHTML = '<i class="bi bi-check2"></i> Tersalin';
      setTimeout(() => btn.innerHTML = old, 1600);
    } catch (e) {}
  }));

  // Lightbox Overlay
  const globalLightbox = document.querySelector('#lightbox');
  const galleryItems = [...document.querySelectorAll('#content [data-lightbox-item]')];
  let galleryIndex = 0;
  let lastFocusedElement = null;

  const showGalleryItem = (i) => {
    if (!globalLightbox || !galleryItems.length) return;
    galleryIndex = (i + galleryItems.length) % galleryItems.length;
    const item = galleryItems[galleryIndex];
    globalLightbox.querySelector('img').src = item.dataset.src;
    globalLightbox.querySelector('img').alt = item.querySelector('img')?.alt || item.dataset.caption || '';
    globalLightbox.querySelector('[data-caption]').textContent = item.dataset.caption || '';
    globalLightbox.classList.add('open');
    globalLightbox.removeAttribute('hidden');
    globalLightbox.querySelector('.lightbox-close')?.focus();
  };

  galleryItems.forEach((el, i) => {
    el.addEventListener('click', () => {
      lastFocusedElement = el;
      showGalleryItem(i);
    });
  });

  globalLightbox?.querySelector('[data-lightbox-prev]')?.addEventListener('click', () => showGalleryItem(galleryIndex - 1));
  globalLightbox?.querySelector('[data-lightbox-next]')?.addEventListener('click', () => showGalleryItem(galleryIndex + 1));
  globalLightbox?.addEventListener('click', e => {
    if (e.target === globalLightbox || e.target.closest('[data-close]')) {
      globalLightbox.classList.remove('open');
      globalLightbox.setAttribute('hidden', 'hidden');
      lastFocusedElement?.focus();
    }
  });

  document.addEventListener('keydown', e => {
    if (globalLightbox?.classList.contains('open')) {
      if (e.key === 'Escape') {
        globalLightbox.classList.remove('open');
        globalLightbox.setAttribute('hidden', 'hidden');
        lastFocusedElement?.focus();
      }
      if (e.key === 'ArrowLeft') showGalleryItem(galleryIndex - 1);
      if (e.key === 'ArrowRight') showGalleryItem(galleryIndex + 1);
    }
  });

  document.querySelectorAll('#lightbox').forEach(lb => lb.setAttribute('hidden', 'hidden'));

  // Header Scroll Effect
  const header = document.querySelector('.site-header');
  if (header) {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        header.style.boxShadow = '0 2px 12px rgba(0,0,0,0.06)';
      } else {
        header.style.boxShadow = 'none';
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
  }

  // Smooth Scroll for internal links
  document.querySelectorAll('a[href^="#"]:not([href="#"])').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Stagger Indices for Grid Children
  const gridContainers = document.querySelectorAll('#content .gallery-masonry, #content .structure-tree, #content .event-list, #content .calendar-grid');
  gridContainers.forEach(container => {
    const children = container.children;
    Array.from(children).forEach((child, idx) => {
      child.style.setProperty('--reveal-index', idx % 6);
    });
  });

  // Scroll Reveal Intersection Observer
  const revealTargets = document.querySelectorAll(
    '#content .reveal-on-scroll, #content .event-featured, #content .event-list-editorial, #content .gallery-item-editorial, #content .portrait-card, #content .editorial-block, #content .connect-card, #content .calendar-preview, #content .contact-list-item, #content .contact-map, #content .event-detail, #content .album-header, #content .about-visual, #content .filter-bar, #content .section-header'
  );

  const observerOptions = {
    root: null,
    rootMargin: '0px 0px -40px 0px',
    threshold: 0.1
  };

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  revealTargets.forEach(el => {
    if (!el.classList.contains('reveal-on-scroll')) {
      el.classList.add('reveal-on-scroll');
    }
    revealObserver.observe(el);
  });
});
