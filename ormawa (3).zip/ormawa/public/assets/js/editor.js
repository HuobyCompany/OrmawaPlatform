document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('textarea[data-editor]').forEach((textarea) => {
    const wrap = document.createElement('div');
    wrap.className = 'editor-wrap';
    const toolbar = document.createElement('div');
    toolbar.className = 'editor-toolbar';
    const editor = document.createElement('div');
    editor.className = 'editor-content';
    editor.contentEditable = 'true';
    editor.innerHTML = textarea.value || '';
    textarea.classList.add('d-none');
    textarea.parentNode.insertBefore(wrap, textarea);
    wrap.append(toolbar, editor, textarea);
    const commands = [
      ['bold','B'], ['italic','I'], ['insertUnorderedList','• List'], ['insertOrderedList','1. List']
    ];
    commands.forEach(([cmd,label]) => {
      const btn = document.createElement('button'); btn.type='button'; btn.className='btn btn-sm btn-light'; btn.textContent=label;
      btn.addEventListener('click',()=>{ document.execCommand(cmd,false,null); editor.focus(); sync(); });
      toolbar.appendChild(btn);
    });
    const linkBtn = document.createElement('button'); linkBtn.type='button'; linkBtn.className='btn btn-sm btn-light'; linkBtn.textContent='Link';
    linkBtn.addEventListener('click',()=>{ const u=window.prompt('URL link:'); if(u){ document.execCommand('createLink',false,u); sync(); editor.focus(); }});
    toolbar.appendChild(linkBtn);
    const sync = () => { textarea.value = editor.innerHTML; };
    editor.addEventListener('input', sync);
    textarea.form?.addEventListener('submit', sync);
  });
});
