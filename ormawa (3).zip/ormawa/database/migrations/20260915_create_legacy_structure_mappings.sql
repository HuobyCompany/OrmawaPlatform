/* Migration: 20260915_create_legacy_structure_mappings.sql */
-- Track legacy organization_positions rows migrated to the new structure model
CREATE TABLE IF NOT EXISTS legacy_structure_mappings (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    legacy_position_id BIGINT UNSIGNED NOT NULL UNIQUE,
    term_id BIGINT UNSIGNED NULL,
    group_id BIGINT UNSIGNED NULL,
    position_id BIGINT UNSIGNED NULL,
    person_id BIGINT UNSIGNED NULL,
    assignment_id BIGINT UNSIGNED NULL,
    status ENUM('migrated', 'skipped', 'ambiguous') NOT NULL DEFAULT 'migrated',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_map_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    CONSTRAINT fk_map_legacy FOREIGN KEY (legacy_position_id) REFERENCES organization_positions(id) ON DELETE CASCADE,
    CONSTRAINT fk_map_term FOREIGN KEY (term_id) REFERENCES organization_terms(id) ON DELETE SET NULL,
    CONSTRAINT fk_map_group FOREIGN KEY (group_id) REFERENCES structure_groups(id) ON DELETE SET NULL,
    CONSTRAINT fk_map_position FOREIGN KEY (position_id) REFERENCES positions(id) ON DELETE SET NULL,
    CONSTRAINT fk_map_person FOREIGN KEY (person_id) REFERENCES persons(id) ON DELETE SET NULL,
    CONSTRAINT fk_map_assignment FOREIGN KEY (assignment_id) REFERENCES position_assignments(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
