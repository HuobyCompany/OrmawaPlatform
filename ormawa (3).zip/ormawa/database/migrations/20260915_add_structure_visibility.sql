/* Migration: 20260915_add_structure_visibility.sql */
-- Add visibility control columns to structure entities for public display
-- ------------------------------------------------------------

-- Add is_public column to structure_groups to control public visibility
ALTER TABLE structure_groups ADD COLUMN is_public TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'Whether this group should be visible on public structure page (1=public, 0=private/admin-only)';

-- Add is_public column to positions to control public visibility
ALTER TABLE positions ADD COLUMN is_public TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'Whether this position should be visible on public structure page (1=public, 0=private/admin-only)';

-- Add is_public column to position_assignments to control public visibility
ALTER TABLE position_assignments ADD COLUMN is_public TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'Whether this assignment should be visible on public structure page (1=public, 0=private/admin-only)';

-- Add index for efficient public queries
CREATE INDEX idx_groups_public ON structure_groups(organization_id, is_public, sort_order);
CREATE INDEX idx_positions_public ON positions(organization_id, group_id, is_public, sort_order);
CREATE INDEX idx_assignments_public ON position_assignments(organization_id, term_id, is_public);
