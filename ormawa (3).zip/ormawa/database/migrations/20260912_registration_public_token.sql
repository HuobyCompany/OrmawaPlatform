-- Migration: Add public_reference and public_token_hash to registration_submissions
-- Run this after 20260910_member_registration.sql

ALTER TABLE `registration_submissions`
  ADD COLUMN `public_reference` VARCHAR(30) NULL AFTER `organization_id`,
  ADD COLUMN `public_token_hash` CHAR(64) NULL AFTER `public_reference`,
  ADD UNIQUE INDEX `uq_reg_sub_public_ref` (`public_reference`);