-- Idempotent Remote URL gallery extension migration.
-- Safe to re-run on databases where columns/ENUM already include 'remote_url'.
-- Depends on 20250909_google_drive_gallery.php (source_type must exist first).

-- Extend source_type enum to include remote_url.
-- MODIFY COLUMN is idempotent: if the ENUM definition already matches,
-- MariaDB applies it as a no-op (no data loss, no error).
ALTER TABLE gallery_albums
  MODIFY COLUMN source_type ENUM('local', 'google_drive', 'remote_url') NOT NULL DEFAULT 'local';

ALTER TABLE gallery_items
  MODIFY COLUMN source_type ENUM('local', 'google_drive', 'remote_url') NOT NULL DEFAULT 'local',
  ADD COLUMN IF NOT EXISTS remote_url VARCHAR(500) NULL AFTER drive_url;
