-- Migration: 20260916_create_members_table.sql
-- Phase 4: Person / Member / User Account Separation
-- Creates dedicated members table to separate identity, membership, and authentication

-- === members: membership relationship with organization ===
CREATE TABLE IF NOT EXISTS members (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    organization_id BIGINT UNSIGNED NOT NULL,
    person_id BIGINT UNSIGNED NULL,
    member_number VARCHAR(20) NOT NULL UNIQUE,
    status ENUM('pending','active','rejected','suspended','inactive','alumni') NOT NULL DEFAULT 'pending',
    joined_at DATETIME NULL,
    reviewed_at DATETIME NULL,
    reviewed_by BIGINT UNSIGNED NULL,
    reviewer_notes TEXT NULL,
    current_term_id BIGINT UNSIGNED NULL,
    batch_year VARCHAR(10) NULL,
    faculty_name VARCHAR(180) NULL,
    prodi_name VARCHAR(180) NULL,
    whatsapp VARCHAR(60) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_members_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    CONSTRAINT fk_members_person FOREIGN KEY (person_id) REFERENCES persons(id) ON DELETE SET NULL,
    CONSTRAINT fk_members_term FOREIGN KEY (current_term_id) REFERENCES organization_terms(id) ON DELETE SET NULL,
    CONSTRAINT fk_members_reviewer FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_member_number (member_number),
    INDEX idx_members_org_status (organization_id, status),
    INDEX idx_members_person (person_id),
    INDEX idx_members_batch (organization_id, batch_year),
    INDEX idx_members_reviewed (reviewed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === member_audit: membership status history ===
CREATE TABLE IF NOT EXISTS member_audit (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    member_id BIGINT UNSIGNED NOT NULL,
    old_status VARCHAR(20) NULL,
    new_status VARCHAR(20) NOT NULL,
    changed_by BIGINT UNSIGNED NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    notes TEXT NULL,
    CONSTRAINT fk_audit_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    CONSTRAINT fk_audit_user FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_member (member_id),
    INDEX idx_audit_date (changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === registration_member_mapping: maps legacy registration_submissions to new members ===
CREATE TABLE IF NOT EXISTS registration_member_mapping (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    registration_submission_id BIGINT UNSIGNED NOT NULL,
    member_id BIGINT UNSIGNED NOT NULL,
    mapping_type ENUM('direct','ambiguous','manual') NOT NULL DEFAULT 'direct',
    confidence_score TINYINT UNSIGNED NULL,
    mapped_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    mapped_by BIGINT UNSIGNED NULL,
    notes TEXT NULL,
    CONSTRAINT fk_map_submission FOREIGN KEY (registration_submission_id) REFERENCES registration_submissions(id) ON DELETE CASCADE,
    CONSTRAINT fk_map_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    CONSTRAINT fk_map_user FOREIGN KEY (mapped_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_submission_mapping (registration_submission_id),
    INDEX idx_map_member (member_id),
    INDEX idx_map_type (mapping_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Note: Legacy registration_submissions data is preserved
-- The mapping table allows us to track which submissions were migrated to which members
-- Existing authentication logic continues to work during transition period
