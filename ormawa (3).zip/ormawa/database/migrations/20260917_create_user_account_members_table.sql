-- Migration: 20260917_create_user_account_members_table.sql
-- Phase 5: Unified Authentication Foundation
-- Creates linking table between users and members for unified authentication

-- === user_account_members: links user accounts to members ===
CREATE TABLE IF NOT EXISTS user_account_members (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT UNSIGNED NOT NULL,
    member_id BIGINT UNSIGNED NULL,
    person_id BIGINT UNSIGNED NULL,
    is_primary BOOLEAN NOT NULL DEFAULT TRUE,
    linked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    linked_by BIGINT UNSIGNED NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_uam_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_uam_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    CONSTRAINT fk_uam_person FOREIGN KEY (person_id) REFERENCES persons(id) ON DELETE SET NULL,
    CONSTRAINT fk_uam_linked_by FOREIGN KEY (linked_by) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_user_member (user_id, member_id),
    UNIQUE KEY uq_user_person (user_id, person_id),
    INDEX idx_uam_user (user_id),
    INDEX idx_uam_member (member_id),
    INDEX idx_uam_person (person_id),
    INDEX idx_uam_primary (is_primary)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Notes:
-- - A user can be linked to a member (if they are a member of an organization)
-- - A user can be linked to a person (if they are not a member but have a person record)
-- - is_primary indicates the primary membership for users with multiple memberships
-- - This enables the unified authentication system while maintaining the separation of concerns
-- - Existing admin users without member/person relationships can continue to work
-- - Legacy member_auth system remains functional as fallback during transition
