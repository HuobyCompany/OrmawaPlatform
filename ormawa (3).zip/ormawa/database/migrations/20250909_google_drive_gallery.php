-- Idempotent Google Drive gallery integration migration.
-- Safe to re-run: ADD COLUMN IF NOT EXISTS + DROP/ADD INDEX IF EXISTS.
-- On a fresh DB initialized from database.sql, these columns already exist
-- (database.sql baseline includes them), so all operations are no-ops.

-- Add Google Drive integration fields to gallery_albums
ALTER TABLE gallery_albums
  ADD COLUMN IF NOT EXISTS source_type ENUM('local', 'google_drive', 'remote_url') NOT NULL DEFAULT 'local' AFTER category,
  ADD COLUMN IF NOT EXISTS drive_folder_id VARCHAR(255) NULL AFTER cover_image,
  ADD COLUMN IF NOT EXISTS drive_folder_name VARCHAR(255) NULL AFTER drive_folder_id,
  ADD COLUMN IF NOT EXISTS last_synced_at DATETIME NULL AFTER drive_folder_name,
  ADD COLUMN IF NOT EXISTS sync_status ENUM('idle', 'syncing', 'synced', 'failed') NOT NULL DEFAULT 'idle' AFTER last_synced_at,
  ADD COLUMN IF NOT EXISTS sync_error TEXT NULL AFTER sync_status;

ALTER TABLE gallery_albums
  DROP INDEX IF EXISTS idx_gallery_albums_drive,
  ADD INDEX idx_gallery_albums_drive (organization_id, source_type, drive_folder_id);

-- Add Google Drive integration fields to gallery_items
ALTER TABLE gallery_items
  ADD COLUMN IF NOT EXISTS source_type ENUM('local', 'google_drive', 'remote_url') NOT NULL DEFAULT 'local' AFTER caption,
  ADD COLUMN IF NOT EXISTS drive_file_id VARCHAR(255) NULL AFTER source_type,
  ADD COLUMN IF NOT EXISTS drive_url TEXT NULL AFTER drive_file_id,
  ADD COLUMN IF NOT EXISTS thumbnail_url VARCHAR(500) NULL AFTER drive_url,
  ADD COLUMN IF NOT EXISTS sync_status ENUM('active', 'removed', 'error') NOT NULL DEFAULT 'active' AFTER thumbnail_url,
  ADD COLUMN IF NOT EXISTS last_synced_at DATETIME NULL AFTER sync_status;

ALTER TABLE gallery_items
  DROP INDEX IF EXISTS uq_gallery_item_drive_file,
  ADD UNIQUE KEY uq_gallery_item_drive_file (album_id, drive_file_id);

ALTER TABLE gallery_items
  DROP INDEX IF EXISTS idx_gallery_items_drive,
  ADD INDEX idx_gallery_items_drive (album_id, source_type, sync_status);
