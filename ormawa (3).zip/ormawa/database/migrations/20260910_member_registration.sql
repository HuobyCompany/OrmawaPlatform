-- Member Registration Form Builder Schema
-- Provides dynamic, data-driven registration form with:
--   - Master faculty/study program data (global)
--   - Dynamic form + field definitions (per-organization)
--   - Submission storage with EAV + historical snapshot
--   - Soft-delete on fields (preserves historical submissions)

-- === Master Data: Faculties (global — Ubhara Jaya) ===
CREATE TABLE IF NOT EXISTS faculties (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL,
  name VARCHAR(180) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  UNIQUE KEY uq_faculty_code (code),
  INDEX idx_faculty_sort (sort_order),
  INDEX idx_faculty_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === Master Data: Study Programs (belong to a faculty) ===
CREATE TABLE IF NOT EXISTS study_programs (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  faculty_id BIGINT UNSIGNED NOT NULL,
  code VARCHAR(20) NOT NULL,
  name VARCHAR(180) NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  CONSTRAINT fk_study_programs_faculty FOREIGN KEY (faculty_id) REFERENCES faculties(id) ON DELETE RESTRICT,
  INDEX idx_sp_faculty (faculty_id),
  INDEX idx_sp_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === Registration Form (one per org; only one active at a time) ===
CREATE TABLE IF NOT EXISTS registration_forms (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  organization_id BIGINT UNSIGNED NOT NULL,
  title VARCHAR(180) NOT NULL DEFAULT 'Formulir Pendaftaran',
  description TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  CONSTRAINT fk_reg_forms_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
  INDEX idx_reg_forms_org (organization_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === Registration Fields (dynamic, per form) ===
CREATE TABLE IF NOT EXISTS registration_fields (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  form_id BIGINT UNSIGNED NOT NULL,
  field_type ENUM('text','textarea','number','phone','date','email','select','radio','checkbox','file_image','file','social_media','faculty_selector','program_study_selector') NOT NULL DEFAULT 'text',
  `name` VARCHAR(100) NOT NULL,
  label VARCHAR(180) NOT NULL,
  placeholder VARCHAR(255) NULL,
  help_text TEXT NULL,
  is_required TINYINT(1) NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  sort_order INT NOT NULL DEFAULT 0,
  options_json JSON NULL,
  validation_rules JSON NULL,
  config_json JSON NULL,
  file_accept VARCHAR(255) NULL,
  file_max_bytes INT NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  deleted_at DATETIME NULL,
  CONSTRAINT fk_reg_fields_form FOREIGN KEY (form_id) REFERENCES registration_forms(id) ON DELETE CASCADE,
  INDEX idx_reg_fields_form (form_id),
  INDEX idx_reg_fields_sort (form_id, sort_order, is_active, deleted_at),
  INDEX idx_reg_fields_name (form_id, `name`),
  INDEX idx_reg_fields_active (is_active, deleted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === Registration Submissions (per org) ===
CREATE TABLE IF NOT EXISTS registration_submissions (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  form_id BIGINT UNSIGNED NOT NULL,
  organization_id BIGINT UNSIGNED NOT NULL,
  status ENUM('pending','approved','rejected','draft') NOT NULL DEFAULT 'pending',
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  reviewer_notes TEXT NULL,
  submitted_at DATETIME NULL,
  reviewed_at DATETIME NULL,
  reviewed_by BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  CONSTRAINT fk_reg_sub_form FOREIGN KEY (form_id) REFERENCES registration_forms(id) ON DELETE CASCADE,
  CONSTRAINT fk_reg_sub_org FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
  INDEX idx_reg_sub_org_status (organization_id, status),
  INDEX idx_reg_sub_org_created (organization_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === Registration Field Values (EAV + historical snapshot) ===
CREATE TABLE IF NOT EXISTS registration_values (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  submission_id BIGINT UNSIGNED NOT NULL,
  field_id BIGINT UNSIGNED NULL,
  field_name VARCHAR(100) NOT NULL,
  field_label VARCHAR(180) NOT NULL,
  field_type VARCHAR(50) NOT NULL,
  `value` TEXT NULL,
  file_path VARCHAR(255) NULL,
  created_at DATETIME NOT NULL,
  CONSTRAINT fk_reg_val_submission FOREIGN KEY (submission_id) REFERENCES registration_submissions(id) ON DELETE CASCADE,
  INDEX idx_reg_val_submission (submission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- === Seed: Master Faculty & Study Program (Ubhara Jaya) ===
INSERT IGNORE INTO faculties (code, name, sort_order, is_active, created_at, updated_at) VALUES
  ('FT',  'Fakultas Teknik', 1, 1, NOW(), NOW()),
  ('FEB', 'Fakultas Ekonomi dan Bisnis', 2, 1, NOW(), NOW()),
  ('FH',  'Fakultas Hukum', 3, 1, NOW(), NOW()),
  ('FISIP','Fakultas Ilmu Sosial dan Ilmu Politik', 4, 1, NOW(), NOW()),
  ('FIK', 'Fakultas Ilmu Kesehatan', 5, 1, NOW(), NOW()),
  ('FAI', 'Fakultas Agama Islam', 6, 1, NOW(), NOW());

INSERT IGNORE INTO study_programs (faculty_id, code, name, sort_order, is_active, created_at, updated_at) VALUES
  (1, 'TI',  'Teknik Industri', 1, 1, NOW(), NOW()),
  (1, 'TS',  'Teknik Sipil', 2, 1, NOW(), NOW()),
  (1, 'TIF', 'Teknik Informatika', 3, 1, NOW(), NOW()),
  (1, 'TE',  'Teknik Elektro', 4, 1, NOW(), NOW()),
  (2, 'MAN','Manajemen', 1, 1, NOW(), NOW()),
  (2, 'AKT','Akuntansi', 2, 1, NOW(), NOW()),
  (2, 'EKO','Ekonomi Pembangunan', 3, 1, NOW(), NOW()),
  (3, 'HUK','Hukum', 1, 1, NOW(), NOW()),
  (4, 'ILKOM','Ilmu Komunikasi', 1, 1, NOW(), NOW()),
  (4, 'HUM','Hubungan Internasional', 2, 1, NOW(), NOW()),
  (5, 'KEP','Keperawatan', 1, 1, NOW(), NOW()),
  (5, 'GIZI','Gizi', 2, 1, NOW(), NOW()),
  (5, 'FARM','Farmasi', 3, 1, NOW(), NOW()),
  (6, 'AHS','Ahwal Syakhsiyah', 1, 1, NOW(), NOW()),
  (6, 'AKB','Agribisnis Syariah', 2, 1, NOW(), NOW());
