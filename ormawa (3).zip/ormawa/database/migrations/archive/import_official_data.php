<?php
/**
 * IMPORT SCRIPT - Data from GBHO New & New AD-ART
 * 
 * This script imports official organization data from:
 * - GBHO new.docx (Garis-garis Besar Haluan Organisasi)
 * - New AD-ART.docx (Anggaran Dasar dan Anggaran Rumah Tangga)
 * 
 * Period: 2026/2027
 * Organization: Keluarga Islam Mahasiswa Universitas Bhayangkara Jakarta Raya (KIMURA)
 */

declare(strict_types=1);
require __DIR__ . '/config/config.php';
require __DIR__ . '/config/constants.php';
date_default_timezone_set(APP_TIMEZONE);
foreach (glob(__DIR__ . '/app/helpers/*.php') as $f) require_once $f;

// Error reporting
error_reporting(E_ALL);
ini_set('display_errors', '0');

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_EMULATE_PREPARES => false
    ]);
    
    echo "=== KIMURA OFFICIAL DATA IMPORT ===\n\n";
    
    // Start transaction
    $pdo->beginTransaction();
    
    // ============================================================
    // PHASE 1: UPDATE ORGANIZATION PROFILE
    // ============================================================
    echo "1. Updating organization profile...\n";
    
    $orgData = [
        'name' => 'Keluarga Islam Mahasiswa Universitas Bhayangkara Jakarta Raya',
        'short_name' => 'KIMURA',
        'slug' => 'kimura',
        'website_name' => 'KIMURA - Click Ur Jannah',
        'description' => 'Lembaga Dakwah Kampus di Universitas Bhayangkara Jakarta Raya yang bergerak dalam aktivitas keislaman, IPTEK, serta pembentuk karakter mahasiswa sebagai generasi penerus bangsa.',
        'about' => '<p>KIMURA (Keluarga Islam Mahasiswa) adalah organisasi kemahasiswaan dalam bidang keislaman di Universitas Bhayangkara Jakarta Raya yang berdiri sejak tahun 2007.</p><p>Sebagai Unit Kegiatan Mahasiswa Lembaga Dakwah Kampus, KIMURA berfungsi sebagai organisasi dakwah yang bergerak dalam aktivitas keislaman, IPTEK, serta pembentuk karakter mahasiswa sebagai generasi penerus bangsa.</p><p>KIMURA memiliki struktur organisasi yang terdiri dari Ketua, Wakil Ketua, Sekretaris, Bendahara, dan divisi-divisi termasuk Kaderisasi, Kemuslimahan, dan Syiar. Setiap periode kepengurusan berlangsung selama 1 tahun dan diatur melalui AD/ART dan GBHO organisasi.</p>',
        'vision' => '<p>Menjadi Unit Kegiatan Mahasiswa Islam yang bermanfaat dan menjadi teladan yang madani.</p>',
        'mission' => '<ol><li>Memperkuat ukhuwah Mahasiswa Islam di Universitas Bhayangkara Jakarta Raya.</li><li>Mendorong anggota untuk lebih profesional dan menyerukan kebaikan.</li><li>Mempersiapkan Mahasiswa muslim Universitas Bhayangkara Jakarta Raya sebagai seorang pemimpin yang Rabbani.</li><li>Berperan aktif dalam menyukseskan budaya akademik dan islami di Universitas Bhayangkara Jakarta Raya.</li><li>Berperan aktif dalam pembinaan untuk menciptakan Mahasiswa yang berkarakter islami di Universitas Bhayangkara Jakarta Raya.</li><li>Menjadikan KIMURA sebagai salah satu pusat wadah keilmuan di Universitas Bhayangkara Jakarta Raya.</li></ol>',
        'values_text' => '<ul><li>Ridho Allah Subhanahu Wa Ta\'ala sebagai tujuan hidup</li><li>Rasulullah Shalallahu Alaihi Wasallam sebagai teladan hidup</li><li>Al-Qur\'an dan Hadits sebagai pedoman</li><li>Muhasabah diri, Amar Ma\'ruf dan Nahi Munkar</li></ul>',
        'primary_color' => '#167b0f',
        'secondary_color' => '#258330',
        'accent_color' => '#30d158',
        'background_color' => '#f7f8fa',
        'text_color' => '#111827',
        'font_family' => 'Inter',
        'email' => 'admin@example.com',
        'phone' => '081234567890',
        'address' => 'Universitas Bhayangkara Jakarta Raya',
        'status' => 'active'
    ];
    
    $sql = "UPDATE organizations SET 
        name = :name,
        short_name = :short_name,
        slug = :slug,
        website_name = :website_name,
        description = :description,
        about = :about,
        vision = :vision,
        mission = :mission,
        values_text = :values_text,
        primary_color = :primary_color,
        secondary_color = :secondary_color,
        accent_color = :accent_color,
        background_color = :background_color,
        text_color = :text_color,
        font_family = :font_family,
        email = :email,
        phone = :phone,
        address = :address,
        status = :status,
        updated_at = NOW()
        WHERE id = 1";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($orgData);
    echo "   ✓ Organization profile updated\n\n";
    
    // ============================================================
    // PHASE 2: IMPORT ORGANIZATION SETTINGS
    // ============================================================
    echo "2. Importing organization settings...\n";
    
    $settings = [
        'foundation' => 'Landasan Gerakan KIMURA adalah sesuatu yang dijadikan tolak ukur dan pedoman asasi dalam organisasi KIMURA. Landasan tersebut meliputi: (1) Landasan ideologi Islam (Al-Qur\'an, Hadist, Ijma Ulama, dan Qiyas), (2) Landasan konstitusional AD/ART organisasi KIMURA, (3) Landasan operasional GBHO.',
        
        'principles' => 'Prinsip Gerakan KIMURA adalah suatu asas yang menjadikan dasar pikiran dan tindakan dalam pergerakan dakwah KIMURA: (1) Ridho Allah Subhanahu Wa Ta\'alaa sebagai tujuan hidup kami, (2) Rasulullah Shalallahu Alaihi Wasallam sebagai teladan hidup kami, (3) Al-Qur\'an dan Hadits adalah pedoman kami, (4) Muhasabah diri, Amar Ma\'ruf dan Nahi Munkar.',
        
        'character' => 'Karakter gerakan KIMURA adalah organisasi kemahasiswaan dalam bidang keislaman.',
        
        'paradigm' => 'Paradigma Gerakan KIMURA adalah pola dasar pemikiran yang menjelaskan metode yang mengedepankan hubungan ukhuwah islamiyah dalam gerakan dakwah KIMURA. Terdiri dari: (1) Gerakan Tauhid - menyerukan kepada mahasiswa muslim untuk menjauhi segala bentuk kesyirikan dan menanaman nilai-nilai keislaman dalam civitas akademik, (2) Gerakan Intelektual - pembekalan dan pemberdayaan potensi pemikiran Mahasiswa serta penyediaan perangkat pengembangan aspek pemikiran.',
        
        'functions' => 'Fungsi KIMURA adalah sebagai organisasi dakwah yang bergerak dalam aktivitas keislaman, IPTEK, serta pembentuk karakter mahasiswa sebagai generasi penerus bangsa.',
        
        'membership_info' => 'Anggota KIMURA adalah seluruh mahasiswa yang beragama Islam Universitas Bhayangkara Jakarta Raya yang telah terdaftar. Ada dua jenis keanggotaan: (1) Anggota Aktif - mahasiswa yang mendaftar sebagai anggota KIMURA dan telah mengikuti Training Organisasi KIMURA, (2) Anggota Pasif - mahasiswa yang tidak mendaftar sebagai anggota KIMURA dan belum ikut Training Organisasi KIMURA.',
        
        'founding_year' => '2007',
        'founding_location' => 'Bekasi',
        'current_period' => '2026/2027',
        'document_gbho' => 'GBHO KIMURA Periode 2026/2027',
        'document_adart' => 'AD/ART KIMURA'
    ];
    
    foreach ($settings as $key => $value) {
        $stmt = $pdo->prepare('INSERT INTO organization_settings (organization_id, setting_key, setting_value, created_at, updated_at) VALUES (1, :k, :v, NOW(), NOW()) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()');
        $stmt->execute(['k' => $key, 'v' => $value]);
    }
    echo "   ✓ Organization settings imported\n\n";
    
    // ============================================================
    // PHASE 3: IMPORT ORGANIZATION STRUCTURE
    // ============================================================
    echo "3. Importing organization structure...\n";
    
    // Clear existing positions for this organization
    // Instead of deleting, we'll update existing and insert new ones
    $stmt = $pdo->prepare('DELETE FROM organization_positions WHERE organization_id = 1');
    $stmt->execute();
    
    $positions = [
        // Top level positions (no parent)
        ['position_name' => 'Pembina', 'description' => 'Pembina organisasi KIMURA.', 'sort_order' => 1, 'person_name' => 'Dr. Ir. Budi Santoso, S.T., M.T.', 'period' => '2026/2027', 'status' => 'active', 'parent_id' => null],
        ['position_name' => 'Ketua Umum', 'description' => 'Memimpin arah strategis organisasi. Bertugas mengontrol, mengamati, dan mengatur organisasi. Berfungsi ke dalam dan ke luar organisasi. Memimpin rapat kerja. Berhak mengambil kebijaksanaan demi kelancaran, ketertiban, kemajuan, dan keselamatan organisasi.', 'sort_order' => 2, 'person_name' => 'Wafdanu Zahrawaan', 'period' => '2026/2027', 'status' => 'active', 'parent_id' => null],
        
        // Second level - under Ketua Umum
        ['position_name' => 'Wakil Ketua', 'description' => 'Mewakili Ketua Umum ketika Ketua Umum tidak ada. Bertanggung jawab atas sistem organisasi dan sistem informasi. Mensosialisasikan visi organisasi. Menjadi pusat standarisasi publikasi dan propaganda.', 'sort_order' => 1, 'person_name' => 'Nauvarel Shidqi Zein', 'period' => '2026/2027', 'status' => 'active', 'parent_id' => 2],
        ['position_name' => 'Sekretaris', 'description' => 'Bertanggung jawab atas kelancaran administrasi keorganisasian dan nuansa sekretariat yang kondusif. Menjalankan fungsi bank data segala keperluan secara administratif sehari-hari termasuk surat-menyurat, dokumentasi, dan kearsipan. Notulensi rapat.', 'sort_order' => 2, 'person_name' => 'Andika Rafa Syahputra', 'period' => '2026/2027', 'status' => 'active', 'parent_id' => 2],
        ['position_name' => 'Bendahara', 'description' => 'Bertanggung jawab terhadap lalu lintas dana halal dari dalam dan luar KIMURA. Memberikan laporan keuangan. Bekerjasama dengan Humas dalam memproduksi segala atribut KIMURA.', 'sort_order' => 3, 'person_name' => 'Fina Dwi Damayanti', 'period' => '2026/2027', 'status' => 'active', 'parent_id' => 2],
        ['position_name' => 'Kaderisasi', 'description' => 'Memastikan roda kepemimpinan dan estafet perjuangan LDK tetap berjalan berkelanjutan melalui pencetakan kader-kader baru yang siap memegang peran strategis. Membentuk mental, moral, kepribadian Islami, serta pemahaman ideologi dakwah yang kuat. Memberikan pelatihan kepemimpinan, manajemen organisasi, komunikasi, dan kemampuan dakwah.', 'sort_order' => 4, 'person_name' => null, 'period' => '2026/2027', 'status' => 'active', 'parent_id' => 2],
        ['position_name' => 'Kemuslimahan', 'description' => 'Mengadakan kajian rutin, tahsin Al-Qur\'an, serta pembinaan khusus kepribadian muslimah sesuai standar. Menjaga stabilitas ruhiyah (spiritual) dan meningkatkan pemahaman keislaman. Menjadi sarana komunikasi, berbagi pengalaman, dan evaluasi program kerja keakhwatan.', 'sort_order' => 5, 'person_name' => null, 'period' => '2026/2027', 'status' => 'active', 'parent_id' => 2],
        ['position_name' => 'Syiar', 'description' => 'Mengelola media dakwah, informasi, dan publikasi organisasi. Merancang konsep, strategi, dan materi program kerja syiar yang relevan dengan kondisi serta kebutuhan mahasiswa maupun masyarakat luas. Menjalin kerjasama dan kemitraan. Menyelaraskan gerakan dan isu-isu strategis keislaman antar-LDK. Mendokumentasikan kegiatan organisasi (foto, video, berita).', 'sort_order' => 6, 'person_name' => null, 'period' => '2026/2027', 'status' => 'active', 'parent_id' => 2],
    ];
    
    $positionMap = [];
    
    // First, insert parent positions
    $parentPositions = array_filter($positions, fn($p) => $p['parent_id'] === null);
    foreach ($parentPositions as $pos) {
        $stmt = $pdo->prepare('INSERT INTO organization_positions (organization_id, parent_id, position_name, description, sort_order, person_name, period, status, created_at, updated_at) VALUES (1, NULL, :name, :desc, :sort, :person, :period, :status, NOW(), NOW())');
        $stmt->execute([
            'name' => $pos['position_name'],
            'desc' => $pos['description'],
            'sort' => $pos['sort_order'],
            'person' => $pos['person_name'],
            'period' => $pos['period'],
            'status' => $pos['status']
        ]);
        $positionMap[$pos['position_name']] = (int)$pdo->lastInsertId();
    }
    
    // Then, insert child positions with correct parent references
    $childPositions = array_filter($positions, fn($p) => $p['parent_id'] !== null);
    foreach ($childPositions as $pos) {
        $parentName = $pos['parent_id'] === 2 ? 'Ketua Umum' : ($pos['parent_id'] === 3 ? 'Wakil Ketua' : null);
        $parentId = $parentName ? ($positionMap[$parentName] ?? null) : null;
        
        if (!$parentId) {
            echo "   WARNING: Parent not found for {$pos['position_name']}, skipping\n";
            continue;
        }
        
        $stmt = $pdo->prepare('INSERT INTO organization_positions (organization_id, parent_id, position_name, description, sort_order, person_name, period, status, created_at, updated_at) VALUES (1, :parent_id, :name, :desc, :sort, :person, :period, :status, NOW(), NOW())');
        $stmt->execute([
            'parent_id' => $parentId,
            'name' => $pos['position_name'],
            'desc' => $pos['description'],
            'sort' => $pos['sort_order'],
            'person' => $pos['person_name'],
            'period' => $pos['period'],
            'status' => $pos['status']
        ]);
        $positionMap[$pos['position_name']] = (int)$pdo->lastInsertId();
    }
    
    echo "   ✓ " . count($positions) . " positions imported\n";
    echo "   Position IDs: " . json_encode($positionMap) . "\n\n";
    
    // ============================================================
    // PHASE 4: COMMIT
    // ============================================================
    $pdo->commit();
    
    echo "=== IMPORT COMPLETED SUCCESSFULLY ===\n";
    echo "Organization: Keluarga Islam Mahasiswa Universitas Bhayangkara Jakarta Raya (KIMURA)\n";
    echo "Period: 2026/2027\n";
    echo "Source: GBHO new.docx & New AD-ART.docx\n";
    echo "\nNext steps:\n";
    echo "1. Verify data in admin dashboard\n";
    echo "2. Check frontend pages for updated content\n";
    echo "3. Upload logo and banner images if not already done\n";
    
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
