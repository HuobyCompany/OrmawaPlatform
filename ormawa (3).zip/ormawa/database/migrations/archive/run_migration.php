<?php
/**
 * Run Migration Script
 * Executes the 20260916_create_members_table.sql migration
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/constants.php';

// Load all app files like the main application does
foreach(glob(__DIR__ . '/../../app/helpers/*.php') as $f) require_once $f;
require_once __DIR__ . '/../../app/core/Database.php';

echo "=== Running Migration: 20260916_create_members_table.sql ===\n\n";

try {
    $pdo = Database::connection();
    $sql = file_get_contents(__DIR__ . '/20260916_create_members_table.sql');

    if ($sql === false) {
        throw new Exception("Could not read migration file");
    }

    echo "Executing SQL migration...\n";
    $pdo->exec($sql);

    echo "✅ Migration completed successfully!\n\n";

    // Verify tables were created
    $tables = ['members', 'member_audit', 'registration_member_mapping'];
    echo "Verifying created tables:\n";
    foreach ($tables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '{$table}'");
        $exists = $stmt->fetch();
        echo ($exists ? "✅" : "❌") . " {$table}\n";
    }

    echo "\nMigration verification complete.\n";
    exit(0);

} catch (Exception $e) {
    echo "❌ Migration failed: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
