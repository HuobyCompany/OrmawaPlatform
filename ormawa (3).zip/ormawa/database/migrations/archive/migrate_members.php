<?php
/**
 * Migration Utility: Migrate Registration Submissions to Members
 *
 * This script migrates existing registration_submissions to the new members table
 * while preserving all legacy data and creating proper person/member relationships.
 *
 * Usage: php database/migrations/migrate_members.php [organization_id]
 *
 * If organization_id is not provided, it will migrate all organizations.
 */

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../app/core/Database.php';

// Load all app files like the main application does
foreach(glob(__DIR__ . '/../../app/helpers/*.php') as $f) require_once $f;
foreach(glob(__DIR__ . '/../../app/models/*.php') as $f) require_once $f;
foreach(glob(__DIR__ . '/../../app/services/*.php') as $f) require_once $f;

echo "=== Member Migration Utility ===\n\n";

// Get organization ID from command line or migrate all
$orgId = isset($argv[1]) ? (int)$argv[1] : null;

try {
    $pdo = Database::connection();

    // Get organizations to migrate
    if ($orgId) {
        $orgStmt = $pdo->prepare('SELECT id, name, slug FROM organizations WHERE id = :id');
        $orgStmt->execute(['id' => $orgId]);
        $organizations = $orgStmt->fetchAll();
    } else {
        $orgStmt = $pdo->prepare('SELECT id, name, slug FROM organizations ORDER BY id');
        $orgStmt->execute();
        $organizations = $orgStmt->fetchAll();
    }

    if (empty($organizations)) {
        echo "No organizations found to migrate.\n";
        exit(0);
    }

    $totalResults = [
        'organizations' => count($organizations),
        'total_migrated' => 0,
        'total_skipped' => 0,
        'total_ambiguous' => 0,
        'total_errors' => 0,
        'org_details' => []
    ];

    foreach ($organizations as $org) {
        echo "Migrating organization: {$org['name']} (ID: {$org['id']})\n";
        echo str_repeat('-', 50) . "\n";

        $results = MemberService::migrateRegistrationSubmissions((int)$org['id']);

        $totalResults['total_migrated'] += $results['migrated'];
        $totalResults['total_skipped'] += $results['skipped'];
        $totalResults['total_ambiguous'] += $results['ambiguous'];
        $totalResults['total_errors'] += $results['errors'];

        echo "Migrated: {$results['migrated']}\n";
        echo "Skipped: {$results['skipped']}\n";
        echo "Ambiguous: {$results['ambiguous']}\n";
        echo "Errors: {$results['errors']}\n";

        if (!empty($results['details'])) {
            echo "\nDetails:\n";
            foreach ($results['details'] as $detail) {
                $status = $detail['status'];
                $message = $detail['message'];
                echo "  [{$status}] Submission #{$detail['submission_id']}: {$message}\n";
            }
        }

        $totalResults['org_details'][$org['id']] = $results;
        echo "\n";
    }

    echo str_repeat('=', 50) . "\n";
    echo "Migration Summary:\n";
    echo "Organizations processed: {$totalResults['organizations']}\n";
    echo "Total migrated: {$totalResults['total_migrated']}\n";
    echo "Total skipped: {$totalResults['total_skipped']}\n";
    echo "Total ambiguous: {$totalResults['total_ambiguous']}\n";
    echo "Total errors: {$totalResults['total_errors']}\n";

    if ($totalResults['total_errors'] > 0) {
        echo "\n⚠️  Migration completed with errors. Please review the details above.\n";
        exit(1);
    } else {
        echo "\n✅ Migration completed successfully!\n";
        exit(0);
    }

} catch (Exception $e) {
    echo "❌ Migration failed: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
    exit(1);
}
