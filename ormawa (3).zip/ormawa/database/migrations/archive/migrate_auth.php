<?php
// Migration script for Phase 5 unified authentication
// Run this script to execute the database migrations

require __DIR__ . '/../../config/config.php';
require __DIR__ . '/../../config/constants.php';

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    echo "Starting Phase 5 Authentication Migration...\n\n";

    // Migration 1: Create user_account_members table
    echo "1. Creating user_account_members table...\n";
    $sql1 = file_get_contents(__DIR__ . '/20260917_create_user_account_members_table.sql');
    $pdo->exec($sql1);
    echo "   ✓ user_account_members table created\n\n";

    // Migration 2: Add remember_token column to users table
    echo "2. Adding remember_token column to users table...\n";
    $sql2 = file_get_contents(__DIR__ . '/20260917_add_users_remember_token.sql');
    $pdo->exec($sql2);
    echo "   ✓ remember_token column added\n\n";

    echo "Phase 5 Authentication Migration completed successfully!\n";
    echo "New tables/columns:\n";
    echo "- user_account_members table\n";
    echo "- users.remember_token column\n";

} catch (PDOException $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
