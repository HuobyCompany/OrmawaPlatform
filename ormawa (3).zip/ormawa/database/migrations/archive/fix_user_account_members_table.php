<?php
// Fix user_account_members table structure
require __DIR__ . '/../../config/config.php';
require __DIR__ . '/../../config/constants.php';

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    echo "Fixing user_account_members table structure...\n\n";

    // Drop existing table and recreate with correct structure
    $pdo->exec("DROP TABLE IF EXISTS user_account_members");
    echo "✓ Dropped existing user_account_members table\n";

    // Create table with correct structure
    $sql = "CREATE TABLE user_account_members (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id BIGINT UNSIGNED NOT NULL,
        member_id BIGINT UNSIGNED NULL,
        person_id BIGINT UNSIGNED NULL,
        is_primary BOOLEAN NOT NULL DEFAULT TRUE,
        linked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        linked_by BIGINT UNSIGNED NULL,
        notes TEXT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_uam_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        CONSTRAINT fk_uam_member FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
        CONSTRAINT fk_uam_person FOREIGN KEY (person_id) REFERENCES persons(id) ON DELETE SET NULL,
        CONSTRAINT fk_uam_linked_by FOREIGN KEY (linked_by) REFERENCES users(id) ON DELETE SET NULL,
        UNIQUE KEY uq_user_member (user_id, member_id),
        UNIQUE KEY uq_user_person (user_id, person_id),
        INDEX idx_uam_user (user_id),
        INDEX idx_uam_member (member_id),
        INDEX idx_uam_person (person_id),
        INDEX idx_uam_primary (is_primary)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    $pdo->exec($sql);
    echo "✓ Created user_account_members table with correct structure\n";

    echo "\nTable structure fixed successfully!\n";

} catch (PDOException $e) {
    echo "Fix failed: " . $e->getMessage() . "\n";
    exit(1);
}
