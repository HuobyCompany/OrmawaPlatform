<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/constants.php';
require_once __DIR__ . '/../../app/core/Database.php';
require_once __DIR__ . '/../../app/models/TermModel.php';
require_once __DIR__ . '/../../app/models/PersonModel.php';
require_once __DIR__ . '/../../app/models/StructureGroupModel.php';
require_once __DIR__ . '/../../app/models/StructurePositionModel.php';
require_once __DIR__ . '/../../app/models/PositionAssignmentModel.php';
require_once __DIR__ . '/../../app/services/LegacyStructureMigrationService.php';

$options = getopt('', ['execute', 'dry-run', 'org:']);
$isExecute = isset($options['execute']);
$dryRun = !$isExecute;
$orgId = isset($options['org']) ? (int)$options['org'] : null;

echo "Starting Legacy Structure Data Migration...\n\n";

$report = LegacyStructureMigrationService::runMigration($dryRun, $orgId);
echo LegacyStructureMigrationService::formatReportText($report);

if ($dryRun) {
    echo "\nNOTE: This was a DRY RUN. No changes were committed to the database.\n";
    echo "To execute real migration, run: php database/migrations/run_legacy_migration.php --execute\n";
} else {
    echo "\nSUCCESS: Real migration executed and committed to database!\n";
}
