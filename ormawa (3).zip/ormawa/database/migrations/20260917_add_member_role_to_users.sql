-- Add 'member' role to users table role enum
-- This separates member authentication from editor/admin roles
ALTER TABLE users MODIFY COLUMN role ENUM('super_admin','organization_admin','editor','member') NOT NULL;