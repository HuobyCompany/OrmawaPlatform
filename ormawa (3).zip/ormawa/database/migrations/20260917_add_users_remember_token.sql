-- Migration: 20260917_add_users_remember_token.sql
-- Phase 5: Unified Authentication Foundation
-- Adds remember_token column to users table for remember-me functionality

ALTER TABLE users ADD COLUMN remember_token VARCHAR(64) NULL AFTER last_login;
CREATE INDEX idx_users_remember_token ON users(remember_token);
