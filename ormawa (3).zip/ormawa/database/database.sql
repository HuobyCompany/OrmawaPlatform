-- ORMAWA Platform Canonical Database Schema
-- Version: 2026.09.19 (Phase 7 Final)
-- Generated: 2026-09-19 13:00:38

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- --------------------------------------------------------
-- Table structure for table `activity_logs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `entity` varchar(80) NOT NULL,
  `description` text NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_logs_user` (`user_id`),
  KEY `idx_logs_org_created` (`organization_id`,`created_at`),
  KEY `idx_logs_action_created` (`action`,`created_at`),
  CONSTRAINT `fk_logs_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=287 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `events`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `title` varchar(220) NOT NULL,
  `slug` varchar(180) NOT NULL,
  `description` longtext DEFAULT NULL,
  `event_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `poster` varchar(255) DEFAULT NULL,
  `poster_size` enum('Small','Medium','Large','Custom') NOT NULL DEFAULT 'Medium',
  `status` enum('draft','published','cancelled') NOT NULL DEFAULT 'draft',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_event_slug` (`organization_id`,`slug`),
  KEY `idx_events_org_date` (`organization_id`,`event_date`),
  KEY `idx_events_org_status_date` (`organization_id`,`status`,`event_date`),
  CONSTRAINT `fk_events_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `faculties`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `faculties`;
CREATE TABLE IF NOT EXISTS `faculties` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(180) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_faculty_code` (`code`),
  KEY `idx_faculty_sort` (`sort_order`),
  KEY `idx_faculty_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `gallery_albums`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `gallery_albums`;
CREATE TABLE IF NOT EXISTS `gallery_albums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `title` varchar(220) NOT NULL,
  `slug` varchar(180) NOT NULL,
  `description` longtext DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `category` varchar(120) DEFAULT NULL,
  `source_type` enum('local','google_drive','remote_url') NOT NULL DEFAULT 'local',
  `cover_image` varchar(255) DEFAULT NULL,
  `drive_folder_id` varchar(255) DEFAULT NULL,
  `drive_folder_name` varchar(255) DEFAULT NULL,
  `last_synced_at` datetime DEFAULT NULL,
  `sync_status` enum('idle','syncing','synced','failed') NOT NULL DEFAULT 'idle',
  `sync_error` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_album_slug` (`organization_id`,`slug`),
  KEY `idx_albums_org_date` (`organization_id`,`event_date`),
  KEY `idx_albums_org_category` (`organization_id`,`category`),
  KEY `idx_gallery_albums_drive` (`organization_id`,`source_type`,`drive_folder_id`),
  CONSTRAINT `fk_gallery_albums_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `gallery_items`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `gallery_items`;
CREATE TABLE IF NOT EXISTS `gallery_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` bigint(20) unsigned NOT NULL,
  `title` varchar(220) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `file_path` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `alt_text` varchar(220) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `source_type` enum('local','google_drive','remote_url') NOT NULL DEFAULT 'local',
  `drive_file_id` varchar(255) DEFAULT NULL,
  `drive_url` text DEFAULT NULL,
  `remote_url` varchar(500) DEFAULT NULL,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `sync_status` enum('active','removed','error') NOT NULL DEFAULT 'active',
  `last_synced_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gallery_item_drive_file` (`album_id`,`drive_file_id`),
  KEY `idx_gallery_items_album_order` (`album_id`,`sort_order`),
  KEY `idx_gallery_items_drive` (`album_id`,`source_type`,`sync_status`),
  CONSTRAINT `fk_gallery_items_album` FOREIGN KEY (`album_id`) REFERENCES `gallery_albums` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `home_sections`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `home_sections`;
CREATE TABLE IF NOT EXISTS `home_sections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `section_key` varchar(80) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 1,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_home_section` (`organization_id`,`section_key`),
  KEY `idx_home_sections_org_order` (`organization_id`,`sort_order`),
  CONSTRAINT `fk_sections_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `legacy_structure_mappings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `legacy_structure_mappings`;
CREATE TABLE IF NOT EXISTS `legacy_structure_mappings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `legacy_position_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned DEFAULT NULL,
  `group_id` bigint(20) unsigned DEFAULT NULL,
  `position_id` bigint(20) unsigned DEFAULT NULL,
  `person_id` bigint(20) unsigned DEFAULT NULL,
  `assignment_id` bigint(20) unsigned DEFAULT NULL,
  `status` enum('migrated','skipped','ambiguous') NOT NULL DEFAULT 'migrated',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `legacy_position_id` (`legacy_position_id`),
  KEY `fk_map_org` (`organization_id`),
  KEY `fk_map_term` (`term_id`),
  KEY `fk_map_group` (`group_id`),
  KEY `fk_map_position` (`position_id`),
  KEY `fk_map_person` (`person_id`),
  KEY `fk_map_assignment` (`assignment_id`),
  CONSTRAINT `fk_map_assignment` FOREIGN KEY (`assignment_id`) REFERENCES `position_assignments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_map_group` FOREIGN KEY (`group_id`) REFERENCES `structure_groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_map_legacy` FOREIGN KEY (`legacy_position_id`) REFERENCES `organization_positions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_map_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_map_person` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_map_position` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_map_term` FOREIGN KEY (`term_id`) REFERENCES `organization_terms` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `letters`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `letters`;
CREATE TABLE IF NOT EXISTS `letters` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `type` enum('incoming','outgoing') NOT NULL DEFAULT 'incoming',
  `letter_number` varchar(120) NOT NULL,
  `title` varchar(255) NOT NULL,
  `sender` varchar(180) NOT NULL,
  `recipient` varchar(180) NOT NULL,
  `letter_date` date NOT NULL,
  `received_or_sent_date` date DEFAULT NULL,
  `category` varchar(100) NOT NULL DEFAULT 'Umum',
  `file_path` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `status` enum('active','archived') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_letters_org_type` (`organization_id`,`type`),
  KEY `idx_letters_org_date` (`organization_id`,`letter_date`),
  KEY `idx_letters_category` (`category`),
  CONSTRAINT `fk_letters_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `media`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `uploaded_by` bigint(20) unsigned DEFAULT NULL,
  `category` varchar(80) NOT NULL DEFAULT 'general',
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `mime_type` varchar(100) NOT NULL,
  `file_size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_media_user` (`uploaded_by`),
  KEY `idx_media_org_created` (`organization_id`,`created_at`),
  KEY `idx_media_org_category` (`organization_id`,`category`),
  CONSTRAINT `fk_media_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_media_user` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `member_audit`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `member_audit`;
CREATE TABLE IF NOT EXISTS `member_audit` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` bigint(20) unsigned NOT NULL,
  `old_status` varchar(20) DEFAULT NULL,
  `new_status` varchar(20) NOT NULL,
  `changed_by` bigint(20) unsigned DEFAULT NULL,
  `changed_at` datetime NOT NULL DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_audit_user` (`changed_by`),
  KEY `idx_audit_member` (`member_id`),
  KEY `idx_audit_date` (`changed_at`),
  CONSTRAINT `fk_audit_member` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `members`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `members`;
CREATE TABLE IF NOT EXISTS `members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `person_id` bigint(20) unsigned DEFAULT NULL,
  `member_number` varchar(20) NOT NULL,
  `status` enum('pending','active','rejected','suspended','inactive','alumni') NOT NULL DEFAULT 'pending',
  `joined_at` datetime DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `reviewer_notes` text DEFAULT NULL,
  `current_term_id` bigint(20) unsigned DEFAULT NULL,
  `batch_year` varchar(10) DEFAULT NULL,
  `faculty_name` varchar(180) DEFAULT NULL,
  `prodi_name` varchar(180) DEFAULT NULL,
  `whatsapp` varchar(60) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `member_number` (`member_number`),
  UNIQUE KEY `uq_member_number` (`member_number`),
  KEY `fk_members_term` (`current_term_id`),
  KEY `fk_members_reviewer` (`reviewed_by`),
  KEY `idx_members_org_status` (`organization_id`,`status`),
  KEY `idx_members_person` (`person_id`),
  KEY `idx_members_batch` (`organization_id`,`batch_year`),
  KEY `idx_members_reviewed` (`reviewed_at`),
  CONSTRAINT `fk_members_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_members_person` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_members_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_members_term` FOREIGN KEY (`current_term_id`) REFERENCES `organization_terms` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `organization_positions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `organization_positions`;
CREATE TABLE IF NOT EXISTS `organization_positions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `position_name` varchar(180) NOT NULL,
  `description` longtext DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `photo` varchar(255) DEFAULT NULL,
  `person_name` varchar(160) DEFAULT NULL,
  `period` varchar(80) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_positions_parent` (`parent_id`),
  KEY `idx_positions_org_parent_order` (`organization_id`,`parent_id`,`sort_order`),
  KEY `idx_positions_org_status` (`organization_id`,`status`),
  CONSTRAINT `fk_positions_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_positions_parent` FOREIGN KEY (`parent_id`) REFERENCES `organization_positions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `organization_settings`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `organization_settings`;
CREATE TABLE IF NOT EXISTS `organization_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_org_setting` (`organization_id`,`setting_key`),
  KEY `idx_settings_org` (`organization_id`),
  CONSTRAINT `fk_settings_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=188 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `organization_terms`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `organization_terms`;
CREATE TABLE IF NOT EXISTS `organization_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `name` varchar(180) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_term_org_slug` (`organization_id`,`slug`),
  CONSTRAINT `fk_terms_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `organizations`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `organizations`;
CREATE TABLE IF NOT EXISTS `organizations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(180) NOT NULL,
  `short_name` varchar(80) NOT NULL DEFAULT '',
  `slug` varchar(100) NOT NULL,
  `website_name` varchar(180) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `about` longtext DEFAULT NULL,
  `vision` longtext DEFAULT NULL,
  `mission` longtext DEFAULT NULL,
  `values_text` longtext DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `hero_image` varchar(255) DEFAULT NULL,
  `primary_color` char(7) NOT NULL DEFAULT '#0a84ff',
  `secondary_color` char(7) NOT NULL DEFAULT '#5e5ce6',
  `accent_color` char(7) NOT NULL DEFAULT '#30d158',
  `background_color` char(7) NOT NULL DEFAULT '#f7f8fa',
  `text_color` char(7) NOT NULL DEFAULT '#111827',
  `font_family` varchar(60) NOT NULL DEFAULT 'Inter',
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `whatsapp` varchar(60) DEFAULT NULL,
  `instagram` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `youtube` varchar(255) DEFAULT NULL,
  `tiktok` varchar(255) DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `map_embed_url` text DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_org_status` (`status`),
  KEY `idx_org_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `pages`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `page_key` varchar(80) NOT NULL,
  `title` varchar(180) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `content` longtext DEFAULT NULL,
  `meta_title` varchar(180) DEFAULT NULL,
  `meta_description` text DEFAULT NULL,
  `status` enum('draft','published') NOT NULL DEFAULT 'published',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_page_key` (`organization_id`,`page_key`),
  UNIQUE KEY `uq_page_slug` (`organization_id`,`slug`),
  KEY `idx_pages_org_status` (`organization_id`,`status`),
  CONSTRAINT `fk_pages_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `persons`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `persons`;
CREATE TABLE IF NOT EXISTS `persons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `full_name` varchar(180) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(60) DEFAULT NULL,
  `photo_media_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_persons_photo` (`photo_media_id`),
  KEY `idx_persons_org` (`organization_id`),
  CONSTRAINT `fk_persons_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_persons_photo` FOREIGN KEY (`photo_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `position_assignments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `position_assignments`;
CREATE TABLE IF NOT EXISTS `position_assignments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL,
  `position_id` bigint(20) unsigned NOT NULL,
  `person_id` bigint(20) unsigned DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','vacant') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_public` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Whether this assignment should be visible on public structure page (1=public, 0=private/admin-only)',
  PRIMARY KEY (`id`),
  KEY `fk_assign_term` (`term_id`),
  KEY `idx_assign_org_term` (`organization_id`,`term_id`),
  KEY `idx_assign_position` (`position_id`),
  KEY `idx_assign_person` (`person_id`),
  KEY `idx_assignments_public` (`organization_id`,`term_id`,`is_public`),
  CONSTRAINT `fk_assign_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_assign_person` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_assign_position` FOREIGN KEY (`position_id`) REFERENCES `positions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_assign_term` FOREIGN KEY (`term_id`) REFERENCES `organization_terms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `positions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `positions`;
CREATE TABLE IF NOT EXISTS `positions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `group_id` bigint(20) unsigned NOT NULL,
  `title` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_public` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Whether this position should be visible on public structure page (1=public, 0=private/admin-only)',
  PRIMARY KEY (`id`),
  KEY `fk_struct_positions_group` (`group_id`),
  KEY `idx_positions_org_group` (`organization_id`,`group_id`,`sort_order`),
  KEY `idx_positions_public` (`organization_id`,`group_id`,`is_public`,`sort_order`),
  CONSTRAINT `fk_struct_positions_group` FOREIGN KEY (`group_id`) REFERENCES `structure_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_struct_positions_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `registration_fields`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `registration_fields`;
CREATE TABLE IF NOT EXISTS `registration_fields` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) unsigned NOT NULL,
  `field_type` enum('text','textarea','number','phone','date','email','select','radio','checkbox','file_image','file','social_media','faculty_selector','program_study_selector') NOT NULL DEFAULT 'text',
  `name` varchar(100) NOT NULL,
  `label` varchar(180) NOT NULL,
  `placeholder` varchar(255) DEFAULT NULL,
  `help_text` text DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `options_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`options_json`)),
  `validation_rules` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`validation_rules`)),
  `config_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`config_json`)),
  `file_accept` varchar(255) DEFAULT NULL,
  `file_max_bytes` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reg_fields_form` (`form_id`),
  KEY `idx_reg_fields_sort` (`form_id`,`sort_order`,`is_active`,`deleted_at`),
  KEY `idx_reg_fields_name` (`form_id`,`name`),
  KEY `idx_reg_fields_active` (`is_active`,`deleted_at`),
  CONSTRAINT `fk_reg_fields_form` FOREIGN KEY (`form_id`) REFERENCES `registration_forms` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `registration_forms`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `registration_forms`;
CREATE TABLE IF NOT EXISTS `registration_forms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `title` varchar(180) NOT NULL DEFAULT 'Formulir Pendaftaran',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reg_forms_org` (`organization_id`),
  CONSTRAINT `fk_reg_forms_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `registration_member_mapping`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `registration_member_mapping`;
CREATE TABLE IF NOT EXISTS `registration_member_mapping` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `registration_submission_id` bigint(20) unsigned NOT NULL,
  `member_id` bigint(20) unsigned NOT NULL,
  `mapping_type` enum('direct','ambiguous','manual') NOT NULL DEFAULT 'direct',
  `confidence_score` tinyint(3) unsigned DEFAULT NULL,
  `mapped_at` datetime NOT NULL DEFAULT current_timestamp(),
  `mapped_by` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_submission_mapping` (`registration_submission_id`),
  KEY `fk_map_user` (`mapped_by`),
  KEY `idx_map_member` (`member_id`),
  KEY `idx_map_type` (`mapping_type`),
  CONSTRAINT `fk_map_member` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_map_submission` FOREIGN KEY (`registration_submission_id`) REFERENCES `registration_submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_map_user` FOREIGN KEY (`mapped_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `registration_submissions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `registration_submissions`;
CREATE TABLE IF NOT EXISTS `registration_submissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` bigint(20) unsigned NOT NULL,
  `organization_id` bigint(20) unsigned NOT NULL,
  `full_name` varchar(180) DEFAULT NULL,
  `faculty_name` varchar(180) DEFAULT NULL,
  `prodi_name` varchar(180) DEFAULT NULL,
  `whatsapp` varchar(50) DEFAULT NULL,
  `batch_year` varchar(10) DEFAULT NULL,
  `member_number` varchar(20) DEFAULT NULL,
  `public_reference` varchar(30) DEFAULT NULL,
  `public_token_hash` char(64) DEFAULT NULL,
  `status` enum('pending','approved','rejected','draft') NOT NULL DEFAULT 'pending',
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `reviewer_notes` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reg_sub_public_ref` (`public_reference`),
  UNIQUE KEY `member_number` (`member_number`),
  KEY `fk_reg_sub_form` (`form_id`),
  KEY `idx_reg_sub_org_status` (`organization_id`,`status`),
  KEY `idx_reg_sub_org_created` (`organization_id`,`created_at`),
  CONSTRAINT `fk_reg_sub_form` FOREIGN KEY (`form_id`) REFERENCES `registration_forms` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reg_sub_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `registration_values`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `registration_values`;
CREATE TABLE IF NOT EXISTS `registration_values` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` bigint(20) unsigned NOT NULL,
  `field_id` bigint(20) unsigned DEFAULT NULL,
  `field_name` varchar(100) NOT NULL,
  `field_label` varchar(180) NOT NULL,
  `field_type` varchar(50) NOT NULL,
  `value` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reg_val_submission` (`submission_id`),
  CONSTRAINT `fk_reg_val_submission` FOREIGN KEY (`submission_id`) REFERENCES `registration_submissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `structure_groups`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `structure_groups`;
CREATE TABLE IF NOT EXISTS `structure_groups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned NOT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `banner_media_id` bigint(20) unsigned DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'Whether this group should be visible on public structure page (1=public, 0=private/admin-only)',
  PRIMARY KEY (`id`),
  KEY `fk_groups_parent` (`parent_id`),
  KEY `idx_groups_org_parent` (`organization_id`,`parent_id`,`sort_order`),
  KEY `fk_groups_banner` (`banner_media_id`),
  KEY `idx_groups_public` (`organization_id`,`is_public`,`sort_order`),
  CONSTRAINT `fk_groups_banner` FOREIGN KEY (`banner_media_id`) REFERENCES `media` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_groups_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_groups_parent` FOREIGN KEY (`parent_id`) REFERENCES `structure_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- Table structure for table `study_programs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `study_programs`;
CREATE TABLE IF NOT EXISTS `study_programs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` bigint(20) unsigned NOT NULL,
  `code` varchar(20) NOT NULL,
  `name` varchar(180) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sp_faculty` (`faculty_id`),
  KEY `idx_sp_active` (`is_active`),
  CONSTRAINT `fk_study_programs_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `user_account_members`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `user_account_members`;
CREATE TABLE IF NOT EXISTS `user_account_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `member_id` bigint(20) unsigned DEFAULT NULL,
  `person_id` bigint(20) unsigned DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 1,
  `linked_at` datetime NOT NULL DEFAULT current_timestamp(),
  `linked_by` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_member` (`user_id`,`member_id`),
  UNIQUE KEY `uq_user_person` (`user_id`,`person_id`),
  KEY `fk_uam_linked_by` (`linked_by`),
  KEY `idx_uam_user` (`user_id`),
  KEY `idx_uam_member` (`member_id`),
  KEY `idx_uam_person` (`person_id`),
  KEY `idx_uam_primary` (`is_primary`),
  CONSTRAINT `fk_uam_linked_by` FOREIGN KEY (`linked_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uam_member` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uam_person` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_uam_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for table `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `organization_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(160) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('super_admin','organization_admin','editor','member') NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `last_login` datetime DEFAULT NULL,
  `remember_token` varchar(64) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_org` (`organization_id`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_remember_token` (`remember_token`),
  CONSTRAINT `fk_users_org` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS=1;
COMMIT;
