-- ORMAWA Platform Official Bootstrap Seed Data
-- Generated: 2026-09-19
-- Clean Generic Release

SET FOREIGN_KEY_CHECKS=0;

-- Default Bootstrap Organization --
INSERT INTO `organizations` (`id`, `name`, `short_name`, `slug`, `website_name`, `description`, `primary_color`, `secondary_color`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Organisasi Mahasiswa', 'ORMAWA', 'ormawa', 'ORMAWA', '', '#1b4332', '#2d6a4f', 'active', NOW(), NOW());

-- Default Organization Settings --
INSERT INTO `organization_settings` (`organization_id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES
(1, 'registration_enabled', '1', NOW(), NOW()),
(1, 'organization_name', 'Organisasi Mahasiswa', NOW(), NOW());

-- Default Bootstrap Users --
INSERT INTO `users` (`id`, `organization_id`, `name`, `email`, `password`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Administrator', 'admin@example.com', '$2y$12$YmSsFiMd2NPJGJ2L1e7Wv.o6X0UhxFP3aLjzKwYBfJ16T4YcQhLrm', 'organization_admin', 'active', NOW(), NOW());

-- Default Organization Terms --
INSERT INTO `organization_terms` (`id`, `organization_id`, `name`, `slug`, `start_date`, `end_date`, `created_at`, `updated_at`) VALUES
(1, 1, 'Periode Awal', 'periode-awal', '2026-01-01', '2026-12-31', NOW(), NOW());

-- Default Faculties & Study Programs (Generic) --
INSERT INTO `faculties` (`id`, `code`, `name`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'FK', 'Fakultas', 1, 1, NOW(), NOW());

INSERT INTO `study_programs` (`id`, `faculty_id`, `code`, `name`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 1, 'PS', 'Program Studi', 1, 1, NOW(), NOW());

SET FOREIGN_KEY_CHECKS=1;
